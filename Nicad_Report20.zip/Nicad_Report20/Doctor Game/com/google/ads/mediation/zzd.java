package com.google.ads.mediation;

import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.mediation.MediationInterstitialAdapter;
import com.google.android.gms.ads.mediation.MediationInterstitialListener;

final class zzd extends FullScreenContentCallback {
  final AbstractAdViewAdapter zza;
  
  final MediationInterstitialListener zzb;
  
  public zzd(AbstractAdViewAdapter paramAbstractAdViewAdapter, MediationInterstitialListener paramMediationInterstitialListener) {
    this.zza = paramAbstractAdViewAdapter;
    this.zzb = paramMediationInterstitialListener;
  }
  
  public final void onAdDismissedFullScreenContent() {
    this.zzb.onAdClosed((MediationInterstitialAdapter)this.zza);
  }
  
  public final void onAdShowedFullScreenContent() {
    this.zzb.onAdOpened((MediationInterstitialAdapter)this.zza);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\ads\mediation\zzd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */