package com.google.android.gms.ads.nativead;

import android.view.View;
import com.google.android.gms.ads.MediaContent;
import com.google.android.gms.ads.VideoController;
import java.util.List;

public interface NativeCustomFormatAd {
  public static final String ASSET_NAME_VIDEO = "_videoMediaView";
  
  void destroy();
  
  List<String> getAvailableAssetNames();
  
  String getCustomFormatId();
  
  DisplayOpenMeasurement getDisplayOpenMeasurement();
  
  NativeAd.Image getImage(String paramString);
  
  MediaContent getMediaContent();
  
  CharSequence getText(String paramString);
  
  @Deprecated
  VideoController getVideoController();
  
  @Deprecated
  MediaView getVideoMediaView();
  
  void performClick(String paramString);
  
  void recordImpression();
  
  public static interface DisplayOpenMeasurement {
    void setView(View param1View);
    
    boolean start();
  }
  
  public static interface OnCustomClickListener {
    void onCustomClick(NativeCustomFormatAd param1NativeCustomFormatAd, String param1String);
  }
  
  public static interface OnCustomFormatAdLoadedListener {
    void onCustomFormatAdLoaded(NativeCustomFormatAd param1NativeCustomFormatAd);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\nativead\NativeCustomFormatAd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */