package com.google.android.gms.ads.internal;

import com.google.android.gms.internal.ads.zzcif;
import com.google.android.gms.internal.ads.zzciq;
import com.google.android.gms.internal.ads.zzckn;

public final class zza {
  public final zzcif zza;
  
  public final zzckn zzb;
  
  public zza(zzckn paramzzckn, zzcif paramzzcif, byte[] paramArrayOfbyte) {
    this.zzb = paramzzckn;
    this.zza = paramzzcif;
  }
  
  public static zza zza() {
    return new zza(new zzckn(), (zzcif)new zzciq(), null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\zza.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */