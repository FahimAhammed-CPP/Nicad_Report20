package com.google.android.gms.ads.internal.client;

import android.os.Bundle;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.internal.ads.zzbdm;
import com.google.android.gms.internal.ads.zzbjx;
import com.google.android.gms.internal.ads.zzbzl;
import com.google.android.gms.internal.ads.zzbzo;
import com.google.android.gms.internal.ads.zzcby;
import com.google.android.gms.internal.ads.zzcgi;
import com.google.android.gms.internal.ads.zzcgp;

public final class zzeq extends zzbr {
  private zzbf zza;
  
  public final void zzA() {}
  
  public final void zzB() {}
  
  public final void zzC(zzbc paramzzbc) {}
  
  public final void zzD(zzbf paramzzbf) {
    this.zza = paramzzbf;
  }
  
  public final void zzE(zzbw paramzzbw) {}
  
  public final void zzF(zzq paramzzq) {}
  
  public final void zzG(zzbz paramzzbz) {}
  
  public final void zzH(zzbdm paramzzbdm) {}
  
  public final void zzI(zzw paramzzw) {}
  
  public final void zzJ(zzcg paramzzcg) {}
  
  public final void zzK(zzdo paramzzdo) {}
  
  public final void zzL(boolean paramBoolean) {}
  
  public final void zzM(zzbzl paramzzbzl) {}
  
  public final void zzN(boolean paramBoolean) {}
  
  public final void zzO(zzbjx paramzzbjx) {}
  
  public final void zzP(zzde paramzzde) {}
  
  public final void zzQ(zzbzo paramzzbzo, String paramString) {}
  
  public final void zzR(String paramString) {}
  
  public final void zzS(zzcby paramzzcby) {}
  
  public final void zzT(String paramString) {}
  
  public final void zzU(zzff paramzzff) {}
  
  public final void zzW(IObjectWrapper paramIObjectWrapper) {}
  
  public final void zzX() {}
  
  public final boolean zzY() {
    return false;
  }
  
  public final boolean zzZ() {
    return false;
  }
  
  public final boolean zzaa(zzl paramzzl) {
    zzcgp.zzg("This app is using a lightweight version of the Google Mobile Ads SDK that requires the latest Google Play services to be installed, but Google Play services is either missing or out of date.");
    zzcgi.zza.post(new zzep(this));
    return false;
  }
  
  public final void zzab(zzcd paramzzcd) {}
  
  public final Bundle zzd() {
    return new Bundle();
  }
  
  public final zzq zzg() {
    return null;
  }
  
  public final zzbf zzi() {
    return null;
  }
  
  public final zzbz zzj() {
    return null;
  }
  
  public final zzdh zzk() {
    return null;
  }
  
  public final zzdk zzl() {
    return null;
  }
  
  public final IObjectWrapper zzn() {
    return null;
  }
  
  public final String zzr() {
    return null;
  }
  
  public final String zzs() {
    return null;
  }
  
  public final String zzt() {
    return null;
  }
  
  public final void zzx() {}
  
  public final void zzy(zzl paramzzl, zzbi paramzzbi) {}
  
  public final void zzz() {}
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzeq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */