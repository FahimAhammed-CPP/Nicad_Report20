package com.google.android.gms.ads.internal.client;

import android.content.Context;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.util.AttributeSet;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.R;

public final class zzy {
  private final AdSize[] zza;
  
  private final String zzb;
  
  public zzy(Context paramContext, AttributeSet paramAttributeSet) {
    TypedArray typedArray = paramContext.getResources().obtainAttributes(paramAttributeSet, R.styleable.AdsAttrs);
    String str1 = typedArray.getString(R.styleable.AdsAttrs_adSize);
    String str2 = typedArray.getString(R.styleable.AdsAttrs_adSizes);
    int i = TextUtils.isEmpty(str1) ^ true;
    int j = TextUtils.isEmpty(str2) ^ true;
    if (i != 0 && j == 0) {
      this.zza = zzc(str1);
    } else if (i == 0 && j != 0) {
      this.zza = zzc(str2);
    } else {
      if (i != 0) {
        typedArray.recycle();
        throw new IllegalArgumentException("Either XML attribute \"adSize\" or XML attribute \"supportedAdSizes\" should be specified, but not both.");
      } 
      typedArray.recycle();
      throw new IllegalArgumentException("Required XML attribute \"adSize\" was missing.");
    } 
    this.zzb = typedArray.getString(R.styleable.AdsAttrs_adUnitId);
    typedArray.recycle();
    if (!TextUtils.isEmpty(this.zzb))
      return; 
    throw new IllegalArgumentException("Required XML attribute \"adUnitId\" was missing.");
  }
  
  private static AdSize[] zzc(String paramString) {
    String[] arrayOfString = paramString.split("\\s*,\\s*");
    int j = arrayOfString.length;
    AdSize[] arrayOfAdSize = new AdSize[j];
    for (int i = 0;; i++) {
      if (i < arrayOfString.length) {
        String str = arrayOfString[i].trim();
        if (str.matches("^(\\d+|FULL_WIDTH)\\s*[xX]\\s*(\\d+|AUTO_HEIGHT)$")) {
          String[] arrayOfString1 = str.split("[xX]");
          arrayOfString1[0] = arrayOfString1[0].trim();
          arrayOfString1[1] = arrayOfString1[1].trim();
          try {
            int k;
            int m;
            if ("FULL_WIDTH".equals(arrayOfString1[0])) {
              k = -1;
            } else {
              k = Integer.parseInt(arrayOfString1[0]);
            } 
            if ("AUTO_HEIGHT".equals(arrayOfString1[1])) {
              m = -2;
            } else {
              m = Integer.parseInt(arrayOfString1[1]);
            } 
            arrayOfAdSize[i] = new AdSize(k, m);
            i++;
          } catch (NumberFormatException numberFormatException) {
            throw new IllegalArgumentException("Could not parse XML attribute \"adSize\": ".concat(String.valueOf(str)));
          } 
          continue;
        } 
        if ("BANNER".equals(str)) {
          arrayOfAdSize[i] = AdSize.BANNER;
        } else if ("LARGE_BANNER".equals(str)) {
          arrayOfAdSize[i] = AdSize.LARGE_BANNER;
        } else if ("FULL_BANNER".equals(str)) {
          arrayOfAdSize[i] = AdSize.FULL_BANNER;
        } else if ("LEADERBOARD".equals(str)) {
          arrayOfAdSize[i] = AdSize.LEADERBOARD;
        } else if ("MEDIUM_RECTANGLE".equals(str)) {
          arrayOfAdSize[i] = AdSize.MEDIUM_RECTANGLE;
        } else if ("SMART_BANNER".equals(str)) {
          arrayOfAdSize[i] = AdSize.SMART_BANNER;
        } else if ("WIDE_SKYSCRAPER".equals(str)) {
          arrayOfAdSize[i] = AdSize.WIDE_SKYSCRAPER;
        } else if ("FLUID".equals(str)) {
          arrayOfAdSize[i] = AdSize.FLUID;
        } else if ("ICON".equals(str)) {
          arrayOfAdSize[i] = AdSize.zza;
        } else {
          throw new IllegalArgumentException("Could not parse XML attribute \"adSize\": ".concat(String.valueOf(str)));
        } 
      } else {
        if (j != 0)
          return arrayOfAdSize; 
        IllegalArgumentException illegalArgumentException = new IllegalArgumentException("Could not parse XML attribute \"adSize\": ".concat(String.valueOf(numberFormatException)));
        throw illegalArgumentException;
      } 
    } 
  }
  
  public final String zza() {
    return this.zzb;
  }
  
  public final AdSize[] zzb(boolean paramBoolean) {
    if (paramBoolean || this.zza.length == 1)
      return this.zza; 
    throw new IllegalArgumentException("The adSizes XML attribute is only allowed on PublisherAdViews.");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */