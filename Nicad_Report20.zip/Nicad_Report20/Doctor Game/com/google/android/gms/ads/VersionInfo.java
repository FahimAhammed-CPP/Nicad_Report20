package com.google.android.gms.ads;

import java.util.Locale;

public class VersionInfo {
  protected int zza;
  
  protected int zzb;
  
  protected int zzc;
  
  public VersionInfo(int paramInt1, int paramInt2, int paramInt3) {
    this.zza = paramInt1;
    this.zzb = paramInt2;
    this.zzc = paramInt3;
  }
  
  public int getMajorVersion() {
    return this.zza;
  }
  
  public int getMicroVersion() {
    return this.zzc;
  }
  
  public int getMinorVersion() {
    return this.zzb;
  }
  
  public String toString() {
    return String.format(Locale.US, "%d.%d.%d", new Object[] { Integer.valueOf(this.zza), Integer.valueOf(this.zzb), Integer.valueOf(this.zzc) });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\VersionInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */