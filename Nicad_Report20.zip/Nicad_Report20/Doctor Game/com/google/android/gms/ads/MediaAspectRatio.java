package com.google.android.gms.ads;

public @interface MediaAspectRatio {
  public static final int ANY = 1;
  
  public static final int LANDSCAPE = 2;
  
  public static final int PORTRAIT = 3;
  
  public static final int SQUARE = 4;
  
  public static final int UNKNOWN = 0;
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\MediaAspectRatio.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */