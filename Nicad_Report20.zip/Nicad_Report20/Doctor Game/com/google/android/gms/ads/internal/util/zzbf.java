package com.google.android.gms.ads.internal.util;

import java.util.ArrayList;
import java.util.List;

public final class zzbf {
  private final String[] zza;
  
  private final double[] zzb;
  
  private final double[] zzc;
  
  private final int[] zzd;
  
  private int zze;
  
  private static final double[] zzc(List paramList) {
    int j = paramList.size();
    double[] arrayOfDouble = new double[j];
    for (int i = 0; i < j; i++)
      arrayOfDouble[i] = ((Double)paramList.get(i)).doubleValue(); 
    return arrayOfDouble;
  }
  
  public final List zza() {
    ArrayList<zzbc> arrayList = new ArrayList(this.zza.length);
    int i = 0;
    while (true) {
      String[] arrayOfString = this.zza;
      if (i < arrayOfString.length) {
        String str = arrayOfString[i];
        double d1 = this.zzc[i];
        double d2 = this.zzb[i];
        int j = this.zzd[i];
        double d3 = j;
        double d4 = this.zze;
        Double.isNaN(d3);
        Double.isNaN(d4);
        arrayList.add(new zzbc(str, d1, d2, d3 / d4, j));
        i++;
        continue;
      } 
      return arrayList;
    } 
  }
  
  public final void zzb(double paramDouble) {
    this.zze++;
    int i = 0;
    while (true) {
      double[] arrayOfDouble = this.zzc;
      if (i < arrayOfDouble.length) {
        double d = arrayOfDouble[i];
        if (d <= paramDouble && paramDouble < this.zzb[i]) {
          int[] arrayOfInt = this.zzd;
          arrayOfInt[i] = arrayOfInt[i] + 1;
        } 
        if (paramDouble < d)
          return; 
        i++;
        continue;
      } 
      break;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzbf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */