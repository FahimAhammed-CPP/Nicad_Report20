package com.google.android.gms.ads;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.gms.ads.admanager.AppEventListener;
import com.google.android.gms.ads.internal.client.zza;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.client.zzdu;
import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.internal.ads.zzbiu;
import com.google.android.gms.internal.ads.zzbjc;
import com.google.android.gms.internal.ads.zzbkq;
import com.google.android.gms.internal.ads.zzcge;
import com.google.android.gms.internal.ads.zzcgp;
import org.checkerframework.checker.initialization.qual.NotOnlyInitialized;

public abstract class BaseAdView extends ViewGroup {
  @NotOnlyInitialized
  protected final zzdu zza;
  
  protected BaseAdView(Context paramContext, int paramInt) {
    super(paramContext);
    this.zza = new zzdu(this, paramInt);
  }
  
  protected BaseAdView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet);
    this.zza = new zzdu(this, paramAttributeSet, false, paramInt);
  }
  
  protected BaseAdView(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1);
    this.zza = new zzdu(this, paramAttributeSet, false, paramInt2);
  }
  
  protected BaseAdView(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2, boolean paramBoolean) {
    super(paramContext, paramAttributeSet, paramInt1);
    this.zza = new zzdu(this, paramAttributeSet, paramBoolean, paramInt2);
  }
  
  protected BaseAdView(Context paramContext, AttributeSet paramAttributeSet, boolean paramBoolean) {
    super(paramContext, paramAttributeSet);
    this.zza = new zzdu(this, paramAttributeSet, paramBoolean);
  }
  
  public void destroy() {
    zzbjc.zzc(getContext());
    if (((Boolean)zzbkq.zze.zze()).booleanValue()) {
      zzbiu zzbiu = zzbjc.zziJ;
      if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue()) {
        zzcge.zzb.execute(new zze(this));
        return;
      } 
    } 
    this.zza.zzk();
  }
  
  public AdListener getAdListener() {
    return this.zza.zza();
  }
  
  public AdSize getAdSize() {
    return this.zza.zzb();
  }
  
  public String getAdUnitId() {
    return this.zza.zzj();
  }
  
  public OnPaidEventListener getOnPaidEventListener() {
    return this.zza.zzc();
  }
  
  public ResponseInfo getResponseInfo() {
    return this.zza.zzd();
  }
  
  public boolean isLoading() {
    return this.zza.zzA();
  }
  
  public void loadAd(AdRequest paramAdRequest) {
    Preconditions.checkMainThread("#008 Must be called on the main UI thread.");
    zzbjc.zzc(getContext());
    if (((Boolean)zzbkq.zzf.zze()).booleanValue()) {
      zzbiu zzbiu = zzbjc.zziM;
      if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue()) {
        zzcge.zzb.execute(new zzc(this, paramAdRequest));
        return;
      } 
    } 
    this.zza.zzm(paramAdRequest.zza());
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    View view = getChildAt(0);
    if (view != null && view.getVisibility() != 8) {
      int i = view.getMeasuredWidth();
      int j = view.getMeasuredHeight();
      paramInt1 = (paramInt3 - paramInt1 - i) / 2;
      paramInt2 = (paramInt4 - paramInt2 - j) / 2;
      view.layout(paramInt1, paramInt2, i + paramInt1, j + paramInt2);
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    int i = 0;
    View view = getChildAt(0);
    if (view != null && view.getVisibility() != 8) {
      measureChild(view, paramInt1, paramInt2);
      i = view.getMeasuredWidth();
      j = view.getMeasuredHeight();
    } else {
      try {
        AdSize adSize = getAdSize();
      } catch (NullPointerException nullPointerException) {
        zzcgp.zzh("Unable to retrieve ad size.", nullPointerException);
        nullPointerException = null;
      } 
      if (nullPointerException != null) {
        Context context = getContext();
        i = nullPointerException.getWidthInPixels(context);
        j = nullPointerException.getHeightInPixels(context);
      } else {
        j = 0;
      } 
    } 
    i = Math.max(i, getSuggestedMinimumWidth());
    int j = Math.max(j, getSuggestedMinimumHeight());
    setMeasuredDimension(View.resolveSize(i, paramInt1), View.resolveSize(j, paramInt2));
  }
  
  public void pause() {
    zzbjc.zzc(getContext());
    if (((Boolean)zzbkq.zzg.zze()).booleanValue()) {
      zzbiu zzbiu = zzbjc.zziK;
      if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue()) {
        zzcge.zzb.execute(new zzd(this));
        return;
      } 
    } 
    this.zza.zzn();
  }
  
  public void resume() {
    zzbjc.zzc(getContext());
    if (((Boolean)zzbkq.zzh.zze()).booleanValue()) {
      zzbiu zzbiu = zzbjc.zziI;
      if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue()) {
        zzcge.zzb.execute(new zzf(this));
        return;
      } 
    } 
    this.zza.zzp();
  }
  
  public void setAdListener(AdListener paramAdListener) {
    this.zza.zzr(paramAdListener);
    if (paramAdListener == null) {
      this.zza.zzq(null);
      return;
    } 
    if (paramAdListener instanceof zza)
      this.zza.zzq((zza)paramAdListener); 
    if (paramAdListener instanceof AppEventListener)
      this.zza.zzv((AppEventListener)paramAdListener); 
  }
  
  public void setAdSize(AdSize paramAdSize) {
    this.zza.zzs(new AdSize[] { paramAdSize });
  }
  
  public void setAdUnitId(String paramString) {
    this.zza.zzu(paramString);
  }
  
  public void setOnPaidEventListener(OnPaidEventListener paramOnPaidEventListener) {
    this.zza.zzx(paramOnPaidEventListener);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\BaseAdView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */