package com.google.android.gms.ads.interstitial;

import android.app.Activity;
import android.content.Context;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.OnPaidEventListener;
import com.google.android.gms.ads.ResponseInfo;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.internal.ads.zzbiu;
import com.google.android.gms.internal.ads.zzbjc;
import com.google.android.gms.internal.ads.zzbkq;
import com.google.android.gms.internal.ads.zzbsm;
import com.google.android.gms.internal.ads.zzcge;

public abstract class InterstitialAd {
  public static void load(Context paramContext, String paramString, AdRequest paramAdRequest, InterstitialAdLoadCallback paramInterstitialAdLoadCallback) {
    Preconditions.checkNotNull(paramContext, "Context cannot be null.");
    Preconditions.checkNotNull(paramString, "AdUnitId cannot be null.");
    Preconditions.checkNotNull(paramAdRequest, "AdRequest cannot be null.");
    Preconditions.checkNotNull(paramInterstitialAdLoadCallback, "LoadCallback cannot be null.");
    Preconditions.checkMainThread("#008 Must be called on the main UI thread.");
    zzbjc.zzc(paramContext);
    if (((Boolean)zzbkq.zzi.zze()).booleanValue()) {
      zzbiu zzbiu = zzbjc.zziM;
      if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue()) {
        zzcge.zzb.execute(new zza(paramContext, paramString, paramAdRequest, paramInterstitialAdLoadCallback));
        return;
      } 
    } 
    (new zzbsm(paramContext, paramString)).zza(paramAdRequest.zza(), paramInterstitialAdLoadCallback);
  }
  
  public abstract String getAdUnitId();
  
  public abstract FullScreenContentCallback getFullScreenContentCallback();
  
  public abstract OnPaidEventListener getOnPaidEventListener();
  
  public abstract ResponseInfo getResponseInfo();
  
  public abstract void setFullScreenContentCallback(FullScreenContentCallback paramFullScreenContentCallback);
  
  public abstract void setImmersiveMode(boolean paramBoolean);
  
  public abstract void setOnPaidEventListener(OnPaidEventListener paramOnPaidEventListener);
  
  public abstract void show(Activity paramActivity);
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interstitial\InterstitialAd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */