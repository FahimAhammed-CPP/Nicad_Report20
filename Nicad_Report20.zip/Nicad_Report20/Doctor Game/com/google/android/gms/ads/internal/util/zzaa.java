package com.google.android.gms.ads.internal.util;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.media.AudioManager;
import android.telephony.TelephonyManager;
import android.webkit.CookieManager;
import android.webkit.WebResourceResponse;
import com.google.android.gms.ads.internal.zzt;
import com.google.android.gms.internal.ads.zzbep;
import com.google.android.gms.internal.ads.zzcmp;
import com.google.android.gms.internal.ads.zzcmw;
import com.google.android.gms.internal.ads.zzcnr;
import java.io.InputStream;
import java.util.Map;

public class zzaa {
  private zzaa() {}
  
  public static zzaa zzm(int paramInt) {
    return (paramInt >= 30) ? new zzy() : ((paramInt >= 28) ? new zzx() : ((paramInt >= 26) ? new zzv() : ((paramInt >= 24) ? new zzu() : ((paramInt >= 21) ? new zzt() : new zzaa()))));
  }
  
  public int zza() {
    return 1;
  }
  
  public CookieManager zzb(Context paramContext) {
    zzt.zzp();
    if (zzs.zzB())
      return null; 
    try {
      return CookieManager.getInstance();
    } finally {
      paramContext = null;
      zze.zzh("Failed to obtain CookieManager.", (Throwable)paramContext);
      zzt.zzo().zzt((Throwable)paramContext, "ApiLevelUtil.getCookieManager");
    } 
  }
  
  public WebResourceResponse zzc(String paramString1, String paramString2, int paramInt, String paramString3, Map paramMap, InputStream paramInputStream) {
    return new WebResourceResponse(paramString1, paramString2, paramInputStream);
  }
  
  public zzcmw zzd(zzcmp paramzzcmp, zzbep paramzzbep, boolean paramBoolean) {
    return (zzcmw)new zzcnr(paramzzcmp, paramzzbep, paramBoolean);
  }
  
  public boolean zze(Activity paramActivity, Configuration paramConfiguration) {
    return false;
  }
  
  public void zzg(Context paramContext) {}
  
  public int zzh(Context paramContext, TelephonyManager paramTelephonyManager) {
    return 1001;
  }
  
  public int zzi(AudioManager paramAudioManager) {
    return 0;
  }
  
  public void zzj(Activity paramActivity) {}
  
  public int zzl(Context paramContext) {
    return ((TelephonyManager)paramContext.getSystemService("phone")).getNetworkType();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzaa.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */