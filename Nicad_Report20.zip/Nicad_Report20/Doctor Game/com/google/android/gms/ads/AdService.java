package com.google.android.gms.ads;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.os.RemoteException;
import com.google.android.gms.ads.internal.client.zzaw;
import com.google.android.gms.internal.ads.zzbvh;
import com.google.android.gms.internal.ads.zzbvk;
import com.google.android.gms.internal.ads.zzcgp;

public class AdService extends IntentService {
  public AdService() {
    super("AdService");
  }
  
  protected final void onHandleIntent(Intent paramIntent) {
    try {
      zzaw.zza().zzl((Context)this, (zzbvk)new zzbvh()).zze(paramIntent);
      return;
    } catch (RemoteException remoteException) {
      zzcgp.zzg("RemoteException calling handleNotificationIntent: ".concat(remoteException.toString()));
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\AdService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */