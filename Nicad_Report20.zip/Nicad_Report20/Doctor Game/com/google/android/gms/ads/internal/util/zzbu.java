package com.google.android.gms.ads.internal.util;

import android.os.Bundle;
import android.os.Parcelable;
import android.util.JsonReader;
import android.util.JsonToken;
import android.util.JsonWriter;
import com.google.android.gms.internal.ads.zzfdp;
import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class zzbu {
  public static final zzbt zza = new zzbs();
  
  public static Bundle zza(JSONObject paramJSONObject) {
    if (paramJSONObject == null)
      return null; 
    Iterator<String> iterator = paramJSONObject.keys();
    Bundle bundle = new Bundle();
    while (iterator.hasNext()) {
      String str = iterator.next();
      Object object = paramJSONObject.opt(str);
      if (object != null) {
        if (object instanceof Boolean) {
          bundle.putBoolean(str, ((Boolean)object).booleanValue());
          continue;
        } 
        if (object instanceof Double) {
          bundle.putDouble(str, ((Double)object).doubleValue());
          continue;
        } 
        if (object instanceof Integer) {
          bundle.putInt(str, ((Integer)object).intValue());
          continue;
        } 
        if (object instanceof Long) {
          bundle.putLong(str, ((Long)object).longValue());
          continue;
        } 
        if (object instanceof String) {
          bundle.putString(str, (String)object);
          continue;
        } 
        if (object instanceof JSONArray) {
          JSONArray jSONArray = (JSONArray)object;
          if (jSONArray.length() != 0) {
            int j = jSONArray.length();
            boolean bool2 = false;
            boolean bool3 = false;
            boolean bool4 = false;
            boolean bool1 = false;
            object = null;
            int i;
            for (i = 0; object == null && i < j; i++) {
              if (!jSONArray.isNull(i)) {
                object = jSONArray.opt(i);
              } else {
                object = null;
              } 
            } 
            if (object == null) {
              zze.zzj("Expected JSONArray with at least 1 non-null element for key:".concat(String.valueOf(str)));
              continue;
            } 
            if (object instanceof JSONObject) {
              Bundle[] arrayOfBundle = new Bundle[j];
              for (i = bool1; i < j; i++) {
                if (!jSONArray.isNull(i)) {
                  object = zza(jSONArray.optJSONObject(i));
                } else {
                  object = null;
                } 
                arrayOfBundle[i] = (Bundle)object;
              } 
              bundle.putParcelableArray(str, (Parcelable[])arrayOfBundle);
              continue;
            } 
            if (object instanceof Number) {
              object = new double[jSONArray.length()];
              for (i = bool2; i < j; i++)
                object[i] = jSONArray.optDouble(i); 
              bundle.putDoubleArray(str, (double[])object);
              continue;
            } 
            if (object instanceof CharSequence) {
              String[] arrayOfString = new String[j];
              for (i = bool3; i < j; i++) {
                if (!jSONArray.isNull(i)) {
                  object = jSONArray.optString(i);
                } else {
                  object = null;
                } 
                arrayOfString[i] = (String)object;
              } 
              bundle.putStringArray(str, arrayOfString);
              continue;
            } 
            if (object instanceof Boolean) {
              object = new boolean[j];
              for (i = bool4; i < j; i++)
                object[i] = jSONArray.optBoolean(i); 
              bundle.putBooleanArray(str, (boolean[])object);
              continue;
            } 
            zze.zzj(String.format("JSONArray with unsupported type %s for key:%s", new Object[] { object.getClass().getCanonicalName(), str }));
          } 
          continue;
        } 
        if (object instanceof JSONObject) {
          bundle.putBundle(str, zza((JSONObject)object));
          continue;
        } 
        zze.zzj("Unsupported type for key:".concat(String.valueOf(str)));
      } 
    } 
    return bundle;
  }
  
  public static String zzb(String paramString, JSONObject paramJSONObject, String... paramVarArgs) {
    JSONObject jSONObject = zzm(paramJSONObject, paramVarArgs);
    return (jSONObject == null) ? "" : jSONObject.optString(paramVarArgs[0], "");
  }
  
  public static List zzc(JSONArray paramJSONArray, List<String> paramList) throws JSONException {
    List<String> list = paramList;
    if (paramList == null)
      list = new ArrayList(); 
    if (paramJSONArray != null)
      for (int i = 0; i < paramJSONArray.length(); i++)
        list.add(paramJSONArray.getString(i));  
    return list;
  }
  
  public static List zzd(JsonReader paramJsonReader) throws IllegalStateException, IOException {
    ArrayList<String> arrayList = new ArrayList();
    paramJsonReader.beginArray();
    while (paramJsonReader.hasNext())
      arrayList.add(paramJsonReader.nextString()); 
    paramJsonReader.endArray();
    return arrayList;
  }
  
  public static JSONArray zze(JsonReader paramJsonReader) throws IllegalStateException, IOException, JSONException {
    JSONArray jSONArray = new JSONArray();
    paramJsonReader.beginArray();
    while (paramJsonReader.hasNext()) {
      JsonToken jsonToken = paramJsonReader.peek();
      if (JsonToken.BEGIN_ARRAY.equals(jsonToken)) {
        jSONArray.put(zze(paramJsonReader));
        continue;
      } 
      if (JsonToken.BEGIN_OBJECT.equals(jsonToken)) {
        jSONArray.put(zzh(paramJsonReader));
        continue;
      } 
      if (JsonToken.BOOLEAN.equals(jsonToken)) {
        jSONArray.put(paramJsonReader.nextBoolean());
        continue;
      } 
      if (JsonToken.NUMBER.equals(jsonToken)) {
        jSONArray.put(paramJsonReader.nextDouble());
        continue;
      } 
      if (JsonToken.STRING.equals(jsonToken)) {
        jSONArray.put(paramJsonReader.nextString());
        continue;
      } 
      throw new IllegalStateException("unexpected json token: ".concat(String.valueOf(String.valueOf(jsonToken))));
    } 
    paramJsonReader.endArray();
    return jSONArray;
  }
  
  public static JSONObject zzf(JSONObject paramJSONObject, String paramString) throws JSONException {
    try {
      return paramJSONObject.getJSONObject(paramString);
    } catch (JSONException jSONException) {
      JSONObject jSONObject = new JSONObject();
      paramJSONObject.put(paramString, jSONObject);
      return jSONObject;
    } 
  }
  
  public static JSONObject zzg(JSONObject paramJSONObject, String... paramVarArgs) {
    paramJSONObject = zzm(paramJSONObject, paramVarArgs);
    return (paramJSONObject == null) ? null : paramJSONObject.optJSONObject(paramVarArgs[1]);
  }
  
  public static JSONObject zzh(JsonReader paramJsonReader) throws IllegalStateException, IOException, JSONException {
    JSONObject jSONObject = new JSONObject();
    paramJsonReader.beginObject();
    while (paramJsonReader.hasNext()) {
      String str = paramJsonReader.nextName();
      JsonToken jsonToken = paramJsonReader.peek();
      if (JsonToken.BEGIN_ARRAY.equals(jsonToken)) {
        jSONObject.put(str, zze(paramJsonReader));
        continue;
      } 
      if (JsonToken.BEGIN_OBJECT.equals(jsonToken)) {
        jSONObject.put(str, zzh(paramJsonReader));
        continue;
      } 
      if (JsonToken.BOOLEAN.equals(jsonToken)) {
        jSONObject.put(str, paramJsonReader.nextBoolean());
        continue;
      } 
      if (JsonToken.NUMBER.equals(jsonToken)) {
        jSONObject.put(str, paramJsonReader.nextDouble());
        continue;
      } 
      if (JsonToken.STRING.equals(jsonToken)) {
        jSONObject.put(str, paramJsonReader.nextString());
        continue;
      } 
      throw new IllegalStateException("unexpected json token: ".concat(String.valueOf(String.valueOf(jsonToken))));
    } 
    paramJsonReader.endObject();
    return jSONObject;
  }
  
  public static void zzi(JsonWriter paramJsonWriter, JSONArray paramJSONArray) throws IOException {
    try {
      paramJsonWriter.beginArray();
      for (int i = 0;; i++) {
        String str;
        if (i < paramJSONArray.length()) {
          Object object = paramJSONArray.get(i);
          if (object instanceof String) {
            paramJsonWriter.value((String)object);
          } else if (object instanceof Number) {
            paramJsonWriter.value((Number)object);
          } else if (object instanceof Boolean) {
            paramJsonWriter.value(((Boolean)object).booleanValue());
          } else if (object instanceof JSONObject) {
            zzj(paramJsonWriter, (JSONObject)object);
          } else if (object instanceof JSONArray) {
            zzi(paramJsonWriter, (JSONArray)object);
          } else {
            str = String.valueOf(object);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("unable to write field: ");
            stringBuilder.append(str);
            throw new JSONException(stringBuilder.toString());
          } 
        } else {
          str.endArray();
          return;
        } 
      } 
    } catch (JSONException jSONException) {
      IOException iOException = new IOException((Throwable)jSONException);
      throw iOException;
    } 
  }
  
  public static void zzj(JsonWriter paramJsonWriter, JSONObject paramJSONObject) throws IOException {
    try {
      String str;
      paramJsonWriter.beginObject();
      Iterator<String> iterator = paramJSONObject.keys();
      while (iterator.hasNext()) {
        String str1 = iterator.next();
        Object object = paramJSONObject.get(str1);
        if (object instanceof String) {
          paramJsonWriter.name(str1).value((String)object);
          continue;
        } 
        if (object instanceof Number) {
          paramJsonWriter.name(str1).value((Number)object);
          continue;
        } 
        if (object instanceof Boolean) {
          paramJsonWriter.name(str1).value(((Boolean)object).booleanValue());
          continue;
        } 
        if (object instanceof JSONObject) {
          zzj(paramJsonWriter.name(str1), (JSONObject)object);
          continue;
        } 
        if (object instanceof JSONArray) {
          zzi(paramJsonWriter.name(str1), (JSONArray)object);
          continue;
        } 
        str = String.valueOf(object);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("unable to write field: ");
        stringBuilder.append(str);
        throw new JSONException(stringBuilder.toString());
      } 
      str.endObject();
      return;
    } catch (JSONException jSONException) {
      IOException iOException = new IOException((Throwable)jSONException);
      throw iOException;
    } 
  }
  
  public static boolean zzk(boolean paramBoolean, JSONObject paramJSONObject, String... paramVarArgs) {
    paramJSONObject = zzm(paramJSONObject, paramVarArgs);
    return (paramJSONObject == null) ? false : paramJSONObject.optBoolean(paramVarArgs[paramVarArgs.length - 1], false);
  }
  
  public static String zzl(zzfdp paramzzfdp) {
    if (paramzzfdp == null)
      return null; 
    StringWriter stringWriter = new StringWriter();
    try {
      JsonWriter jsonWriter = new JsonWriter(stringWriter);
      zzn(jsonWriter, paramzzfdp);
      jsonWriter.close();
      return stringWriter.toString();
    } catch (IOException iOException) {
      zze.zzh("Error when writing JSON.", iOException);
      return null;
    } 
  }
  
  private static JSONObject zzm(JSONObject paramJSONObject, String[] paramArrayOfString) {
    for (int i = 0; i < paramArrayOfString.length - 1; i++) {
      if (paramJSONObject == null)
        return null; 
      paramJSONObject = paramJSONObject.optJSONObject(paramArrayOfString[i]);
    } 
    return paramJSONObject;
  }
  
  private static void zzn(JsonWriter paramJsonWriter, Object paramObject) throws IOException {
    if (paramObject == null) {
      paramJsonWriter.nullValue();
      return;
    } 
    if (paramObject instanceof Number) {
      paramJsonWriter.value((Number)paramObject);
      return;
    } 
    if (paramObject instanceof Boolean) {
      paramJsonWriter.value(((Boolean)paramObject).booleanValue());
      return;
    } 
    if (paramObject instanceof String) {
      paramJsonWriter.value((String)paramObject);
      return;
    } 
    if (paramObject instanceof zzfdp) {
      zzj(paramJsonWriter, ((zzfdp)paramObject).zzd);
      return;
    } 
    if (paramObject instanceof Map) {
      paramJsonWriter.beginObject();
      paramObject = ((Map)paramObject).entrySet().iterator();
      while (paramObject.hasNext()) {
        Map.Entry entry = paramObject.next();
        Object object = entry.getKey();
        if (object instanceof String) {
          entry = (Map.Entry)entry.getValue();
          zzn(paramJsonWriter.name((String)object), entry);
        } 
      } 
      paramJsonWriter.endObject();
      return;
    } 
    if (paramObject instanceof List) {
      paramJsonWriter.beginArray();
      paramObject = ((List)paramObject).iterator();
      while (paramObject.hasNext())
        zzn(paramJsonWriter, paramObject.next()); 
      paramJsonWriter.endArray();
      return;
    } 
    paramJsonWriter.nullValue();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzbu.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */