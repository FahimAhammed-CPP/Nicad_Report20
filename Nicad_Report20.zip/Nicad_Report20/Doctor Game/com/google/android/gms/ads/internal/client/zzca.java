package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.internal.ads.zzarz;
import com.google.android.gms.internal.ads.zzasb;
import com.google.android.gms.internal.ads.zzbmh;
import com.google.android.gms.internal.ads.zzbmi;
import com.google.android.gms.internal.ads.zzbmn;
import com.google.android.gms.internal.ads.zzbmo;
import com.google.android.gms.internal.ads.zzbqr;
import com.google.android.gms.internal.ads.zzbqt;
import com.google.android.gms.internal.ads.zzbqu;
import com.google.android.gms.internal.ads.zzbvk;
import com.google.android.gms.internal.ads.zzbyu;
import com.google.android.gms.internal.ads.zzbyv;
import com.google.android.gms.internal.ads.zzbzb;
import com.google.android.gms.internal.ads.zzbzc;
import com.google.android.gms.internal.ads.zzcbv;
import com.google.android.gms.internal.ads.zzcck;
import com.google.android.gms.internal.ads.zzccl;
import com.google.android.gms.internal.ads.zzcff;
import com.google.android.gms.internal.ads.zzcfg;

public final class zzca extends zzarz implements zzcc {
  zzca(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IClientApi");
  }
  
  public final zzbo zzb(IObjectWrapper paramIObjectWrapper, String paramString, zzbvk paramzzbvk, int paramInt) throws RemoteException {
    zzbo zzbo;
    Parcel parcel2 = zza();
    zzasb.zzg(parcel2, (IInterface)paramIObjectWrapper);
    parcel2.writeString(paramString);
    zzasb.zzg(parcel2, (IInterface)paramzzbvk);
    parcel2.writeInt(223104000);
    Parcel parcel1 = zzbk(3, parcel2);
    IBinder iBinder = parcel1.readStrongBinder();
    if (iBinder == null) {
      iBinder = null;
    } else {
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
      if (iInterface instanceof zzbo) {
        zzbo = (zzbo)iInterface;
      } else {
        zzbo = new zzbm((IBinder)zzbo);
      } 
    } 
    parcel1.recycle();
    return zzbo;
  }
  
  public final zzbs zzc(IObjectWrapper paramIObjectWrapper, zzq paramzzq, String paramString, zzbvk paramzzbvk, int paramInt) throws RemoteException {
    zzbs zzbs;
    Parcel parcel2 = zza();
    zzasb.zzg(parcel2, (IInterface)paramIObjectWrapper);
    zzasb.zze(parcel2, (Parcelable)paramzzq);
    parcel2.writeString(paramString);
    zzasb.zzg(parcel2, (IInterface)paramzzbvk);
    parcel2.writeInt(223104000);
    Parcel parcel1 = zzbk(13, parcel2);
    IBinder iBinder = parcel1.readStrongBinder();
    if (iBinder == null) {
      iBinder = null;
    } else {
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdManager");
      if (iInterface instanceof zzbs) {
        zzbs = (zzbs)iInterface;
      } else {
        zzbs = new zzbq((IBinder)zzbs);
      } 
    } 
    parcel1.recycle();
    return zzbs;
  }
  
  public final zzbs zzd(IObjectWrapper paramIObjectWrapper, zzq paramzzq, String paramString, zzbvk paramzzbvk, int paramInt) throws RemoteException {
    zzbs zzbs;
    Parcel parcel2 = zza();
    zzasb.zzg(parcel2, (IInterface)paramIObjectWrapper);
    zzasb.zze(parcel2, (Parcelable)paramzzq);
    parcel2.writeString(paramString);
    zzasb.zzg(parcel2, (IInterface)paramzzbvk);
    parcel2.writeInt(223104000);
    Parcel parcel1 = zzbk(1, parcel2);
    IBinder iBinder = parcel1.readStrongBinder();
    if (iBinder == null) {
      iBinder = null;
    } else {
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdManager");
      if (iInterface instanceof zzbs) {
        zzbs = (zzbs)iInterface;
      } else {
        zzbs = new zzbq((IBinder)zzbs);
      } 
    } 
    parcel1.recycle();
    return zzbs;
  }
  
  public final zzbs zze(IObjectWrapper paramIObjectWrapper, zzq paramzzq, String paramString, zzbvk paramzzbvk, int paramInt) throws RemoteException {
    zzbs zzbs;
    Parcel parcel2 = zza();
    zzasb.zzg(parcel2, (IInterface)paramIObjectWrapper);
    zzasb.zze(parcel2, (Parcelable)paramzzq);
    parcel2.writeString(paramString);
    zzasb.zzg(parcel2, (IInterface)paramzzbvk);
    parcel2.writeInt(223104000);
    Parcel parcel1 = zzbk(2, parcel2);
    IBinder iBinder = parcel1.readStrongBinder();
    if (iBinder == null) {
      iBinder = null;
    } else {
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdManager");
      if (iInterface instanceof zzbs) {
        zzbs = (zzbs)iInterface;
      } else {
        zzbs = new zzbq((IBinder)zzbs);
      } 
    } 
    parcel1.recycle();
    return zzbs;
  }
  
  public final zzbs zzf(IObjectWrapper paramIObjectWrapper, zzq paramzzq, String paramString, int paramInt) throws RemoteException {
    zzbs zzbs;
    Parcel parcel2 = zza();
    zzasb.zzg(parcel2, (IInterface)paramIObjectWrapper);
    zzasb.zze(parcel2, (Parcelable)paramzzq);
    parcel2.writeString(paramString);
    parcel2.writeInt(223104000);
    Parcel parcel1 = zzbk(10, parcel2);
    IBinder iBinder = parcel1.readStrongBinder();
    if (iBinder == null) {
      iBinder = null;
    } else {
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdManager");
      if (iInterface instanceof zzbs) {
        zzbs = (zzbs)iInterface;
      } else {
        zzbs = new zzbq((IBinder)zzbs);
      } 
    } 
    parcel1.recycle();
    return zzbs;
  }
  
  public final zzcm zzg(IObjectWrapper paramIObjectWrapper, int paramInt) throws RemoteException {
    zzcm zzcm;
    Parcel parcel = zza();
    zzasb.zzg(parcel, (IInterface)paramIObjectWrapper);
    parcel.writeInt(223104000);
    parcel = zzbk(9, parcel);
    IBinder iBinder = parcel.readStrongBinder();
    if (iBinder == null) {
      iBinder = null;
    } else {
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IMobileAdsSettingManager");
      if (iInterface instanceof zzcm) {
        zzcm = (zzcm)iInterface;
      } else {
        zzcm = new zzck((IBinder)zzcm);
      } 
    } 
    parcel.recycle();
    return zzcm;
  }
  
  public final zzbmi zzh(IObjectWrapper paramIObjectWrapper1, IObjectWrapper paramIObjectWrapper2) throws RemoteException {
    Parcel parcel2 = zza();
    zzasb.zzg(parcel2, (IInterface)paramIObjectWrapper1);
    zzasb.zzg(parcel2, (IInterface)paramIObjectWrapper2);
    Parcel parcel1 = zzbk(5, parcel2);
    zzbmi zzbmi = zzbmh.zzbB(parcel1.readStrongBinder());
    parcel1.recycle();
    return zzbmi;
  }
  
  public final zzbmo zzi(IObjectWrapper paramIObjectWrapper1, IObjectWrapper paramIObjectWrapper2, IObjectWrapper paramIObjectWrapper3) throws RemoteException {
    Parcel parcel2 = zza();
    zzasb.zzg(parcel2, (IInterface)paramIObjectWrapper1);
    zzasb.zzg(parcel2, (IInterface)paramIObjectWrapper2);
    zzasb.zzg(parcel2, (IInterface)paramIObjectWrapper3);
    Parcel parcel1 = zzbk(11, parcel2);
    zzbmo zzbmo = zzbmn.zze(parcel1.readStrongBinder());
    parcel1.recycle();
    return zzbmo;
  }
  
  public final zzbqu zzj(IObjectWrapper paramIObjectWrapper, zzbvk paramzzbvk, int paramInt, zzbqr paramzzbqr) throws RemoteException {
    Parcel parcel2 = zza();
    zzasb.zzg(parcel2, (IInterface)paramIObjectWrapper);
    zzasb.zzg(parcel2, (IInterface)paramzzbvk);
    parcel2.writeInt(223104000);
    zzasb.zzg(parcel2, (IInterface)paramzzbqr);
    Parcel parcel1 = zzbk(16, parcel2);
    zzbqu zzbqu = zzbqt.zzb(parcel1.readStrongBinder());
    parcel1.recycle();
    return zzbqu;
  }
  
  public final zzbyv zzk(IObjectWrapper paramIObjectWrapper, zzbvk paramzzbvk, int paramInt) throws RemoteException {
    Parcel parcel2 = zza();
    zzasb.zzg(parcel2, (IInterface)paramIObjectWrapper);
    zzasb.zzg(parcel2, (IInterface)paramzzbvk);
    parcel2.writeInt(223104000);
    Parcel parcel1 = zzbk(15, parcel2);
    zzbyv zzbyv = zzbyu.zzb(parcel1.readStrongBinder());
    parcel1.recycle();
    return zzbyv;
  }
  
  public final zzbzc zzl(IObjectWrapper paramIObjectWrapper) throws RemoteException {
    Parcel parcel2 = zza();
    zzasb.zzg(parcel2, (IInterface)paramIObjectWrapper);
    Parcel parcel1 = zzbk(8, parcel2);
    zzbzc zzbzc = zzbzb.zzF(parcel1.readStrongBinder());
    parcel1.recycle();
    return zzbzc;
  }
  
  public final zzcbv zzm(IObjectWrapper paramIObjectWrapper, zzbvk paramzzbvk, int paramInt) throws RemoteException {
    throw null;
  }
  
  public final zzccl zzn(IObjectWrapper paramIObjectWrapper, String paramString, zzbvk paramzzbvk, int paramInt) throws RemoteException {
    Parcel parcel2 = zza();
    zzasb.zzg(parcel2, (IInterface)paramIObjectWrapper);
    parcel2.writeString(paramString);
    zzasb.zzg(parcel2, (IInterface)paramzzbvk);
    parcel2.writeInt(223104000);
    Parcel parcel1 = zzbk(12, parcel2);
    zzccl zzccl = zzcck.zzq(parcel1.readStrongBinder());
    parcel1.recycle();
    return zzccl;
  }
  
  public final zzcfg zzo(IObjectWrapper paramIObjectWrapper, zzbvk paramzzbvk, int paramInt) throws RemoteException {
    Parcel parcel2 = zza();
    zzasb.zzg(parcel2, (IInterface)paramIObjectWrapper);
    zzasb.zzg(parcel2, (IInterface)paramzzbvk);
    parcel2.writeInt(223104000);
    Parcel parcel1 = zzbk(14, parcel2);
    zzcfg zzcfg = zzcff.zzb(parcel1.readStrongBinder());
    parcel1.recycle();
    return zzcfg;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzca.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */