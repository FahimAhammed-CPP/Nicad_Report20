package com.google.android.gms.ads.internal.util;

import android.content.Context;
import com.google.android.gms.internal.ads.zzcgu;

public final class zzby extends zzb {
  private final zzcgu zza;
  
  private final String zzb;
  
  public zzby(Context paramContext, String paramString1, String paramString2) {
    this.zza = new zzcgu(str);
    this.zzb = paramString2;
  }
  
  public final void zza() {
    this.zza.zza(this.zzb);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzby.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */