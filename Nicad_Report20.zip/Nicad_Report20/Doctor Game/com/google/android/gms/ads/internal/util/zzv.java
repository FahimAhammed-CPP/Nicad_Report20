package com.google.android.gms.ads.internal.util;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.telephony.TelephonyManager;
import com.google.android.gms.ads.internal.zzt;

public class zzv extends zzu {
  public final void zzg(Context paramContext) {
    NotificationChannel notificationChannel = new NotificationChannel("offline_notification_channel", "AdMob Offline Notifications", 2);
    notificationChannel.setShowBadge(false);
    ((NotificationManager)paramContext.getSystemService(NotificationManager.class)).createNotificationChannel(notificationChannel);
  }
  
  public final int zzh(Context paramContext, TelephonyManager paramTelephonyManager) {
    zzt.zzp();
    return (zzs.zzx(paramContext, "android.permission.ACCESS_NETWORK_STATE") && paramTelephonyManager.isDataEnabled()) ? 2 : 1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzv.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */