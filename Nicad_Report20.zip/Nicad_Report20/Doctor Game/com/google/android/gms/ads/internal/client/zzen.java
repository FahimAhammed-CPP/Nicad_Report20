package com.google.android.gms.ads.internal.client;

import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzcgi;
import com.google.android.gms.internal.ads.zzcgp;

final class zzen extends zzbk {
  public final String zze() throws RemoteException {
    return null;
  }
  
  public final String zzf() throws RemoteException {
    return null;
  }
  
  public final void zzg(zzl paramzzl) throws RemoteException {
    zzh(paramzzl, 1);
  }
  
  public final void zzh(zzl paramzzl, int paramInt) throws RemoteException {
    zzcgp.zzg("This app is using a lightweight version of the Google Mobile Ads SDK that requires the latest Google Play services to be installed, but Google Play services is either missing or out of date.");
    zzcgi.zza.post(new zzel(this));
  }
  
  public final boolean zzi() throws RemoteException {
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzen.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */