package com.google.android.gms.ads.internal.client;

import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzasa;

public abstract class zzbb extends zzasa implements zzbc {
  public zzbb() {
    super("com.google.android.gms.ads.internal.client.IAdClickListener");
  }
  
  protected final boolean zzbI(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2) throws RemoteException {
    if (paramInt1 == 1) {
      zzb();
      paramParcel2.writeNoException();
      return true;
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzbb.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */