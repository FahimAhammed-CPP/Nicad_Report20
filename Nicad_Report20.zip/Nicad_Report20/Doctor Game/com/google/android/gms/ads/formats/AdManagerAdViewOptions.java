package com.google.android.gms.ads.formats;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.internal.client.zzfd;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelWriter;
import com.google.android.gms.internal.ads.zzbnu;
import com.google.android.gms.internal.ads.zzbnv;

public final class AdManagerAdViewOptions extends AbstractSafeParcelable {
  public static final Parcelable.Creator<AdManagerAdViewOptions> CREATOR = new zzc();
  
  private final boolean zza;
  
  private final IBinder zzb;
  
  AdManagerAdViewOptions(boolean paramBoolean, IBinder paramIBinder) {
    this.zza = paramBoolean;
    this.zzb = paramIBinder;
  }
  
  public boolean getManualImpressionsEnabled() {
    return this.zza;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = SafeParcelWriter.beginObjectHeader(paramParcel);
    SafeParcelWriter.writeBoolean(paramParcel, 1, getManualImpressionsEnabled());
    SafeParcelWriter.writeIBinder(paramParcel, 2, this.zzb, false);
    SafeParcelWriter.finishObjectHeader(paramParcel, paramInt);
  }
  
  public final zzbnv zza() {
    IBinder iBinder = this.zzb;
    return (iBinder == null) ? null : zzbnu.zzc(iBinder);
  }
  
  public static final class Builder {
    private boolean zza = false;
    
    private ShouldDelayBannerRenderingListener zzb;
    
    public AdManagerAdViewOptions build() {
      return new AdManagerAdViewOptions(this, null);
    }
    
    public Builder setManualImpressionsEnabled(boolean param1Boolean) {
      this.zza = param1Boolean;
      return this;
    }
    
    public Builder setShouldDelayBannerRenderingListener(ShouldDelayBannerRenderingListener param1ShouldDelayBannerRenderingListener) {
      this.zzb = param1ShouldDelayBannerRenderingListener;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\formats\AdManagerAdViewOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */