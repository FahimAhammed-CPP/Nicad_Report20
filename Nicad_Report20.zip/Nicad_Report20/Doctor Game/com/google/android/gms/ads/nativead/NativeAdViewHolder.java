package com.google.android.gms.ads.nativead;

import android.os.RemoteException;
import android.view.View;
import com.google.android.gms.ads.internal.client.zzaw;
import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.dynamic.ObjectWrapper;
import com.google.android.gms.internal.ads.zzbmo;
import com.google.android.gms.internal.ads.zzcgp;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;
import java.util.WeakHashMap;
import org.checkerframework.checker.initialization.qual.NotOnlyInitialized;

public final class NativeAdViewHolder {
  public static WeakHashMap zza = new WeakHashMap<Object, Object>();
  
  @NotOnlyInitialized
  private zzbmo zzb;
  
  private WeakReference zzc;
  
  public NativeAdViewHolder(View paramView, Map<String, View> paramMap1, Map<String, View> paramMap2) {
    Preconditions.checkNotNull(paramView, "ContainerView must not be null");
    if (paramView instanceof NativeAdView) {
      zzcgp.zzg("The provided containerView is of type of NativeAdView, which cannot be usedwith NativeAdViewHolder.");
      return;
    } 
    if (zza.get(paramView) != null) {
      zzcgp.zzg("The provided containerView is already in use with another NativeAdViewHolder.");
      return;
    } 
    zza.put(paramView, this);
    this.zzc = new WeakReference<View>(paramView);
    paramMap1 = zza(paramMap1);
    paramMap2 = zza(paramMap2);
    this.zzb = zzaw.zza().zzh(paramView, (HashMap)paramMap1, (HashMap)paramMap2);
  }
  
  private static final HashMap zza(Map<?, ?> paramMap) {
    return (paramMap == null) ? new HashMap<Object, Object>() : new HashMap<Object, Object>(paramMap);
  }
  
  public final void setClickConfirmingView(View paramView) {
    try {
      this.zzb.zzb(ObjectWrapper.wrap(paramView));
      return;
    } catch (RemoteException remoteException) {
      zzcgp.zzh("Unable to call setClickConfirmingView on delegate", (Throwable)remoteException);
      return;
    } 
  }
  
  public void setNativeAd(NativeAd paramNativeAd) {
    Object object = paramNativeAd.zza();
    WeakReference<View> weakReference = this.zzc;
    if (weakReference != null) {
      View view = weakReference.get();
    } else {
      weakReference = null;
    } 
    if (weakReference == null) {
      zzcgp.zzj("NativeAdViewHolder.setNativeAd containerView doesn't exist, returning");
      return;
    } 
    if (!zza.containsKey(weakReference))
      zza.put(weakReference, this); 
    zzbmo zzbmo1 = this.zzb;
    if (zzbmo1 != null)
      try {
        zzbmo1.zzc((IObjectWrapper)object);
        return;
      } catch (RemoteException remoteException) {
        zzcgp.zzh("Unable to call setNativeAd on delegate", (Throwable)remoteException);
      }  
  }
  
  public void unregisterNativeAd() {
    zzbmo zzbmo1 = this.zzb;
    if (zzbmo1 != null)
      try {
        zzbmo1.zzd();
      } catch (RemoteException remoteException) {
        zzcgp.zzh("Unable to call unregisterNativeAd on delegate", (Throwable)remoteException);
      }  
    WeakReference<View> weakReference = this.zzc;
    if (weakReference != null) {
      View view = weakReference.get();
    } else {
      weakReference = null;
    } 
    if (weakReference != null)
      zza.remove(weakReference); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\nativead\NativeAdViewHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */