package com.google.android.gms.ads.internal.client;

import android.os.RemoteException;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.internal.ads.zzbrw;
import java.util.ArrayList;
import java.util.List;

final class zzec extends zzbrw {
  public final void zzb(List paramList) throws RemoteException {
    synchronized (zzed.zzg(this.zza)) {
      zzed zzed1 = this.zza;
      int i = 0;
      zzed.zzk(zzed1, false);
      zzed.zzj(this.zza, true);
      ArrayList<OnInitializationCompleteListener> arrayList = new ArrayList(zzed.zzi(this.zza));
      zzed.zzi(this.zza).clear();
      InitializationStatus initializationStatus = zzed.zzd(paramList);
      int j = arrayList.size();
      while (i < j) {
        ((OnInitializationCompleteListener)arrayList.get(i)).onInitializationComplete(initializationStatus);
        i++;
      } 
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */