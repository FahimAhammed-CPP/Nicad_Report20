package com.google.android.gms.ads.internal.util;

import com.google.android.gms.internal.ads.zzakh;
import com.google.android.gms.internal.ads.zzakm;

final class zzbh implements zzakh {
  zzbh(zzbo paramzzbo, String paramString, zzbl paramzzbl) {}
  
  public final void zza(zzakm paramzzakm) {
    String str2 = this.zza;
    String str1 = paramzzakm.toString();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Failed to load URL: ");
    stringBuilder.append(str2);
    stringBuilder.append("\n");
    stringBuilder.append(str1);
    zze.zzj(stringBuilder.toString());
    this.zzb.zza(null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzbh.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */