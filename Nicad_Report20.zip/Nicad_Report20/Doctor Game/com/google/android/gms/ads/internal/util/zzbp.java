package com.google.android.gms.ads.internal.util;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.internal.ads.zzarz;
import com.google.android.gms.internal.ads.zzasb;

public final class zzbp extends zzarz implements zzbr {
  zzbp(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.util.IWorkManagerUtil");
  }
  
  public final void zze(IObjectWrapper paramIObjectWrapper) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zzg(parcel, (IInterface)paramIObjectWrapper);
    zzbl(2, parcel);
  }
  
  public final boolean zzf(IObjectWrapper paramIObjectWrapper, String paramString1, String paramString2) throws RemoteException {
    Parcel parcel2 = zza();
    zzasb.zzg(parcel2, (IInterface)paramIObjectWrapper);
    parcel2.writeString(paramString1);
    parcel2.writeString(paramString2);
    Parcel parcel1 = zzbk(1, parcel2);
    boolean bool = zzasb.zzh(parcel1);
    parcel1.recycle();
    return bool;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzbp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */