package com.google.android.gms.ads.internal.util;

import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper;

public interface zzbr extends IInterface {
  void zze(IObjectWrapper paramIObjectWrapper) throws RemoteException;
  
  boolean zzf(IObjectWrapper paramIObjectWrapper, String paramString1, String paramString2) throws RemoteException;
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzbr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */