package com.google.android.gms.ads.internal.client;

public final class zzb extends zzbb {
  private final zza zza;
  
  public zzb(zza paramzza) {
    this.zza = paramzza;
  }
  
  public final void zzb() {
    this.zza.onAdClicked();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzb.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */