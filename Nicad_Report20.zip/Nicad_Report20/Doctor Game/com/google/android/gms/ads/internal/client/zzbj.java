package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzarz;
import com.google.android.gms.internal.ads.zzasb;

public final class zzbj extends zzarz implements zzbl {
  zzbj(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IAdLoader");
  }
  
  public final String zze() throws RemoteException {
    throw null;
  }
  
  public final String zzf() throws RemoteException {
    throw null;
  }
  
  public final void zzg(zzl paramzzl) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zze(parcel, (Parcelable)paramzzl);
    zzbl(1, parcel);
  }
  
  public final void zzh(zzl paramzzl, int paramInt) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zze(parcel, (Parcelable)paramzzl);
    parcel.writeInt(paramInt);
    zzbl(5, parcel);
  }
  
  public final boolean zzi() throws RemoteException {
    Parcel parcel = zzbk(3, zza());
    boolean bool = zzasb.zzh(parcel);
    parcel.recycle();
    return bool;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzbj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */