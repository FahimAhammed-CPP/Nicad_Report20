package com.google.android.gms.ads.internal.util;

import android.content.Context;
import com.google.android.gms.internal.ads.zzcgo;
import com.google.android.gms.internal.ads.zzchf;
import com.google.android.gms.internal.ads.zzfzp;

public final class zzd {
  public static void zza(Context paramContext) {
    if (!zzcgo.zzk(paramContext))
      return; 
    if (!zzcgo.zzm()) {
      zzfzp zzfzp = (new zzc(paramContext)).zzb();
      zze.zzi("Updating ad debug logging enablement.");
      zzchf.zza(zzfzp, "AdDebugLogUpdater.updateEnablement");
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */