package com.google.android.gms.ads.internal.util;

import android.util.Log;
import com.google.android.gms.internal.ads.zzbkv;
import com.google.android.gms.internal.ads.zzcgp;
import java.util.Iterator;

public final class zze extends zzcgp {
  public static void zza(String paramString) {
    if (zzc()) {
      if (paramString == null || paramString.length() <= 4000) {
        Log.v("Ads", paramString);
        return;
      } 
      Iterator<String> iterator = zza.zzd(paramString).iterator();
      for (boolean bool = true; iterator.hasNext(); bool = false) {
        String str = iterator.next();
        if (bool) {
          Log.v("Ads", str);
        } else {
          Log.v("Ads-cont", str);
        } 
      } 
    } 
  }
  
  public static void zzb(String paramString, Throwable paramThrowable) {
    if (zzc())
      Log.v("Ads", paramString, paramThrowable); 
  }
  
  public static boolean zzc() {
    return (zzm(2) && ((Boolean)zzbkv.zza.zze()).booleanValue());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zze.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */