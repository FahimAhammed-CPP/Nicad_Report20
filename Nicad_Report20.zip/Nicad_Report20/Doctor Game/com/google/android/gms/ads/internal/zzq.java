package com.google.android.gms.ads.internal;

import android.os.AsyncTask;
import com.google.android.gms.internal.ads.zzcgp;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

final class zzq extends AsyncTask {
  protected final String zza(Void... paramVarArgs) {
    try {
      zzs zzs1 = this.zza;
      zzs.zzv(zzs1, zzs.zzu(zzs1).get(1000L, TimeUnit.MILLISECONDS));
    } catch (InterruptedException interruptedException) {
      zzcgp.zzk("", interruptedException);
    } catch (ExecutionException executionException) {
    
    } catch (TimeoutException timeoutException) {
      zzcgp.zzk("", timeoutException);
    } 
    return this.zza.zzp();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\zzq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */