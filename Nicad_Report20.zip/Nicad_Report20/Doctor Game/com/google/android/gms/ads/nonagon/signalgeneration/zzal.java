package com.google.android.gms.ads.nonagon.signalgeneration;

import com.google.android.gms.internal.ads.zzchc;
import com.google.android.gms.internal.ads.zzecg;
import com.google.android.gms.internal.ads.zzfzq;
import com.google.android.gms.internal.ads.zzgxi;
import com.google.android.gms.internal.ads.zzgxq;
import com.google.android.gms.internal.ads.zzgxv;
import java.util.concurrent.Executor;

public final class zzal implements zzgxi {
  private final zzgxv zza;
  
  private final zzgxv zzb;
  
  public zzal(zzgxv paramzzgxv1, zzgxv paramzzgxv2) {
    this.zza = paramzzgxv1;
    this.zzb = paramzzgxv2;
  }
  
  public final zzak zza() {
    zzfzq zzfzq = zzchc.zza;
    zzgxq.zzb(zzfzq);
    return new zzak((Executor)zzfzq, ((zzecg)this.zzb).zza());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\nonagon\signalgeneration\zzal.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */