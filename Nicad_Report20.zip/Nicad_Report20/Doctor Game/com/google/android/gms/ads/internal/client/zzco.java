package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzarz;

public final class zzco extends zzarz implements zzcq {
  zzco(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IMuteThisAdListener");
  }
  
  public final void zze() throws RemoteException {
    zzbl(1, zza());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzco.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */