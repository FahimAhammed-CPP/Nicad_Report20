package com.google.android.gms.ads.internal.client;

import com.google.android.gms.ads.AdListener;

public final class zzg extends zzbe {
  private final AdListener zza;
  
  public zzg(AdListener paramAdListener) {
    this.zza = paramAdListener;
  }
  
  public final AdListener zzb() {
    return this.zza;
  }
  
  public final void zzc() {
    AdListener adListener = this.zza;
    if (adListener != null)
      adListener.onAdClicked(); 
  }
  
  public final void zzd() {
    AdListener adListener = this.zza;
    if (adListener != null)
      adListener.onAdClosed(); 
  }
  
  public final void zze(int paramInt) {}
  
  public final void zzf(zze paramzze) {
    AdListener adListener = this.zza;
    if (adListener != null)
      adListener.onAdFailedToLoad(paramzze.zzb()); 
  }
  
  public final void zzg() {
    AdListener adListener = this.zza;
    if (adListener != null)
      adListener.onAdImpression(); 
  }
  
  public final void zzh() {}
  
  public final void zzi() {
    AdListener adListener = this.zza;
    if (adListener != null)
      adListener.onAdLoaded(); 
  }
  
  public final void zzj() {
    AdListener adListener = this.zza;
    if (adListener != null)
      adListener.onAdOpened(); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzg.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */