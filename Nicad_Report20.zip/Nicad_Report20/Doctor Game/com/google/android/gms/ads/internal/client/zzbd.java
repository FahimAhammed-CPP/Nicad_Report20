package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzarz;
import com.google.android.gms.internal.ads.zzasb;

public final class zzbd extends zzarz implements zzbf {
  zzbd(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IAdListener");
  }
  
  public final void zzc() throws RemoteException {
    zzbl(6, zza());
  }
  
  public final void zzd() throws RemoteException {
    zzbl(1, zza());
  }
  
  public final void zze(int paramInt) throws RemoteException {
    Parcel parcel = zza();
    parcel.writeInt(paramInt);
    zzbl(2, parcel);
  }
  
  public final void zzf(zze paramzze) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zze(parcel, (Parcelable)paramzze);
    zzbl(8, parcel);
  }
  
  public final void zzg() throws RemoteException {
    zzbl(7, zza());
  }
  
  public final void zzh() throws RemoteException {
    zzbl(3, zza());
  }
  
  public final void zzi() throws RemoteException {
    zzbl(4, zza());
  }
  
  public final void zzj() throws RemoteException {
    zzbl(5, zza());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzbd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */