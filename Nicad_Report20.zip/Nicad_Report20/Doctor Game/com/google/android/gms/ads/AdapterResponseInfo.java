package com.google.android.gms.ads;

import android.os.Bundle;
import com.google.android.gms.ads.internal.client.zze;
import com.google.android.gms.ads.internal.client.zzu;
import org.json.JSONException;
import org.json.JSONObject;

public final class AdapterResponseInfo {
  private final zzu zza;
  
  private final AdError zzb;
  
  private AdapterResponseInfo(zzu paramzzu) {
    AdError adError;
    this.zza = paramzzu;
    zze zze = paramzzu.zzc;
    if (zze == null) {
      zze = null;
    } else {
      adError = zze.zza();
    } 
    this.zzb = adError;
  }
  
  public static AdapterResponseInfo zza(zzu paramzzu) {
    return (paramzzu != null) ? new AdapterResponseInfo(paramzzu) : null;
  }
  
  public AdError getAdError() {
    return this.zzb;
  }
  
  public String getAdSourceId() {
    return this.zza.zzf;
  }
  
  public String getAdSourceInstanceId() {
    return this.zza.zzh;
  }
  
  public String getAdSourceInstanceName() {
    return this.zza.zzg;
  }
  
  public String getAdSourceName() {
    return this.zza.zze;
  }
  
  public String getAdapterClassName() {
    return this.zza.zza;
  }
  
  public Bundle getCredentials() {
    return this.zza.zzd;
  }
  
  public long getLatencyMillis() {
    return this.zza.zzb;
  }
  
  public String toString() {
    try {
      return zzb().toString(2);
    } catch (JSONException jSONException) {
      return "Error forming toString output.";
    } 
  }
  
  public final JSONObject zzb() throws JSONException {
    JSONObject jSONObject1 = new JSONObject();
    jSONObject1.put("Adapter", this.zza.zza);
    jSONObject1.put("Latency", this.zza.zzb);
    String str = getAdSourceName();
    if (str == null) {
      jSONObject1.put("Ad Source Name", "null");
    } else {
      jSONObject1.put("Ad Source Name", str);
    } 
    str = getAdSourceId();
    if (str == null) {
      jSONObject1.put("Ad Source ID", "null");
    } else {
      jSONObject1.put("Ad Source ID", str);
    } 
    str = getAdSourceInstanceName();
    if (str == null) {
      jSONObject1.put("Ad Source Instance Name", "null");
    } else {
      jSONObject1.put("Ad Source Instance Name", str);
    } 
    str = getAdSourceInstanceId();
    if (str == null) {
      jSONObject1.put("Ad Source Instance ID", "null");
    } else {
      jSONObject1.put("Ad Source Instance ID", str);
    } 
    JSONObject jSONObject2 = new JSONObject();
    for (String str1 : this.zza.zzd.keySet())
      jSONObject2.put(str1, this.zza.zzd.get(str1)); 
    jSONObject1.put("Credentials", jSONObject2);
    AdError adError = this.zzb;
    if (adError == null) {
      jSONObject1.put("Ad Error", "null");
      return jSONObject1;
    } 
    jSONObject1.put("Ad Error", adError.zzb());
    return jSONObject1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\AdapterResponseInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */