package com.google.android.gms.ads.internal.client;

import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzasa;
import com.google.android.gms.internal.ads.zzasb;

public abstract class zzcf extends zzasa implements zzcg {
  public zzcf() {
    super("com.google.android.gms.ads.internal.client.IFullScreenContentCallback");
  }
  
  protected final boolean zzbI(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2) throws RemoteException {
    if (paramInt1 != 1) {
      if (paramInt1 != 2) {
        if (paramInt1 != 3) {
          if (paramInt1 != 4) {
            if (paramInt1 != 5)
              return false; 
            zzb();
          } else {
            zze();
          } 
        } else {
          zzc();
        } 
      } else {
        zzf();
      } 
    } else {
      zze zze = (zze)zzasb.zza(paramParcel1, zze.CREATOR);
      zzasb.zzc(paramParcel1);
      zzd(zze);
    } 
    paramParcel2.writeNoException();
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzcf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */