package com.google.android.gms.ads.internal;

import android.app.Activity;
import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import com.google.android.gms.ads.internal.client.zzaw;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.util.zze;
import com.google.android.gms.ads.internal.util.zzs;
import com.google.android.gms.internal.ads.zzaox;
import com.google.android.gms.internal.ads.zzapa;
import com.google.android.gms.internal.ads.zzapd;
import com.google.android.gms.internal.ads.zzbiu;
import com.google.android.gms.internal.ads.zzbjc;
import com.google.android.gms.internal.ads.zzcgi;
import com.google.android.gms.internal.ads.zzcgv;
import com.google.android.gms.internal.ads.zzchc;
import com.google.android.gms.internal.ads.zzfmx;
import com.google.android.gms.internal.ads.zzfnz;
import com.google.android.gms.internal.ads.zzfot;
import java.util.List;
import java.util.Vector;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicReference;

public final class zzi implements Runnable, zzapa {
  protected boolean zza;
  
  final CountDownLatch zzb = new CountDownLatch(1);
  
  private final List zzc = new Vector();
  
  private final AtomicReference zzd = new AtomicReference();
  
  private final AtomicReference zze = new AtomicReference();
  
  private final boolean zzf;
  
  private final boolean zzg;
  
  private final Executor zzh;
  
  private final zzfmx zzi;
  
  private Context zzj;
  
  private final Context zzk;
  
  private zzcgv zzl;
  
  private final zzcgv zzm;
  
  private final boolean zzn;
  
  private int zzo;
  
  public zzi(Context paramContext, zzcgv paramzzcgv) {
    this.zzj = paramContext;
    this.zzk = paramContext;
    this.zzl = paramzzcgv;
    this.zzm = paramzzcgv;
    this.zzh = Executors.newCachedThreadPool();
    zzbiu zzbiu2 = zzbjc.zzbV;
    boolean bool = ((Boolean)zzay.zzc().zzb(zzbiu2)).booleanValue();
    this.zzn = bool;
    this.zzi = zzfmx.zza(paramContext, this.zzh, bool);
    zzbiu zzbiu1 = zzbjc.zzbR;
    this.zzf = ((Boolean)zzay.zzc().zzb(zzbiu1)).booleanValue();
    zzbiu1 = zzbjc.zzbW;
    this.zzg = ((Boolean)zzay.zzc().zzb(zzbiu1)).booleanValue();
    zzbiu1 = zzbjc.zzbU;
    if (((Boolean)zzay.zzc().zzb(zzbiu1)).booleanValue()) {
      this.zzo = 2;
    } else {
      this.zzo = 1;
    } 
    zzbiu1 = zzbjc.zzcF;
    if (!((Boolean)zzay.zzc().zzb(zzbiu1)).booleanValue())
      this.zza = zzc(); 
    zzbiu1 = zzbjc.zzcy;
    if (((Boolean)zzay.zzc().zzb(zzbiu1)).booleanValue()) {
      zzchc.zza.execute(this);
      return;
    } 
    zzaw.zzb();
    if (zzcgi.zzt()) {
      zzchc.zza.execute(this);
      return;
    } 
    run();
  }
  
  private final zzapa zzj() {
    return (zzi() == 2) ? this.zze.get() : this.zzd.get();
  }
  
  private final void zzm() {
    zzapa zzapa1 = zzj();
    if (!this.zzc.isEmpty()) {
      if (zzapa1 == null)
        return; 
      for (Object[] arrayOfObject : this.zzc) {
        int i = arrayOfObject.length;
        if (i == 1) {
          zzapa1.zzk((MotionEvent)arrayOfObject[0]);
          continue;
        } 
        if (i == 3)
          zzapa1.zzl(((Integer)arrayOfObject[0]).intValue(), ((Integer)arrayOfObject[1]).intValue(), ((Integer)arrayOfObject[2]).intValue()); 
      } 
      this.zzc.clear();
    } 
  }
  
  private final void zzo(boolean paramBoolean) {
    zzapd zzapd = zzapd.zzt(this.zzl.zza, zzp(this.zzj), paramBoolean, this.zzo);
    this.zzd.set(zzapd);
  }
  
  private static final Context zzp(Context paramContext) {
    Context context = paramContext.getApplicationContext();
    return (context == null) ? paramContext : context;
  }
  
  public final void run() {
    try {
      zzbiu zzbiu = zzbjc.zzcF;
      if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue())
        this.zza = zzc(); 
      boolean bool3 = this.zzl.zzd;
      zzbiu = zzbjc.zzaQ;
      boolean bool4 = ((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue();
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (!bool4) {
        bool1 = bool2;
        if (bool3)
          bool1 = true; 
      } 
      if (zzi() == 1) {
        zzo(bool1);
        if (this.zzo == 2)
          this.zzh.execute(new zzg(this, bool1)); 
      } else {
        long l = System.currentTimeMillis();
        try {
          zzaox zzaox = zzaox.zza(this.zzl.zza, zzp(this.zzj), bool1, this.zzn);
          this.zze.set(zzaox);
          if (this.zzg && !zzaox.zzq()) {
            this.zzo = 1;
            zzo(bool1);
          } 
        } catch (NullPointerException nullPointerException) {
          this.zzo = 1;
          zzo(bool1);
          this.zzi.zzc(2031, System.currentTimeMillis() - l, nullPointerException);
        } 
      } 
      return;
    } finally {
      this.zzb.countDown();
      this.zzj = null;
      this.zzl = null;
    } 
  }
  
  protected final boolean zzc() {
    Context context2 = this.zzj;
    zzfmx zzfmx1 = this.zzi;
    zzh zzh = new zzh(this);
    Context context1 = this.zzj;
    int i = zzfnz.zzb(context2, zzfmx1);
    zzbiu zzbiu = zzbjc.zzbS;
    return (new zzfot(context1, i, zzh, ((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue())).zzd(1);
  }
  
  public final boolean zzd() {
    try {
      this.zzb.await();
      return true;
    } catch (InterruptedException interruptedException) {
      zze.zzk("Interrupted during GADSignals creation.", interruptedException);
      return false;
    } 
  }
  
  public final String zze(Context paramContext, String paramString, View paramView) {
    return zzf(paramContext, paramString, paramView, null);
  }
  
  public final String zzf(Context paramContext, String paramString, View paramView, Activity paramActivity) {
    if (zzd()) {
      zzapa zzapa1 = zzj();
      zzbiu zzbiu = zzbjc.zzir;
      if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue()) {
        zzt.zzp();
        zzs.zzF(paramView, 4, null);
      } 
      if (zzapa1 != null) {
        zzm();
        return zzapa1.zzf(zzp(paramContext), paramString, paramView, paramActivity);
      } 
    } 
    return "";
  }
  
  public final String zzg(Context paramContext) {
    if (zzd()) {
      zzapa zzapa1 = zzj();
      if (zzapa1 != null) {
        zzm();
        return zzapa1.zzg(zzp(paramContext));
      } 
    } 
    return "";
  }
  
  public final String zzh(Context paramContext, View paramView, Activity paramActivity) {
    zzbiu zzbiu = zzbjc.zziq;
    if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue()) {
      if (zzd()) {
        zzapa zzapa1 = zzj();
        zzbiu zzbiu1 = zzbjc.zzir;
        if (((Boolean)zzay.zzc().zzb(zzbiu1)).booleanValue()) {
          zzt.zzp();
          zzs.zzF(paramView, 2, null);
        } 
        if (zzapa1 != null)
          return zzapa1.zzh(paramContext, paramView, paramActivity); 
      } 
    } else {
      zzapa zzapa1 = zzj();
      zzbiu zzbiu1 = zzbjc.zzir;
      if (((Boolean)zzay.zzc().zzb(zzbiu1)).booleanValue()) {
        zzt.zzp();
        zzs.zzF(paramView, 2, null);
      } 
      if (zzapa1 != null)
        return zzapa1.zzh(paramContext, paramView, paramActivity); 
    } 
    return "";
  }
  
  protected final int zzi() {
    return (this.zzf && !this.zza) ? 1 : this.zzo;
  }
  
  public final void zzk(MotionEvent paramMotionEvent) {
    zzapa zzapa1 = zzj();
    if (zzapa1 != null) {
      zzm();
      zzapa1.zzk(paramMotionEvent);
      return;
    } 
    this.zzc.add(new Object[] { paramMotionEvent });
  }
  
  public final void zzl(int paramInt1, int paramInt2, int paramInt3) {
    zzapa zzapa1 = zzj();
    if (zzapa1 != null) {
      zzm();
      zzapa1.zzl(paramInt1, paramInt2, paramInt3);
      return;
    } 
    this.zzc.add(new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Integer.valueOf(paramInt3) });
  }
  
  public final void zzn(View paramView) {
    zzapa zzapa1 = zzj();
    if (zzapa1 != null)
      zzapa1.zzn(paramView); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\zzi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */