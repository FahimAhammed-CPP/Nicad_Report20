package com.google.android.gms.ads;

import android.content.Context;
import android.os.Parcelable;
import android.util.DisplayMetrics;
import com.google.android.gms.ads.internal.client.zzaw;
import com.google.android.gms.ads.internal.client.zzq;
import com.google.android.gms.internal.ads.zzcgi;
import com.google.android.gms.internal.ads.zzcgp;

public final class AdSize {
  public static final int AUTO_HEIGHT = -2;
  
  public static final AdSize BANNER = new AdSize(320, 50, "320x50_mb");
  
  public static final AdSize FLUID;
  
  public static final AdSize FULL_BANNER = new AdSize(468, 60, "468x60_as");
  
  public static final int FULL_WIDTH = -1;
  
  public static final AdSize INVALID;
  
  public static final AdSize LARGE_BANNER = new AdSize(320, 100, "320x100_as");
  
  public static final AdSize LEADERBOARD = new AdSize(728, 90, "728x90_as");
  
  public static final AdSize MEDIUM_RECTANGLE = new AdSize(300, 250, "300x250_as");
  
  public static final AdSize SEARCH;
  
  @Deprecated
  public static final AdSize SMART_BANNER;
  
  public static final AdSize WIDE_SKYSCRAPER = new AdSize(160, 600, "160x600_as");
  
  public static final AdSize zza;
  
  private final int zzb;
  
  private final int zzc;
  
  private final String zzd;
  
  private boolean zze;
  
  private boolean zzf;
  
  private int zzg;
  
  private boolean zzh;
  
  private int zzi;
  
  static {
    SMART_BANNER = new AdSize(-1, -2, "smart_banner");
    FLUID = new AdSize(-3, -4, "fluid");
    INVALID = new AdSize(0, 0, "invalid");
    zza = new AdSize(50, 50, "50x50_mb");
    SEARCH = new AdSize(-3, 0, "search_v2");
  }
  
  public AdSize(int paramInt1, int paramInt2) {
    this(paramInt1, paramInt2, stringBuilder.toString());
  }
  
  AdSize(int paramInt1, int paramInt2, String paramString) {
    if (paramInt1 >= 0 || paramInt1 == -1 || paramInt1 == -3) {
      if (paramInt2 >= 0 || paramInt2 == -2 || paramInt2 == -4) {
        this.zzb = paramInt1;
        this.zzc = paramInt2;
        this.zzd = paramString;
        return;
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Invalid height for AdSize: ");
      stringBuilder1.append(paramInt2);
      throw new IllegalArgumentException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Invalid width for AdSize: ");
    stringBuilder.append(paramInt1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public static AdSize getCurrentOrientationAnchoredAdaptiveBannerAdSize(Context paramContext, int paramInt) {
    AdSize adSize = zzcgi.zzc(paramContext, paramInt, 50, 0);
    adSize.zze = true;
    return adSize;
  }
  
  public static AdSize getCurrentOrientationInlineAdaptiveBannerAdSize(Context paramContext, int paramInt) {
    int i = zzcgi.zza(paramContext, 0);
    if (i == -1)
      return INVALID; 
    AdSize adSize = new AdSize(paramInt, 0);
    adSize.zzg = i;
    adSize.zzf = true;
    return adSize;
  }
  
  public static AdSize getCurrentOrientationInterscrollerAdSize(Context paramContext, int paramInt) {
    return zzj(paramInt, zzcgi.zza(paramContext, 0));
  }
  
  public static AdSize getInlineAdaptiveBannerAdSize(int paramInt1, int paramInt2) {
    AdSize adSize = new AdSize(paramInt1, 0);
    adSize.zzg = paramInt2;
    adSize.zzf = true;
    if (paramInt2 < 32) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("The maximum height set for the inline adaptive ad size was ");
      stringBuilder.append(paramInt2);
      stringBuilder.append(" dp, which is below the minimum recommended value of 32 dp.");
      zzcgp.zzj(stringBuilder.toString());
    } 
    return adSize;
  }
  
  public static AdSize getLandscapeAnchoredAdaptiveBannerAdSize(Context paramContext, int paramInt) {
    AdSize adSize = zzcgi.zzc(paramContext, paramInt, 50, 2);
    adSize.zze = true;
    return adSize;
  }
  
  public static AdSize getLandscapeInlineAdaptiveBannerAdSize(Context paramContext, int paramInt) {
    int i = zzcgi.zza(paramContext, 2);
    AdSize adSize = new AdSize(paramInt, 0);
    if (i == -1)
      return INVALID; 
    adSize.zzg = i;
    adSize.zzf = true;
    return adSize;
  }
  
  public static AdSize getLandscapeInterscrollerAdSize(Context paramContext, int paramInt) {
    return zzj(paramInt, zzcgi.zza(paramContext, 2));
  }
  
  public static AdSize getPortraitAnchoredAdaptiveBannerAdSize(Context paramContext, int paramInt) {
    AdSize adSize = zzcgi.zzc(paramContext, paramInt, 50, 1);
    adSize.zze = true;
    return adSize;
  }
  
  public static AdSize getPortraitInlineAdaptiveBannerAdSize(Context paramContext, int paramInt) {
    int i = zzcgi.zza(paramContext, 1);
    AdSize adSize = new AdSize(paramInt, 0);
    if (i == -1)
      return INVALID; 
    adSize.zzg = i;
    adSize.zzf = true;
    return adSize;
  }
  
  public static AdSize getPortraitInterscrollerAdSize(Context paramContext, int paramInt) {
    return zzj(paramInt, zzcgi.zza(paramContext, 1));
  }
  
  private static AdSize zzj(int paramInt1, int paramInt2) {
    if (paramInt2 == -1)
      return INVALID; 
    AdSize adSize = new AdSize(paramInt1, 0);
    adSize.zzi = paramInt2;
    adSize.zzh = true;
    return adSize;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == null)
      return false; 
    if (paramObject == this)
      return true; 
    if (!(paramObject instanceof AdSize))
      return false; 
    paramObject = paramObject;
    return (this.zzb == ((AdSize)paramObject).zzb && this.zzc == ((AdSize)paramObject).zzc && this.zzd.equals(((AdSize)paramObject).zzd));
  }
  
  public int getHeight() {
    return this.zzc;
  }
  
  public int getHeightInPixels(Context paramContext) {
    int i = this.zzc;
    if (i != -4 && i != -3) {
      if (i != -2) {
        zzaw.zzb();
        return zzcgi.zzw(paramContext, this.zzc);
      } 
      return zzq.zza(paramContext.getResources().getDisplayMetrics());
    } 
    return -1;
  }
  
  public int getWidth() {
    return this.zzb;
  }
  
  public int getWidthInPixels(Context paramContext) {
    int i = this.zzb;
    if (i != -3) {
      if (i != -1) {
        zzaw.zzb();
        return zzcgi.zzw(paramContext, this.zzb);
      } 
      DisplayMetrics displayMetrics = paramContext.getResources().getDisplayMetrics();
      Parcelable.Creator creator = zzq.CREATOR;
      return displayMetrics.widthPixels;
    } 
    return -1;
  }
  
  public int hashCode() {
    return this.zzd.hashCode();
  }
  
  public boolean isAutoHeight() {
    return (this.zzc == -2);
  }
  
  public boolean isFluid() {
    return (this.zzb == -3 && this.zzc == -4);
  }
  
  public boolean isFullWidth() {
    return (this.zzb == -1);
  }
  
  public String toString() {
    return this.zzd;
  }
  
  final int zza() {
    return this.zzi;
  }
  
  final int zzb() {
    return this.zzg;
  }
  
  final void zzc(int paramInt) {
    this.zzg = paramInt;
  }
  
  final void zzd(int paramInt) {
    this.zzi = paramInt;
  }
  
  final void zze(boolean paramBoolean) {
    this.zzf = true;
  }
  
  final void zzf(boolean paramBoolean) {
    this.zzh = true;
  }
  
  final boolean zzg() {
    return this.zze;
  }
  
  final boolean zzh() {
    return this.zzf;
  }
  
  final boolean zzi() {
    return this.zzh;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\AdSize.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */