package com.google.android.gms.ads.nonagon.signalgeneration;

import android.content.Context;
import android.graphics.Point;
import android.net.Uri;
import android.os.Build;
import android.os.RemoteException;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebView;
import com.google.android.gms.ads.AdFormat;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.client.zzl;
import com.google.android.gms.ads.internal.client.zzm;
import com.google.android.gms.ads.internal.client.zzq;
import com.google.android.gms.ads.internal.util.zzbx;
import com.google.android.gms.ads.internal.util.zze;
import com.google.android.gms.ads.internal.zzt;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.dynamic.ObjectWrapper;
import com.google.android.gms.internal.ads.zzape;
import com.google.android.gms.internal.ads.zzapf;
import com.google.android.gms.internal.ads.zzbiu;
import com.google.android.gms.internal.ads.zzbjc;
import com.google.android.gms.internal.ads.zzbkl;
import com.google.android.gms.internal.ads.zzbzr;
import com.google.android.gms.internal.ads.zzcaa;
import com.google.android.gms.internal.ads.zzcfd;
import com.google.android.gms.internal.ads.zzcff;
import com.google.android.gms.internal.ads.zzcfk;
import com.google.android.gms.internal.ads.zzcgp;
import com.google.android.gms.internal.ads.zzcgv;
import com.google.android.gms.internal.ads.zzchc;
import com.google.android.gms.internal.ads.zzcom;
import com.google.android.gms.internal.ads.zzdck;
import com.google.android.gms.internal.ads.zzdik;
import com.google.android.gms.internal.ads.zzdtn;
import com.google.android.gms.internal.ads.zzdxl;
import com.google.android.gms.internal.ads.zzdxv;
import com.google.android.gms.internal.ads.zzfed;
import com.google.android.gms.internal.ads.zzffb;
import com.google.android.gms.internal.ads.zzfji;
import com.google.android.gms.internal.ads.zzfjj;
import com.google.android.gms.internal.ads.zzfju;
import com.google.android.gms.internal.ads.zzfjw;
import com.google.android.gms.internal.ads.zzfkm;
import com.google.android.gms.internal.ads.zzftm;
import com.google.android.gms.internal.ads.zzfyx;
import com.google.android.gms.internal.ads.zzfzg;
import com.google.android.gms.internal.ads.zzfzp;
import com.google.android.gms.internal.ads.zzfzq;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import org.json.JSONObject;

public final class zzaa extends zzcff {
  protected static final List zza = new ArrayList(Arrays.asList((Object[])new String[] { "/aclk", "/pcs/click", "/dbm/clk" }));
  
  protected static final List zzb = new ArrayList(Arrays.asList((Object[])new String[] { ".doubleclick.net", ".googleadservices.com" }));
  
  protected static final List zzc = new ArrayList(Arrays.asList((Object[])new String[] { "/pagead/adview", "/pcs/view", "/pagead/conversion", "/dbm/ad" }));
  
  protected static final List zzd = new ArrayList(Arrays.asList((Object[])new String[] { ".doubleclick.net", ".googleadservices.com", ".googlesyndication.com" }));
  
  private final zzcgv zzA;
  
  private String zzB;
  
  private final String zzC;
  
  private final List zzD;
  
  private final List zzE;
  
  private final List zzF;
  
  private final List zzG;
  
  private final zzcom zzf;
  
  private Context zzg;
  
  private final zzape zzh;
  
  private final zzffb zzi;
  
  private zzdxl zzj;
  
  private final zzfzq zzk;
  
  private final ScheduledExecutorService zzl;
  
  private zzcaa zzm;
  
  private Point zzn;
  
  private Point zzo;
  
  private final Set zzp;
  
  private final zzc zzq;
  
  private final zzdxv zzr;
  
  private final zzfkm zzs;
  
  private final boolean zzt;
  
  private final boolean zzu;
  
  private final boolean zzv;
  
  private final boolean zzw;
  
  private final String zzx;
  
  private final String zzy;
  
  private final AtomicInteger zzz;
  
  public zzaa(zzcom paramzzcom, Context paramContext, zzape paramzzape, zzffb paramzzffb, zzfzq paramzzfzq, ScheduledExecutorService paramScheduledExecutorService, zzdxv paramzzdxv, zzfkm paramzzfkm, zzcgv paramzzcgv) {
    List list;
    this.zzj = null;
    this.zzn = new Point();
    this.zzo = new Point();
    this.zzp = Collections.newSetFromMap(new WeakHashMap<Object, Boolean>());
    this.zzz = new AtomicInteger(0);
    this.zzf = paramzzcom;
    this.zzg = paramContext;
    this.zzh = paramzzape;
    this.zzi = paramzzffb;
    this.zzk = paramzzfzq;
    this.zzl = paramScheduledExecutorService;
    this.zzq = paramzzcom.zzm();
    this.zzr = paramzzdxv;
    this.zzs = paramzzfkm;
    this.zzA = paramzzcgv;
    zzbiu zzbiu = zzbjc.zzgq;
    this.zzt = ((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue();
    zzbiu = zzbjc.zzgp;
    this.zzu = ((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue();
    zzbiu = zzbjc.zzgr;
    this.zzv = ((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue();
    zzbiu = zzbjc.zzgt;
    this.zzw = ((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue();
    zzbiu = zzbjc.zzgs;
    this.zzx = (String)zzay.zzc().zzb(zzbiu);
    zzbiu = zzbjc.zzgu;
    this.zzy = (String)zzay.zzc().zzb(zzbiu);
    zzbiu = zzbjc.zzgv;
    this.zzC = (String)zzay.zzc().zzb(zzbiu);
    zzbiu = zzbjc.zzgw;
    if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue()) {
      zzbiu = zzbjc.zzgx;
      this.zzD = zzX((String)zzay.zzc().zzb(zzbiu));
      zzbiu = zzbjc.zzgy;
      this.zzE = zzX((String)zzay.zzc().zzb(zzbiu));
      zzbiu = zzbjc.zzgz;
      this.zzF = zzX((String)zzay.zzc().zzb(zzbiu));
      zzbiu = zzbjc.zzgA;
      list = zzX((String)zzay.zzc().zzb(zzbiu));
    } else {
      this.zzD = zza;
      this.zzE = zzb;
      this.zzF = zzc;
      list = zzd;
    } 
    this.zzG = list;
  }
  
  private final zzh zzQ(Context paramContext, String paramString1, String paramString2, zzq paramzzq, zzl paramzzl) {
    zzfed zzfed = new zzfed();
    zzbiu zzbiu = zzbjc.zzgC;
    if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue())
      if ("REWARDED".equals(paramString2)) {
        zzfed.zzo().zza(2);
      } else if ("REWARDED_INTERSTITIAL".equals(paramString2)) {
        zzfed.zzo().zza(3);
      }  
    zzg zzg = this.zzf.zzn();
    zzdck zzdck = new zzdck();
    zzdck.zzc(paramContext);
    String str = paramString1;
    if (paramString1 == null)
      str = "adUnitId"; 
    zzfed.zzs(str);
    zzl zzl1 = paramzzl;
    if (paramzzl == null)
      zzl1 = (new zzm()).zza(); 
    zzfed.zzE(zzl1);
    zzq zzq1 = paramzzq;
    if (paramzzq == null) {
      zzbiu zzbiu1 = zzbjc.zzgC;
      if (!((Boolean)zzay.zzc().zzb(zzbiu1)).booleanValue()) {
        zzq zzq2 = new zzq();
      } else {
        byte b;
        switch (paramString2.hashCode()) {
          default:
            b = -1;
            break;
          case 1951953708:
            if (paramString2.equals("BANNER")) {
              b = 0;
              break;
            } 
          case 1854800829:
            if (paramString2.equals("REWARDED_INTERSTITIAL")) {
              b = 2;
              break;
            } 
          case 543046670:
            if (paramString2.equals("REWARDED")) {
              b = 1;
              break;
            } 
          case -1999289321:
            if (paramString2.equals("NATIVE")) {
              b = 3;
              break;
            } 
        } 
        if (b != 0) {
          if (b != 1 && b != 2) {
            if (b != 3) {
              zzq zzq2 = new zzq();
            } else {
              zzq zzq2 = zzq.zzc();
            } 
          } else {
            zzq zzq2 = zzq.zzd();
          } 
        } else {
          zzq1 = new zzq(paramContext, AdSize.BANNER);
        } 
      } 
    } 
    zzfed.zzr(zzq1);
    zzfed.zzx(true);
    zzdck.zzf(zzfed.zzG());
    zzg.zza(zzdck.zzg());
    zzac zzac = new zzac();
    zzac.zza(paramString2);
    zzg.zzb(new zzae(zzac, null));
    new zzdik();
    zzh zzh = zzg.zzc();
    this.zzj = zzh.zza();
    return zzh;
  }
  
  private final zzfzp zzR(String paramString) {
    zzdtn[] arrayOfZzdtn = new zzdtn[1];
    zzfzp zzfzp = zzfzg.zzn(this.zzi.zza(), new zzk(this, arrayOfZzdtn, paramString), (Executor)this.zzk);
    zzfzp.zzc(new zzl(this, arrayOfZzdtn), (Executor)this.zzk);
    zzfyx zzfyx = zzfyx.zzv(zzfzp);
    zzbiu zzbiu = zzbjc.zzgG;
    return zzfzg.zzf(zzfzg.zzm(zzfzg.zzo((zzfzp)zzfyx, ((Integer)zzay.zzc().zzb(zzbiu)).intValue(), TimeUnit.MILLISECONDS, this.zzl), zzv.zza, (Executor)this.zzk), Exception.class, zzj.zza, (Executor)this.zzk);
  }
  
  private final void zzS(List paramList, IObjectWrapper paramIObjectWrapper, zzbzr paramzzbzr, boolean paramBoolean) {
    zzbiu zzbiu = zzbjc.zzgF;
    if (!((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue()) {
      zze.zzj("The updating URL feature is not enabled.");
      try {
        paramzzbzr.zze("The updating URL feature is not enabled.");
        return;
      } catch (RemoteException remoteException) {
        zzcgp.zzh("", (Throwable)remoteException);
        return;
      } 
    } 
    Iterator<Uri> iterator = remoteException.iterator();
    int i = 0;
    while (iterator.hasNext()) {
      if (zzN(iterator.next()))
        i++; 
    } 
    if (i > 1)
      zze.zzj("Multiple google urls found: ".concat(String.valueOf(String.valueOf(remoteException)))); 
    ArrayList<zzfzp> arrayList = new ArrayList();
    for (Uri uri : remoteException) {
      zzfzp zzfzp;
      if (!zzN(uri)) {
        zze.zzj("Not a Google URL: ".concat(String.valueOf(String.valueOf(uri))));
        zzfzp = zzfzg.zzi(uri);
      } else {
        zzfzp = this.zzk.zzb(new zzq(this, (Uri)zzfzp, paramIObjectWrapper));
        if (zzV()) {
          zzfzp = zzfzg.zzn(zzfzp, new zzr(this), (Executor)this.zzk);
        } else {
          zze.zzi("Asset view map is empty.");
        } 
      } 
      arrayList.add(zzfzp);
    } 
    zzfzg.zzr(zzfzg.zze(arrayList), new zzy(this, paramzzbzr, paramBoolean), this.zzf.zzA());
  }
  
  private final void zzT(List paramList, IObjectWrapper paramIObjectWrapper, zzbzr paramzzbzr, boolean paramBoolean) {
    zzbiu zzbiu = zzbjc.zzgF;
    if (!((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue())
      try {
        paramzzbzr.zze("The updating URL feature is not enabled.");
        return;
      } catch (RemoteException remoteException) {
        zzcgp.zzh("", (Throwable)remoteException);
        return;
      }  
    zzfzp zzfzp = this.zzk.zzb(new zzs(this, (List)remoteException, paramIObjectWrapper));
    if (zzV()) {
      zzfzp = zzfzg.zzn(zzfzp, new zzt(this), (Executor)this.zzk);
    } else {
      zze.zzi("Asset view map is empty.");
    } 
    zzfzg.zzr(zzfzp, new zzx(this, paramzzbzr, paramBoolean), this.zzf.zzA());
  }
  
  private static boolean zzU(Uri paramUri, List paramList1, List paramList2) {
    String str2 = paramUri.getHost();
    String str1 = paramUri.getPath();
    if (str2 != null) {
      if (str1 == null)
        return false; 
      Iterator<String> iterator = paramList1.iterator();
      while (iterator.hasNext()) {
        if (str1.contains(iterator.next())) {
          Iterator<String> iterator1 = paramList2.iterator();
          while (iterator1.hasNext()) {
            if (str2.endsWith(iterator1.next()))
              return true; 
          } 
        } 
      } 
    } 
    return false;
  }
  
  private final boolean zzV() {
    zzcaa zzcaa1 = this.zzm;
    if (zzcaa1 != null) {
      Map map = zzcaa1.zzb;
      if (map != null && !map.isEmpty())
        return true; 
    } 
    return false;
  }
  
  private static final Uri zzW(Uri paramUri, String paramString1, String paramString2) {
    StringBuilder stringBuilder;
    String str = paramUri.toString();
    int j = str.indexOf("&adurl=");
    int i = j;
    if (j == -1)
      i = str.indexOf("?adurl="); 
    if (i != -1) {
      stringBuilder = new StringBuilder(str.substring(0, ++i));
      stringBuilder.append(paramString1);
      stringBuilder.append("=");
      stringBuilder.append(paramString2);
      stringBuilder.append("&");
      stringBuilder.append(str.substring(i));
      return Uri.parse(stringBuilder.toString());
    } 
    return stringBuilder.buildUpon().appendQueryParameter(paramString1, paramString2).build();
  }
  
  private static final List zzX(String paramString) {
    String[] arrayOfString = TextUtils.split(paramString, ",");
    ArrayList<String> arrayList = new ArrayList();
    int j = arrayOfString.length;
    for (int i = 0; i < j; i++) {
      String str = arrayOfString[i];
      if (!zzftm.zzd(str))
        arrayList.add(str); 
    } 
    return arrayList;
  }
  
  final boolean zzN(Uri paramUri) {
    return zzU(paramUri, this.zzD, this.zzE);
  }
  
  final boolean zzO(Uri paramUri) {
    return zzU(paramUri, this.zzF, this.zzG);
  }
  
  public final void zze(IObjectWrapper paramIObjectWrapper, zzcfk paramzzcfk, zzcfd paramzzcfd) {
    zzfzp zzfzp1;
    zzfzp zzfzp2;
    Context context = (Context)ObjectWrapper.unwrap(paramIObjectWrapper);
    this.zzg = context;
    zzfjj zzfjj = zzfji.zza(context, 22);
    zzfjj.zzf();
    zzbiu zzbiu = zzbjc.zziH;
    if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue()) {
      zzfzp1 = zzchc.zza.zzb(new zzo(this, paramzzcfk));
      zzfzp2 = zzfzg.zzn(zzfzp1, zzp.zza, (Executor)zzchc.zza);
    } else {
      zzh zzh = zzQ(this.zzg, paramzzcfk.zza, paramzzcfk.zzb, paramzzcfk.zzc, paramzzcfk.zzd);
      zzfzp1 = zzfzg.zzi(zzh);
      zzfzp2 = zzh.zzc();
    } 
    zzfzg.zzr(zzfzp2, new zzw(this, zzfzp1, paramzzcfk, paramzzcfd, zzfjj, zzt.zzB().currentTimeMillis()), this.zzf.zzA());
  }
  
  public final void zzf(zzcaa paramzzcaa) {
    this.zzm = paramzzcaa;
    this.zzi.zzc(1);
  }
  
  public final void zzg(List paramList, IObjectWrapper paramIObjectWrapper, zzbzr paramzzbzr) {
    zzS(paramList, paramIObjectWrapper, paramzzbzr, true);
  }
  
  public final void zzh(List paramList, IObjectWrapper paramIObjectWrapper, zzbzr paramzzbzr) {
    zzT(paramList, paramIObjectWrapper, paramzzbzr, true);
  }
  
  public final void zzi(IObjectWrapper paramIObjectWrapper) {
    zzbiu zzbiu = zzbjc.zzib;
    if (!((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue())
      return; 
    if (Build.VERSION.SDK_INT < 21) {
      zze.zzj("Not registering the webview because the Android API level is lower than Lollopop which has security risks on webviews.");
      return;
    } 
    zzbiu = zzbjc.zzic;
    if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue()) {
      zzfzp zzfzp;
      zzbiu = zzbjc.zziH;
      if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue()) {
        zzfzp = zzfzg.zzl(new zzu(this), (Executor)zzchc.zza);
      } else {
        zzfzp = zzQ(this.zzg, null, AdFormat.BANNER.name(), null, null).zzc();
      } 
      zzfzg.zzr(zzfzp, new zzz(this), this.zzf.zzA());
    } 
    WebView webView = (WebView)ObjectWrapper.unwrap(paramIObjectWrapper);
    if (webView == null) {
      zze.zzg("The webView cannot be null.");
      return;
    } 
    if (this.zzp.contains(webView)) {
      zze.zzi("This webview has already been registered.");
      return;
    } 
    this.zzp.add(webView);
    webView.addJavascriptInterface(new TaggingLibraryJsInterface(webView, this.zzh, this.zzr), "gmaSdk");
  }
  
  public final void zzj(IObjectWrapper paramIObjectWrapper) {
    View view;
    zzbiu zzbiu = zzbjc.zzgF;
    if (!((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue())
      return; 
    MotionEvent motionEvent2 = (MotionEvent)ObjectWrapper.unwrap(paramIObjectWrapper);
    zzcaa zzcaa1 = this.zzm;
    if (zzcaa1 == null) {
      zzcaa1 = null;
    } else {
      view = zzcaa1.zza;
    } 
    this.zzn = zzbx.zza(motionEvent2, view);
    if (motionEvent2.getAction() == 0)
      this.zzo = this.zzn; 
    MotionEvent motionEvent1 = MotionEvent.obtain(motionEvent2);
    motionEvent1.setLocation(this.zzn.x, this.zzn.y);
    this.zzh.zzd(motionEvent1);
    motionEvent1.recycle();
  }
  
  public final void zzk(List paramList, IObjectWrapper paramIObjectWrapper, zzbzr paramzzbzr) {
    zzS(paramList, paramIObjectWrapper, paramzzbzr, false);
  }
  
  public final void zzl(List paramList, IObjectWrapper paramIObjectWrapper, zzbzr paramzzbzr) {
    zzT(paramList, paramIObjectWrapper, paramzzbzr, false);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\nonagon\signalgeneration\zzaa.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */