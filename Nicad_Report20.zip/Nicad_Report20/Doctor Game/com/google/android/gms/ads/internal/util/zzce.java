package com.google.android.gms.ads.internal.util;

import android.content.Context;

public final class zzce {
  private static zzce zzb;
  
  String zza;
  
  public static zzce zza() {
    if (zzb == null)
      zzb = new zzce(); 
    return zzb;
  }
  
  public final void zzb(Context paramContext) {
    // Byte code:
    //   0: ldc 'Updating user agent.'
    //   2: invokestatic zza : (Ljava/lang/String;)V
    //   5: aload_1
    //   6: invokestatic getDefaultUserAgent : (Landroid/content/Context;)Ljava/lang/String;
    //   9: astore #4
    //   11: aload #4
    //   13: aload_0
    //   14: getfield zza : Ljava/lang/String;
    //   17: invokevirtual equals : (Ljava/lang/Object;)Z
    //   20: ifne -> 94
    //   23: aload_1
    //   24: invokestatic getRemoteContext : (Landroid/content/Context;)Landroid/content/Context;
    //   27: astore_3
    //   28: aload_3
    //   29: astore_2
    //   30: invokestatic isPackageSide : ()Z
    //   33: ifne -> 42
    //   36: aload_3
    //   37: ifnonnull -> 88
    //   40: aconst_null
    //   41: astore_2
    //   42: aload_1
    //   43: invokestatic getDefaultUserAgent : (Landroid/content/Context;)Ljava/lang/String;
    //   46: astore_3
    //   47: aload_1
    //   48: ldc 'admob_user_agent'
    //   50: iconst_0
    //   51: invokevirtual getSharedPreferences : (Ljava/lang/String;I)Landroid/content/SharedPreferences;
    //   54: invokeinterface edit : ()Landroid/content/SharedPreferences$Editor;
    //   59: ldc 'user_agent'
    //   61: aload_3
    //   62: invokeinterface putString : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    //   67: astore_3
    //   68: aload_2
    //   69: ifnonnull -> 81
    //   72: aload_3
    //   73: invokeinterface apply : ()V
    //   78: goto -> 88
    //   81: aload_1
    //   82: aload_3
    //   83: ldc 'admob_user_agent'
    //   85: invokestatic publishWorldReadableSharedPreferences : (Landroid/content/Context;Landroid/content/SharedPreferences$Editor;Ljava/lang/String;)V
    //   88: aload_0
    //   89: aload #4
    //   91: putfield zza : Ljava/lang/String;
    //   94: ldc 'User agent is updated.'
    //   96: invokestatic zza : (Ljava/lang/String;)V
    //   99: return
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzce.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */