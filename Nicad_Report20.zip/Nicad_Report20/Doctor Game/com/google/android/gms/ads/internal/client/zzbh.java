package com.google.android.gms.ads.internal.client;

import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzasa;
import com.google.android.gms.internal.ads.zzasb;

public abstract class zzbh extends zzasa implements zzbi {
  public zzbh() {
    super("com.google.android.gms.ads.internal.client.IAdLoadCallback");
  }
  
  protected final boolean zzbI(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2) throws RemoteException {
    if (paramInt1 != 1) {
      if (paramInt1 != 2)
        return false; 
      zze zze = (zze)zzasb.zza(paramParcel1, zze.CREATOR);
      zzasb.zzc(paramParcel1);
      zzb(zze);
    } else {
      zzc();
    } 
    paramParcel2.writeNoException();
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzbh.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */