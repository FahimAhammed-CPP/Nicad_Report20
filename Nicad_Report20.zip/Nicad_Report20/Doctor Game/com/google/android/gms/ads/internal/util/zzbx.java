package com.google.android.gms.ads.internal.util;

import android.content.Context;
import android.graphics.Point;
import android.graphics.Rect;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.TextView;
import com.google.android.gms.ads.internal.client.zzaw;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.zzt;
import com.google.android.gms.internal.ads.zzbiu;
import com.google.android.gms.internal.ads.zzbjc;
import com.google.android.gms.internal.ads.zzfdk;
import com.google.android.gms.internal.ads.zzfsj;
import com.google.android.gms.internal.ads.zzftk;
import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public final class zzbx {
  public static Point zza(MotionEvent paramMotionEvent, View paramView) {
    int[] arrayOfInt = zzj(paramView);
    float f1 = paramMotionEvent.getRawX();
    int i = arrayOfInt[0];
    float f2 = paramMotionEvent.getRawY();
    int j = arrayOfInt[1];
    return new Point((int)f1 - i, (int)f2 - j);
  }
  
  public static WindowManager.LayoutParams zzb() {
    WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-2, -2, 0, 0, -2);
    zzbiu zzbiu = zzbjc.zzgS;
    layoutParams.flags = ((Integer)zzay.zzc().zzb(zzbiu)).intValue();
    layoutParams.type = 2;
    layoutParams.gravity = 8388659;
    return layoutParams;
  }
  
  public static JSONObject zzc(String paramString, Context paramContext, Point paramPoint1, Point paramPoint2) {
    JSONObject jSONObject1;
    JSONObject jSONObject2 = null;
    JSONException jSONException = null;
    try {
      JSONObject jSONObject = new JSONObject();
      try {
        jSONObject2 = new JSONObject();
        try {
          int i = paramPoint2.x;
          jSONObject2.put("x", zzaw.zzb().zzb(paramContext, i));
          i = paramPoint2.y;
          jSONObject2.put("y", zzaw.zzb().zzb(paramContext, i));
          i = paramPoint1.x;
          jSONObject2.put("start_x", zzaw.zzb().zzb(paramContext, i));
          i = paramPoint1.y;
          jSONObject2.put("start_y", zzaw.zzb().zzb(paramContext, i));
          JSONObject jSONObject3 = jSONObject2;
        } catch (JSONException jSONException1) {
          zze.zzh("Error occurred while putting signals into JSON object.", (Throwable)jSONException1);
          jSONException1 = jSONException;
        } 
        jSONObject.put("click_point", jSONException1);
        jSONObject.put("asset_id", paramString);
        return jSONObject;
      } catch (Exception null) {
        jSONObject1 = jSONObject;
      } 
    } catch (Exception exception) {
      jSONObject1 = jSONObject2;
    } 
    zze.zzh("Error occurred while grabbing click signals.", exception);
    return jSONObject1;
  }
  
  public static JSONObject zzd(Context paramContext, Map paramMap1, Map paramMap2, View paramView) {
    JSONObject jSONObject2 = new JSONObject();
    if (paramMap1 == null || paramView == null)
      return jSONObject2; 
    int[] arrayOfInt = zzj(paramView);
    Iterator<Map.Entry> iterator = paramMap1.entrySet().iterator();
    JSONObject jSONObject1 = jSONObject2;
    while (true) {
      if (iterator.hasNext()) {
        Map.Entry entry = iterator.next();
        View view = ((WeakReference<View>)entry.getValue()).get();
        if (view != null) {
          int[] arrayOfInt1 = zzj(view);
          JSONObject jSONObject = new JSONObject();
          jSONObject2 = new JSONObject();
          try {
            int i = view.getMeasuredWidth();
            try {
              boolean bool;
              JSONObject jSONObject3;
              jSONObject2.put("width", zzaw.zzb().zzb(paramContext, i));
              i = view.getMeasuredHeight();
              jSONObject2.put("height", zzaw.zzb().zzb(paramContext, i));
              i = arrayOfInt1[0];
              int j = arrayOfInt[0];
              jSONObject2.put("x", zzaw.zzb().zzb(paramContext, i - j));
              i = arrayOfInt1[1];
              j = arrayOfInt[1];
              jSONObject2.put("y", zzaw.zzb().zzb(paramContext, i - j));
              jSONObject2.put("relative_to", "ad_view");
              jSONObject.put("frame", jSONObject2);
              Rect rect = new Rect();
              if (view.getLocalVisibleRect(rect)) {
                jSONObject3 = zzk(paramContext, rect);
              } else {
                jSONObject3 = new JSONObject();
                jSONObject3.put("width", 0);
                jSONObject3.put("height", 0);
                i = arrayOfInt1[0];
                j = arrayOfInt[0];
                jSONObject3.put("x", zzaw.zzb().zzb(paramContext, i - j));
                i = arrayOfInt1[1];
                j = arrayOfInt[1];
                jSONObject3.put("y", zzaw.zzb().zzb(paramContext, i - j));
                jSONObject3.put("relative_to", "ad_view");
              } 
              jSONObject.put("visible_bounds", jSONObject3);
              if (((String)entry.getKey()).equals("3010")) {
                zzbiu zzbiu = zzbjc.zzgO;
                if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue())
                  jSONObject.put("mediaview_graphics_matrix", view.getMatrix().toShortString()); 
                zzbiu = zzbjc.zzgP;
                if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue()) {
                  ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
                  jSONObject.put("view_width_layout_type", zzl(layoutParams.width) - 1);
                  jSONObject.put("view_height_layout_type", zzl(layoutParams.height) - 1);
                } 
              } 
              if (view instanceof TextView) {
                TextView textView = (TextView)view;
                jSONObject.put("text_color", textView.getCurrentTextColor());
                jSONObject.put("font_size", textView.getTextSize());
                jSONObject.put("text", textView.getText());
              } 
              if (paramMap2 != null && paramMap2.containsKey(entry.getKey()) && view.isClickable()) {
                bool = true;
              } else {
                bool = false;
              } 
              jSONObject.put("is_clickable", bool);
              String str = (String)entry.getKey();
              try {
                jSONObject1.put(str, jSONObject);
                continue;
              } catch (JSONException jSONException) {}
            } catch (JSONException jSONException) {}
          } catch (JSONException jSONException) {}
          zze.zzj("Unable to get asset views information");
        } 
        continue;
      } 
      return jSONObject1;
    } 
  }
  
  public static JSONObject zze(Context paramContext, View paramView) {
    JSONObject jSONObject = new JSONObject();
    if (paramView == null)
      return jSONObject; 
    try {
      zzt.zzp();
      jSONObject.put("can_show_on_lock_screen", zzs.zzl(paramView));
      zzt.zzp();
      jSONObject.put("is_keyguard_locked", zzs.zzz(paramContext));
      return jSONObject;
    } catch (JSONException jSONException) {
      zze.zzj("Unable to get lock screen information");
      return jSONObject;
    } 
  }
  
  public static JSONObject zzf(View paramView) {
    boolean bool;
    JSONObject jSONObject = new JSONObject();
    if (paramView == null)
      return jSONObject; 
    try {
      ViewParent viewParent;
      zzbiu zzbiu = zzbjc.zzgN;
      boolean bool2 = ((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue();
      boolean bool1 = false;
      bool = false;
      if (bool2) {
        zzt.zzp();
        for (viewParent = paramView.getParent(); viewParent != null && !(viewParent instanceof android.widget.ScrollView); viewParent = viewParent.getParent());
      } else {
        int i;
        zzt.zzp();
        ViewParent viewParent1;
        for (viewParent1 = viewParent.getParent(); viewParent1 != null && !(viewParent1 instanceof AdapterView); viewParent1 = viewParent1.getParent());
        if (viewParent1 == null) {
          i = -1;
        } else {
          i = ((AdapterView)viewParent1).getPositionForView((View)viewParent);
        } 
        bool = bool1;
        if (i != -1)
          bool = true; 
        jSONObject.put("contained_in_scroll_view", bool);
        return jSONObject;
      } 
    } catch (Exception exception) {
      return jSONObject;
    } 
    if (exception != null)
      bool = true; 
    jSONObject.put("contained_in_scroll_view", bool);
    return jSONObject;
  }
  
  public static JSONObject zzg(Context paramContext, View paramView) {
    // Byte code:
    //   0: new org/json/JSONObject
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #4
    //   9: aload_1
    //   10: ifnonnull -> 16
    //   13: aload #4
    //   15: areturn
    //   16: aload_1
    //   17: invokestatic zzj : (Landroid/view/View;)[I
    //   20: astore #5
    //   22: iconst_2
    //   23: newarray int
    //   25: astore #6
    //   27: aload #6
    //   29: iconst_0
    //   30: aload_1
    //   31: invokevirtual getMeasuredWidth : ()I
    //   34: iastore
    //   35: aload #6
    //   37: iconst_1
    //   38: aload_1
    //   39: invokevirtual getMeasuredHeight : ()I
    //   42: iastore
    //   43: aload_1
    //   44: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   47: astore_3
    //   48: aload_3
    //   49: instanceof android/view/ViewGroup
    //   52: ifeq -> 103
    //   55: aload_3
    //   56: checkcast android/view/ViewGroup
    //   59: astore #7
    //   61: aload #6
    //   63: iconst_0
    //   64: aload #7
    //   66: invokevirtual getMeasuredWidth : ()I
    //   69: aload #6
    //   71: iconst_0
    //   72: iaload
    //   73: invokestatic min : (II)I
    //   76: iastore
    //   77: aload #6
    //   79: iconst_1
    //   80: aload #7
    //   82: invokevirtual getMeasuredHeight : ()I
    //   85: aload #6
    //   87: iconst_1
    //   88: iaload
    //   89: invokestatic min : (II)I
    //   92: iastore
    //   93: aload_3
    //   94: invokeinterface getParent : ()Landroid/view/ViewParent;
    //   99: astore_3
    //   100: goto -> 48
    //   103: new org/json/JSONObject
    //   106: dup
    //   107: invokespecial <init> : ()V
    //   110: astore_3
    //   111: aload_1
    //   112: invokevirtual getMeasuredWidth : ()I
    //   115: istore_2
    //   116: aload_3
    //   117: ldc 'width'
    //   119: invokestatic zzb : ()Lcom/google/android/gms/internal/ads/zzcgi;
    //   122: aload_0
    //   123: iload_2
    //   124: invokevirtual zzb : (Landroid/content/Context;I)I
    //   127: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   130: pop
    //   131: aload_1
    //   132: invokevirtual getMeasuredHeight : ()I
    //   135: istore_2
    //   136: aload_3
    //   137: ldc 'height'
    //   139: invokestatic zzb : ()Lcom/google/android/gms/internal/ads/zzcgi;
    //   142: aload_0
    //   143: iload_2
    //   144: invokevirtual zzb : (Landroid/content/Context;I)I
    //   147: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   150: pop
    //   151: aload #5
    //   153: iconst_0
    //   154: iaload
    //   155: istore_2
    //   156: aload_3
    //   157: ldc 'x'
    //   159: invokestatic zzb : ()Lcom/google/android/gms/internal/ads/zzcgi;
    //   162: aload_0
    //   163: iload_2
    //   164: invokevirtual zzb : (Landroid/content/Context;I)I
    //   167: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   170: pop
    //   171: aload #5
    //   173: iconst_1
    //   174: iaload
    //   175: istore_2
    //   176: aload_3
    //   177: ldc 'y'
    //   179: invokestatic zzb : ()Lcom/google/android/gms/internal/ads/zzcgi;
    //   182: aload_0
    //   183: iload_2
    //   184: invokevirtual zzb : (Landroid/content/Context;I)I
    //   187: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   190: pop
    //   191: aload #6
    //   193: iconst_0
    //   194: iaload
    //   195: istore_2
    //   196: aload_3
    //   197: ldc_w 'maximum_visible_width'
    //   200: invokestatic zzb : ()Lcom/google/android/gms/internal/ads/zzcgi;
    //   203: aload_0
    //   204: iload_2
    //   205: invokevirtual zzb : (Landroid/content/Context;I)I
    //   208: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   211: pop
    //   212: aload #6
    //   214: iconst_1
    //   215: iaload
    //   216: istore_2
    //   217: aload_3
    //   218: ldc_w 'maximum_visible_height'
    //   221: invokestatic zzb : ()Lcom/google/android/gms/internal/ads/zzcgi;
    //   224: aload_0
    //   225: iload_2
    //   226: invokevirtual zzb : (Landroid/content/Context;I)I
    //   229: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   232: pop
    //   233: aload_3
    //   234: ldc 'relative_to'
    //   236: ldc_w 'window'
    //   239: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   242: pop
    //   243: aload #4
    //   245: ldc 'frame'
    //   247: aload_3
    //   248: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   251: pop
    //   252: new android/graphics/Rect
    //   255: dup
    //   256: invokespecial <init> : ()V
    //   259: astore_3
    //   260: aload_1
    //   261: aload_3
    //   262: invokevirtual getGlobalVisibleRect : (Landroid/graphics/Rect;)Z
    //   265: ifeq -> 277
    //   268: aload_0
    //   269: aload_3
    //   270: invokestatic zzk : (Landroid/content/Context;Landroid/graphics/Rect;)Lorg/json/JSONObject;
    //   273: astore_0
    //   274: goto -> 353
    //   277: new org/json/JSONObject
    //   280: dup
    //   281: invokespecial <init> : ()V
    //   284: astore_3
    //   285: aload_3
    //   286: ldc 'width'
    //   288: iconst_0
    //   289: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   292: pop
    //   293: aload_3
    //   294: ldc 'height'
    //   296: iconst_0
    //   297: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   300: pop
    //   301: aload #5
    //   303: iconst_0
    //   304: iaload
    //   305: istore_2
    //   306: aload_3
    //   307: ldc 'x'
    //   309: invokestatic zzb : ()Lcom/google/android/gms/internal/ads/zzcgi;
    //   312: aload_0
    //   313: iload_2
    //   314: invokevirtual zzb : (Landroid/content/Context;I)I
    //   317: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   320: pop
    //   321: aload #5
    //   323: iconst_1
    //   324: iaload
    //   325: istore_2
    //   326: aload_3
    //   327: ldc 'y'
    //   329: invokestatic zzb : ()Lcom/google/android/gms/internal/ads/zzcgi;
    //   332: aload_0
    //   333: iload_2
    //   334: invokevirtual zzb : (Landroid/content/Context;I)I
    //   337: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   340: pop
    //   341: aload_3
    //   342: ldc 'relative_to'
    //   344: ldc_w 'window'
    //   347: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   350: pop
    //   351: aload_3
    //   352: astore_0
    //   353: aload #4
    //   355: ldc 'visible_bounds'
    //   357: aload_0
    //   358: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   361: pop
    //   362: goto -> 371
    //   365: ldc_w 'Unable to get native ad view bounding box'
    //   368: invokestatic zzj : (Ljava/lang/String;)V
    //   371: getstatic com/google/android/gms/internal/ads/zzbjc.zzfo : Lcom/google/android/gms/internal/ads/zzbiu;
    //   374: astore_0
    //   375: invokestatic zzc : ()Lcom/google/android/gms/internal/ads/zzbja;
    //   378: aload_0
    //   379: invokevirtual zzb : (Lcom/google/android/gms/internal/ads/zzbiu;)Ljava/lang/Object;
    //   382: checkcast java/lang/Boolean
    //   385: invokevirtual booleanValue : ()Z
    //   388: ifeq -> 559
    //   391: aload_1
    //   392: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   395: astore_0
    //   396: aload_0
    //   397: ifnull -> 445
    //   400: aload_0
    //   401: invokevirtual getClass : ()Ljava/lang/Class;
    //   404: ldc_w 'getTemplateTypeName'
    //   407: iconst_0
    //   408: anewarray java/lang/Class
    //   411: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   414: aload_0
    //   415: iconst_0
    //   416: anewarray java/lang/Object
    //   419: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   422: checkcast java/lang/String
    //   425: astore_0
    //   426: goto -> 449
    //   429: astore_0
    //   430: goto -> 438
    //   433: astore_0
    //   434: goto -> 438
    //   437: astore_0
    //   438: ldc_w 'Cannot access method getTemplateTypeName: '
    //   441: aload_0
    //   442: invokestatic zzh : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   445: ldc_w ''
    //   448: astore_0
    //   449: aload_0
    //   450: invokevirtual hashCode : ()I
    //   453: istore_2
    //   454: iload_2
    //   455: ldc_w -2066603854
    //   458: if_icmpeq -> 486
    //   461: iload_2
    //   462: ldc_w 2019754500
    //   465: if_icmpeq -> 471
    //   468: goto -> 501
    //   471: aload_0
    //   472: ldc_w 'medium_template'
    //   475: invokevirtual equals : (Ljava/lang/Object;)Z
    //   478: ifeq -> 501
    //   481: iconst_1
    //   482: istore_2
    //   483: goto -> 503
    //   486: aload_0
    //   487: ldc_w 'small_template'
    //   490: invokevirtual equals : (Ljava/lang/Object;)Z
    //   493: ifeq -> 501
    //   496: iconst_0
    //   497: istore_2
    //   498: goto -> 503
    //   501: iconst_m1
    //   502: istore_2
    //   503: iload_2
    //   504: ifeq -> 538
    //   507: iload_2
    //   508: iconst_1
    //   509: if_icmpeq -> 525
    //   512: aload #4
    //   514: ldc_w 'native_template_type'
    //   517: iconst_0
    //   518: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   521: pop
    //   522: goto -> 559
    //   525: aload #4
    //   527: ldc_w 'native_template_type'
    //   530: iconst_2
    //   531: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   534: pop
    //   535: goto -> 559
    //   538: aload #4
    //   540: ldc_w 'native_template_type'
    //   543: iconst_1
    //   544: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   547: pop
    //   548: goto -> 559
    //   551: astore_0
    //   552: ldc_w 'Could not log native template signal to JSON'
    //   555: aload_0
    //   556: invokestatic zzh : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   559: getstatic com/google/android/gms/internal/ads/zzbjc.zzgP : Lcom/google/android/gms/internal/ads/zzbiu;
    //   562: astore_0
    //   563: invokestatic zzc : ()Lcom/google/android/gms/internal/ads/zzbja;
    //   566: aload_0
    //   567: invokevirtual zzb : (Lcom/google/android/gms/internal/ads/zzbiu;)Ljava/lang/Object;
    //   570: checkcast java/lang/Boolean
    //   573: invokevirtual booleanValue : ()Z
    //   576: ifeq -> 627
    //   579: aload_1
    //   580: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   583: astore_0
    //   584: aload #4
    //   586: ldc 'view_width_layout_type'
    //   588: aload_0
    //   589: getfield width : I
    //   592: invokestatic zzl : (I)I
    //   595: iconst_1
    //   596: isub
    //   597: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   600: pop
    //   601: aload #4
    //   603: ldc 'view_height_layout_type'
    //   605: aload_0
    //   606: getfield height : I
    //   609: invokestatic zzl : (I)I
    //   612: iconst_1
    //   613: isub
    //   614: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   617: pop
    //   618: aload #4
    //   620: areturn
    //   621: ldc_w 'Unable to get native ad view layout types'
    //   624: invokestatic zza : (Ljava/lang/String;)V
    //   627: aload #4
    //   629: areturn
    //   630: astore_0
    //   631: goto -> 365
    //   634: astore_0
    //   635: goto -> 445
    //   638: astore_0
    //   639: goto -> 621
    // Exception table:
    //   from	to	target	type
    //   16	48	630	java/lang/Exception
    //   48	100	630	java/lang/Exception
    //   103	151	630	java/lang/Exception
    //   156	171	630	java/lang/Exception
    //   176	191	630	java/lang/Exception
    //   196	212	630	java/lang/Exception
    //   217	274	630	java/lang/Exception
    //   277	301	630	java/lang/Exception
    //   306	321	630	java/lang/Exception
    //   326	351	630	java/lang/Exception
    //   353	362	630	java/lang/Exception
    //   400	426	634	java/lang/NoSuchMethodException
    //   400	426	437	java/lang/SecurityException
    //   400	426	433	java/lang/IllegalAccessException
    //   400	426	429	java/lang/reflect/InvocationTargetException
    //   449	454	551	org/json/JSONException
    //   512	522	551	org/json/JSONException
    //   525	535	551	org/json/JSONException
    //   538	548	551	org/json/JSONException
    //   579	618	638	java/lang/Exception
  }
  
  public static boolean zzh(Context paramContext, zzfdk paramzzfdk) {
    zzbiu zzbiu1;
    if (!paramzzfdk.zzO)
      return false; 
    zzbiu zzbiu2 = zzbjc.zzgQ;
    if (((Boolean)zzay.zzc().zzb(zzbiu2)).booleanValue()) {
      zzbiu1 = zzbjc.zzgT;
      return ((Boolean)zzay.zzc().zzb(zzbiu1)).booleanValue();
    } 
    zzbiu2 = zzbjc.zzgR;
    String str = (String)zzay.zzc().zzb(zzbiu2);
    if (!str.isEmpty()) {
      if (zzbiu1 == null)
        return false; 
      String str1 = zzbiu1.getPackageName();
      Iterator<String> iterator = zzftk.zzc(zzfsj.zzc(';')).zzd(str).iterator();
      while (iterator.hasNext()) {
        if (((String)iterator.next()).equals(str1))
          return true; 
      } 
    } 
    return false;
  }
  
  public static boolean zzi(int paramInt) {
    zzbiu zzbiu = zzbjc.zzcG;
    if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue()) {
      zzbiu = zzbjc.zzcH;
      if (!((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue() && paramInt > 15299999)
        return false; 
    } 
    return true;
  }
  
  public static int[] zzj(View paramView) {
    int[] arrayOfInt = new int[2];
    if (paramView != null)
      paramView.getLocationOnScreen(arrayOfInt); 
    return arrayOfInt;
  }
  
  private static JSONObject zzk(Context paramContext, Rect paramRect) throws JSONException {
    JSONObject jSONObject = new JSONObject();
    int i = paramRect.right;
    int j = paramRect.left;
    jSONObject.put("width", zzaw.zzb().zzb(paramContext, i - j));
    i = paramRect.bottom;
    j = paramRect.top;
    jSONObject.put("height", zzaw.zzb().zzb(paramContext, i - j));
    i = paramRect.left;
    jSONObject.put("x", zzaw.zzb().zzb(paramContext, i));
    i = paramRect.top;
    jSONObject.put("y", zzaw.zzb().zzb(paramContext, i));
    jSONObject.put("relative_to", "self");
    return jSONObject;
  }
  
  private static int zzl(int paramInt) {
    return (paramInt != -2) ? ((paramInt != -1) ? 2 : 3) : 4;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzbx.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */