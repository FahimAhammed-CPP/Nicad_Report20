package com.google.android.gms.ads.internal.client;

import android.os.Bundle;
import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.internal.ads.zzcci;
import com.google.android.gms.internal.ads.zzcck;
import com.google.android.gms.internal.ads.zzcco;
import com.google.android.gms.internal.ads.zzccs;
import com.google.android.gms.internal.ads.zzcct;
import com.google.android.gms.internal.ads.zzccz;
import com.google.android.gms.internal.ads.zzcgi;
import com.google.android.gms.internal.ads.zzcgp;

public final class zzew extends zzcck {
  private static void zzr(zzccs paramzzccs) {
    zzcgp.zzg("This app is using a lightweight version of the Google Mobile Ads SDK that requires the latest Google Play services to be installed, but Google Play services is either missing or out of date.");
    zzcgi.zza.post(new zzev(paramzzccs));
  }
  
  public final Bundle zzb() throws RemoteException {
    return new Bundle();
  }
  
  public final zzdh zzc() {
    return null;
  }
  
  public final zzcci zzd() {
    return null;
  }
  
  public final String zze() throws RemoteException {
    return "";
  }
  
  public final void zzf(zzl paramzzl, zzccs paramzzccs) throws RemoteException {
    zzr(paramzzccs);
  }
  
  public final void zzg(zzl paramzzl, zzccs paramzzccs) throws RemoteException {
    zzr(paramzzccs);
  }
  
  public final void zzh(boolean paramBoolean) {}
  
  public final void zzi(zzdb paramzzdb) throws RemoteException {}
  
  public final void zzj(zzde paramzzde) {}
  
  public final void zzk(zzcco paramzzcco) throws RemoteException {}
  
  public final void zzl(zzccz paramzzccz) {}
  
  public final void zzm(IObjectWrapper paramIObjectWrapper) throws RemoteException {}
  
  public final void zzn(IObjectWrapper paramIObjectWrapper, boolean paramBoolean) {}
  
  public final boolean zzo() throws RemoteException {
    return false;
  }
  
  public final void zzp(zzcct paramzzcct) throws RemoteException {}
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzew.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */