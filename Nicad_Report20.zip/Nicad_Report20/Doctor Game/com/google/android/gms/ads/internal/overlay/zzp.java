package com.google.android.gms.ads.internal.overlay;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

final class zzp extends AnimatorListenerAdapter {
  zzp(zzr paramzzr) {}
  
  private final void zza(boolean paramBoolean) {
    this.zza.setClickable(paramBoolean);
    zzr.zza(this.zza).setClickable(paramBoolean);
  }
  
  public final void onAnimationCancel(Animator paramAnimator) {
    zza(true);
  }
  
  public final void onAnimationEnd(Animator paramAnimator) {
    zza(true);
  }
  
  public final void onAnimationStart(Animator paramAnimator) {
    zza(false);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\overlay\zzp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */