package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.internal.ads.zzarz;
import com.google.android.gms.internal.ads.zzasb;
import com.google.android.gms.internal.ads.zzbvk;

public final class zzbp extends zzarz implements IInterface {
  zzbp(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IAdLoaderBuilderCreator");
  }
  
  public final IBinder zze(IObjectWrapper paramIObjectWrapper, String paramString, zzbvk paramzzbvk, int paramInt) throws RemoteException {
    Parcel parcel2 = zza();
    zzasb.zzg(parcel2, (IInterface)paramIObjectWrapper);
    parcel2.writeString(paramString);
    zzasb.zzg(parcel2, (IInterface)paramzzbvk);
    parcel2.writeInt(223104000);
    Parcel parcel1 = zzbk(1, parcel2);
    IBinder iBinder = parcel1.readStrongBinder();
    parcel1.recycle();
    return iBinder;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzbp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */