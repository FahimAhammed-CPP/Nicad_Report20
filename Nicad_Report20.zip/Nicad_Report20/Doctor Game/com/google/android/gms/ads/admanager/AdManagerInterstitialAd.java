package com.google.android.gms.ads.admanager;

import android.content.Context;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.internal.ads.zzbiu;
import com.google.android.gms.internal.ads.zzbjc;
import com.google.android.gms.internal.ads.zzbkq;
import com.google.android.gms.internal.ads.zzbsm;
import com.google.android.gms.internal.ads.zzcge;

public abstract class AdManagerInterstitialAd extends InterstitialAd {
  public static void load(Context paramContext, String paramString, AdManagerAdRequest paramAdManagerAdRequest, AdManagerInterstitialAdLoadCallback paramAdManagerInterstitialAdLoadCallback) {
    Preconditions.checkNotNull(paramContext, "Context cannot be null.");
    Preconditions.checkNotNull(paramString, "AdUnitId cannot be null.");
    Preconditions.checkNotNull(paramAdManagerAdRequest, "AdManagerAdRequest cannot be null.");
    Preconditions.checkNotNull(paramAdManagerInterstitialAdLoadCallback, "LoadCallback cannot be null.");
    Preconditions.checkMainThread("#008 Must be called on the main UI thread.");
    zzbjc.zzc(paramContext);
    if (((Boolean)zzbkq.zzi.zze()).booleanValue()) {
      zzbiu zzbiu = zzbjc.zziM;
      if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue()) {
        zzcge.zzb.execute(new zzc(paramContext, paramString, paramAdManagerAdRequest, paramAdManagerInterstitialAdLoadCallback));
        return;
      } 
    } 
    (new zzbsm(paramContext, paramString)).zza(paramAdManagerAdRequest.zza(), paramAdManagerInterstitialAdLoadCallback);
  }
  
  public abstract AppEventListener getAppEventListener();
  
  public abstract void setAppEventListener(AppEventListener paramAppEventListener);
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\admanager\AdManagerInterstitialAd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */