package com.google.android.gms.ads.internal.util;

import android.net.Uri;
import com.google.android.gms.ads.internal.zzt;
import com.google.android.gms.internal.ads.zzfpz;
import java.util.concurrent.Callable;



/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */