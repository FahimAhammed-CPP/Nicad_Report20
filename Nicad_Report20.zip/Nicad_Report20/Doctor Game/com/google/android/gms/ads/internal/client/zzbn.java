package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.ads.formats.AdManagerAdViewOptions;
import com.google.android.gms.ads.formats.PublisherAdViewOptions;
import com.google.android.gms.internal.ads.zzasa;
import com.google.android.gms.internal.ads.zzasb;
import com.google.android.gms.internal.ads.zzbls;
import com.google.android.gms.internal.ads.zzbnb;
import com.google.android.gms.internal.ads.zzbnc;
import com.google.android.gms.internal.ads.zzbne;
import com.google.android.gms.internal.ads.zzbnf;
import com.google.android.gms.internal.ads.zzbnh;
import com.google.android.gms.internal.ads.zzbni;
import com.google.android.gms.internal.ads.zzbnk;
import com.google.android.gms.internal.ads.zzbnl;
import com.google.android.gms.internal.ads.zzbno;
import com.google.android.gms.internal.ads.zzbnp;
import com.google.android.gms.internal.ads.zzbnr;
import com.google.android.gms.internal.ads.zzbns;
import com.google.android.gms.internal.ads.zzbsc;
import com.google.android.gms.internal.ads.zzbsk;
import com.google.android.gms.internal.ads.zzbsl;

public abstract class zzbn extends zzasa implements zzbo {
  public zzbn() {
    super("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
  }
  
  protected final boolean zzbI(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2) throws RemoteException {
    zzbsl zzbsl;
    zzbsc zzbsc;
    zzbns zzbns;
    PublisherAdViewOptions publisherAdViewOptions;
    zzbnp zzbnp;
    IInterface iInterface;
    zzbls zzbls;
    String str;
    zzbnf zzbnf;
    zzbnc zzbnc;
    IBinder iBinder1;
    zzbnl zzbnl1;
    zzbf zzbf;
    IBinder iBinder2;
    zzbnl zzbnl2;
    zzbni zzbni;
    zzq zzq = null;
    AdManagerAdViewOptions adManagerAdViewOptions = null;
    switch (paramInt1) {
      default:
        return false;
      case 15:
        adManagerAdViewOptions = (AdManagerAdViewOptions)zzasb.zza(paramParcel1, AdManagerAdViewOptions.CREATOR);
        zzasb.zzc(paramParcel1);
        zzm(adManagerAdViewOptions);
        paramParcel2.writeNoException();
        return true;
      case 14:
        zzbsl = zzbsk.zzb(paramParcel1.readStrongBinder());
        zzasb.zzc(paramParcel1);
        zzi(zzbsl);
        paramParcel2.writeNoException();
        return true;
      case 13:
        zzbsc = (zzbsc)zzasb.zza(paramParcel1, zzbsc.CREATOR);
        zzasb.zzc(paramParcel1);
        zzn(zzbsc);
        paramParcel2.writeNoException();
        return true;
      case 10:
        zzbns = zzbnr.zzb(paramParcel1.readStrongBinder());
        zzasb.zzc(paramParcel1);
        zzk(zzbns);
        paramParcel2.writeNoException();
        return true;
      case 9:
        publisherAdViewOptions = (PublisherAdViewOptions)zzasb.zza(paramParcel1, PublisherAdViewOptions.CREATOR);
        zzasb.zzc(paramParcel1);
        zzp(publisherAdViewOptions);
        paramParcel2.writeNoException();
        return true;
      case 8:
        zzbnp = zzbno.zzb(paramParcel1.readStrongBinder());
        zzq = (zzq)zzasb.zza(paramParcel1, zzq.CREATOR);
        zzasb.zzc(paramParcel1);
        zzj(zzbnp, zzq);
        paramParcel2.writeNoException();
        return true;
      case 7:
        iBinder2 = paramParcel1.readStrongBinder();
        if (iBinder2 != null) {
          iInterface = iBinder2.queryLocalInterface("com.google.android.gms.ads.internal.client.ICorrelationIdProvider");
          if (iInterface instanceof zzcd) {
            iInterface = iInterface;
          } else {
            iInterface = new zzcd(iBinder2);
          } 
        } 
        zzasb.zzc(paramParcel1);
        zzq((zzcd)iInterface);
        paramParcel2.writeNoException();
        return true;
      case 6:
        zzbls = (zzbls)zzasb.zza(paramParcel1, zzbls.CREATOR);
        zzasb.zzc(paramParcel1);
        zzo(zzbls);
        paramParcel2.writeNoException();
        return true;
      case 5:
        str = paramParcel1.readString();
        zzbnl2 = zzbnk.zzb(paramParcel1.readStrongBinder());
        zzbni = zzbnh.zzb(paramParcel1.readStrongBinder());
        zzasb.zzc(paramParcel1);
        zzh(str, zzbnl2, zzbni);
        paramParcel2.writeNoException();
        return true;
      case 4:
        zzbnf = zzbne.zzb(paramParcel1.readStrongBinder());
        zzasb.zzc(paramParcel1);
        zzg(zzbnf);
        paramParcel2.writeNoException();
        return true;
      case 3:
        zzbnc = zzbnb.zzb(paramParcel1.readStrongBinder());
        zzasb.zzc(paramParcel1);
        zzf(zzbnc);
        paramParcel2.writeNoException();
        return true;
      case 2:
        iBinder1 = paramParcel1.readStrongBinder();
        if (iBinder1 == null) {
          zzbnl1 = zzbnl2;
        } else {
          IInterface iInterface1 = zzbnl1.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdListener");
          if (iInterface1 instanceof zzbf) {
            zzbf = (zzbf)iInterface1;
          } else {
            zzbf = new zzbd((IBinder)zzbf);
          } 
        } 
        zzasb.zzc(paramParcel1);
        zzl(zzbf);
        paramParcel2.writeNoException();
        return true;
      case 1:
        break;
    } 
    zzbl zzbl = zze();
    paramParcel2.writeNoException();
    zzasb.zzg(paramParcel2, zzbl);
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzbn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */