package com.google.android.gms.ads;

import com.google.android.gms.common.Feature;

public final class zzg {
  public static final Feature zza;
  
  public static final Feature[] zzb;
  
  static {
    Feature feature = new Feature("additional_video_csi", 1L);
    zza = feature;
    zzb = new Feature[] { feature };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\zzg.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */