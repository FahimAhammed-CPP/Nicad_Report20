package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzarz;
import com.google.android.gms.internal.ads.zzasb;

public final class zzdc extends zzarz implements zzde {
  zzdc(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IOnPaidEventListener");
  }
  
  public final void zze(zzs paramzzs) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zze(parcel, (Parcelable)paramzzs);
    zzbl(1, parcel);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzdc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */