package com.google.android.gms.ads.nonagon.signalgeneration;

import com.google.android.gms.internal.ads.zzgxi;

public final class zzah implements zzgxi {
  private final zzae zza;
  
  public zzah(zzae paramzzae) {
    this.zza = paramzzae;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\nonagon\signalgeneration\zzah.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */