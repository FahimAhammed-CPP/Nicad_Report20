package com.google.android.gms.ads.internal.util;

import android.content.Context;
import com.google.android.gms.internal.ads.zzcaf;
import com.google.android.gms.internal.ads.zzcgp;
import java.util.concurrent.Callable;

public final class zzcb {
  @Deprecated
  public static Object zza(Context paramContext, Callable<Callable> paramCallable) {
    try {
    
    } finally {
      paramCallable = null;
      zzcgp.zzh("Unexpected exception.", (Throwable)paramCallable);
      zzcaf.zza(paramContext).zzd((Throwable)paramCallable, "StrictModeUtil.runWithLaxStrictMode");
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzcb.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */