package com.google.android.gms.ads.internal.client;

import android.content.Context;
import android.os.RemoteException;
import com.google.android.gms.ads.AdInspectorError;
import com.google.android.gms.ads.OnAdInspectorClosedListener;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.ads.initialization.AdapterStatus;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.dynamic.ObjectWrapper;
import com.google.android.gms.internal.ads.zzbrq;
import com.google.android.gms.internal.ads.zzbry;
import com.google.android.gms.internal.ads.zzbrz;
import com.google.android.gms.internal.ads.zzbvd;
import com.google.android.gms.internal.ads.zzcgp;
import com.google.android.gms.internal.ads.zzftm;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.annotation.Nullable;

public final class zzed {
  private static zzed zza;
  
  private final Object zzb = new Object();
  
  private final ArrayList zzc = new ArrayList();
  
  private boolean zzd = false;
  
  private boolean zze = false;
  
  private final Object zzf = new Object();
  
  private zzcm zzg;
  
  @Nullable
  private OnAdInspectorClosedListener zzh = null;
  
  private RequestConfiguration zzi = (new RequestConfiguration.Builder()).build();
  
  public static zzed zzf() {
    // Byte code:
    //   0: ldc com/google/android/gms/ads/internal/client/zzed
    //   2: monitorenter
    //   3: getstatic com/google/android/gms/ads/internal/client/zzed.zza : Lcom/google/android/gms/ads/internal/client/zzed;
    //   6: ifnonnull -> 19
    //   9: new com/google/android/gms/ads/internal/client/zzed
    //   12: dup
    //   13: invokespecial <init> : ()V
    //   16: putstatic com/google/android/gms/ads/internal/client/zzed.zza : Lcom/google/android/gms/ads/internal/client/zzed;
    //   19: getstatic com/google/android/gms/ads/internal/client/zzed.zza : Lcom/google/android/gms/ads/internal/client/zzed;
    //   22: astore_0
    //   23: ldc com/google/android/gms/ads/internal/client/zzed
    //   25: monitorexit
    //   26: aload_0
    //   27: areturn
    //   28: astore_0
    //   29: ldc com/google/android/gms/ads/internal/client/zzed
    //   31: monitorexit
    //   32: aload_0
    //   33: athrow
    // Exception table:
    //   from	to	target	type
    //   3	19	28	finally
    //   19	26	28	finally
    //   29	32	28	finally
  }
  
  private static InitializationStatus zzw(List paramList) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    for (zzbrq zzbrq : paramList) {
      AdapterStatus.State state;
      String str = zzbrq.zza;
      if (zzbrq.zzb) {
        state = AdapterStatus.State.READY;
      } else {
        state = AdapterStatus.State.NOT_READY;
      } 
      hashMap.put(str, new zzbry(state, zzbrq.zzd, zzbrq.zzc));
    } 
    return (InitializationStatus)new zzbrz(hashMap);
  }
  
  private final void zzx(Context paramContext, @Nullable String paramString, @Nullable OnInitializationCompleteListener paramOnInitializationCompleteListener) {
    try {
      zzbvd.zza().zzb(paramContext, null);
      this.zzg.zzj();
      this.zzg.zzk(null, ObjectWrapper.wrap(null));
      return;
    } catch (RemoteException remoteException) {
      zzcgp.zzk("MobileAdsSettingManager initialization failed", (Throwable)remoteException);
      return;
    } 
  }
  
  private final void zzy(Context paramContext) {
    if (this.zzg == null)
      this.zzg = (zzcm)(new zzao(zzaw.zza(), paramContext)).zzd(paramContext, false); 
  }
  
  private final void zzz(RequestConfiguration paramRequestConfiguration) {
    try {
      this.zzg.zzs(new zzez(paramRequestConfiguration));
      return;
    } catch (RemoteException remoteException) {
      zzcgp.zzh("Unable to set request configuration parcel.", (Throwable)remoteException);
      return;
    } 
  }
  
  public final float zza() {
    synchronized (this.zzf) {
      zzcm zzcm1 = this.zzg;
      float f = 1.0F;
      if (zzcm1 == null)
        return 1.0F; 
      try {
        float f1 = zzcm1.zze();
        f = f1;
      } catch (RemoteException remoteException) {
        zzcgp.zzh("Unable to get app volume.", (Throwable)remoteException);
      } 
      return f;
    } 
  }
  
  public final RequestConfiguration zzc() {
    return this.zzi;
  }
  
  public final InitializationStatus zze() {
    synchronized (this.zzf) {
      boolean bool;
      if (this.zzg != null) {
        bool = true;
      } else {
        bool = false;
      } 
      Preconditions.checkState(bool, "MobileAds.initialize() must be called prior to getting initialization status.");
      try {
        return zzw(this.zzg.zzg());
      } catch (RemoteException remoteException) {}
      zzcgp.zzg("Unable to get Initialization status.");
      return new zzdv(this);
    } 
  }
  
  @Deprecated
  public final String zzh() {
    synchronized (this.zzf) {
      boolean bool;
      if (this.zzg != null) {
        bool = true;
      } else {
        bool = false;
      } 
      Preconditions.checkState(bool, "MobileAds.initialize() must be called prior to getting version string.");
      try {
        return zzftm.zzc(this.zzg.zzf());
      } catch (RemoteException remoteException) {
        zzcgp.zzh("Unable to get version string.", (Throwable)remoteException);
        return "";
      } 
    } 
  }
  
  public final void zzl(Context paramContext) {
    synchronized (this.zzf) {
      zzy(paramContext);
      try {
        this.zzg.zzi();
      } catch (RemoteException remoteException) {
        zzcgp.zzg("Unable to disable mediation adapter initialization.");
      } 
      return;
    } 
  }
  
  public final void zzm(Context paramContext, @Nullable String paramString, @Nullable OnInitializationCompleteListener paramOnInitializationCompleteListener) {
    // Byte code:
    //   0: aload_0
    //   1: getfield zzb : Ljava/lang/Object;
    //   4: astore_2
    //   5: aload_2
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield zzd : Z
    //   11: ifeq -> 30
    //   14: aload_3
    //   15: ifnull -> 27
    //   18: aload_0
    //   19: getfield zzc : Ljava/util/ArrayList;
    //   22: aload_3
    //   23: invokevirtual add : (Ljava/lang/Object;)Z
    //   26: pop
    //   27: aload_2
    //   28: monitorexit
    //   29: return
    //   30: aload_0
    //   31: getfield zze : Z
    //   34: ifeq -> 54
    //   37: aload_3
    //   38: ifnull -> 51
    //   41: aload_3
    //   42: aload_0
    //   43: invokevirtual zze : ()Lcom/google/android/gms/ads/initialization/InitializationStatus;
    //   46: invokeinterface onInitializationComplete : (Lcom/google/android/gms/ads/initialization/InitializationStatus;)V
    //   51: aload_2
    //   52: monitorexit
    //   53: return
    //   54: aload_0
    //   55: iconst_1
    //   56: putfield zzd : Z
    //   59: aload_3
    //   60: ifnull -> 72
    //   63: aload_0
    //   64: getfield zzc : Ljava/util/ArrayList;
    //   67: aload_3
    //   68: invokevirtual add : (Ljava/lang/Object;)Z
    //   71: pop
    //   72: aload_2
    //   73: monitorexit
    //   74: aload_1
    //   75: ifnull -> 316
    //   78: aload_0
    //   79: getfield zzf : Ljava/lang/Object;
    //   82: astore_2
    //   83: aload_2
    //   84: monitorenter
    //   85: aload_0
    //   86: aload_1
    //   87: invokespecial zzy : (Landroid/content/Context;)V
    //   90: aload_0
    //   91: getfield zzg : Lcom/google/android/gms/ads/internal/client/zzcm;
    //   94: new com/google/android/gms/ads/internal/client/zzec
    //   97: dup
    //   98: aload_0
    //   99: aconst_null
    //   100: invokespecial <init> : (Lcom/google/android/gms/ads/internal/client/zzed;Lcom/google/android/gms/ads/internal/client/zzeb;)V
    //   103: invokeinterface zzr : (Lcom/google/android/gms/internal/ads/zzbrx;)V
    //   108: aload_0
    //   109: getfield zzg : Lcom/google/android/gms/ads/internal/client/zzcm;
    //   112: new com/google/android/gms/internal/ads/zzbvh
    //   115: dup
    //   116: invokespecial <init> : ()V
    //   119: invokeinterface zzn : (Lcom/google/android/gms/internal/ads/zzbvk;)V
    //   124: aload_0
    //   125: getfield zzi : Lcom/google/android/gms/ads/RequestConfiguration;
    //   128: invokevirtual getTagForChildDirectedTreatment : ()I
    //   131: iconst_m1
    //   132: if_icmpne -> 146
    //   135: aload_0
    //   136: getfield zzi : Lcom/google/android/gms/ads/RequestConfiguration;
    //   139: invokevirtual getTagForUnderAgeOfConsent : ()I
    //   142: iconst_m1
    //   143: if_icmpeq -> 170
    //   146: aload_0
    //   147: aload_0
    //   148: getfield zzi : Lcom/google/android/gms/ads/RequestConfiguration;
    //   151: invokespecial zzz : (Lcom/google/android/gms/ads/RequestConfiguration;)V
    //   154: goto -> 170
    //   157: astore_1
    //   158: goto -> 312
    //   161: astore #4
    //   163: ldc 'MobileAdsSettingManager initialization failed'
    //   165: aload #4
    //   167: invokestatic zzk : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   170: aload_1
    //   171: invokestatic zzc : (Landroid/content/Context;)V
    //   174: getstatic com/google/android/gms/internal/ads/zzbkq.zza : Lcom/google/android/gms/internal/ads/zzbke;
    //   177: invokevirtual zze : ()Ljava/lang/Object;
    //   180: checkcast java/lang/Boolean
    //   183: invokevirtual booleanValue : ()Z
    //   186: ifeq -> 237
    //   189: getstatic com/google/android/gms/internal/ads/zzbjc.zziL : Lcom/google/android/gms/internal/ads/zzbiu;
    //   192: astore #4
    //   194: invokestatic zzc : ()Lcom/google/android/gms/internal/ads/zzbja;
    //   197: aload #4
    //   199: invokevirtual zzb : (Lcom/google/android/gms/internal/ads/zzbiu;)Ljava/lang/Object;
    //   202: checkcast java/lang/Boolean
    //   205: invokevirtual booleanValue : ()Z
    //   208: ifeq -> 237
    //   211: ldc_w 'Initializing on bg thread'
    //   214: invokestatic zze : (Ljava/lang/String;)V
    //   217: getstatic com/google/android/gms/internal/ads/zzcge.zza : Ljava/util/concurrent/ThreadPoolExecutor;
    //   220: new com/google/android/gms/ads/internal/client/zzdw
    //   223: dup
    //   224: aload_0
    //   225: aload_1
    //   226: aconst_null
    //   227: aload_3
    //   228: invokespecial <init> : (Lcom/google/android/gms/ads/internal/client/zzed;Landroid/content/Context;Ljava/lang/String;Lcom/google/android/gms/ads/initialization/OnInitializationCompleteListener;)V
    //   231: invokevirtual execute : (Ljava/lang/Runnable;)V
    //   234: goto -> 309
    //   237: getstatic com/google/android/gms/internal/ads/zzbkq.zzb : Lcom/google/android/gms/internal/ads/zzbke;
    //   240: invokevirtual zze : ()Ljava/lang/Object;
    //   243: checkcast java/lang/Boolean
    //   246: invokevirtual booleanValue : ()Z
    //   249: ifeq -> 296
    //   252: getstatic com/google/android/gms/internal/ads/zzbjc.zziL : Lcom/google/android/gms/internal/ads/zzbiu;
    //   255: astore #4
    //   257: invokestatic zzc : ()Lcom/google/android/gms/internal/ads/zzbja;
    //   260: aload #4
    //   262: invokevirtual zzb : (Lcom/google/android/gms/internal/ads/zzbiu;)Ljava/lang/Object;
    //   265: checkcast java/lang/Boolean
    //   268: invokevirtual booleanValue : ()Z
    //   271: ifeq -> 296
    //   274: getstatic com/google/android/gms/internal/ads/zzcge.zzb : Ljava/util/concurrent/ExecutorService;
    //   277: new com/google/android/gms/ads/internal/client/zzdx
    //   280: dup
    //   281: aload_0
    //   282: aload_1
    //   283: aconst_null
    //   284: aload_3
    //   285: invokespecial <init> : (Lcom/google/android/gms/ads/internal/client/zzed;Landroid/content/Context;Ljava/lang/String;Lcom/google/android/gms/ads/initialization/OnInitializationCompleteListener;)V
    //   288: invokeinterface execute : (Ljava/lang/Runnable;)V
    //   293: goto -> 309
    //   296: ldc_w 'Initializing on calling thread'
    //   299: invokestatic zze : (Ljava/lang/String;)V
    //   302: aload_0
    //   303: aload_1
    //   304: aconst_null
    //   305: aload_3
    //   306: invokespecial zzx : (Landroid/content/Context;Ljava/lang/String;Lcom/google/android/gms/ads/initialization/OnInitializationCompleteListener;)V
    //   309: aload_2
    //   310: monitorexit
    //   311: return
    //   312: aload_2
    //   313: monitorexit
    //   314: aload_1
    //   315: athrow
    //   316: new java/lang/IllegalArgumentException
    //   319: dup
    //   320: ldc_w 'Context cannot be null.'
    //   323: invokespecial <init> : (Ljava/lang/String;)V
    //   326: athrow
    //   327: astore_1
    //   328: aload_2
    //   329: monitorexit
    //   330: aload_1
    //   331: athrow
    // Exception table:
    //   from	to	target	type
    //   7	14	327	finally
    //   18	27	327	finally
    //   27	29	327	finally
    //   30	37	327	finally
    //   41	51	327	finally
    //   51	53	327	finally
    //   54	59	327	finally
    //   63	72	327	finally
    //   72	74	327	finally
    //   85	146	161	android/os/RemoteException
    //   85	146	157	finally
    //   146	154	161	android/os/RemoteException
    //   146	154	157	finally
    //   163	170	157	finally
    //   170	234	157	finally
    //   237	293	157	finally
    //   296	309	157	finally
    //   309	311	157	finally
    //   312	314	157	finally
    //   328	330	327	finally
  }
  
  public final void zzp(Context paramContext, OnAdInspectorClosedListener paramOnAdInspectorClosedListener) {
    synchronized (this.zzf) {
      zzy(paramContext);
      this.zzh = paramOnAdInspectorClosedListener;
      try {
        this.zzg.zzl(new zzea(null));
      } catch (RemoteException remoteException) {
        zzcgp.zzg("Unable to open the ad inspector.");
        if (paramOnAdInspectorClosedListener != null)
          paramOnAdInspectorClosedListener.onAdInspectorClosed(new AdInspectorError(0, "Ad inspector had an internal error.", "com.google.android.gms.ads")); 
      } 
      return;
    } 
  }
  
  public final void zzq(Context paramContext, String paramString) {
    synchronized (this.zzf) {
      boolean bool;
      if (this.zzg != null) {
        bool = true;
      } else {
        bool = false;
      } 
      Preconditions.checkState(bool, "MobileAds.initialize() must be called prior to opening debug menu.");
      try {
        this.zzg.zzm(ObjectWrapper.wrap(paramContext), paramString);
      } catch (RemoteException remoteException) {
        zzcgp.zzh("Unable to open debug menu.", (Throwable)remoteException);
      } 
      return;
    } 
  }
  
  public final void zzr(Class paramClass) {
    Object object = this.zzf;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
    try {
      this.zzg.zzh(paramClass.getCanonicalName());
    } catch (RemoteException remoteException) {
      zzcgp.zzh("Unable to register RtbAdapter", (Throwable)remoteException);
    } finally {}
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
  }
  
  public final void zzs(boolean paramBoolean) {
    synchronized (this.zzf) {
      boolean bool;
      if (this.zzg != null) {
        bool = true;
      } else {
        bool = false;
      } 
      Preconditions.checkState(bool, "MobileAds.initialize() must be called prior to setting app muted state.");
      try {
        this.zzg.zzo(paramBoolean);
      } catch (RemoteException remoteException) {
        zzcgp.zzh("Unable to set app mute state.", (Throwable)remoteException);
      } 
      return;
    } 
  }
  
  public final void zzt(float paramFloat) {
    boolean bool1;
    boolean bool2 = true;
    if (paramFloat >= 0.0F && paramFloat <= 1.0F) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    Preconditions.checkArgument(bool1, "The app volume must be a value between 0 and 1 inclusive.");
    synchronized (this.zzf) {
      if (this.zzg != null) {
        bool1 = bool2;
      } else {
        bool1 = false;
      } 
      Preconditions.checkState(bool1, "MobileAds.initialize() must be called prior to setting the app volume.");
      try {
        this.zzg.zzp(paramFloat);
      } catch (RemoteException remoteException) {
        zzcgp.zzh("Unable to set app volume.", (Throwable)remoteException);
      } 
      return;
    } 
  }
  
  public final void zzu(RequestConfiguration paramRequestConfiguration) {
    boolean bool;
    if (paramRequestConfiguration != null) {
      bool = true;
    } else {
      bool = false;
    } 
    Preconditions.checkArgument(bool, "Null passed to setRequestConfiguration.");
    synchronized (this.zzf) {
      RequestConfiguration requestConfiguration = this.zzi;
      this.zzi = paramRequestConfiguration;
      if (this.zzg == null)
        return; 
      if (requestConfiguration.getTagForChildDirectedTreatment() != paramRequestConfiguration.getTagForChildDirectedTreatment() || requestConfiguration.getTagForUnderAgeOfConsent() != paramRequestConfiguration.getTagForUnderAgeOfConsent())
        zzz(paramRequestConfiguration); 
      return;
    } 
  }
  
  public final boolean zzv() {
    synchronized (this.zzf) {
      zzcm zzcm1 = this.zzg;
      boolean bool = false;
      if (zzcm1 == null)
        return false; 
      try {
        boolean bool1 = zzcm1.zzt();
        bool = bool1;
      } catch (RemoteException remoteException) {
        zzcgp.zzh("Unable to get app mute state.", (Throwable)remoteException);
      } 
      return bool;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzed.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */