package com.google.android.gms.ads.internal;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.util.zzs;
import com.google.android.gms.internal.ads.zzcaq;
import com.google.android.gms.internal.ads.zzcdq;
import java.util.Collections;
import java.util.List;
import javax.annotation.ParametersAreNonnullByDefault;

@ParametersAreNonnullByDefault
public final class zzb {
  private final Context zza;
  
  private boolean zzb;
  
  private final zzcdq zzc;
  
  private final zzcaq zzd;
  
  public zzb(Context paramContext, zzcdq paramzzcdq, zzcaq paramzzcaq) {
    this.zza = paramContext;
    this.zzc = paramzzcdq;
    this.zzd = new zzcaq(false, Collections.emptyList());
  }
  
  private final boolean zzd() {
    zzcdq zzcdq1 = this.zzc;
    return ((zzcdq1 != null && (zzcdq1.zza()).zzf) || this.zzd.zza);
  }
  
  public final void zza() {
    this.zzb = true;
  }
  
  public final void zzb(String paramString) {
    if (!zzd())
      return; 
    String str = paramString;
    if (paramString == null)
      str = ""; 
    zzcdq zzcdq1 = this.zzc;
    if (zzcdq1 != null) {
      zzcdq1.zzd(str, null, 3);
      return;
    } 
    zzcaq zzcaq1 = this.zzd;
    if (zzcaq1.zza) {
      List list = zzcaq1.zzb;
      if (list != null)
        for (String str1 : list) {
          if (!TextUtils.isEmpty(str1)) {
            str1 = str1.replace("{NAVIGATION_URL}", Uri.encode(str));
            zzt.zzp();
            zzs.zzH(this.zza, "", str1);
          } 
        }  
    } 
  }
  
  public final boolean zzc() {
    return (!zzd() || this.zzb);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\zzb.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */