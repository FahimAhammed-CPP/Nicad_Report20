package com.google.android.gms.ads.internal.client;

import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.internal.ads.zzarz;
import com.google.android.gms.internal.ads.zzasb;
import com.google.android.gms.internal.ads.zzbdm;
import com.google.android.gms.internal.ads.zzbjx;
import com.google.android.gms.internal.ads.zzbzl;
import com.google.android.gms.internal.ads.zzbzo;
import com.google.android.gms.internal.ads.zzcby;

public final class zzbq extends zzarz implements zzbs {
  zzbq(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IAdManager");
  }
  
  public final void zzA() throws RemoteException {
    zzbl(11, zza());
  }
  
  public final void zzB() throws RemoteException {
    zzbl(6, zza());
  }
  
  public final void zzC(zzbc paramzzbc) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zzg(parcel, paramzzbc);
    zzbl(20, parcel);
  }
  
  public final void zzD(zzbf paramzzbf) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zzg(parcel, paramzzbf);
    zzbl(7, parcel);
  }
  
  public final void zzE(zzbw paramzzbw) throws RemoteException {
    throw null;
  }
  
  public final void zzF(zzq paramzzq) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zze(parcel, (Parcelable)paramzzq);
    zzbl(13, parcel);
  }
  
  public final void zzG(zzbz paramzzbz) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zzg(parcel, paramzzbz);
    zzbl(8, parcel);
  }
  
  public final void zzH(zzbdm paramzzbdm) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zzg(parcel, (IInterface)paramzzbdm);
    zzbl(40, parcel);
  }
  
  public final void zzI(zzw paramzzw) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zze(parcel, (Parcelable)paramzzw);
    zzbl(39, parcel);
  }
  
  public final void zzJ(zzcg paramzzcg) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zzg(parcel, paramzzcg);
    zzbl(45, parcel);
  }
  
  public final void zzK(zzdo paramzzdo) throws RemoteException {
    throw null;
  }
  
  public final void zzL(boolean paramBoolean) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zzd(parcel, paramBoolean);
    zzbl(34, parcel);
  }
  
  public final void zzM(zzbzl paramzzbzl) throws RemoteException {
    throw null;
  }
  
  public final void zzN(boolean paramBoolean) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zzd(parcel, paramBoolean);
    zzbl(22, parcel);
  }
  
  public final void zzO(zzbjx paramzzbjx) throws RemoteException {
    throw null;
  }
  
  public final void zzP(zzde paramzzde) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zzg(parcel, paramzzde);
    zzbl(42, parcel);
  }
  
  public final void zzQ(zzbzo paramzzbzo, String paramString) throws RemoteException {
    throw null;
  }
  
  public final void zzR(String paramString) throws RemoteException {
    throw null;
  }
  
  public final void zzS(zzcby paramzzcby) throws RemoteException {
    throw null;
  }
  
  public final void zzT(String paramString) throws RemoteException {
    throw null;
  }
  
  public final void zzU(zzff paramzzff) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zze(parcel, (Parcelable)paramzzff);
    zzbl(29, parcel);
  }
  
  public final void zzW(IObjectWrapper paramIObjectWrapper) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zzg(parcel, (IInterface)paramIObjectWrapper);
    zzbl(44, parcel);
  }
  
  public final void zzX() throws RemoteException {
    throw null;
  }
  
  public final boolean zzY() throws RemoteException {
    Parcel parcel = zzbk(23, zza());
    boolean bool = zzasb.zzh(parcel);
    parcel.recycle();
    return bool;
  }
  
  public final boolean zzZ() throws RemoteException {
    throw null;
  }
  
  public final boolean zzaa(zzl paramzzl) throws RemoteException {
    Parcel parcel2 = zza();
    zzasb.zze(parcel2, (Parcelable)paramzzl);
    Parcel parcel1 = zzbk(4, parcel2);
    boolean bool = zzasb.zzh(parcel1);
    parcel1.recycle();
    return bool;
  }
  
  public final void zzab(zzcd paramzzcd) throws RemoteException {
    throw null;
  }
  
  public final Bundle zzd() throws RemoteException {
    throw null;
  }
  
  public final zzq zzg() throws RemoteException {
    Parcel parcel = zzbk(12, zza());
    zzq zzq = (zzq)zzasb.zza(parcel, zzq.CREATOR);
    parcel.recycle();
    return zzq;
  }
  
  public final zzbf zzi() throws RemoteException {
    zzbf zzbf;
    Parcel parcel = zzbk(33, zza());
    IBinder iBinder = parcel.readStrongBinder();
    if (iBinder == null) {
      iBinder = null;
    } else {
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdListener");
      if (iInterface instanceof zzbf) {
        zzbf = (zzbf)iInterface;
      } else {
        zzbf = new zzbd((IBinder)zzbf);
      } 
    } 
    parcel.recycle();
    return zzbf;
  }
  
  public final zzbz zzj() throws RemoteException {
    zzbz zzbz;
    Parcel parcel = zzbk(32, zza());
    IBinder iBinder = parcel.readStrongBinder();
    if (iBinder == null) {
      iBinder = null;
    } else {
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IAppEventListener");
      if (iInterface instanceof zzbz) {
        zzbz = (zzbz)iInterface;
      } else {
        zzbz = new zzbx((IBinder)zzbz);
      } 
    } 
    parcel.recycle();
    return zzbz;
  }
  
  public final zzdh zzk() throws RemoteException {
    zzdh zzdh;
    Parcel parcel = zzbk(41, zza());
    IBinder iBinder = parcel.readStrongBinder();
    if (iBinder == null) {
      iBinder = null;
    } else {
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IResponseInfo");
      if (iInterface instanceof zzdh) {
        zzdh = (zzdh)iInterface;
      } else {
        zzdh = new zzdf((IBinder)zzdh);
      } 
    } 
    parcel.recycle();
    return zzdh;
  }
  
  public final zzdk zzl() throws RemoteException {
    zzdk zzdk;
    Parcel parcel = zzbk(26, zza());
    IBinder iBinder = parcel.readStrongBinder();
    if (iBinder == null) {
      iBinder = null;
    } else {
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IVideoController");
      if (iInterface instanceof zzdk) {
        zzdk = (zzdk)iInterface;
      } else {
        zzdk = new zzdi((IBinder)zzdk);
      } 
    } 
    parcel.recycle();
    return zzdk;
  }
  
  public final IObjectWrapper zzn() throws RemoteException {
    Parcel parcel = zzbk(1, zza());
    IObjectWrapper iObjectWrapper = IObjectWrapper.Stub.asInterface(parcel.readStrongBinder());
    parcel.recycle();
    return iObjectWrapper;
  }
  
  public final String zzr() throws RemoteException {
    Parcel parcel = zzbk(31, zza());
    String str = parcel.readString();
    parcel.recycle();
    return str;
  }
  
  public final String zzs() throws RemoteException {
    throw null;
  }
  
  public final String zzt() throws RemoteException {
    throw null;
  }
  
  public final void zzx() throws RemoteException {
    zzbl(2, zza());
  }
  
  public final void zzy(zzl paramzzl, zzbi paramzzbi) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zze(parcel, (Parcelable)paramzzl);
    zzasb.zzg(parcel, paramzzbi);
    zzbl(43, parcel);
  }
  
  public final void zzz() throws RemoteException {
    zzbl(5, zza());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzbq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */