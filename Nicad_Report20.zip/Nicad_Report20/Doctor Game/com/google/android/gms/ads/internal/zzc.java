package com.google.android.gms.ads.internal;

import android.content.Context;
import android.os.Looper;
import com.google.android.gms.common.internal.BaseGmsClient;

public abstract class zzc extends BaseGmsClient {
  protected zzc(Context paramContext, Looper paramLooper, int paramInt, BaseGmsClient.BaseConnectionCallbacks paramBaseConnectionCallbacks, BaseGmsClient.BaseOnConnectionFailedListener paramBaseOnConnectionFailedListener, String paramString) {
    super(paramContext, paramLooper, paramInt, paramBaseConnectionCallbacks, paramBaseOnConnectionFailedListener, null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\zzc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */