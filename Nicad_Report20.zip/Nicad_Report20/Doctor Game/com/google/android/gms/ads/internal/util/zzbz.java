package com.google.android.gms.ads.internal.util;

import com.google.android.gms.ads.internal.zzt;

public final class zzbz {
  private long zza;
  
  private long zzb = Long.MIN_VALUE;
  
  private final Object zzc = new Object();
  
  public zzbz(long paramLong) {
    this.zza = paramLong;
  }
  
  public final void zza(long paramLong) {
    synchronized (this.zzc) {
      this.zza = paramLong;
      return;
    } 
  }
  
  public final boolean zzb() {
    synchronized (this.zzc) {
      long l = zzt.zzB().elapsedRealtime();
      if (this.zzb + this.zza > l)
        return false; 
      this.zzb = l;
      return true;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzbz.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */