package com.google.android.gms.ads.internal.client;

import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.internal.ads.zzasa;
import com.google.android.gms.internal.ads.zzasb;
import com.google.android.gms.internal.ads.zzbdl;
import com.google.android.gms.internal.ads.zzbdm;
import com.google.android.gms.internal.ads.zzbjw;
import com.google.android.gms.internal.ads.zzbjx;
import com.google.android.gms.internal.ads.zzbzk;
import com.google.android.gms.internal.ads.zzbzl;
import com.google.android.gms.internal.ads.zzbzn;
import com.google.android.gms.internal.ads.zzbzo;
import com.google.android.gms.internal.ads.zzcbx;
import com.google.android.gms.internal.ads.zzcby;

public abstract class zzbr extends zzasa implements zzbs {
  public zzbr() {
    super("com.google.android.gms.ads.internal.client.IAdManager");
  }
  
  public static zzbs zzac(IBinder paramIBinder) {
    if (paramIBinder == null)
      return null; 
    IInterface iInterface = paramIBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdManager");
    return (iInterface instanceof zzbs) ? (zzbs)iInterface : new zzbq(paramIBinder);
  }
  
  protected final boolean zzbI(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2) throws RemoteException {
    zzdh zzdh;
    Bundle bundle;
    String str3;
    zzbf zzbf1;
    zzbz zzbz1;
    String str2;
    zzdk zzdk;
    String str1;
    zzq zzq1;
    boolean bool;
    zzcg zzcg;
    IObjectWrapper iObjectWrapper2;
    IInterface iInterface;
    IBinder iBinder6;
    zzde zzde;
    zzbdm zzbdm;
    zzw zzw;
    String str5;
    IBinder iBinder5;
    zzbw zzbw;
    zzdo zzdo;
    zzff zzff;
    String str4;
    zzcby zzcby;
    IBinder iBinder4;
    zzcd zzcd;
    IBinder iBinder3;
    zzbc zzbc;
    zzbjx zzbjx;
    zzbzo zzbzo;
    zzbzl zzbzl;
    zzq zzq2;
    IBinder iBinder2;
    zzbz zzbz2;
    IBinder iBinder1;
    zzbf zzbf2;
    zzl zzl1;
    zzl zzl2;
    String str6;
    IBinder iBinder7 = null;
    IBinder iBinder9 = null;
    IBinder iBinder10 = null;
    IBinder iBinder11 = null;
    IBinder iBinder12 = null;
    IBinder iBinder13 = null;
    IBinder iBinder14 = null;
    IBinder iBinder8 = null;
    switch (paramInt1) {
      default:
        return false;
      case 45:
        iBinder7 = paramParcel1.readStrongBinder();
        if (iBinder7 == null) {
          iBinder7 = iBinder8;
        } else {
          IInterface iInterface1 = iBinder7.queryLocalInterface("com.google.android.gms.ads.internal.client.IFullScreenContentCallback");
          if (iInterface1 instanceof zzcg) {
            zzcg = (zzcg)iInterface1;
          } else {
            zzcg = new zzce((IBinder)zzcg);
          } 
        } 
        zzasb.zzc(paramParcel1);
        zzJ(zzcg);
        paramParcel2.writeNoException();
        return true;
      case 44:
        iObjectWrapper2 = IObjectWrapper.Stub.asInterface(paramParcel1.readStrongBinder());
        zzasb.zzc(paramParcel1);
        zzW(iObjectWrapper2);
        paramParcel2.writeNoException();
        return true;
      case 43:
        zzl2 = (zzl)zzasb.zza(paramParcel1, zzl.CREATOR);
        iBinder9 = paramParcel1.readStrongBinder();
        if (iBinder9 != null) {
          iInterface = iBinder9.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdLoadCallback");
          if (iInterface instanceof zzbi) {
            iInterface = iInterface;
          } else {
            iInterface = new zzbg(iBinder9);
          } 
        } 
        zzasb.zzc(paramParcel1);
        zzy(zzl2, (zzbi)iInterface);
        paramParcel2.writeNoException();
        return true;
      case 42:
        iBinder6 = paramParcel1.readStrongBinder();
        if (iBinder6 == null) {
          iBinder6 = iBinder9;
        } else {
          IInterface iInterface1 = iBinder6.queryLocalInterface("com.google.android.gms.ads.internal.client.IOnPaidEventListener");
          if (iInterface1 instanceof zzde) {
            zzde = (zzde)iInterface1;
          } else {
            zzde = new zzdc((IBinder)zzde);
          } 
        } 
        zzasb.zzc(paramParcel1);
        zzP(zzde);
        paramParcel2.writeNoException();
        return true;
      case 41:
        zzdh = zzk();
        paramParcel2.writeNoException();
        zzasb.zzg(paramParcel2, zzdh);
        return true;
      case 40:
        zzbdm = zzbdl.zze(zzdh.readStrongBinder());
        zzasb.zzc((Parcel)zzdh);
        zzH(zzbdm);
        paramParcel2.writeNoException();
        return true;
      case 39:
        zzw = (zzw)zzasb.zza((Parcel)zzdh, zzw.CREATOR);
        zzasb.zzc((Parcel)zzdh);
        zzI(zzw);
        paramParcel2.writeNoException();
        return true;
      case 38:
        str5 = zzdh.readString();
        zzasb.zzc((Parcel)zzdh);
        zzR(str5);
        paramParcel2.writeNoException();
        return true;
      case 37:
        bundle = zzd();
        paramParcel2.writeNoException();
        zzasb.zzf(paramParcel2, (Parcelable)bundle);
        return true;
      case 36:
        iBinder5 = bundle.readStrongBinder();
        if (iBinder5 == null) {
          iBinder5 = iBinder10;
        } else {
          IInterface iInterface1 = iBinder5.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdMetadataListener");
          if (iInterface1 instanceof zzbw) {
            zzbw = (zzbw)iInterface1;
          } else {
            zzbw = new zzbu((IBinder)zzbw);
          } 
        } 
        zzasb.zzc((Parcel)bundle);
        zzE(zzbw);
        paramParcel2.writeNoException();
        return true;
      case 35:
        str3 = zzt();
        paramParcel2.writeNoException();
        paramParcel2.writeString(str3);
        return true;
      case 34:
        bool = zzasb.zzh((Parcel)str3);
        zzasb.zzc((Parcel)str3);
        zzL(bool);
        paramParcel2.writeNoException();
        return true;
      case 33:
        zzbf1 = zzi();
        paramParcel2.writeNoException();
        zzasb.zzg(paramParcel2, zzbf1);
        return true;
      case 32:
        zzbz1 = zzj();
        paramParcel2.writeNoException();
        zzasb.zzg(paramParcel2, zzbz1);
        return true;
      case 31:
        str2 = zzr();
        paramParcel2.writeNoException();
        paramParcel2.writeString(str2);
        return true;
      case 30:
        zzdo = (zzdo)zzasb.zza((Parcel)str2, zzdo.CREATOR);
        zzasb.zzc((Parcel)str2);
        zzK(zzdo);
        paramParcel2.writeNoException();
        return true;
      case 29:
        zzff = (zzff)zzasb.zza((Parcel)str2, zzff.CREATOR);
        zzasb.zzc((Parcel)str2);
        zzU(zzff);
        paramParcel2.writeNoException();
        return true;
      case 26:
        zzdk = zzl();
        paramParcel2.writeNoException();
        zzasb.zzg(paramParcel2, zzdk);
        return true;
      case 25:
        str4 = zzdk.readString();
        zzasb.zzc((Parcel)zzdk);
        zzT(str4);
        paramParcel2.writeNoException();
        return true;
      case 24:
        zzcby = zzcbx.zzb(zzdk.readStrongBinder());
        zzasb.zzc((Parcel)zzdk);
        zzS(zzcby);
        paramParcel2.writeNoException();
        return true;
      case 23:
        bool = zzY();
        paramParcel2.writeNoException();
        zzasb.zzd(paramParcel2, bool);
        return true;
      case 22:
        bool = zzasb.zzh((Parcel)zzdk);
        zzasb.zzc((Parcel)zzdk);
        zzN(bool);
        paramParcel2.writeNoException();
        return true;
      case 21:
        iBinder4 = zzdk.readStrongBinder();
        if (iBinder4 == null) {
          iBinder4 = iBinder11;
        } else {
          IInterface iInterface1 = iBinder4.queryLocalInterface("com.google.android.gms.ads.internal.client.ICorrelationIdProvider");
          if (iInterface1 instanceof zzcd) {
            zzcd = (zzcd)iInterface1;
          } else {
            zzcd = new zzcd((IBinder)zzcd);
          } 
        } 
        zzasb.zzc((Parcel)zzdk);
        zzab(zzcd);
        paramParcel2.writeNoException();
        return true;
      case 20:
        iBinder3 = zzdk.readStrongBinder();
        if (iBinder3 == null) {
          iBinder3 = iBinder12;
        } else {
          IInterface iInterface1 = iBinder3.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdClickListener");
          if (iInterface1 instanceof zzbc) {
            zzbc = (zzbc)iInterface1;
          } else {
            zzbc = new zzba((IBinder)zzbc);
          } 
        } 
        zzasb.zzc((Parcel)zzdk);
        zzC(zzbc);
        paramParcel2.writeNoException();
        return true;
      case 19:
        zzbjx = zzbjw.zzb(zzdk.readStrongBinder());
        zzasb.zzc((Parcel)zzdk);
        zzO(zzbjx);
        paramParcel2.writeNoException();
        return true;
      case 18:
        str1 = zzs();
        paramParcel2.writeNoException();
        paramParcel2.writeString(str1);
        return true;
      case 15:
        zzbzo = zzbzn.zzb(str1.readStrongBinder());
        str6 = str1.readString();
        zzasb.zzc((Parcel)str1);
        zzQ(zzbzo, str6);
        paramParcel2.writeNoException();
        return true;
      case 14:
        zzbzl = zzbzk.zzb(str1.readStrongBinder());
        zzasb.zzc((Parcel)str1);
        zzM(zzbzl);
        paramParcel2.writeNoException();
        return true;
      case 13:
        zzq2 = (zzq)zzasb.zza((Parcel)str1, zzq.CREATOR);
        zzasb.zzc((Parcel)str1);
        zzF(zzq2);
        paramParcel2.writeNoException();
        return true;
      case 12:
        zzq1 = zzg();
        paramParcel2.writeNoException();
        zzasb.zzf(paramParcel2, (Parcelable)zzq1);
        return true;
      case 11:
        zzA();
        paramParcel2.writeNoException();
        return true;
      case 10:
        paramParcel2.writeNoException();
        return true;
      case 9:
        zzX();
        paramParcel2.writeNoException();
        return true;
      case 8:
        iBinder2 = zzq1.readStrongBinder();
        if (iBinder2 == null) {
          iBinder2 = iBinder13;
        } else {
          IInterface iInterface1 = iBinder2.queryLocalInterface("com.google.android.gms.ads.internal.client.IAppEventListener");
          if (iInterface1 instanceof zzbz) {
            zzbz2 = (zzbz)iInterface1;
          } else {
            zzbz2 = new zzbx((IBinder)zzbz2);
          } 
        } 
        zzasb.zzc((Parcel)zzq1);
        zzG(zzbz2);
        paramParcel2.writeNoException();
        return true;
      case 7:
        iBinder1 = zzq1.readStrongBinder();
        if (iBinder1 == null) {
          iBinder1 = iBinder14;
        } else {
          IInterface iInterface1 = iBinder1.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdListener");
          if (iInterface1 instanceof zzbf) {
            zzbf2 = (zzbf)iInterface1;
          } else {
            zzbf2 = new zzbd((IBinder)zzbf2);
          } 
        } 
        zzasb.zzc((Parcel)zzq1);
        zzD(zzbf2);
        paramParcel2.writeNoException();
        return true;
      case 6:
        zzB();
        paramParcel2.writeNoException();
        return true;
      case 5:
        zzz();
        paramParcel2.writeNoException();
        return true;
      case 4:
        zzl1 = (zzl)zzasb.zza((Parcel)zzq1, zzl.CREATOR);
        zzasb.zzc((Parcel)zzq1);
        bool = zzaa(zzl1);
        paramParcel2.writeNoException();
        zzasb.zzd(paramParcel2, bool);
        return true;
      case 3:
        bool = zzZ();
        paramParcel2.writeNoException();
        zzasb.zzd(paramParcel2, bool);
        return true;
      case 2:
        zzx();
        paramParcel2.writeNoException();
        return true;
      case 1:
        break;
    } 
    IObjectWrapper iObjectWrapper1 = zzn();
    paramParcel2.writeNoException();
    zzasb.zzg(paramParcel2, (IInterface)iObjectWrapper1);
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzbr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */