package com.google.android.gms.ads.formats;

import android.view.View;
import com.google.android.gms.ads.VideoController;
import java.util.List;

@Deprecated
public interface NativeCustomTemplateAd {
  public static final String ASSET_NAME_VIDEO = "_videoMediaView";
  
  void destroy();
  
  List<String> getAvailableAssetNames();
  
  String getCustomTemplateId();
  
  DisplayOpenMeasurement getDisplayOpenMeasurement();
  
  NativeAd.Image getImage(String paramString);
  
  CharSequence getText(String paramString);
  
  VideoController getVideoController();
  
  MediaView getVideoMediaView();
  
  void performClick(String paramString);
  
  void recordImpression();
  
  public static interface DisplayOpenMeasurement {
    void setView(View param1View);
    
    boolean start();
  }
  
  public static interface OnCustomClickListener {
    void onCustomClick(NativeCustomTemplateAd param1NativeCustomTemplateAd, String param1String);
  }
  
  public static interface OnCustomTemplateAdLoadedListener {
    void onCustomTemplateAdLoaded(NativeCustomTemplateAd param1NativeCustomTemplateAd);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\formats\NativeCustomTemplateAd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */