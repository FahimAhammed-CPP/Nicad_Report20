package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzarz;

public final class zzba extends zzarz implements zzbc {
  zzba(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IAdClickListener");
  }
  
  public final void zzb() throws RemoteException {
    zzbl(1, zza());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzba.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */