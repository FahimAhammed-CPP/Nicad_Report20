package com.google.android.gms.ads.internal.client;

import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.internal.ads.zzbmi;
import com.google.android.gms.internal.ads.zzbmo;
import com.google.android.gms.internal.ads.zzbqr;
import com.google.android.gms.internal.ads.zzbqu;
import com.google.android.gms.internal.ads.zzbvk;
import com.google.android.gms.internal.ads.zzbyv;
import com.google.android.gms.internal.ads.zzbzc;
import com.google.android.gms.internal.ads.zzcbv;
import com.google.android.gms.internal.ads.zzccl;
import com.google.android.gms.internal.ads.zzcfg;

public interface zzcc extends IInterface {
  zzbo zzb(IObjectWrapper paramIObjectWrapper, String paramString, zzbvk paramzzbvk, int paramInt) throws RemoteException;
  
  zzbs zzc(IObjectWrapper paramIObjectWrapper, zzq paramzzq, String paramString, zzbvk paramzzbvk, int paramInt) throws RemoteException;
  
  zzbs zzd(IObjectWrapper paramIObjectWrapper, zzq paramzzq, String paramString, zzbvk paramzzbvk, int paramInt) throws RemoteException;
  
  zzbs zze(IObjectWrapper paramIObjectWrapper, zzq paramzzq, String paramString, zzbvk paramzzbvk, int paramInt) throws RemoteException;
  
  zzbs zzf(IObjectWrapper paramIObjectWrapper, zzq paramzzq, String paramString, int paramInt) throws RemoteException;
  
  zzcm zzg(IObjectWrapper paramIObjectWrapper, int paramInt) throws RemoteException;
  
  zzbmi zzh(IObjectWrapper paramIObjectWrapper1, IObjectWrapper paramIObjectWrapper2) throws RemoteException;
  
  zzbmo zzi(IObjectWrapper paramIObjectWrapper1, IObjectWrapper paramIObjectWrapper2, IObjectWrapper paramIObjectWrapper3) throws RemoteException;
  
  zzbqu zzj(IObjectWrapper paramIObjectWrapper, zzbvk paramzzbvk, int paramInt, zzbqr paramzzbqr) throws RemoteException;
  
  zzbyv zzk(IObjectWrapper paramIObjectWrapper, zzbvk paramzzbvk, int paramInt) throws RemoteException;
  
  zzbzc zzl(IObjectWrapper paramIObjectWrapper) throws RemoteException;
  
  zzcbv zzm(IObjectWrapper paramIObjectWrapper, zzbvk paramzzbvk, int paramInt) throws RemoteException;
  
  zzccl zzn(IObjectWrapper paramIObjectWrapper, String paramString, zzbvk paramzzbvk, int paramInt) throws RemoteException;
  
  zzcfg zzo(IObjectWrapper paramIObjectWrapper, zzbvk paramzzbvk, int paramInt) throws RemoteException;
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzcc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */