package com.google.android.gms.ads.internal.client;

import android.os.Bundle;
import android.os.IInterface;
import android.os.RemoteException;
import java.util.List;

public interface zzdh extends IInterface {
  Bundle zze() throws RemoteException;
  
  zzu zzf() throws RemoteException;
  
  String zzg() throws RemoteException;
  
  String zzh() throws RemoteException;
  
  String zzi() throws RemoteException;
  
  List zzj() throws RemoteException;
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzdh.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */