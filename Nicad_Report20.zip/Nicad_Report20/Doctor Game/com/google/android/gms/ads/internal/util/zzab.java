package com.google.android.gms.ads.internal.util;

import android.content.Context;
import android.media.AudioManager;

public final class zzab {
  private boolean zza = false;
  
  private float zzb = 1.0F;
  
  public static float zzb(Context paramContext) {
    AudioManager audioManager = (AudioManager)paramContext.getSystemService("audio");
    if (audioManager == null)
      return 0.0F; 
    int i = audioManager.getStreamMaxVolume(3);
    int j = audioManager.getStreamVolume(3);
    return (i == 0) ? 0.0F : (j / i);
  }
  
  private final boolean zzf() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield zzb : F
    //   6: fstore_1
    //   7: fload_1
    //   8: fconst_0
    //   9: fcmpl
    //   10: iflt -> 19
    //   13: iconst_1
    //   14: istore_2
    //   15: aload_0
    //   16: monitorexit
    //   17: iload_2
    //   18: ireturn
    //   19: iconst_0
    //   20: istore_2
    //   21: goto -> 15
    //   24: astore_3
    //   25: aload_0
    //   26: monitorexit
    //   27: goto -> 32
    //   30: aload_3
    //   31: athrow
    //   32: goto -> 30
    // Exception table:
    //   from	to	target	type
    //   2	7	24	finally
  }
  
  public final float zza() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial zzf : ()Z
    //   6: ifeq -> 18
    //   9: aload_0
    //   10: getfield zzb : F
    //   13: fstore_1
    //   14: aload_0
    //   15: monitorexit
    //   16: fload_1
    //   17: freturn
    //   18: aload_0
    //   19: monitorexit
    //   20: fconst_1
    //   21: freturn
    //   22: astore_2
    //   23: aload_0
    //   24: monitorexit
    //   25: aload_2
    //   26: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	22	finally
  }
  
  public final void zzc(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: iload_1
    //   4: putfield zza : Z
    //   7: aload_0
    //   8: monitorexit
    //   9: return
    //   10: astore_2
    //   11: aload_0
    //   12: monitorexit
    //   13: aload_2
    //   14: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	10	finally
  }
  
  public final void zzd(float paramFloat) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: fload_1
    //   4: putfield zzb : F
    //   7: aload_0
    //   8: monitorexit
    //   9: return
    //   10: astore_2
    //   11: aload_0
    //   12: monitorexit
    //   13: aload_2
    //   14: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	10	finally
  }
  
  public final boolean zze() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield zza : Z
    //   6: istore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: iload_1
    //   10: ireturn
    //   11: astore_2
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_2
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzab.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */