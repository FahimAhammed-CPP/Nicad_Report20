package com.google.android.gms.ads.internal.client;

import com.google.android.gms.ads.initialization.AdapterStatus;

final class zzdy implements AdapterStatus {
  zzdy(zzed paramzzed) {}
  
  public final String getDescription() {
    return "Google Mobile Ads SDK initialization functionality unavailable for this session. Ad requests can be made at any time.";
  }
  
  public final AdapterStatus.State getInitializationState() {
    return AdapterStatus.State.READY;
  }
  
  public final int getLatency() {
    return 0;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzdy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */