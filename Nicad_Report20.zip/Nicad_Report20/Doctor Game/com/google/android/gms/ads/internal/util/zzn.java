package com.google.android.gms.ads.internal.util;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import androidx.browser.customtabs.CustomTabsIntent;
import com.google.android.gms.internal.ads.zzbjy;
import com.google.android.gms.internal.ads.zzbka;
import com.google.android.gms.internal.ads.zzgxw;

final class zzn implements zzbjy {
  zzn(zzs paramzzs, zzbka paramzzbka, Context paramContext, Uri paramUri) {}
  
  public final void zza() {
    CustomTabsIntent customTabsIntent = (new CustomTabsIntent.Builder(this.zza.zza())).build();
    customTabsIntent.intent.setPackage(zzgxw.zza(this.zzb));
    customTabsIntent.launchUrl(this.zzb, this.zzc);
    this.zza.zzf((Activity)this.zzb);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */