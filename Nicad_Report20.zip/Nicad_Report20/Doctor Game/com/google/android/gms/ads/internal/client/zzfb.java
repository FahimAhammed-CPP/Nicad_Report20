package com.google.android.gms.ads.internal.client;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.search.SearchAdRequest;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelWriter;

public final class zzfb extends AbstractSafeParcelable {
  public static final Parcelable.Creator<zzfb> CREATOR = new zzfc();
  
  public final String zza;
  
  public zzfb(SearchAdRequest paramSearchAdRequest) {
    this.zza = paramSearchAdRequest.getQuery();
  }
  
  zzfb(String paramString) {
    this.zza = paramString;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = SafeParcelWriter.beginObjectHeader(paramParcel);
    SafeParcelWriter.writeString(paramParcel, 15, this.zza, false);
    SafeParcelWriter.finishObjectHeader(paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzfb.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */