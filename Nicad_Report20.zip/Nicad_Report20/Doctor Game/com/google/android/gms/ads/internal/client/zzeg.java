package com.google.android.gms.ads.internal.client;

import android.os.Bundle;
import android.text.TextUtils;
import org.json.JSONException;
import org.json.JSONObject;

public final class zzeg {
  private final String zza;
  
  private final Bundle zzb;
  
  private final String zzc;
  
  public zzeg(String paramString1, Bundle paramBundle, String paramString2) {
    this.zza = paramString1;
    this.zzb = paramBundle;
    this.zzc = paramString2;
  }
  
  public final Bundle zza() {
    return this.zzb;
  }
  
  public final String zzb() {
    return this.zza;
  }
  
  final String zzc() {
    return this.zzc;
  }
  
  public final String zzd() {
    if (TextUtils.isEmpty(this.zzc))
      return ""; 
    try {
      return (new JSONObject(this.zzc)).optString("request_id", "");
    } catch (JSONException jSONException) {
      return "";
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzeg.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */