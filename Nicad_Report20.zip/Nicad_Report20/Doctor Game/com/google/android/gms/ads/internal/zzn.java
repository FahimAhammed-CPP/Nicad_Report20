package com.google.android.gms.ads.internal;

import android.view.MotionEvent;
import android.view.View;

final class zzn implements View.OnTouchListener {
  zzn(zzs paramzzs) {}
  
  public final boolean onTouch(View paramView, MotionEvent paramMotionEvent) {
    zzs zzs1 = this.zza;
    if (zzs.zzf(zzs1) != null)
      zzs.zzf(zzs1).zzd(paramMotionEvent); 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\zzn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */