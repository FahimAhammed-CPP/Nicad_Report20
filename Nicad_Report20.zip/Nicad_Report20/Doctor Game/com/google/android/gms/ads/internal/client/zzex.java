package com.google.android.gms.ads.internal.client;

import android.os.RemoteException;
import com.google.android.gms.ads.rewarded.OnAdMetadataChangedListener;

public final class zzex extends zzda {
  private final OnAdMetadataChangedListener zza;
  
  public zzex(OnAdMetadataChangedListener paramOnAdMetadataChangedListener) {
    this.zza = paramOnAdMetadataChangedListener;
  }
  
  public final void zze() throws RemoteException {
    OnAdMetadataChangedListener onAdMetadataChangedListener = this.zza;
    if (onAdMetadataChangedListener != null)
      onAdMetadataChangedListener.onAdMetadataChanged(); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzex.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */