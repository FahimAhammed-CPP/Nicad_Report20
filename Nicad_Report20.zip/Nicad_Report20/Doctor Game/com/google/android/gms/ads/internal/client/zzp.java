package com.google.android.gms.ads.internal.client;

import android.content.Context;
import android.os.Bundle;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.ads.query.AdInfo;
import com.google.android.gms.ads.query.QueryInfo;
import com.google.android.gms.ads.search.SearchAdRequest;
import com.google.android.gms.internal.ads.zzcgi;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Set;

public final class zzp {
  public static final zzp zza = new zzp();
  
  public final zzl zza(Context paramContext, zzdr paramzzdr) {
    long l;
    Date date = paramzzdr.zzo();
    if (date != null) {
      l = date.getTime();
    } else {
      l = -1L;
    } 
    String str1 = paramzzdr.zzl();
    int i = paramzzdr.zza();
    Set<?> set = paramzzdr.zzr();
    if (!set.isEmpty()) {
      List<?> list1 = Collections.unmodifiableList(new ArrayList(set));
    } else {
      set = null;
    } 
    boolean bool1 = paramzzdr.zzt(paramContext);
    Bundle bundle = paramzzdr.zzf(AdMobAdapter.class);
    AdInfo adInfo = paramzzdr.zzi();
    if (adInfo != null) {
      String str;
      QueryInfo queryInfo = adInfo.getQueryInfo();
      if (queryInfo != null) {
        str = queryInfo.zza().zzc();
      } else {
        str = "";
      } 
      zzc zzc = new zzc(paramzzdr.zzi().getAdString(), str);
    } else {
      adInfo = null;
    } 
    String str2 = paramzzdr.zzm();
    SearchAdRequest searchAdRequest = paramzzdr.zzj();
    if (searchAdRequest != null) {
      zzfb zzfb = new zzfb(searchAdRequest);
    } else {
      searchAdRequest = null;
    } 
    paramContext = paramContext.getApplicationContext();
    if (paramContext != null) {
      String str = paramContext.getPackageName();
      zzaw.zzb();
      str = zzcgi.zzp(Thread.currentThread().getStackTrace(), str);
    } else {
      paramContext = null;
    } 
    boolean bool2 = paramzzdr.zzs();
    RequestConfiguration requestConfiguration = zzed.zzf().zzc();
    int j = Math.max(paramzzdr.zzc(), requestConfiguration.getTagForChildDirectedTreatment());
    int k = Math.max(-1, requestConfiguration.getTagForUnderAgeOfConsent());
    String str3 = Collections.<String>max(Arrays.asList(new String[] { null, requestConfiguration.getMaxAdContentRating() }, ), zzo.zza);
    List list = paramzzdr.zzp();
    return new zzl(8, l, bundle, i, (List)set, bool1, j, false, str2, (zzfb)searchAdRequest, null, str1, paramzzdr.zzg(), paramzzdr.zze(), Collections.unmodifiableList(new ArrayList(paramzzdr.zzq())), paramzzdr.zzn(), (String)paramContext, bool2, (zzc)adInfo, k, str3, list, paramzzdr.zzb(), paramzzdr.zzk());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */