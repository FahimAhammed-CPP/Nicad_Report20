package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.IInterface;
import com.google.android.gms.internal.ads.zzarz;

public final class zzcd extends zzarz implements IInterface {
  zzcd(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.ICorrelationIdProvider");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzcd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */