package com.google.android.gms.ads.internal.client;

import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzcgp;

final class zzep implements Runnable {
  zzep(zzeq paramzzeq) {}
  
  public final void run() {
    zzeq zzeq1 = this.zza;
    if (zzeq.zzb(zzeq1) != null)
      try {
        zzeq.zzb(zzeq1).zze(1);
        return;
      } catch (RemoteException remoteException) {
        zzcgp.zzk("Could not notify onAdFailedToLoad event.", (Throwable)remoteException);
      }  
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzep.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */