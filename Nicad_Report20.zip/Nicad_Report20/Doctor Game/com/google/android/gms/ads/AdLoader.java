package com.google.android.gms.ads;

import android.content.Context;
import android.os.RemoteException;
import com.google.android.gms.ads.admanager.AdManagerAdRequest;
import com.google.android.gms.ads.formats.AdManagerAdViewOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.NativeCustomTemplateAd;
import com.google.android.gms.ads.formats.OnAdManagerAdViewLoadedListener;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.client.zzbf;
import com.google.android.gms.ads.internal.client.zzbl;
import com.google.android.gms.ads.internal.client.zzbo;
import com.google.android.gms.ads.internal.client.zzdr;
import com.google.android.gms.ads.internal.client.zzeo;
import com.google.android.gms.ads.internal.client.zzff;
import com.google.android.gms.ads.internal.client.zzg;
import com.google.android.gms.ads.internal.client.zzp;
import com.google.android.gms.ads.internal.client.zzq;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeCustomFormatAd;
import com.google.android.gms.internal.ads.zzbiu;
import com.google.android.gms.internal.ads.zzbjc;
import com.google.android.gms.internal.ads.zzbkq;
import com.google.android.gms.internal.ads.zzbls;
import com.google.android.gms.internal.ads.zzbnp;
import com.google.android.gms.internal.ads.zzbns;
import com.google.android.gms.internal.ads.zzboj;
import com.google.android.gms.internal.ads.zzbol;
import com.google.android.gms.internal.ads.zzbom;
import com.google.android.gms.internal.ads.zzbyp;
import com.google.android.gms.internal.ads.zzbyr;
import com.google.android.gms.internal.ads.zzcge;
import com.google.android.gms.internal.ads.zzcgp;

public class AdLoader {
  private final zzp zza;
  
  private final Context zzb;
  
  private final zzbl zzc;
  
  AdLoader(Context paramContext, zzbl paramzzbl, zzp paramzzp) {
    this.zzb = paramContext;
    this.zzc = paramzzbl;
    this.zza = paramzzp;
  }
  
  private final void zzb(zzdr paramzzdr) {
    zzbjc.zzc(this.zzb);
    if (((Boolean)zzbkq.zzc.zze()).booleanValue()) {
      zzbiu zzbiu = zzbjc.zziM;
      if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue()) {
        zzcge.zzb.execute(new zza(this, paramzzdr));
        return;
      } 
    } 
    try {
      this.zzc.zzg(this.zza.zza(this.zzb, paramzzdr));
      return;
    } catch (RemoteException remoteException) {
      zzcgp.zzh("Failed to load ad.", (Throwable)remoteException);
      return;
    } 
  }
  
  public boolean isLoading() {
    try {
      return this.zzc.zzi();
    } catch (RemoteException remoteException) {
      zzcgp.zzk("Failed to check if ad is loading.", (Throwable)remoteException);
      return false;
    } 
  }
  
  public void loadAd(AdRequest paramAdRequest) {
    zzb(paramAdRequest.zza());
  }
  
  public void loadAd(AdManagerAdRequest paramAdManagerAdRequest) {
    zzb(paramAdManagerAdRequest.zza);
  }
  
  public void loadAds(AdRequest paramAdRequest, int paramInt) {
    zzdr zzdr = paramAdRequest.zza();
    try {
      this.zzc.zzh(this.zza.zza(this.zzb, zzdr), paramInt);
      return;
    } catch (RemoteException remoteException) {
      zzcgp.zzh("Failed to load ads.", (Throwable)remoteException);
      return;
    } 
  }
  
  public static class Builder {
    private final Context zza;
    
    private final zzbo zzb;
    
    public Builder(Context param1Context, String param1String) {
      this.zza = context;
      this.zzb = zzbo1;
    }
    
    public AdLoader build() {
      try {
        return new AdLoader(this.zza, this.zzb.zze(), zzp.zza);
      } catch (RemoteException remoteException) {
        zzcgp.zzh("Failed to build AdLoader.", (Throwable)remoteException);
        zzeo zzeo = new zzeo();
        return new AdLoader(this.zza, zzeo.zzc(), zzp.zza);
      } 
    }
    
    public Builder forAdManagerAdView(OnAdManagerAdViewLoadedListener param1OnAdManagerAdViewLoadedListener, AdSize... param1VarArgs) {
      if (param1VarArgs != null && param1VarArgs.length > 0)
        try {
          zzq zzq = new zzq(this.zza, param1VarArgs);
          this.zzb.zzj((zzbnp)new zzbol(param1OnAdManagerAdViewLoadedListener), zzq);
          return this;
        } catch (RemoteException remoteException) {
          zzcgp.zzk("Failed to add Google Ad Manager banner ad listener", (Throwable)remoteException);
          return this;
        }  
      throw new IllegalArgumentException("The supported ad sizes must contain at least one valid ad size.");
    }
    
    public Builder forCustomFormatAd(String param1String, NativeCustomFormatAd.OnCustomFormatAdLoadedListener param1OnCustomFormatAdLoadedListener, NativeCustomFormatAd.OnCustomClickListener param1OnCustomClickListener) {
      zzbyp zzbyp = new zzbyp(param1OnCustomFormatAdLoadedListener, param1OnCustomClickListener);
      try {
        this.zzb.zzh(param1String, zzbyp.zzb(), zzbyp.zza());
        return this;
      } catch (RemoteException remoteException) {
        zzcgp.zzk("Failed to add custom format ad listener", (Throwable)remoteException);
        return this;
      } 
    }
    
    @Deprecated
    public Builder forCustomTemplateAd(String param1String, NativeCustomTemplateAd.OnCustomTemplateAdLoadedListener param1OnCustomTemplateAdLoadedListener, NativeCustomTemplateAd.OnCustomClickListener param1OnCustomClickListener) {
      zzboj zzboj = new zzboj(param1OnCustomTemplateAdLoadedListener, param1OnCustomClickListener);
      try {
        this.zzb.zzh(param1String, zzboj.zze(), zzboj.zzd());
        return this;
      } catch (RemoteException remoteException) {
        zzcgp.zzk("Failed to add custom template ad listener", (Throwable)remoteException);
        return this;
      } 
    }
    
    public Builder forNativeAd(NativeAd.OnNativeAdLoadedListener param1OnNativeAdLoadedListener) {
      try {
        this.zzb.zzk((zzbns)new zzbyr(param1OnNativeAdLoadedListener));
        return this;
      } catch (RemoteException remoteException) {
        zzcgp.zzk("Failed to add google native ad listener", (Throwable)remoteException);
        return this;
      } 
    }
    
    @Deprecated
    public Builder forUnifiedNativeAd(UnifiedNativeAd.OnUnifiedNativeAdLoadedListener param1OnUnifiedNativeAdLoadedListener) {
      try {
        this.zzb.zzk((zzbns)new zzbom(param1OnUnifiedNativeAdLoadedListener));
        return this;
      } catch (RemoteException remoteException) {
        zzcgp.zzk("Failed to add google native ad listener", (Throwable)remoteException);
        return this;
      } 
    }
    
    public Builder withAdListener(AdListener param1AdListener) {
      try {
        this.zzb.zzl((zzbf)new zzg(param1AdListener));
        return this;
      } catch (RemoteException remoteException) {
        zzcgp.zzk("Failed to set AdListener.", (Throwable)remoteException);
        return this;
      } 
    }
    
    public Builder withAdManagerAdViewOptions(AdManagerAdViewOptions param1AdManagerAdViewOptions) {
      try {
        this.zzb.zzm(param1AdManagerAdViewOptions);
        return this;
      } catch (RemoteException remoteException) {
        zzcgp.zzk("Failed to specify Ad Manager banner ad options", (Throwable)remoteException);
        return this;
      } 
    }
    
    @Deprecated
    public Builder withNativeAdOptions(NativeAdOptions param1NativeAdOptions) {
      try {
        this.zzb.zzo(new zzbls(param1NativeAdOptions));
        return this;
      } catch (RemoteException remoteException) {
        zzcgp.zzk("Failed to specify native ad options", (Throwable)remoteException);
        return this;
      } 
    }
    
    public Builder withNativeAdOptions(NativeAdOptions param1NativeAdOptions) {
      int i;
      boolean bool1;
      boolean bool2;
      zzbo zzbo1;
      try {
        zzbo1 = this.zzb;
        bool1 = param1NativeAdOptions.shouldReturnUrlsForImageAssets();
        bool2 = param1NativeAdOptions.shouldRequestMultipleImages();
        i = param1NativeAdOptions.getAdChoicesPlacement();
        if (param1NativeAdOptions.getVideoOptions() != null) {
          zzff zzff1 = new zzff(param1NativeAdOptions.getVideoOptions());
          zzbo1.zzo(new zzbls(4, bool1, -1, bool2, i, zzff1, param1NativeAdOptions.zza(), param1NativeAdOptions.getMediaAspectRatio()));
          return this;
        } 
      } catch (RemoteException remoteException) {
        zzcgp.zzk("Failed to specify native ad options", (Throwable)remoteException);
        return this;
      } 
      zzff zzff = null;
      zzbo1.zzo(new zzbls(4, bool1, -1, bool2, i, zzff, remoteException.zza(), remoteException.getMediaAspectRatio()));
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\AdLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */