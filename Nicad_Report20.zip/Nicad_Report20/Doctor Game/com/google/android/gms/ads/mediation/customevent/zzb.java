package com.google.android.gms.ads.mediation.customevent;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.mediation.MediationInterstitialListener;
import com.google.android.gms.internal.ads.zzcgp;

final class zzb implements CustomEventInterstitialListener {
  private final CustomEventAdapter zzb;
  
  private final MediationInterstitialListener zzc;
  
  public zzb(CustomEventAdapter paramCustomEventAdapter1, CustomEventAdapter paramCustomEventAdapter2, MediationInterstitialListener paramMediationInterstitialListener) {
    this.zzb = paramCustomEventAdapter2;
    this.zzc = paramMediationInterstitialListener;
  }
  
  public final void onAdClicked() {
    zzcgp.zze("Custom event adapter called onAdClicked.");
    this.zzc.onAdClicked(this.zzb);
  }
  
  public final void onAdClosed() {
    zzcgp.zze("Custom event adapter called onAdClosed.");
    this.zzc.onAdClosed(this.zzb);
  }
  
  public final void onAdFailedToLoad(int paramInt) {
    zzcgp.zze("Custom event adapter called onFailedToReceiveAd.");
    this.zzc.onAdFailedToLoad(this.zzb, paramInt);
  }
  
  public final void onAdFailedToLoad(AdError paramAdError) {
    zzcgp.zze("Custom event adapter called onFailedToReceiveAd.");
    this.zzc.onAdFailedToLoad(this.zzb, paramAdError);
  }
  
  public final void onAdLeftApplication() {
    zzcgp.zze("Custom event adapter called onAdLeftApplication.");
    this.zzc.onAdLeftApplication(this.zzb);
  }
  
  public final void onAdLoaded() {
    zzcgp.zze("Custom event adapter called onReceivedAd.");
    this.zzc.onAdLoaded(this.zza);
  }
  
  public final void onAdOpened() {
    zzcgp.zze("Custom event adapter called onAdOpened.");
    this.zzc.onAdOpened(this.zzb);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\mediation\customevent\zzb.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */