package com.google.android.gms.ads.internal.util;

import android.content.Context;
import com.google.android.gms.ads.internal.client.zzaw;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.internal.ads.zzajn;
import com.google.android.gms.internal.ads.zzajw;
import com.google.android.gms.internal.ads.zzajz;
import com.google.android.gms.internal.ads.zzakd;
import com.google.android.gms.internal.ads.zzakg;
import com.google.android.gms.internal.ads.zzakm;
import com.google.android.gms.internal.ads.zzakr;
import com.google.android.gms.internal.ads.zzaks;
import com.google.android.gms.internal.ads.zzakz;
import com.google.android.gms.internal.ads.zzale;
import com.google.android.gms.internal.ads.zzbiu;
import com.google.android.gms.internal.ads.zzbjc;
import com.google.android.gms.internal.ads.zzbrp;
import com.google.android.gms.internal.ads.zzcgi;
import java.io.File;
import java.util.regex.Pattern;

public final class zzax extends zzaks {
  private final Context zzc;
  
  private zzax(Context paramContext, zzakr paramzzakr) {
    super(paramzzakr);
    this.zzc = paramContext;
  }
  
  public static zzakg zzb(Context paramContext) {
    zzax zzax1 = new zzax(paramContext, (zzakr)new zzale(null, null));
    zzakg zzakg = new zzakg((zzajn)new zzakz(new File(paramContext.getCacheDir(), "admob_volley"), 20971520), (zzajw)zzax1, 4);
    zzakg.zzd();
    return zzakg;
  }
  
  public final zzajz zza(zzakd paramzzakd) throws zzakm {
    if (paramzzakd.zza() == 0) {
      String str = paramzzakd.zzk();
      zzbiu zzbiu = zzbjc.zzdD;
      if (Pattern.matches((String)zzay.zzc().zzb(zzbiu), str)) {
        zzaw.zzb();
        if (zzcgi.zzr(this.zzc, 13400000)) {
          zzajz zzajz = (new zzbrp(this.zzc)).zza(paramzzakd);
          if (zzajz != null) {
            zze.zza("Got gmscore asset response: ".concat(String.valueOf(paramzzakd.zzk())));
            return zzajz;
          } 
          zze.zza("Failed to get gmscore asset response: ".concat(String.valueOf(paramzzakd.zzk())));
        } 
      } 
    } 
    return super.zza(paramzzakd);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzax.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */