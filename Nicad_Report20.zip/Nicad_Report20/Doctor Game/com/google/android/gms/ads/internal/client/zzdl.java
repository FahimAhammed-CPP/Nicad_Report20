package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzarz;
import com.google.android.gms.internal.ads.zzasb;

public final class zzdl extends zzarz implements zzdn {
  zzdl(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IVideoLifecycleCallbacks");
  }
  
  public final void zze() throws RemoteException {
    zzbl(4, zza());
  }
  
  public final void zzf(boolean paramBoolean) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zzd(parcel, paramBoolean);
    zzbl(5, parcel);
  }
  
  public final void zzg() throws RemoteException {
    zzbl(3, zza());
  }
  
  public final void zzh() throws RemoteException {
    zzbl(2, zza());
  }
  
  public final void zzi() throws RemoteException {
    zzbl(1, zza());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzdl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */