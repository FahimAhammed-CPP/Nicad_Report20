package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzasa;
import com.google.android.gms.internal.ads.zzasb;

public abstract class zzdd extends zzasa implements zzde {
  public zzdd() {
    super("com.google.android.gms.ads.internal.client.IOnPaidEventListener");
  }
  
  public static zzde zzb(IBinder paramIBinder) {
    if (paramIBinder == null)
      return null; 
    IInterface iInterface = paramIBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IOnPaidEventListener");
    return (iInterface instanceof zzde) ? (zzde)iInterface : new zzdc(paramIBinder);
  }
  
  protected final boolean zzbI(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2) throws RemoteException {
    if (paramInt1 == 1) {
      zzs zzs = (zzs)zzasb.zza(paramParcel1, zzs.CREATOR);
      zzasb.zzc(paramParcel1);
      zze(zzs);
      paramParcel2.writeNoException();
      return true;
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzdd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */