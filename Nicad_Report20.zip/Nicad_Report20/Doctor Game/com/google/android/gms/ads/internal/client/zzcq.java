package com.google.android.gms.ads.internal.client;

import android.os.IInterface;
import android.os.RemoteException;

public interface zzcq extends IInterface {
  void zze() throws RemoteException;
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzcq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */