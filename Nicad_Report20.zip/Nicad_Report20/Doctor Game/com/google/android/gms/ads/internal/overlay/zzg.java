package com.google.android.gms.ads.internal.overlay;

import android.content.Context;
import android.view.MotionEvent;
import android.widget.RelativeLayout;
import com.google.android.gms.ads.internal.util.zzas;

final class zzg extends RelativeLayout {
  final zzas zza;
  
  boolean zzb;
  
  public zzg(Context paramContext, String paramString1, String paramString2, String paramString3) {
    super(paramContext);
    zzas zzas1 = new zzas(paramContext, paramString1);
    this.zza = zzas1;
    zzas1.zzo(paramString2);
    this.zza.zzn(paramString3);
  }
  
  public final boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    if (!this.zzb)
      this.zza.zzm(paramMotionEvent); 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\overlay\zzg.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */