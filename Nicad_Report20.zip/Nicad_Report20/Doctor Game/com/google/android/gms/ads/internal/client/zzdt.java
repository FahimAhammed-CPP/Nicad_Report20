package com.google.android.gms.ads.internal.client;

import com.google.android.gms.ads.LoadAdError;

final class zzdt extends zzax {
  zzdt(zzdu paramzzdu) {}
  
  public final void onAdFailedToLoad(LoadAdError paramLoadAdError) {
    zzdu zzdu1 = this.zza;
    zzdu.zze(zzdu1).zzb(zzdu1.zzi());
    super.onAdFailedToLoad(paramLoadAdError);
  }
  
  public final void onAdLoaded() {
    zzdu zzdu1 = this.zza;
    zzdu.zze(zzdu1).zzb(zzdu1.zzi());
    super.onAdLoaded();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzdt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */