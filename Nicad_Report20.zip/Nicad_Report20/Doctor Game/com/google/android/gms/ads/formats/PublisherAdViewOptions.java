package com.google.android.gms.ads.formats;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.internal.client.zzby;
import com.google.android.gms.ads.internal.client.zzbz;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelWriter;
import com.google.android.gms.internal.ads.zzbnu;
import com.google.android.gms.internal.ads.zzbnv;

@Deprecated
public final class PublisherAdViewOptions extends AbstractSafeParcelable {
  public static final Parcelable.Creator<PublisherAdViewOptions> CREATOR = new zzf();
  
  private final boolean zza;
  
  private final zzbz zzb;
  
  private final IBinder zzc;
  
  PublisherAdViewOptions(boolean paramBoolean, IBinder paramIBinder1, IBinder paramIBinder2) {
    this.zza = paramBoolean;
    if (paramIBinder1 != null) {
      zzbz zzbz1 = zzby.zzd(paramIBinder1);
    } else {
      paramIBinder1 = null;
    } 
    this.zzb = (zzbz)paramIBinder1;
    this.zzc = paramIBinder2;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    IBinder iBinder;
    paramInt = SafeParcelWriter.beginObjectHeader(paramParcel);
    SafeParcelWriter.writeBoolean(paramParcel, 1, this.zza);
    zzbz zzbz1 = this.zzb;
    if (zzbz1 == null) {
      zzbz1 = null;
    } else {
      iBinder = zzbz1.asBinder();
    } 
    SafeParcelWriter.writeIBinder(paramParcel, 2, iBinder, false);
    SafeParcelWriter.writeIBinder(paramParcel, 3, this.zzc, false);
    SafeParcelWriter.finishObjectHeader(paramParcel, paramInt);
  }
  
  public final zzbz zza() {
    return this.zzb;
  }
  
  public final zzbnv zzb() {
    IBinder iBinder = this.zzc;
    return (iBinder == null) ? null : zzbnu.zzc(iBinder);
  }
  
  public final boolean zzc() {
    return this.zza;
  }
  
  @Deprecated
  public static final class Builder {
    private ShouldDelayBannerRenderingListener zza;
    
    public Builder setShouldDelayBannerRenderingListener(ShouldDelayBannerRenderingListener param1ShouldDelayBannerRenderingListener) {
      this.zza = param1ShouldDelayBannerRenderingListener;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\formats\PublisherAdViewOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */