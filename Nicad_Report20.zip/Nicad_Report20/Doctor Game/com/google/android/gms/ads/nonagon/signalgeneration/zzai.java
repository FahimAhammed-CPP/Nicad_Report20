package com.google.android.gms.ads.nonagon.signalgeneration;

import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.internal.ads.zzbiu;
import com.google.android.gms.internal.ads.zzbjc;
import com.google.android.gms.internal.ads.zzdcg;
import com.google.android.gms.internal.ads.zzdch;
import com.google.android.gms.internal.ads.zzfhy;
import com.google.android.gms.internal.ads.zzfib;
import com.google.android.gms.internal.ads.zzfih;
import com.google.android.gms.internal.ads.zzgxi;
import com.google.android.gms.internal.ads.zzgxv;
import java.util.concurrent.TimeUnit;

public final class zzai implements zzgxi {
  private final zzgxv zza;
  
  private final zzgxv zzb;
  
  private final zzgxv zzc;
  
  public zzai(zzgxv paramzzgxv1, zzgxv paramzzgxv2, zzgxv paramzzgxv3) {
    this.zza = paramzzgxv1;
    this.zzb = paramzzgxv2;
    this.zzc = paramzzgxv3;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\nonagon\signalgeneration\zzai.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */