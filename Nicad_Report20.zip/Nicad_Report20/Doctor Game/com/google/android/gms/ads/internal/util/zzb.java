package com.google.android.gms.ads.internal.util;

import com.google.android.gms.internal.ads.zzchc;
import com.google.android.gms.internal.ads.zzfzp;

public abstract class zzb {
  private final Runnable zza = new zza(this);
  
  private volatile Thread zzb;
  
  public abstract void zza();
  
  public zzfzp zzb() {
    return zzchc.zza.zza(this.zza);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzb.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */