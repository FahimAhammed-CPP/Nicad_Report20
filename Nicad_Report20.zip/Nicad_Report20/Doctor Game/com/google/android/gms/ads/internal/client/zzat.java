package com.google.android.gms.ads.internal.client;

import android.content.Context;
import android.os.RemoteException;
import com.google.android.gms.dynamic.ObjectWrapper;
import com.google.android.gms.internal.ads.zzbvk;
import com.google.android.gms.internal.ads.zzccx;

final class zzat extends zzav {
  zzat(zzau paramzzau, Context paramContext, String paramString, zzbvk paramzzbvk) {}
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */