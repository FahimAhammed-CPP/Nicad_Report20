package com.google.android.gms.ads.internal.overlay;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.util.zze;
import com.google.android.gms.ads.internal.util.zzs;
import com.google.android.gms.ads.internal.zza;
import com.google.android.gms.ads.internal.zzb;
import com.google.android.gms.ads.internal.zzt;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.dynamic.ObjectWrapper;
import com.google.android.gms.internal.ads.zzbep;
import com.google.android.gms.internal.ads.zzbiu;
import com.google.android.gms.internal.ads.zzbjc;
import com.google.android.gms.internal.ads.zzbop;
import com.google.android.gms.internal.ads.zzbor;
import com.google.android.gms.internal.ads.zzbzb;
import com.google.android.gms.internal.ads.zzcgv;
import com.google.android.gms.internal.ads.zzcmp;
import com.google.android.gms.internal.ads.zzcnb;
import com.google.android.gms.internal.ads.zzcoc;
import com.google.android.gms.internal.ads.zzcoe;
import com.google.android.gms.internal.ads.zzegw;
import com.google.android.gms.internal.ads.zzfpz;
import java.util.Collections;

public class zzl extends zzbzb implements zzad {
  static final int zza = Color.argb(0, 0, 0, 0);
  
  protected final Activity zzb;
  
  AdOverlayInfoParcel zzc;
  
  zzcmp zzd;
  
  zzh zze;
  
  zzr zzf;
  
  boolean zzg = false;
  
  FrameLayout zzh;
  
  WebChromeClient.CustomViewCallback zzi;
  
  boolean zzj = false;
  
  boolean zzk = false;
  
  zzg zzl;
  
  boolean zzm = false;
  
  int zzn = 1;
  
  private final Object zzo = new Object();
  
  private Runnable zzp;
  
  private boolean zzq;
  
  private boolean zzr;
  
  private boolean zzs = false;
  
  private boolean zzt = false;
  
  private boolean zzu = true;
  
  public zzl(Activity paramActivity) {
    this.zzb = paramActivity;
  }
  
  private final void zzG(Configuration paramConfiguration) {
    // Byte code:
    //   0: aload_0
    //   1: getfield zzc : Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;
    //   4: astore #7
    //   6: iconst_1
    //   7: istore #4
    //   9: iconst_0
    //   10: istore #5
    //   12: aload #7
    //   14: ifnull -> 42
    //   17: aload #7
    //   19: getfield zzo : Lcom/google/android/gms/ads/internal/zzj;
    //   22: astore #7
    //   24: aload #7
    //   26: ifnull -> 42
    //   29: aload #7
    //   31: getfield zzb : Z
    //   34: ifeq -> 42
    //   37: iconst_1
    //   38: istore_2
    //   39: goto -> 44
    //   42: iconst_0
    //   43: istore_2
    //   44: invokestatic zzq : ()Lcom/google/android/gms/ads/internal/util/zzaa;
    //   47: aload_0
    //   48: getfield zzb : Landroid/app/Activity;
    //   51: aload_1
    //   52: invokevirtual zze : (Landroid/app/Activity;Landroid/content/res/Configuration;)Z
    //   55: istore #6
    //   57: aload_0
    //   58: getfield zzk : Z
    //   61: ifeq -> 68
    //   64: iload_2
    //   65: ifeq -> 124
    //   68: iload #6
    //   70: ifne -> 124
    //   73: aload_0
    //   74: getfield zzc : Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;
    //   77: astore_1
    //   78: iload #4
    //   80: istore_2
    //   81: iload #5
    //   83: istore_3
    //   84: aload_1
    //   85: ifnull -> 129
    //   88: aload_1
    //   89: getfield zzo : Lcom/google/android/gms/ads/internal/zzj;
    //   92: astore_1
    //   93: iload #4
    //   95: istore_2
    //   96: iload #5
    //   98: istore_3
    //   99: aload_1
    //   100: ifnull -> 129
    //   103: iload #4
    //   105: istore_2
    //   106: iload #5
    //   108: istore_3
    //   109: aload_1
    //   110: getfield zzg : Z
    //   113: ifeq -> 129
    //   116: iconst_1
    //   117: istore_3
    //   118: iload #4
    //   120: istore_2
    //   121: goto -> 129
    //   124: iconst_0
    //   125: istore_2
    //   126: iload #5
    //   128: istore_3
    //   129: aload_0
    //   130: getfield zzb : Landroid/app/Activity;
    //   133: invokevirtual getWindow : ()Landroid/view/Window;
    //   136: astore_1
    //   137: getstatic com/google/android/gms/internal/ads/zzbjc.zzaY : Lcom/google/android/gms/internal/ads/zzbiu;
    //   140: astore #7
    //   142: invokestatic zzc : ()Lcom/google/android/gms/internal/ads/zzbja;
    //   145: aload #7
    //   147: invokevirtual zzb : (Lcom/google/android/gms/internal/ads/zzbiu;)Ljava/lang/Object;
    //   150: checkcast java/lang/Boolean
    //   153: invokevirtual booleanValue : ()Z
    //   156: ifeq -> 196
    //   159: aload_1
    //   160: invokevirtual getDecorView : ()Landroid/view/View;
    //   163: astore_1
    //   164: iload_2
    //   165: ifeq -> 186
    //   168: iload_3
    //   169: ifeq -> 179
    //   172: sipush #5894
    //   175: istore_2
    //   176: goto -> 190
    //   179: sipush #5380
    //   182: istore_2
    //   183: goto -> 190
    //   186: sipush #256
    //   189: istore_2
    //   190: aload_1
    //   191: iload_2
    //   192: invokevirtual setSystemUiVisibility : (I)V
    //   195: return
    //   196: iload_2
    //   197: ifeq -> 229
    //   200: aload_1
    //   201: sipush #1024
    //   204: invokevirtual addFlags : (I)V
    //   207: aload_1
    //   208: sipush #2048
    //   211: invokevirtual clearFlags : (I)V
    //   214: iload_3
    //   215: ifeq -> 228
    //   218: aload_1
    //   219: invokevirtual getDecorView : ()Landroid/view/View;
    //   222: sipush #4098
    //   225: invokevirtual setSystemUiVisibility : (I)V
    //   228: return
    //   229: aload_1
    //   230: sipush #2048
    //   233: invokevirtual addFlags : (I)V
    //   236: aload_1
    //   237: sipush #1024
    //   240: invokevirtual clearFlags : (I)V
    //   243: return
  }
  
  private static final void zzH(IObjectWrapper paramIObjectWrapper, View paramView) {
    if (paramIObjectWrapper != null && paramView != null)
      zzt.zzA().zzc(paramIObjectWrapper, paramView); 
  }
  
  public final void zzA(View paramView, WebChromeClient.CustomViewCallback paramCustomViewCallback) {
    FrameLayout frameLayout = new FrameLayout((Context)this.zzb);
    this.zzh = frameLayout;
    frameLayout.setBackgroundColor(-16777216);
    this.zzh.addView(paramView, -1, -1);
    this.zzb.setContentView((View)this.zzh);
    this.zzr = true;
    this.zzi = paramCustomViewCallback;
    this.zzg = true;
  }
  
  protected final void zzB(boolean paramBoolean) throws zzf {
    if (!this.zzr)
      this.zzb.requestWindowFeature(1); 
    Window window = this.zzb.getWindow();
    if (window != null) {
      boolean bool2;
      zzcmp zzcmp2 = this.zzc.zzd;
      AdOverlayInfoParcel adOverlayInfoParcel2 = null;
      if (zzcmp2 != null) {
        zzcoc zzcoc = zzcmp2.zzP();
      } else {
        zzcmp2 = null;
      } 
      boolean bool4 = false;
      boolean bool5 = false;
      boolean bool3 = false;
      if (zzcmp2 != null && zzcmp2.zzJ()) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      this.zzm = false;
      boolean bool1 = bool5;
      if (bool2) {
        int i = this.zzc.zzj;
        if (i == 6) {
          bool1 = bool3;
          if ((this.zzb.getResources().getConfiguration()).orientation == 1)
            bool1 = true; 
          this.zzm = bool1;
        } else {
          bool1 = bool5;
          if (i == 7) {
            bool1 = bool4;
            if ((this.zzb.getResources().getConfiguration()).orientation == 2)
              bool1 = true; 
            this.zzm = bool1;
          } 
        } 
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Delay onShow to next orientation change: ");
      stringBuilder.append(bool1);
      zze.zze(stringBuilder.toString());
      zzy(this.zzc.zzj);
      window.setFlags(16777216, 16777216);
      zze.zze("Hardware acceleration on the AdActivity window enabled.");
      if (!this.zzk) {
        this.zzl.setBackgroundColor(-16777216);
      } else {
        this.zzl.setBackgroundColor(zza);
      } 
      this.zzb.setContentView((View)this.zzl);
      this.zzr = true;
      if (paramBoolean) {
        try {
          zzb zzb;
          zzt.zzz();
          Activity activity = this.zzb;
          zzcmp zzcmp4 = this.zzc.zzd;
          if (zzcmp4 != null) {
            zzcoe zzcoe = zzcmp4.zzQ();
          } else {
            zzcmp4 = null;
          } 
          zzcmp zzcmp5 = this.zzc.zzd;
          if (zzcmp5 != null) {
            String str1 = zzcmp5.zzU();
          } else {
            zzcmp5 = null;
          } 
          AdOverlayInfoParcel adOverlayInfoParcel5 = this.zzc;
          zzcgv zzcgv = adOverlayInfoParcel5.zzm;
          zzcmp zzcmp6 = adOverlayInfoParcel5.zzd;
          if (zzcmp6 != null) {
            zza zza = zzcmp6.zzm();
          } else {
            zzcmp6 = null;
          } 
          zzcmp4 = zzcnb.zza((Context)activity, (zzcoe)zzcmp4, (String)zzcmp5, true, bool2, null, null, zzcgv, null, null, (zza)zzcmp6, zzbep.zza(), null, null);
          this.zzd = zzcmp4;
          zzcoc zzcoc = zzcmp4.zzP();
          AdOverlayInfoParcel adOverlayInfoParcel4 = this.zzc;
          zzbop zzbop = adOverlayInfoParcel4.zzp;
          zzbor zzbor = adOverlayInfoParcel4.zze;
          zzz zzz = adOverlayInfoParcel4.zzi;
          zzcmp zzcmp7 = adOverlayInfoParcel4.zzd;
          adOverlayInfoParcel4 = adOverlayInfoParcel2;
          if (zzcmp7 != null)
            zzb = zzcmp7.zzP().zzd(); 
          zzcoc.zzL(null, zzbop, null, zzbor, zzz, true, null, zzb, null, null, null, null, null, null, null, null, null, null);
          this.zzd.zzP().zzz(new zzd(this));
          AdOverlayInfoParcel adOverlayInfoParcel3 = this.zzc;
          String str = adOverlayInfoParcel3.zzl;
          if (str != null) {
            this.zzd.loadUrl(str);
          } else {
            str = adOverlayInfoParcel3.zzh;
            if (str != null) {
              this.zzd.loadDataWithBaseURL(adOverlayInfoParcel3.zzf, str, "text/html", "UTF-8", null);
            } else {
              throw new zzf("No URL or HTML to display in ad overlay.");
            } 
          } 
          zzcmp zzcmp3 = this.zzc.zzd;
          if (zzcmp3 != null)
            zzcmp3.zzat(this); 
        } catch (Exception exception) {
          zze.zzh("Error obtaining webview.", exception);
          throw new zzf("Could not obtain webview for the overlay.", exception);
        } 
      } else {
        zzcmp zzcmp3 = this.zzc.zzd;
        this.zzd = zzcmp3;
        zzcmp3.zzam((Context)this.zzb);
      } 
      this.zzd.zzah(this);
      zzcmp zzcmp1 = this.zzc.zzd;
      if (zzcmp1 != null)
        zzH(zzcmp1.zzS(), (View)this.zzl); 
      if (this.zzc.zzk != 5) {
        ViewParent viewParent = this.zzd.getParent();
        if (viewParent != null && viewParent instanceof ViewGroup)
          ((ViewGroup)viewParent).removeView(this.zzd.zzH()); 
        if (this.zzk)
          this.zzd.zzal(); 
        this.zzl.addView(this.zzd.zzH(), -1, -1);
      } 
      if (!paramBoolean && !this.zzm)
        zze(); 
      AdOverlayInfoParcel adOverlayInfoParcel1 = this.zzc;
      if (adOverlayInfoParcel1.zzk != 5) {
        zzu(bool2);
        if (this.zzd.zzay())
          zzw(bool2, true); 
        return;
      } 
      zzegw.zzh(this.zzb, this, adOverlayInfoParcel1.zzu, adOverlayInfoParcel1.zzr, adOverlayInfoParcel1.zzs, adOverlayInfoParcel1.zzt, adOverlayInfoParcel1.zzq, adOverlayInfoParcel1.zzv);
      return;
    } 
    throw new zzf("Invalid activity, no window available.");
  }
  
  public final void zzC() {
    synchronized (this.zzo) {
      this.zzq = true;
      if (this.zzp != null) {
        zzs.zza.removeCallbacks(this.zzp);
        zzs.zza.post(this.zzp);
      } 
      return;
    } 
  }
  
  protected final void zzD() {
    if (this.zzb.isFinishing()) {
      if (this.zzs)
        return; 
      this.zzs = true;
      zzcmp zzcmp1 = this.zzd;
      if (zzcmp1 != null) {
        zzcmp1.zzY(this.zzn - 1);
        synchronized (this.zzo) {
          if (!this.zzq && this.zzd.zzaz()) {
            zzbiu zzbiu1 = zzbjc.zzdV;
            if (((Boolean)zzay.zzc().zzb(zzbiu1)).booleanValue() && !this.zzt) {
              AdOverlayInfoParcel adOverlayInfoParcel = this.zzc;
              if (adOverlayInfoParcel != null) {
                zzo zzo = adOverlayInfoParcel.zzc;
                if (zzo != null)
                  zzo.zzbC(); 
              } 
            } 
            this.zzp = new zze(this);
            zzfpz zzfpz = zzs.zza;
            Runnable runnable = this.zzp;
            zzbiu zzbiu2 = zzbjc.zzaR;
            zzfpz.postDelayed(runnable, ((Long)zzay.zzc().zzb(zzbiu2)).longValue());
            return;
          } 
        } 
      } 
      zzc();
    } 
  }
  
  public final boolean zzE() {
    this.zzn = 1;
    if (this.zzd == null)
      return true; 
    zzbiu zzbiu = zzbjc.zzhE;
    if (!((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue() || !this.zzd.canGoBack()) {
      boolean bool = this.zzd.zzaE();
      if (!bool)
        this.zzd.zzd("onbackblocked", Collections.emptyMap()); 
      return bool;
    } 
    this.zzd.goBack();
    return false;
  }
  
  public final void zzb() {
    this.zzn = 3;
    this.zzb.finish();
    AdOverlayInfoParcel adOverlayInfoParcel = this.zzc;
    if (adOverlayInfoParcel != null && adOverlayInfoParcel.zzk == 5)
      this.zzb.overridePendingTransition(0, 0); 
  }
  
  public final void zzbJ() {
    this.zzn = 2;
    this.zzb.finish();
  }
  
  final void zzc() {
    if (this.zzt)
      return; 
    this.zzt = true;
    zzcmp zzcmp1 = this.zzd;
    if (zzcmp1 != null) {
      this.zzl.removeView(zzcmp1.zzH());
      zzh zzh1 = this.zze;
      if (zzh1 != null) {
        this.zzd.zzam(zzh1.zzd);
        this.zzd.zzap(false);
        ViewGroup viewGroup = this.zze.zzc;
        View view = this.zzd.zzH();
        zzh zzh2 = this.zze;
        viewGroup.addView(view, zzh2.zza, zzh2.zzb);
        this.zze = null;
      } else if (this.zzb.getApplicationContext() != null) {
        this.zzd.zzam(this.zzb.getApplicationContext());
      } 
      this.zzd = null;
    } 
    AdOverlayInfoParcel adOverlayInfoParcel = this.zzc;
    if (adOverlayInfoParcel != null) {
      zzo zzo = adOverlayInfoParcel.zzc;
      if (zzo != null)
        zzo.zzf(this.zzn); 
    } 
    adOverlayInfoParcel = this.zzc;
    if (adOverlayInfoParcel != null) {
      zzcmp zzcmp2 = adOverlayInfoParcel.zzd;
      if (zzcmp2 != null)
        zzH(zzcmp2.zzS(), this.zzc.zzd.zzH()); 
    } 
  }
  
  public final void zzd() {
    this.zzl.zzb = true;
  }
  
  protected final void zze() {
    this.zzd.zzZ();
  }
  
  public final void zzf() {
    AdOverlayInfoParcel adOverlayInfoParcel = this.zzc;
    if (adOverlayInfoParcel != null && this.zzg)
      zzy(adOverlayInfoParcel.zzj); 
    if (this.zzh != null) {
      this.zzb.setContentView((View)this.zzl);
      this.zzr = true;
      this.zzh.removeAllViews();
      this.zzh = null;
    } 
    WebChromeClient.CustomViewCallback customViewCallback = this.zzi;
    if (customViewCallback != null) {
      customViewCallback.onCustomViewHidden();
      this.zzi = null;
    } 
    this.zzg = false;
  }
  
  public final void zzg(int paramInt1, int paramInt2, Intent paramIntent) {}
  
  public final void zzh() {
    this.zzn = 1;
  }
  
  public final void zzj(IObjectWrapper paramIObjectWrapper) {
    zzG((Configuration)ObjectWrapper.unwrap(paramIObjectWrapper));
  }
  
  public void zzk(Bundle paramBundle) {
    // Byte code:
    //   0: aload_0
    //   1: getfield zzb : Landroid/app/Activity;
    //   4: iconst_1
    //   5: invokevirtual requestWindowFeature : (I)Z
    //   8: pop
    //   9: aload_1
    //   10: ifnull -> 29
    //   13: aload_1
    //   14: ldc_w 'com.google.android.gms.ads.internal.overlay.hasResumed'
    //   17: iconst_0
    //   18: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   21: ifeq -> 29
    //   24: iconst_1
    //   25: istore_3
    //   26: goto -> 31
    //   29: iconst_0
    //   30: istore_3
    //   31: aload_0
    //   32: iload_3
    //   33: putfield zzj : Z
    //   36: aload_0
    //   37: getfield zzb : Landroid/app/Activity;
    //   40: invokevirtual getIntent : ()Landroid/content/Intent;
    //   43: invokestatic zza : (Landroid/content/Intent;)Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;
    //   46: astore #4
    //   48: aload_0
    //   49: aload #4
    //   51: putfield zzc : Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;
    //   54: aload #4
    //   56: ifnull -> 426
    //   59: aload #4
    //   61: getfield zzm : Lcom/google/android/gms/internal/ads/zzcgv;
    //   64: getfield zzc : I
    //   67: ldc_w 7500000
    //   70: if_icmple -> 78
    //   73: aload_0
    //   74: iconst_4
    //   75: putfield zzn : I
    //   78: aload_0
    //   79: getfield zzb : Landroid/app/Activity;
    //   82: invokevirtual getIntent : ()Landroid/content/Intent;
    //   85: ifnull -> 106
    //   88: aload_0
    //   89: aload_0
    //   90: getfield zzb : Landroid/app/Activity;
    //   93: invokevirtual getIntent : ()Landroid/content/Intent;
    //   96: ldc_w 'shouldCallOnOverlayOpened'
    //   99: iconst_1
    //   100: invokevirtual getBooleanExtra : (Ljava/lang/String;Z)Z
    //   103: putfield zzu : Z
    //   106: aload_0
    //   107: getfield zzc : Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;
    //   110: astore #4
    //   112: aload #4
    //   114: getfield zzo : Lcom/google/android/gms/ads/internal/zzj;
    //   117: astore #5
    //   119: aload #5
    //   121: ifnull -> 142
    //   124: aload #5
    //   126: getfield zza : Z
    //   129: istore_3
    //   130: aload_0
    //   131: iload_3
    //   132: putfield zzk : Z
    //   135: iload_3
    //   136: ifeq -> 195
    //   139: goto -> 156
    //   142: aload #4
    //   144: getfield zzk : I
    //   147: iconst_5
    //   148: if_icmpne -> 190
    //   151: aload_0
    //   152: iconst_1
    //   153: putfield zzk : Z
    //   156: aload #4
    //   158: getfield zzk : I
    //   161: iconst_5
    //   162: if_icmpeq -> 195
    //   165: aload #5
    //   167: getfield zzf : I
    //   170: iconst_m1
    //   171: if_icmpeq -> 195
    //   174: new com/google/android/gms/ads/internal/overlay/zzk
    //   177: dup
    //   178: aload_0
    //   179: aconst_null
    //   180: invokespecial <init> : (Lcom/google/android/gms/ads/internal/overlay/zzl;Lcom/google/android/gms/ads/internal/overlay/zzj;)V
    //   183: invokevirtual zzb : ()Lcom/google/android/gms/internal/ads/zzfzp;
    //   186: pop
    //   187: goto -> 195
    //   190: aload_0
    //   191: iconst_0
    //   192: putfield zzk : Z
    //   195: aload_1
    //   196: ifnonnull -> 286
    //   199: aload_0
    //   200: getfield zzu : Z
    //   203: ifeq -> 240
    //   206: aload_0
    //   207: getfield zzc : Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;
    //   210: getfield zzx : Lcom/google/android/gms/internal/ads/zzddn;
    //   213: astore_1
    //   214: aload_1
    //   215: ifnull -> 222
    //   218: aload_1
    //   219: invokevirtual zze : ()V
    //   222: aload_0
    //   223: getfield zzc : Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;
    //   226: getfield zzc : Lcom/google/android/gms/ads/internal/overlay/zzo;
    //   229: astore_1
    //   230: aload_1
    //   231: ifnull -> 240
    //   234: aload_1
    //   235: invokeinterface zzb : ()V
    //   240: aload_0
    //   241: getfield zzc : Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;
    //   244: astore_1
    //   245: aload_1
    //   246: getfield zzk : I
    //   249: iconst_1
    //   250: if_icmpeq -> 286
    //   253: aload_1
    //   254: getfield zzb : Lcom/google/android/gms/ads/internal/client/zza;
    //   257: astore_1
    //   258: aload_1
    //   259: ifnull -> 268
    //   262: aload_1
    //   263: invokeinterface onAdClicked : ()V
    //   268: aload_0
    //   269: getfield zzc : Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;
    //   272: getfield zzy : Lcom/google/android/gms/internal/ads/zzdkn;
    //   275: astore_1
    //   276: aload_1
    //   277: ifnull -> 286
    //   280: aload_1
    //   281: invokeinterface zzq : ()V
    //   286: aload_0
    //   287: getfield zzb : Landroid/app/Activity;
    //   290: astore_1
    //   291: aload_0
    //   292: getfield zzc : Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;
    //   295: astore #4
    //   297: new com/google/android/gms/ads/internal/overlay/zzg
    //   300: dup
    //   301: aload_1
    //   302: aload #4
    //   304: getfield zzn : Ljava/lang/String;
    //   307: aload #4
    //   309: getfield zzm : Lcom/google/android/gms/internal/ads/zzcgv;
    //   312: getfield zza : Ljava/lang/String;
    //   315: aload #4
    //   317: getfield zzw : Ljava/lang/String;
    //   320: invokespecial <init> : (Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   323: astore_1
    //   324: aload_0
    //   325: aload_1
    //   326: putfield zzl : Lcom/google/android/gms/ads/internal/overlay/zzg;
    //   329: aload_1
    //   330: sipush #1000
    //   333: invokevirtual setId : (I)V
    //   336: invokestatic zzq : ()Lcom/google/android/gms/ads/internal/util/zzaa;
    //   339: aload_0
    //   340: getfield zzb : Landroid/app/Activity;
    //   343: invokevirtual zzj : (Landroid/app/Activity;)V
    //   346: aload_0
    //   347: getfield zzc : Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;
    //   350: astore_1
    //   351: aload_1
    //   352: getfield zzk : I
    //   355: istore_2
    //   356: iload_2
    //   357: iconst_1
    //   358: if_icmpeq -> 420
    //   361: iload_2
    //   362: iconst_2
    //   363: if_icmpeq -> 399
    //   366: iload_2
    //   367: iconst_3
    //   368: if_icmpeq -> 393
    //   371: iload_2
    //   372: iconst_5
    //   373: if_icmpne -> 382
    //   376: aload_0
    //   377: iconst_0
    //   378: invokevirtual zzB : (Z)V
    //   381: return
    //   382: new com/google/android/gms/ads/internal/overlay/zzf
    //   385: dup
    //   386: ldc_w 'Could not determine ad overlay type.'
    //   389: invokespecial <init> : (Ljava/lang/String;)V
    //   392: athrow
    //   393: aload_0
    //   394: iconst_1
    //   395: invokevirtual zzB : (Z)V
    //   398: return
    //   399: aload_0
    //   400: new com/google/android/gms/ads/internal/overlay/zzh
    //   403: dup
    //   404: aload_1
    //   405: getfield zzd : Lcom/google/android/gms/internal/ads/zzcmp;
    //   408: invokespecial <init> : (Lcom/google/android/gms/internal/ads/zzcmp;)V
    //   411: putfield zze : Lcom/google/android/gms/ads/internal/overlay/zzh;
    //   414: aload_0
    //   415: iconst_0
    //   416: invokevirtual zzB : (Z)V
    //   419: return
    //   420: aload_0
    //   421: iconst_0
    //   422: invokevirtual zzB : (Z)V
    //   425: return
    //   426: new com/google/android/gms/ads/internal/overlay/zzf
    //   429: dup
    //   430: ldc_w 'Could not get info for ad overlay.'
    //   433: invokespecial <init> : (Ljava/lang/String;)V
    //   436: athrow
    //   437: astore_1
    //   438: aload_1
    //   439: invokevirtual getMessage : ()Ljava/lang/String;
    //   442: invokestatic zzj : (Ljava/lang/String;)V
    //   445: aload_0
    //   446: iconst_4
    //   447: putfield zzn : I
    //   450: aload_0
    //   451: getfield zzb : Landroid/app/Activity;
    //   454: invokevirtual finish : ()V
    //   457: return
    // Exception table:
    //   from	to	target	type
    //   36	54	437	com/google/android/gms/ads/internal/overlay/zzf
    //   59	78	437	com/google/android/gms/ads/internal/overlay/zzf
    //   78	106	437	com/google/android/gms/ads/internal/overlay/zzf
    //   106	119	437	com/google/android/gms/ads/internal/overlay/zzf
    //   124	135	437	com/google/android/gms/ads/internal/overlay/zzf
    //   142	156	437	com/google/android/gms/ads/internal/overlay/zzf
    //   156	187	437	com/google/android/gms/ads/internal/overlay/zzf
    //   190	195	437	com/google/android/gms/ads/internal/overlay/zzf
    //   199	214	437	com/google/android/gms/ads/internal/overlay/zzf
    //   218	222	437	com/google/android/gms/ads/internal/overlay/zzf
    //   222	230	437	com/google/android/gms/ads/internal/overlay/zzf
    //   234	240	437	com/google/android/gms/ads/internal/overlay/zzf
    //   240	258	437	com/google/android/gms/ads/internal/overlay/zzf
    //   262	268	437	com/google/android/gms/ads/internal/overlay/zzf
    //   268	276	437	com/google/android/gms/ads/internal/overlay/zzf
    //   280	286	437	com/google/android/gms/ads/internal/overlay/zzf
    //   286	356	437	com/google/android/gms/ads/internal/overlay/zzf
    //   376	381	437	com/google/android/gms/ads/internal/overlay/zzf
    //   382	393	437	com/google/android/gms/ads/internal/overlay/zzf
    //   393	398	437	com/google/android/gms/ads/internal/overlay/zzf
    //   399	419	437	com/google/android/gms/ads/internal/overlay/zzf
    //   420	425	437	com/google/android/gms/ads/internal/overlay/zzf
    //   426	437	437	com/google/android/gms/ads/internal/overlay/zzf
  }
  
  public final void zzl() {
    zzcmp zzcmp1 = this.zzd;
    if (zzcmp1 != null)
      try {
        this.zzl.removeView(zzcmp1.zzH());
      } catch (NullPointerException nullPointerException) {} 
    zzD();
  }
  
  public final void zzm() {
    if (this.zzm) {
      this.zzm = false;
      zze();
    } 
  }
  
  public final void zzn() {
    zzf();
    AdOverlayInfoParcel adOverlayInfoParcel = this.zzc;
    if (adOverlayInfoParcel != null) {
      zzo zzo = adOverlayInfoParcel.zzc;
      if (zzo != null)
        zzo.zzbr(); 
    } 
    zzbiu zzbiu = zzbjc.zzdX;
    if (!((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue() && this.zzd != null && (!this.zzb.isFinishing() || this.zze == null))
      this.zzd.onPause(); 
    zzD();
  }
  
  public final void zzo() {}
  
  public final void zzp() {
    AdOverlayInfoParcel adOverlayInfoParcel = this.zzc;
    if (adOverlayInfoParcel != null) {
      zzo zzo = adOverlayInfoParcel.zzc;
      if (zzo != null)
        zzo.zzbK(); 
    } 
    zzG(this.zzb.getResources().getConfiguration());
    zzbiu zzbiu = zzbjc.zzdX;
    if (!((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue()) {
      zzcmp zzcmp1 = this.zzd;
      if (zzcmp1 != null && !zzcmp1.zzaB()) {
        this.zzd.onResume();
        return;
      } 
      zze.zzj("The webview does not exist. Ignoring action.");
    } 
  }
  
  public final void zzq(Bundle paramBundle) {
    paramBundle.putBoolean("com.google.android.gms.ads.internal.overlay.hasResumed", this.zzj);
  }
  
  public final void zzr() {
    zzbiu zzbiu = zzbjc.zzdX;
    if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue()) {
      zzcmp zzcmp1 = this.zzd;
      if (zzcmp1 != null && !zzcmp1.zzaB()) {
        this.zzd.onResume();
        return;
      } 
      zze.zzj("The webview does not exist. Ignoring action.");
    } 
  }
  
  public final void zzs() {
    zzbiu zzbiu = zzbjc.zzdX;
    if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue() && this.zzd != null && (!this.zzb.isFinishing() || this.zze == null))
      this.zzd.onPause(); 
    zzD();
  }
  
  public final void zzt() {
    AdOverlayInfoParcel adOverlayInfoParcel = this.zzc;
    if (adOverlayInfoParcel != null) {
      zzo zzo = adOverlayInfoParcel.zzc;
      if (zzo != null)
        zzo.zze(); 
    } 
  }
  
  public final void zzu(boolean paramBoolean) {
    boolean bool1;
    zzbiu zzbiu = zzbjc.zzdZ;
    int i = ((Integer)zzay.zzc().zzb(zzbiu)).intValue();
    zzbiu = zzbjc.zzaU;
    boolean bool = ((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue();
    boolean bool2 = false;
    if (bool || paramBoolean) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    zzq zzq = new zzq();
    zzq.zzd = 50;
    if (true != bool1) {
      j = 0;
    } else {
      j = i;
    } 
    zzq.zza = j;
    int j = bool2;
    if (true != bool1)
      j = i; 
    zzq.zzb = j;
    zzq.zzc = i;
    this.zzf = new zzr((Context)this.zzb, zzq, this);
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
    layoutParams.addRule(10);
    if (true != bool1) {
      i = 9;
    } else {
      i = 11;
    } 
    layoutParams.addRule(i);
    zzw(paramBoolean, this.zzc.zzg);
    this.zzl.addView((View)this.zzf, (ViewGroup.LayoutParams)layoutParams);
  }
  
  public final void zzv() {
    this.zzr = true;
  }
  
  public final void zzw(boolean paramBoolean1, boolean paramBoolean2) {
    // Byte code:
    //   0: getstatic com/google/android/gms/internal/ads/zzbjc.zzaS : Lcom/google/android/gms/internal/ads/zzbiu;
    //   3: astore #7
    //   5: invokestatic zzc : ()Lcom/google/android/gms/internal/ads/zzbja;
    //   8: aload #7
    //   10: invokevirtual zzb : (Lcom/google/android/gms/internal/ads/zzbiu;)Ljava/lang/Object;
    //   13: checkcast java/lang/Boolean
    //   16: invokevirtual booleanValue : ()Z
    //   19: istore #6
    //   21: iconst_1
    //   22: istore #5
    //   24: iload #6
    //   26: ifeq -> 65
    //   29: aload_0
    //   30: getfield zzc : Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;
    //   33: astore #7
    //   35: aload #7
    //   37: ifnull -> 65
    //   40: aload #7
    //   42: getfield zzo : Lcom/google/android/gms/ads/internal/zzj;
    //   45: astore #7
    //   47: aload #7
    //   49: ifnull -> 65
    //   52: aload #7
    //   54: getfield zzh : Z
    //   57: ifeq -> 65
    //   60: iconst_1
    //   61: istore_3
    //   62: goto -> 67
    //   65: iconst_0
    //   66: istore_3
    //   67: getstatic com/google/android/gms/internal/ads/zzbjc.zzaT : Lcom/google/android/gms/internal/ads/zzbiu;
    //   70: astore #7
    //   72: invokestatic zzc : ()Lcom/google/android/gms/internal/ads/zzbja;
    //   75: aload #7
    //   77: invokevirtual zzb : (Lcom/google/android/gms/internal/ads/zzbiu;)Ljava/lang/Object;
    //   80: checkcast java/lang/Boolean
    //   83: invokevirtual booleanValue : ()Z
    //   86: ifeq -> 126
    //   89: aload_0
    //   90: getfield zzc : Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;
    //   93: astore #7
    //   95: aload #7
    //   97: ifnull -> 126
    //   100: aload #7
    //   102: getfield zzo : Lcom/google/android/gms/ads/internal/zzj;
    //   105: astore #7
    //   107: aload #7
    //   109: ifnull -> 126
    //   112: aload #7
    //   114: getfield zzi : Z
    //   117: ifeq -> 126
    //   120: iconst_1
    //   121: istore #4
    //   123: goto -> 129
    //   126: iconst_0
    //   127: istore #4
    //   129: iload_1
    //   130: ifeq -> 166
    //   133: iload_2
    //   134: ifeq -> 166
    //   137: iload_3
    //   138: ifeq -> 166
    //   141: iload #4
    //   143: ifne -> 166
    //   146: new com/google/android/gms/internal/ads/zzbyf
    //   149: dup
    //   150: aload_0
    //   151: getfield zzd : Lcom/google/android/gms/internal/ads/zzcmp;
    //   154: ldc_w 'useCustomClose'
    //   157: invokespecial <init> : (Lcom/google/android/gms/internal/ads/zzcmp;Ljava/lang/String;)V
    //   160: ldc_w 'Custom close has been disabled for interstitial ads in this ad slot.'
    //   163: invokevirtual zzg : (Ljava/lang/String;)V
    //   166: aload_0
    //   167: getfield zzf : Lcom/google/android/gms/ads/internal/overlay/zzr;
    //   170: astore #7
    //   172: aload #7
    //   174: ifnull -> 207
    //   177: iload #5
    //   179: istore_1
    //   180: iload #4
    //   182: ifne -> 201
    //   185: iload_2
    //   186: ifeq -> 199
    //   189: iload_3
    //   190: ifne -> 199
    //   193: iload #5
    //   195: istore_1
    //   196: goto -> 201
    //   199: iconst_0
    //   200: istore_1
    //   201: aload #7
    //   203: iload_1
    //   204: invokevirtual zzb : (Z)V
    //   207: return
  }
  
  public final void zzx() {
    this.zzl.removeView((View)this.zzf);
    zzu(true);
  }
  
  public final void zzy(int paramInt) {
    int i = (this.zzb.getApplicationInfo()).targetSdkVersion;
    zzbiu zzbiu = zzbjc.zzfb;
    if (i >= ((Integer)zzay.zzc().zzb(zzbiu)).intValue()) {
      i = (this.zzb.getApplicationInfo()).targetSdkVersion;
      zzbiu = zzbjc.zzfc;
      if (i <= ((Integer)zzay.zzc().zzb(zzbiu)).intValue()) {
        i = Build.VERSION.SDK_INT;
        zzbiu = zzbjc.zzfd;
        if (i >= ((Integer)zzay.zzc().zzb(zzbiu)).intValue()) {
          i = Build.VERSION.SDK_INT;
          zzbiu = zzbjc.zzfe;
          if (i <= ((Integer)zzay.zzc().zzb(zzbiu)).intValue())
            return; 
        } 
      } 
    } 
    try {
      return;
    } finally {
      zzbiu = null;
      zzt.zzo().zzs((Throwable)zzbiu, "AdOverlay.setRequestedOrientation");
    } 
  }
  
  public final void zzz(boolean paramBoolean) {
    if (paramBoolean) {
      this.zzl.setBackgroundColor(0);
      return;
    } 
    this.zzl.setBackgroundColor(-16777216);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\overlay\zzl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */