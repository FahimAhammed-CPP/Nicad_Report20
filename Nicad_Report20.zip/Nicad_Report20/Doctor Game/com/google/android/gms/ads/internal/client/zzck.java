package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.internal.ads.zzarz;
import com.google.android.gms.internal.ads.zzasb;
import com.google.android.gms.internal.ads.zzbrq;
import com.google.android.gms.internal.ads.zzbrx;
import com.google.android.gms.internal.ads.zzbvk;
import java.util.ArrayList;
import java.util.List;

public final class zzck extends zzarz implements zzcm {
  zzck(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IMobileAdsSettingManager");
  }
  
  public final float zze() throws RemoteException {
    Parcel parcel = zzbk(7, zza());
    float f = parcel.readFloat();
    parcel.recycle();
    return f;
  }
  
  public final String zzf() throws RemoteException {
    Parcel parcel = zzbk(9, zza());
    String str = parcel.readString();
    parcel.recycle();
    return str;
  }
  
  public final List zzg() throws RemoteException {
    Parcel parcel = zzbk(13, zza());
    ArrayList arrayList = parcel.createTypedArrayList(zzbrq.CREATOR);
    parcel.recycle();
    return arrayList;
  }
  
  public final void zzh(String paramString) throws RemoteException {
    Parcel parcel = zza();
    parcel.writeString(paramString);
    zzbl(10, parcel);
  }
  
  public final void zzi() throws RemoteException {
    zzbl(15, zza());
  }
  
  public final void zzj() throws RemoteException {
    zzbl(1, zza());
  }
  
  public final void zzk(String paramString, IObjectWrapper paramIObjectWrapper) throws RemoteException {
    Parcel parcel = zza();
    parcel.writeString(null);
    zzasb.zzg(parcel, (IInterface)paramIObjectWrapper);
    zzbl(6, parcel);
  }
  
  public final void zzl(zzcy paramzzcy) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zzg(parcel, paramzzcy);
    zzbl(16, parcel);
  }
  
  public final void zzm(IObjectWrapper paramIObjectWrapper, String paramString) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zzg(parcel, (IInterface)paramIObjectWrapper);
    parcel.writeString(paramString);
    zzbl(5, parcel);
  }
  
  public final void zzn(zzbvk paramzzbvk) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zzg(parcel, (IInterface)paramzzbvk);
    zzbl(11, parcel);
  }
  
  public final void zzo(boolean paramBoolean) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zzd(parcel, paramBoolean);
    zzbl(4, parcel);
  }
  
  public final void zzp(float paramFloat) throws RemoteException {
    Parcel parcel = zza();
    parcel.writeFloat(paramFloat);
    zzbl(2, parcel);
  }
  
  public final void zzq(String paramString) throws RemoteException {
    throw null;
  }
  
  public final void zzr(zzbrx paramzzbrx) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zzg(parcel, (IInterface)paramzzbrx);
    zzbl(12, parcel);
  }
  
  public final void zzs(zzez paramzzez) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zze(parcel, (Parcelable)paramzzez);
    zzbl(14, parcel);
  }
  
  public final boolean zzt() throws RemoteException {
    Parcel parcel = zzbk(8, zza());
    boolean bool = zzasb.zzh(parcel);
    parcel.recycle();
    return bool;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzck.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */