package com.google.android.gms.ads.internal.client;

import com.google.android.gms.ads.AdInspectorError;
import com.google.android.gms.ads.OnAdInspectorClosedListener;
import javax.annotation.Nullable;

final class zzea extends zzcx {
  private zzea() {}
  
  public final void zze(@Nullable zze paramzze) {
    OnAdInspectorClosedListener onAdInspectorClosedListener = zzed.zzb(zzed.zzf());
    if (onAdInspectorClosedListener != null) {
      AdInspectorError adInspectorError;
      if (paramzze == null) {
        paramzze = null;
      } else {
        adInspectorError = new AdInspectorError(paramzze.zza, paramzze.zzb, paramzze.zzc);
      } 
      onAdInspectorClosedListener.onAdInspectorClosed(adInspectorError);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzea.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */