package com.google.android.gms.ads.internal.overlay;

import com.google.android.gms.internal.ads.zzfre;
import com.google.android.gms.internal.ads.zzfrf;

final class zzv implements zzfrf {
  zzv(zzw paramzzw) {}
  
  public final void zza(zzfre paramzzfre) {
    this.zza.zzi(paramzzfre);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\overlay\zzv.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */