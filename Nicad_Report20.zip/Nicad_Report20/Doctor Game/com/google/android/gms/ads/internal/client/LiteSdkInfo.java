package com.google.android.gms.ads.internal.client;

import android.content.Context;
import com.google.android.gms.internal.ads.zzbvh;
import com.google.android.gms.internal.ads.zzbvk;

public class LiteSdkInfo extends zzci {
  public LiteSdkInfo(Context paramContext) {}
  
  public zzbvk getAdapterCreator() {
    return (zzbvk)new zzbvh();
  }
  
  public zzeh getLiteSdkVersion() {
    return new zzeh(223104600, 223104000, "21.3.0");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\LiteSdkInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */