package com.google.android.gms.ads.internal.offline.buffering;

import android.content.Context;
import android.os.RemoteException;
import androidx.work.ListenableWorker;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import com.google.android.gms.ads.internal.client.zzaw;
import com.google.android.gms.dynamic.ObjectWrapper;
import com.google.android.gms.internal.ads.zzbvh;
import com.google.android.gms.internal.ads.zzbvk;
import com.google.android.gms.internal.ads.zzbyv;

public class OfflineNotificationPoster extends Worker {
  private final zzbyv zza;
  
  public OfflineNotificationPoster(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
    this.zza = zzaw.zza().zzl(paramContext, (zzbvk)new zzbvh());
  }
  
  public final ListenableWorker.Result doWork() {
    String str1 = getInputData().getString("uri");
    String str2 = getInputData().getString("gws_query_id");
    try {
      this.zza.zzg(ObjectWrapper.wrap(getApplicationContext()), str1, str2);
      return ListenableWorker.Result.success();
    } catch (RemoteException remoteException) {
      return ListenableWorker.Result.failure();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\offline\buffering\OfflineNotificationPoster.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */