package com.google.android.gms.ads.internal.client;

import android.os.RemoteException;
import com.google.android.gms.ads.formats.AdManagerAdViewOptions;
import com.google.android.gms.ads.formats.PublisherAdViewOptions;
import com.google.android.gms.internal.ads.zzbls;
import com.google.android.gms.internal.ads.zzbnc;
import com.google.android.gms.internal.ads.zzbnf;
import com.google.android.gms.internal.ads.zzbni;
import com.google.android.gms.internal.ads.zzbnl;
import com.google.android.gms.internal.ads.zzbnp;
import com.google.android.gms.internal.ads.zzbns;
import com.google.android.gms.internal.ads.zzbsc;
import com.google.android.gms.internal.ads.zzbsl;

public final class zzeo extends zzbn {
  private zzbf zza;
  
  public final zzbl zzc() {
    return new zzen(this, null);
  }
  
  public final zzbl zze() throws RemoteException {
    return new zzen(this, null);
  }
  
  public final void zzf(zzbnc paramzzbnc) throws RemoteException {}
  
  public final void zzg(zzbnf paramzzbnf) throws RemoteException {}
  
  public final void zzh(String paramString, zzbnl paramzzbnl, zzbni paramzzbni) throws RemoteException {}
  
  public final void zzi(zzbsl paramzzbsl) throws RemoteException {}
  
  public final void zzj(zzbnp paramzzbnp, zzq paramzzq) throws RemoteException {}
  
  public final void zzk(zzbns paramzzbns) throws RemoteException {}
  
  public final void zzl(zzbf paramzzbf) throws RemoteException {
    this.zza = paramzzbf;
  }
  
  public final void zzm(AdManagerAdViewOptions paramAdManagerAdViewOptions) throws RemoteException {}
  
  public final void zzn(zzbsc paramzzbsc) throws RemoteException {}
  
  public final void zzo(zzbls paramzzbls) throws RemoteException {}
  
  public final void zzp(PublisherAdViewOptions paramPublisherAdViewOptions) throws RemoteException {}
  
  public final void zzq(zzcd paramzzcd) throws RemoteException {}
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzeo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */