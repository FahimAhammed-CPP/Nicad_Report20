package com.google.android.gms.ads.mediation;

import android.os.Bundle;

public final class zza {
  private int zza;
  
  public final Bundle zza() {
    Bundle bundle = new Bundle();
    bundle.putInt("capabilities", this.zza);
    return bundle;
  }
  
  public final zza zzb(int paramInt) {
    this.zza = 1;
    return this;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\mediation\zza.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */