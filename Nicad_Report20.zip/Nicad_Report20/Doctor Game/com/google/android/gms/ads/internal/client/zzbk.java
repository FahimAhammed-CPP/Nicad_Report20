package com.google.android.gms.ads.internal.client;

import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzasa;
import com.google.android.gms.internal.ads.zzasb;

public abstract class zzbk extends zzasa implements zzbl {
  public zzbk() {
    super("com.google.android.gms.ads.internal.client.IAdLoader");
  }
  
  protected final boolean zzbI(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2) throws RemoteException {
    String str;
    if (paramInt1 != 1) {
      if (paramInt1 != 2) {
        if (paramInt1 != 3) {
          if (paramInt1 != 4) {
            if (paramInt1 != 5)
              return false; 
            zzl zzl1 = (zzl)zzasb.zza(paramParcel1, zzl.CREATOR);
            paramInt1 = paramParcel1.readInt();
            zzasb.zzc(paramParcel1);
            zzh(zzl1, paramInt1);
            paramParcel2.writeNoException();
            return true;
          } 
          String str1 = zzf();
          paramParcel2.writeNoException();
          paramParcel2.writeString(str1);
          return true;
        } 
        boolean bool = zzi();
        paramParcel2.writeNoException();
        zzasb.zzd(paramParcel2, bool);
        return true;
      } 
      str = zze();
      paramParcel2.writeNoException();
      paramParcel2.writeString(str);
      return true;
    } 
    zzl zzl = (zzl)zzasb.zza((Parcel)str, zzl.CREATOR);
    zzasb.zzc((Parcel)str);
    zzg(zzl);
    paramParcel2.writeNoException();
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzbk.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */