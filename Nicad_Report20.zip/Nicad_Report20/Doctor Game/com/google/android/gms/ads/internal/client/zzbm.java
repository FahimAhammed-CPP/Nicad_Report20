package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import com.google.android.gms.ads.formats.AdManagerAdViewOptions;
import com.google.android.gms.ads.formats.PublisherAdViewOptions;
import com.google.android.gms.internal.ads.zzarz;
import com.google.android.gms.internal.ads.zzasb;
import com.google.android.gms.internal.ads.zzbls;
import com.google.android.gms.internal.ads.zzbnc;
import com.google.android.gms.internal.ads.zzbnf;
import com.google.android.gms.internal.ads.zzbni;
import com.google.android.gms.internal.ads.zzbnl;
import com.google.android.gms.internal.ads.zzbnp;
import com.google.android.gms.internal.ads.zzbns;
import com.google.android.gms.internal.ads.zzbsc;
import com.google.android.gms.internal.ads.zzbsl;

public final class zzbm extends zzarz implements zzbo {
  zzbm(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
  }
  
  public final zzbl zze() throws RemoteException {
    zzbl zzbl;
    Parcel parcel = zzbk(1, zza());
    IBinder iBinder = parcel.readStrongBinder();
    if (iBinder == null) {
      iBinder = null;
    } else {
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdLoader");
      if (iInterface instanceof zzbl) {
        zzbl = (zzbl)iInterface;
      } else {
        zzbl = new zzbj((IBinder)zzbl);
      } 
    } 
    parcel.recycle();
    return zzbl;
  }
  
  public final void zzf(zzbnc paramzzbnc) throws RemoteException {
    throw null;
  }
  
  public final void zzg(zzbnf paramzzbnf) throws RemoteException {
    throw null;
  }
  
  public final void zzh(String paramString, zzbnl paramzzbnl, zzbni paramzzbni) throws RemoteException {
    Parcel parcel = zza();
    parcel.writeString(paramString);
    zzasb.zzg(parcel, (IInterface)paramzzbnl);
    zzasb.zzg(parcel, (IInterface)paramzzbni);
    zzbl(5, parcel);
  }
  
  public final void zzi(zzbsl paramzzbsl) throws RemoteException {
    throw null;
  }
  
  public final void zzj(zzbnp paramzzbnp, zzq paramzzq) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zzg(parcel, (IInterface)paramzzbnp);
    zzasb.zze(parcel, (Parcelable)paramzzq);
    zzbl(8, parcel);
  }
  
  public final void zzk(zzbns paramzzbns) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zzg(parcel, (IInterface)paramzzbns);
    zzbl(10, parcel);
  }
  
  public final void zzl(zzbf paramzzbf) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zzg(parcel, paramzzbf);
    zzbl(2, parcel);
  }
  
  public final void zzm(AdManagerAdViewOptions paramAdManagerAdViewOptions) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zze(parcel, (Parcelable)paramAdManagerAdViewOptions);
    zzbl(15, parcel);
  }
  
  public final void zzn(zzbsc paramzzbsc) throws RemoteException {
    throw null;
  }
  
  public final void zzo(zzbls paramzzbls) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zze(parcel, (Parcelable)paramzzbls);
    zzbl(6, parcel);
  }
  
  public final void zzp(PublisherAdViewOptions paramPublisherAdViewOptions) throws RemoteException {
    throw null;
  }
  
  public final void zzq(zzcd paramzzcd) throws RemoteException {
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzbm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */