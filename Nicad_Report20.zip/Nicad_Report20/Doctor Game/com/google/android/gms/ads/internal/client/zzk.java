package com.google.android.gms.ads.internal.client;

import android.content.Context;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.dynamic.ObjectWrapper;
import com.google.android.gms.dynamic.RemoteCreator;
import com.google.android.gms.internal.ads.zzbiu;
import com.google.android.gms.internal.ads.zzbjc;
import com.google.android.gms.internal.ads.zzbvk;
import com.google.android.gms.internal.ads.zzcaf;
import com.google.android.gms.internal.ads.zzcah;
import com.google.android.gms.internal.ads.zzcgp;
import com.google.android.gms.internal.ads.zzcgs;
import com.google.android.gms.internal.ads.zzcgt;

public final class zzk extends RemoteCreator {
  private zzcah zza;
  
  public zzk() {
    super("com.google.android.gms.ads.AdManagerCreatorImpl");
  }
  
  public final zzbs zza(Context paramContext, zzq paramzzq, String paramString, zzbvk paramzzbvk, int paramInt) {
    zzcah zzcah1;
    IInterface iInterface;
    zzbjc.zzc(paramContext);
    zzbiu zzbiu = zzbjc.zzis;
    if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue()) {
      zzbs zzbs;
      try {
        zzbs zzbs1;
        IObjectWrapper iObjectWrapper = ObjectWrapper.wrap(paramContext);
        IBinder iBinder = ((zzbt)zzcgt.zzb(paramContext, "com.google.android.gms.ads.ChimeraAdManagerCreatorImpl", zzj.zza)).zze(iObjectWrapper, paramzzq, paramString, paramzzbvk, 223104000, paramInt);
        if (iBinder == null)
          return null; 
        iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdManager");
        if (iInterface instanceof zzbs) {
          zzbs1 = (zzbs)iInterface;
          zzbs = zzbs1;
        } else {
          zzbs1 = new zzbq((IBinder)zzbs1);
          zzbs = zzbs1;
        } 
      } catch (zzcgs zzcgs) {
        zzcah1 = zzcaf.zza((Context)zzbs);
        this.zza = zzcah1;
        zzcah1.zzd((Throwable)zzcgs, "AdManagerCreator.newAdManagerByDynamiteLoader");
        zzcgp.zzl("#007 Could not call remote method.", (Throwable)zzcgs);
        return null;
      } catch (RemoteException remoteException) {
      
      } catch (NullPointerException nullPointerException) {}
    } else {
      try {
        zzbs zzbs;
        IObjectWrapper iObjectWrapper = ObjectWrapper.wrap(zzcah1);
        IBinder iBinder = ((zzbt)getRemoteCreatorInstance((Context)zzcah1)).zze(iObjectWrapper, (zzq)nullPointerException, (String)iInterface, paramzzbvk, 223104000, paramInt);
        if (iBinder == null)
          return null; 
        IInterface iInterface1 = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdManager");
        if (iInterface1 instanceof zzbs) {
          zzbs = (zzbs)iInterface1;
        } else {
          zzbs = new zzbq((IBinder)zzbs);
        } 
      } catch (RemoteException remoteException) {
        zzcgp.zzf("Could not create remote AdManager.", (Throwable)remoteException);
        return null;
      } catch (com.google.android.gms.dynamic.RemoteCreator.RemoteCreatorException remoteCreatorException) {}
      return (zzbs)remoteCreatorException;
    } 
    return (zzbs)remoteCreatorException;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzk.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */