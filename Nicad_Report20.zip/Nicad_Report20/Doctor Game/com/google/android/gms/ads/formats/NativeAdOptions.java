package com.google.android.gms.ads.formats;

import com.google.android.gms.ads.VideoOptions;

@Deprecated
public final class NativeAdOptions {
  public static final int ADCHOICES_BOTTOM_LEFT = 3;
  
  public static final int ADCHOICES_BOTTOM_RIGHT = 2;
  
  public static final int ADCHOICES_TOP_LEFT = 0;
  
  public static final int ADCHOICES_TOP_RIGHT = 1;
  
  public static final int NATIVE_MEDIA_ASPECT_RATIO_ANY = 1;
  
  public static final int NATIVE_MEDIA_ASPECT_RATIO_LANDSCAPE = 2;
  
  public static final int NATIVE_MEDIA_ASPECT_RATIO_PORTRAIT = 3;
  
  public static final int NATIVE_MEDIA_ASPECT_RATIO_SQUARE = 4;
  
  public static final int NATIVE_MEDIA_ASPECT_RATIO_UNKNOWN = 0;
  
  @Deprecated
  public static final int ORIENTATION_ANY = 0;
  
  @Deprecated
  public static final int ORIENTATION_LANDSCAPE = 2;
  
  @Deprecated
  public static final int ORIENTATION_PORTRAIT = 1;
  
  private final boolean zza;
  
  private final int zzb;
  
  private final int zzc;
  
  private final boolean zzd;
  
  private final int zze;
  
  private final VideoOptions zzf;
  
  private final boolean zzg;
  
  public int getAdChoicesPlacement() {
    return this.zze;
  }
  
  @Deprecated
  public int getImageOrientation() {
    return this.zzb;
  }
  
  public int getMediaAspectRatio() {
    return this.zzc;
  }
  
  public VideoOptions getVideoOptions() {
    return this.zzf;
  }
  
  public boolean shouldRequestMultipleImages() {
    return this.zzd;
  }
  
  public boolean shouldReturnUrlsForImageAssets() {
    return this.zza;
  }
  
  public final boolean zza() {
    return this.zzg;
  }
  
  public static @interface AdChoicesPlacement {}
  
  public static final class Builder {
    private boolean zza = false;
    
    private int zzb = -1;
    
    private int zzc = 0;
    
    private boolean zzd = false;
    
    private VideoOptions zze;
    
    private int zzf = 1;
    
    private boolean zzg = false;
    
    public NativeAdOptions build() {
      return new NativeAdOptions(this, null);
    }
    
    public Builder setAdChoicesPlacement(int param1Int) {
      this.zzf = param1Int;
      return this;
    }
    
    @Deprecated
    public Builder setImageOrientation(int param1Int) {
      this.zzb = param1Int;
      return this;
    }
    
    public Builder setMediaAspectRatio(int param1Int) {
      this.zzc = param1Int;
      return this;
    }
    
    public Builder setRequestCustomMuteThisAd(boolean param1Boolean) {
      this.zzg = param1Boolean;
      return this;
    }
    
    public Builder setRequestMultipleImages(boolean param1Boolean) {
      this.zzd = param1Boolean;
      return this;
    }
    
    public Builder setReturnUrlsForImageAssets(boolean param1Boolean) {
      this.zza = param1Boolean;
      return this;
    }
    
    public Builder setVideoOptions(VideoOptions param1VideoOptions) {
      this.zze = param1VideoOptions;
      return this;
    }
  }
  
  public static @interface NativeMediaAspectRatio {}
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\formats\NativeAdOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */