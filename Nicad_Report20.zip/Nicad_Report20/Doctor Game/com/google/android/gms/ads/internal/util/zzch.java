package com.google.android.gms.ads.internal.util;

import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.os.Build;
import android.util.Range;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class zzch {
  private static final Map zza = new HashMap<Object, Object>();
  
  private static List zzb;
  
  private static final Object zzc = new Object();
  
  public static List zza(String paramString) {
    synchronized (zzc) {
      List list;
      if (zza.containsKey(paramString)) {
        list = (List)zza.get(paramString);
        return list;
      } 
      try {
        synchronized (zzc) {
          if (zzb != null) {
          
          } else if (Build.VERSION.SDK_INT >= 21) {
            zzb = Arrays.asList((new MediaCodecList(0)).getCodecInfos());
          } else {
            int j = MediaCodecList.getCodecCount();
            zzb = new ArrayList(j);
            for (int i = 0; i < j; i++) {
              MediaCodecInfo mediaCodecInfo = MediaCodecList.getCodecInfoAt(i);
              zzb.add(mediaCodecInfo);
            } 
          } 
          null = new ArrayList();
          for (MediaCodecInfo mediaCodecInfo : zzb) {
            if (!mediaCodecInfo.isEncoder() && Arrays.<String>asList(mediaCodecInfo.getSupportedTypes()).contains(list)) {
              HashMap<Object, Object> hashMap1 = new HashMap<Object, Object>();
              hashMap1.put("codecName", mediaCodecInfo.getName());
              MediaCodecInfo.CodecCapabilities codecCapabilities = mediaCodecInfo.getCapabilitiesForType((String)list);
              ArrayList<Integer[]> arrayList1 = new ArrayList();
              for (MediaCodecInfo.CodecProfileLevel codecProfileLevel : codecCapabilities.profileLevels) {
                arrayList1.add(new Integer[] { Integer.valueOf(codecProfileLevel.profile), Integer.valueOf(codecProfileLevel.level) });
              } 
              hashMap1.put("profileLevels", arrayList1);
              if (Build.VERSION.SDK_INT >= 21) {
                MediaCodecInfo.VideoCapabilities videoCapabilities = codecCapabilities.getVideoCapabilities();
                hashMap1.put("bitRatesBps", zzb(videoCapabilities.getBitrateRange()));
                hashMap1.put("widthAlignment", Integer.valueOf(videoCapabilities.getWidthAlignment()));
                hashMap1.put("heightAlignment", Integer.valueOf(videoCapabilities.getHeightAlignment()));
                hashMap1.put("frameRates", zzb(videoCapabilities.getSupportedFrameRates()));
                hashMap1.put("widths", zzb(videoCapabilities.getSupportedWidths()));
                hashMap1.put("heights", zzb(videoCapabilities.getSupportedHeights()));
              } 
              if (Build.VERSION.SDK_INT >= 23)
                hashMap1.put("instancesLimit", Integer.valueOf(codecCapabilities.getMaxSupportedInstances())); 
              null.add(hashMap1);
            } 
          } 
          zza.put(list, null);
          return (List)null;
        } 
      } catch (RuntimeException runtimeException) {
      
      } catch (LinkageError linkageError) {}
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      hashMap.put("error", linkageError.getClass().getSimpleName());
      ArrayList<HashMap<Object, Object>> arrayList = new ArrayList();
      arrayList.add(hashMap);
      zza.put(list, arrayList);
      return arrayList;
    } 
  }
  
  private static Integer[] zzb(Range paramRange) {
    return new Integer[] { (Integer)paramRange.getLower(), (Integer)paramRange.getUpper() };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzch.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */