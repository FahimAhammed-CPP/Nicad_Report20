package com.google.android.gms.ads.internal.overlay;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;
import com.google.android.gms.ads.internal.util.zzb;
import com.google.android.gms.ads.internal.util.zzs;
import com.google.android.gms.ads.internal.zzj;
import com.google.android.gms.ads.internal.zzt;

final class zzk extends zzb {
  public final void zza() {
    Bitmap bitmap = zzt.zzu().zza(Integer.valueOf(this.zza.zzc.zzo.zzf));
    if (bitmap != null) {
      BitmapDrawable bitmapDrawable;
      zzt.zzp();
      zzl zzl1 = this.zza;
      Activity activity = zzl1.zzb;
      zzj zzj = zzl1.zzc.zzo;
      boolean bool = zzj.zzd;
      float f = zzj.zze;
      if (!bool || f <= 0.0F || f > 25.0F) {
        bitmapDrawable = new BitmapDrawable(activity.getResources(), bitmap);
      } else {
        try {
          Bitmap bitmap2 = Bitmap.createScaledBitmap(bitmap, bitmap.getWidth(), bitmap.getHeight(), false);
          Bitmap bitmap1 = Bitmap.createBitmap(bitmap2);
          RenderScript renderScript = RenderScript.create((Context)activity);
          ScriptIntrinsicBlur scriptIntrinsicBlur = ScriptIntrinsicBlur.create(renderScript, Element.U8_4(renderScript));
          Allocation allocation2 = Allocation.createFromBitmap(renderScript, bitmap2);
          Allocation allocation1 = Allocation.createFromBitmap(renderScript, bitmap1);
          scriptIntrinsicBlur.setRadius(f);
          scriptIntrinsicBlur.setInput(allocation2);
          scriptIntrinsicBlur.forEach(allocation1);
          allocation1.copyTo(bitmap1);
          bitmapDrawable = new BitmapDrawable(activity.getResources(), bitmap1);
        } catch (RuntimeException runtimeException) {
          bitmapDrawable = new BitmapDrawable(activity.getResources(), bitmap);
        } 
      } 
      zzs.zza.post(new zzi(this, (Drawable)bitmapDrawable));
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\overlay\zzk.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */