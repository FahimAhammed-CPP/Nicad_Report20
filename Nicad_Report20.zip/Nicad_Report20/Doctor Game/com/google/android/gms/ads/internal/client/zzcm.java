package com.google.android.gms.ads.internal.client;

import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.internal.ads.zzbrx;
import com.google.android.gms.internal.ads.zzbvk;
import java.util.List;

public interface zzcm extends IInterface {
  float zze() throws RemoteException;
  
  String zzf() throws RemoteException;
  
  List zzg() throws RemoteException;
  
  void zzh(String paramString) throws RemoteException;
  
  void zzi() throws RemoteException;
  
  void zzj() throws RemoteException;
  
  void zzk(String paramString, IObjectWrapper paramIObjectWrapper) throws RemoteException;
  
  void zzl(zzcy paramzzcy) throws RemoteException;
  
  void zzm(IObjectWrapper paramIObjectWrapper, String paramString) throws RemoteException;
  
  void zzn(zzbvk paramzzbvk) throws RemoteException;
  
  void zzo(boolean paramBoolean) throws RemoteException;
  
  void zzp(float paramFloat) throws RemoteException;
  
  void zzq(String paramString) throws RemoteException;
  
  void zzr(zzbrx paramzzbrx) throws RemoteException;
  
  void zzs(zzez paramzzez) throws RemoteException;
  
  boolean zzt() throws RemoteException;
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzcm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */