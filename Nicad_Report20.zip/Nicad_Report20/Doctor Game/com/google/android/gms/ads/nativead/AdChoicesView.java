package com.google.android.gms.ads.nativead;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.RelativeLayout;

public class AdChoicesView extends RelativeLayout {
  public AdChoicesView(Context paramContext) {
    super(paramContext);
  }
  
  public AdChoicesView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  public AdChoicesView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
  }
  
  public AdChoicesView(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\nativead\AdChoicesView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */