package com.google.android.gms.ads;

import android.graphics.drawable.Drawable;
import com.google.android.gms.internal.ads.zzbmy;

public interface MediaContent {
  float getAspectRatio();
  
  float getCurrentTime();
  
  float getDuration();
  
  Drawable getMainImage();
  
  VideoController getVideoController();
  
  boolean hasVideoContent();
  
  void setMainImage(Drawable paramDrawable);
  
  zzbmy zza();
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\MediaContent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */