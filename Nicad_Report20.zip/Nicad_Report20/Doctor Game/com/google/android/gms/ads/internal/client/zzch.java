package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzarz;
import com.google.android.gms.internal.ads.zzasb;
import com.google.android.gms.internal.ads.zzbvj;
import com.google.android.gms.internal.ads.zzbvk;

public final class zzch extends zzarz implements zzcj {
  zzch(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.ILiteSdkInfo");
  }
  
  public final zzbvk getAdapterCreator() throws RemoteException {
    Parcel parcel = zzbk(2, zza());
    zzbvk zzbvk = zzbvj.zzf(parcel.readStrongBinder());
    parcel.recycle();
    return zzbvk;
  }
  
  public final zzeh getLiteSdkVersion() throws RemoteException {
    Parcel parcel = zzbk(1, zza());
    zzeh zzeh = (zzeh)zzasb.zza(parcel, zzeh.CREATOR);
    parcel.recycle();
    return zzeh;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzch.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */