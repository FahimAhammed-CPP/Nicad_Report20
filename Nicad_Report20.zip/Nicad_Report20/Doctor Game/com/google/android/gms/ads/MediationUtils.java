package com.google.android.gms.ads;

import android.content.Context;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.internal.ads.zzbiu;
import com.google.android.gms.internal.ads.zzbjc;
import java.util.Iterator;
import java.util.List;

public class MediationUtils {
  protected static final double MIN_HEIGHT_RATIO = 0.7D;
  
  protected static final double MIN_WIDTH_RATIO = 0.5D;
  
  public static AdSize findClosestSize(Context paramContext, AdSize paramAdSize, List<AdSize> paramList) {
    zzbiu zzbiu;
    AdSize adSize = null;
    Context context = null;
    if (paramList != null) {
      AdSize adSize1;
      if (paramAdSize == null)
        return null; 
      AdSize adSize2 = paramAdSize;
      if (!paramAdSize.zzh()) {
        adSize2 = paramAdSize;
        if (!paramAdSize.zzi()) {
          float f = (paramContext.getResources().getDisplayMetrics()).density;
          adSize2 = new AdSize(Math.round(paramAdSize.getWidthInPixels(paramContext) / f), Math.round(paramAdSize.getHeightInPixels(paramContext) / f));
        } 
      } 
      Iterator<AdSize> iterator = paramList.iterator();
      paramContext = context;
      while (true) {
        adSize = adSize1;
        if (iterator.hasNext()) {
          paramAdSize = iterator.next();
          if (paramAdSize != null) {
            int k = adSize2.getWidth();
            int i = paramAdSize.getWidth();
            int m = adSize2.getHeight();
            int j = paramAdSize.getHeight();
            double d = k;
            Double.isNaN(d);
            if (d * 0.5D <= i && k >= i) {
              if (adSize2.zzi()) {
                k = adSize2.zza();
                zzbiu = zzbjc.zzgL;
                if (((Integer)zzay.zzc().zzb(zzbiu)).intValue() <= i) {
                  zzbiu = zzbjc.zzgM;
                  if (((Integer)zzay.zzc().zzb(zzbiu)).intValue() <= j && k >= j)
                    continue; 
                } 
                continue;
              } 
              if (adSize2.zzh()) {
                if (adSize2.zzb() >= j)
                  continue; 
                continue;
              } 
              d = m;
              Double.isNaN(d);
              if (d * 0.7D > j || m < j)
                continue; 
              continue;
            } 
          } 
          continue;
        } 
        break;
        if (paramContext == null || paramContext.getWidth() * paramContext.getHeight() <= paramAdSize.getWidth() * paramAdSize.getHeight())
          adSize1 = paramAdSize; 
      } 
    } 
    return (AdSize)zzbiu;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\MediationUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */