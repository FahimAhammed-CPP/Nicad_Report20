package com.google.android.gms.ads.nonagon.signalgeneration;

import android.os.Bundle;
import android.util.JsonReader;
import java.io.IOException;

public final class zzam {
  public final String zza;
  
  public String zzb;
  
  public Bundle zzc;
  
  public zzam(JsonReader paramJsonReader) throws IOException {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: new android/os/Bundle
    //   8: dup
    //   9: invokespecial <init> : ()V
    //   12: putfield zzc : Landroid/os/Bundle;
    //   15: new java/util/HashMap
    //   18: dup
    //   19: invokespecial <init> : ()V
    //   22: astore #4
    //   24: aload_1
    //   25: invokevirtual beginObject : ()V
    //   28: ldc ''
    //   30: astore_3
    //   31: aload_1
    //   32: invokevirtual hasNext : ()Z
    //   35: ifeq -> 180
    //   38: aload_1
    //   39: invokevirtual nextName : ()Ljava/lang/String;
    //   42: astore #6
    //   44: aload #6
    //   46: astore #5
    //   48: aload #6
    //   50: ifnonnull -> 57
    //   53: ldc ''
    //   55: astore #5
    //   57: aload #5
    //   59: invokevirtual hashCode : ()I
    //   62: istore_2
    //   63: iload_2
    //   64: ldc -995427962
    //   66: if_icmpeq -> 93
    //   69: iload_2
    //   70: ldc -271442291
    //   72: if_icmpeq -> 78
    //   75: goto -> 108
    //   78: aload #5
    //   80: ldc 'signal_dictionary'
    //   82: invokevirtual equals : (Ljava/lang/Object;)Z
    //   85: ifeq -> 108
    //   88: iconst_1
    //   89: istore_2
    //   90: goto -> 110
    //   93: aload #5
    //   95: ldc 'params'
    //   97: invokevirtual equals : (Ljava/lang/Object;)Z
    //   100: ifeq -> 108
    //   103: iconst_0
    //   104: istore_2
    //   105: goto -> 110
    //   108: iconst_m1
    //   109: istore_2
    //   110: iload_2
    //   111: ifeq -> 172
    //   114: iload_2
    //   115: iconst_1
    //   116: if_icmpeq -> 126
    //   119: aload_1
    //   120: invokevirtual skipValue : ()V
    //   123: goto -> 31
    //   126: new java/util/HashMap
    //   129: dup
    //   130: invokespecial <init> : ()V
    //   133: astore #4
    //   135: aload_1
    //   136: invokevirtual beginObject : ()V
    //   139: aload_1
    //   140: invokevirtual hasNext : ()Z
    //   143: ifeq -> 165
    //   146: aload #4
    //   148: aload_1
    //   149: invokevirtual nextName : ()Ljava/lang/String;
    //   152: aload_1
    //   153: invokevirtual nextString : ()Ljava/lang/String;
    //   156: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   161: pop
    //   162: goto -> 139
    //   165: aload_1
    //   166: invokevirtual endObject : ()V
    //   169: goto -> 31
    //   172: aload_1
    //   173: invokevirtual nextString : ()Ljava/lang/String;
    //   176: astore_3
    //   177: goto -> 31
    //   180: aload_0
    //   181: aload_3
    //   182: putfield zza : Ljava/lang/String;
    //   185: aload_1
    //   186: invokevirtual endObject : ()V
    //   189: aload #4
    //   191: invokeinterface entrySet : ()Ljava/util/Set;
    //   196: invokeinterface iterator : ()Ljava/util/Iterator;
    //   201: astore_1
    //   202: aload_1
    //   203: invokeinterface hasNext : ()Z
    //   208: ifeq -> 267
    //   211: aload_1
    //   212: invokeinterface next : ()Ljava/lang/Object;
    //   217: checkcast java/util/Map$Entry
    //   220: astore_3
    //   221: aload_3
    //   222: invokeinterface getKey : ()Ljava/lang/Object;
    //   227: ifnull -> 202
    //   230: aload_3
    //   231: invokeinterface getValue : ()Ljava/lang/Object;
    //   236: ifnull -> 202
    //   239: aload_0
    //   240: getfield zzc : Landroid/os/Bundle;
    //   243: aload_3
    //   244: invokeinterface getKey : ()Ljava/lang/Object;
    //   249: checkcast java/lang/String
    //   252: aload_3
    //   253: invokeinterface getValue : ()Ljava/lang/Object;
    //   258: checkcast java/lang/String
    //   261: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
    //   264: goto -> 202
    //   267: return
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\nonagon\signalgeneration\zzam.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */