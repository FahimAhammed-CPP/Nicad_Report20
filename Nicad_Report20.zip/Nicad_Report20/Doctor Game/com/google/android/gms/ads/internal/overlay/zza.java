package com.google.android.gms.ads.internal.overlay;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.util.zze;
import com.google.android.gms.ads.internal.util.zzs;
import com.google.android.gms.ads.internal.zzt;
import com.google.android.gms.internal.ads.zzbiu;
import com.google.android.gms.internal.ads.zzbjc;

public final class zza {
  public static final boolean zza(Context paramContext, Intent paramIntent, zzz paramzzz, zzx paramzzx, boolean paramBoolean) {
    if (paramBoolean)
      return zzc(paramContext, paramIntent.getData(), paramzzz, paramzzx); 
    try {
      String str = paramIntent.toURI();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Launching an intent: ");
      stringBuilder.append(str);
      zze.zza(stringBuilder.toString());
      zzt.zzp();
      zzs.zzJ(paramContext, paramIntent);
      if (paramzzz != null)
        paramzzz.zzg(); 
      if (paramzzx != null)
        paramzzx.zza(true); 
      return true;
    } catch (ActivityNotFoundException activityNotFoundException) {
      zze.zzj(activityNotFoundException.getMessage());
      if (paramzzx != null)
        paramzzx.zza(false); 
      return false;
    } 
  }
  
  public static final boolean zzb(Context paramContext, zzc paramzzc, zzz paramzzz, zzx paramzzx) {
    int i = 0;
    if (paramzzc == null) {
      zze.zzj("No intent data for launcher overlay.");
      return false;
    } 
    zzbjc.zzc(paramContext);
    Intent intent = paramzzc.zzh;
    if (intent != null)
      return zza(paramContext, intent, paramzzz, paramzzx, paramzzc.zzj); 
    intent = new Intent();
    if (TextUtils.isEmpty(paramzzc.zzb)) {
      zze.zzj("Open GMSG did not contain a URL.");
      return false;
    } 
    if (!TextUtils.isEmpty(paramzzc.zzc)) {
      intent.setDataAndType(Uri.parse(paramzzc.zzb), paramzzc.zzc);
    } else {
      intent.setData(Uri.parse(paramzzc.zzb));
    } 
    intent.setAction("android.intent.action.VIEW");
    if (!TextUtils.isEmpty(paramzzc.zzd))
      intent.setPackage(paramzzc.zzd); 
    if (!TextUtils.isEmpty(paramzzc.zze)) {
      String[] arrayOfString = paramzzc.zze.split("/", 2);
      if (arrayOfString.length < 2) {
        zze.zzj("Could not parse component name from open GMSG: ".concat(String.valueOf(paramzzc.zze)));
        return false;
      } 
      intent.setClassName(arrayOfString[0], arrayOfString[1]);
    } 
    String str = paramzzc.zzf;
    if (!TextUtils.isEmpty(str)) {
      try {
        int j = Integer.parseInt(str);
        i = j;
      } catch (NumberFormatException numberFormatException) {
        zze.zzj("Could not parse intent flags.");
      } 
      intent.addFlags(i);
    } 
    zzbiu zzbiu = zzbjc.zzdG;
    if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue()) {
      intent.addFlags(268435456);
      intent.putExtra("android.support.customtabs.extra.user_opt_out", true);
    } else {
      zzbiu = zzbjc.zzdF;
      if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue()) {
        zzt.zzp();
        zzs.zzm(paramContext, intent);
      } 
    } 
    return zza(paramContext, intent, paramzzz, paramzzx, paramzzc.zzj);
  }
  
  private static final boolean zzc(Context paramContext, Uri paramUri, zzz paramzzz, zzx paramzzx) {
    byte b;
    try {
      int i = zzt.zzp().zzk(paramContext, paramUri);
      b = i;
      if (paramzzz != null) {
        paramzzz.zzg();
        b = i;
      } 
    } catch (ActivityNotFoundException activityNotFoundException) {
      zze.zzj(activityNotFoundException.getMessage());
      b = 6;
    } 
    if (paramzzx != null)
      paramzzx.zzb(b); 
    return !(b != 5);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\overlay\zza.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */