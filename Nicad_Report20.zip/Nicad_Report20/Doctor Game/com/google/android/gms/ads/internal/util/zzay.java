package com.google.android.gms.ads.internal.util;

public final class zzay extends Exception {
  private final int zza;
  
  public zzay(String paramString, int paramInt) {
    super(paramString);
    this.zza = paramInt;
  }
  
  public final int zza() {
    return this.zza;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzay.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */