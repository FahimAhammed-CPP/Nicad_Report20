package com.google.android.gms.ads.formats;

import android.content.Context;
import android.widget.RelativeLayout;

@Deprecated
public final class zza extends RelativeLayout {
  public zza(Context paramContext) {
    super(paramContext);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\formats\zza.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */