package com.google.android.gms.ads.internal.util;

import android.graphics.Bitmap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public final class zzbw {
  final Map zza = new ConcurrentHashMap<Object, Object>();
  
  private final AtomicInteger zzb = new AtomicInteger(0);
  
  public final Bitmap zza(Integer paramInteger) {
    return (Bitmap)this.zza.get(paramInteger);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzbw.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */