package com.google.android.gms.ads.internal;

import android.view.View;

public interface zzf {
  void zza(View paramView);
  
  void zzb();
  
  void zzc();
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\zzf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */