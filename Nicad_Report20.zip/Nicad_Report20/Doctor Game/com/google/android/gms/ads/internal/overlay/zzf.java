package com.google.android.gms.ads.internal.overlay;

final class zzf extends Exception {
  public zzf(String paramString) {
    super(paramString);
  }
  
  public zzf(String paramString, Throwable paramThrowable) {
    super("Could not obtain webview for the overlay.", paramThrowable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\overlay\zzf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */