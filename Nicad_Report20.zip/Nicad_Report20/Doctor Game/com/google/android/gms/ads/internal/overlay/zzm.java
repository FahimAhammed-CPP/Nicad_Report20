package com.google.android.gms.ads.internal.overlay;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import com.google.android.gms.ads.internal.client.zza;
import com.google.android.gms.ads.internal.util.zzs;
import com.google.android.gms.ads.internal.zzt;
import com.google.android.gms.common.util.PlatformVersion;
import com.google.android.gms.internal.ads.zzdkn;

public final class zzm {
  public static final void zza(Context paramContext, AdOverlayInfoParcel paramAdOverlayInfoParcel, boolean paramBoolean) {
    zzz zzz;
    if (paramAdOverlayInfoParcel.zzk == 4 && paramAdOverlayInfoParcel.zzc == null) {
      Activity activity1;
      zza zza = paramAdOverlayInfoParcel.zzb;
      if (zza != null)
        zza.onAdClicked(); 
      zzdkn zzdkn = paramAdOverlayInfoParcel.zzy;
      if (zzdkn != null)
        zzdkn.zzq(); 
      Activity activity2 = paramAdOverlayInfoParcel.zzd.zzk();
      zzc zzc2 = paramAdOverlayInfoParcel.zza;
      Context context = paramContext;
      if (zzc2 != null) {
        context = paramContext;
        if (zzc2.zzj) {
          context = paramContext;
          if (activity2 != null)
            activity1 = activity2; 
        } 
      } 
      zzt.zzh();
      zzc zzc1 = paramAdOverlayInfoParcel.zza;
      zzz = paramAdOverlayInfoParcel.zzi;
      if (zzc1 != null) {
        zzx zzx = zzc1.zzi;
      } else {
        paramContext = null;
      } 
      zza.zzb((Context)activity1, zzc1, zzz, (zzx)paramContext);
      return;
    } 
    Intent intent = new Intent();
    intent.setClassName(paramContext, "com.google.android.gms.ads.AdActivity");
    intent.putExtra("com.google.android.gms.ads.internal.overlay.useClientJar", ((AdOverlayInfoParcel)zzz).zzm.zzd);
    intent.putExtra("shouldCallOnOverlayOpened", paramBoolean);
    Bundle bundle = new Bundle(1);
    bundle.putParcelable("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo", (Parcelable)zzz);
    intent.putExtra("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo", bundle);
    if (!PlatformVersion.isAtLeastLollipop())
      intent.addFlags(524288); 
    if (!(paramContext instanceof Activity))
      intent.addFlags(268435456); 
    zzt.zzp();
    zzs.zzJ(paramContext, intent);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\overlay\zzm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */