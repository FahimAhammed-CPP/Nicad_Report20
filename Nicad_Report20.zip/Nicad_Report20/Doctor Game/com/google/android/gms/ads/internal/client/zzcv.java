package com.google.android.gms.ads.internal.client;

import android.os.RemoteException;
import com.google.android.gms.ads.MuteThisAdReason;
import com.google.android.gms.internal.ads.zzcgp;

public final class zzcv implements MuteThisAdReason {
  private final String zza;
  
  private final zzcu zzb;
  
  public zzcv(zzcu paramzzcu) {
    this.zzb = paramzzcu;
    try {
      String str = paramzzcu.zze();
    } catch (RemoteException remoteException) {
      zzcgp.zzh("", (Throwable)remoteException);
      remoteException = null;
    } 
    this.zza = (String)remoteException;
  }
  
  public final String getDescription() {
    return this.zza;
  }
  
  public final String toString() {
    return this.zza;
  }
  
  public final zzcu zza() {
    return this.zzb;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzcv.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */