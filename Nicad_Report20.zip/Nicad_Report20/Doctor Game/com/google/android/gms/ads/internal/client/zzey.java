package com.google.android.gms.ads.internal.client;

import com.google.android.gms.ads.AdValue;
import com.google.android.gms.ads.OnPaidEventListener;

public final class zzey extends zzdd {
  private final OnPaidEventListener zza;
  
  public zzey(OnPaidEventListener paramOnPaidEventListener) {
    this.zza = paramOnPaidEventListener;
  }
  
  public final void zze(zzs paramzzs) {
    OnPaidEventListener onPaidEventListener = this.zza;
    if (onPaidEventListener != null)
      onPaidEventListener.onPaidEvent(AdValue.zza(paramzzs.zzb, paramzzs.zzc, paramzzs.zzd)); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */