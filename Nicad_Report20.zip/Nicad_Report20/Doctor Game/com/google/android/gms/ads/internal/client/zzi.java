package com.google.android.gms.ads.internal.client;

import android.content.Context;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.dynamic.ObjectWrapper;
import com.google.android.gms.dynamic.RemoteCreator;
import com.google.android.gms.internal.ads.zzbvk;
import com.google.android.gms.internal.ads.zzcgp;

public final class zzi extends RemoteCreator {
  public zzi() {
    super("com.google.android.gms.ads.AdLoaderBuilderCreatorImpl");
  }
  
  public final zzbo zza(Context paramContext, String paramString, zzbvk paramzzbvk) {
    try {
      zzbo zzbo;
      IObjectWrapper iObjectWrapper = ObjectWrapper.wrap(paramContext);
      IBinder iBinder = ((zzbp)getRemoteCreatorInstance(paramContext)).zze(iObjectWrapper, paramString, paramzzbvk, 223104000);
      if (iBinder == null)
        return null; 
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
      if (iInterface instanceof zzbo) {
        zzbo = (zzbo)iInterface;
      } else {
        zzbo = new zzbm((IBinder)zzbo);
      } 
    } catch (RemoteException remoteException) {
      zzcgp.zzk("Could not create remote builder for AdLoader.", (Throwable)remoteException);
      return null;
    } catch (com.google.android.gms.dynamic.RemoteCreator.RemoteCreatorException remoteCreatorException) {}
    return (zzbo)remoteCreatorException;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */