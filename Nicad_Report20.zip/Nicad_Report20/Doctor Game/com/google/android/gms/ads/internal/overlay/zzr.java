package com.google.android.gms.ads.internal.overlay;

import android.animation.Animator;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import com.google.android.gms.ads.impl.R;
import com.google.android.gms.ads.internal.client.zzaw;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.util.zze;
import com.google.android.gms.ads.internal.zzt;
import com.google.android.gms.common.util.PlatformVersion;
import com.google.android.gms.internal.ads.zzbiu;
import com.google.android.gms.internal.ads.zzbjc;
import com.google.android.gms.internal.ads.zzcgi;

public final class zzr extends FrameLayout implements View.OnClickListener {
  private final ImageButton zza;
  
  private final zzad zzb;
  
  public zzr(Context paramContext, zzq paramzzq, zzad paramzzad) {
    super(paramContext);
    this.zzb = paramzzad;
    setOnClickListener(this);
    this.zza = new ImageButton(paramContext);
    zzc();
    this.zza.setBackgroundColor(0);
    this.zza.setOnClickListener(this);
    ImageButton imageButton = this.zza;
    zzaw.zzb();
    int i = zzcgi.zzw(paramContext, paramzzq.zza);
    zzaw.zzb();
    int j = zzcgi.zzw(paramContext, 0);
    zzaw.zzb();
    int k = zzcgi.zzw(paramContext, paramzzq.zzb);
    zzaw.zzb();
    imageButton.setPadding(i, j, k, zzcgi.zzw(paramContext, paramzzq.zzc));
    this.zza.setContentDescription("Interstitial close button");
    imageButton = this.zza;
    zzaw.zzb();
    i = zzcgi.zzw(paramContext, paramzzq.zzd + paramzzq.zza + paramzzq.zzb);
    zzaw.zzb();
    addView((View)imageButton, (ViewGroup.LayoutParams)new FrameLayout.LayoutParams(i, zzcgi.zzw(paramContext, paramzzq.zzd + paramzzq.zzc), 17));
    zzbiu zzbiu = zzbjc.zzaW;
    long l = ((Long)zzay.zzc().zzb(zzbiu)).longValue();
    if (l <= 0L)
      return; 
    zzbiu = zzbjc.zzaX;
    if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue()) {
      zzp zzp = new zzp(this);
    } else {
      zzbiu = null;
    } 
    this.zza.setAlpha(0.0F);
    this.zza.animate().alpha(1.0F).setDuration(l).setListener((Animator.AnimatorListener)zzbiu);
  }
  
  private final void zzc() {
    zzbiu zzbiu = zzbjc.zzaV;
    String str = (String)zzay.zzc().zzb(zzbiu);
    if (!PlatformVersion.isAtLeastLollipop() || TextUtils.isEmpty(str) || "default".equals(str)) {
      this.zza.setImageResource(17301527);
      return;
    } 
    Resources resources = zzt.zzo().zzd();
    if (resources != null) {
      zzbiu zzbiu1;
      zzbiu zzbiu2 = null;
      try {
        if ("white".equals(str)) {
          Drawable drawable = resources.getDrawable(R.drawable.admob_close_button_white_circle_black_cross);
        } else {
          zzbiu = zzbiu2;
          if ("black".equals(str))
            Drawable drawable = resources.getDrawable(R.drawable.admob_close_button_black_circle_white_cross); 
        } 
      } catch (android.content.res.Resources.NotFoundException notFoundException) {
        zze.zze("Close button resource not found, falling back to default.");
        zzbiu1 = zzbiu2;
      } 
      if (zzbiu1 == null) {
        this.zza.setImageResource(17301527);
        return;
      } 
      this.zza.setImageDrawable((Drawable)zzbiu1);
      this.zza.setScaleType(ImageView.ScaleType.CENTER);
      return;
    } 
    this.zza.setImageResource(17301527);
  }
  
  public final void onClick(View paramView) {
    zzad zzad1 = this.zzb;
    if (zzad1 != null)
      zzad1.zzbJ(); 
  }
  
  public final void zzb(boolean paramBoolean) {
    if (paramBoolean) {
      this.zza.setVisibility(8);
      zzbiu zzbiu = zzbjc.zzaW;
      if (((Long)zzay.zzc().zzb(zzbiu)).longValue() > 0L) {
        this.zza.animate().cancel();
        this.zza.clearAnimation();
      } 
      return;
    } 
    this.zza.setVisibility(0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\overlay\zzr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */