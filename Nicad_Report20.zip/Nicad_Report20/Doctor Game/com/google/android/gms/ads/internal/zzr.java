package com.google.android.gms.ads.internal;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.internal.client.zzl;
import com.google.android.gms.ads.internal.util.zze;
import com.google.android.gms.common.wrappers.Wrappers;
import com.google.android.gms.internal.ads.zzbkg;
import com.google.android.gms.internal.ads.zzcgv;
import com.google.android.gms.internal.ads.zzevb;
import java.util.Map;
import java.util.TreeMap;
import org.json.JSONArray;
import org.json.JSONException;

final class zzr {
  private final Context zza;
  
  private final String zzb;
  
  private final Map zzc;
  
  private String zzd;
  
  private String zze;
  
  private final String zzf;
  
  public zzr(Context paramContext, String paramString) {
    String str;
    this.zza = paramContext.getApplicationContext();
    this.zzb = paramString;
    this.zzc = new TreeMap<Object, Object>();
    paramString = paramContext.getPackageName();
    try {
      str = (Wrappers.packageManager(paramContext).getPackageInfo(paramContext.getPackageName(), 0)).versionName;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramString);
      stringBuilder.append("-");
      stringBuilder.append(str);
      str = stringBuilder.toString();
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      zze.zzh("Unable to get package version name for reporting", (Throwable)nameNotFoundException);
      str = String.valueOf(paramString).concat("-missing");
    } 
    this.zzf = str;
  }
  
  public final String zza() {
    return this.zzf;
  }
  
  public final String zzb() {
    return this.zze;
  }
  
  public final String zzc() {
    return this.zzb;
  }
  
  public final String zzd() {
    return this.zzd;
  }
  
  public final Map zze() {
    return this.zzc;
  }
  
  public final void zzf(zzl paramzzl, zzcgv paramzzcgv) {
    this.zzd = paramzzl.zzj.zza;
    Bundle bundle = paramzzl.zzm;
    if (bundle != null) {
      bundle = bundle.getBundle(AdMobAdapter.class.getName());
    } else {
      bundle = null;
    } 
    if (bundle == null)
      return; 
    str = (String)zzbkg.zzc.zze();
    for (String str1 : bundle.keySet()) {
      if (str.equals(str1)) {
        this.zze = bundle.getString(str1);
        continue;
      } 
      if (str1.startsWith("csa_"))
        this.zzc.put(str1.substring(4), bundle.getString(str1)); 
    } 
    this.zzc.put("SDKVersion", paramzzcgv.zza);
    if (((Boolean)zzbkg.zza.zze()).booleanValue())
      try {
        JSONArray jSONArray = new JSONArray((String)zzbkg.zzb.zze());
        Bundle bundle1 = zzevb.zzc(this.zza, jSONArray);
        for (String str : bundle1.keySet())
          this.zzc.put(str, bundle1.get(str).toString()); 
      } catch (JSONException jSONException) {
        zze.zzh("Flag gads:afs:csa_tcf_data_to_collect not a valid JSON array", (Throwable)jSONException);
      }  
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\zzr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */