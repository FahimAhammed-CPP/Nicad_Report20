package com.google.android.gms.ads.internal.client;

import android.os.IInterface;
import android.os.RemoteException;

public interface zzbl extends IInterface {
  String zze() throws RemoteException;
  
  String zzf() throws RemoteException;
  
  void zzg(zzl paramzzl) throws RemoteException;
  
  void zzh(zzl paramzzl, int paramInt) throws RemoteException;
  
  boolean zzi() throws RemoteException;
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzbl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */