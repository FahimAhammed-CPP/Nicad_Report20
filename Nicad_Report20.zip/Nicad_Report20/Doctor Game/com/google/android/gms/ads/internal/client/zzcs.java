package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzarz;

public final class zzcs extends zzarz implements zzcu {
  zzcs(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IMuteThisAdReason");
  }
  
  public final String zze() throws RemoteException {
    Parcel parcel = zzbk(1, zza());
    String str = parcel.readString();
    parcel.recycle();
    return str;
  }
  
  public final String zzf() throws RemoteException {
    Parcel parcel = zzbk(2, zza());
    String str = parcel.readString();
    parcel.recycle();
    return str;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzcs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */