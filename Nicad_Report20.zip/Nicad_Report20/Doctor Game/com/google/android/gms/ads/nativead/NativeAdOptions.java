package com.google.android.gms.ads.nativead;

import com.google.android.gms.ads.VideoOptions;

public final class NativeAdOptions {
  public static final int ADCHOICES_BOTTOM_LEFT = 3;
  
  public static final int ADCHOICES_BOTTOM_RIGHT = 2;
  
  public static final int ADCHOICES_TOP_LEFT = 0;
  
  public static final int ADCHOICES_TOP_RIGHT = 1;
  
  public static final int NATIVE_MEDIA_ASPECT_RATIO_ANY = 1;
  
  public static final int NATIVE_MEDIA_ASPECT_RATIO_LANDSCAPE = 2;
  
  public static final int NATIVE_MEDIA_ASPECT_RATIO_PORTRAIT = 3;
  
  public static final int NATIVE_MEDIA_ASPECT_RATIO_SQUARE = 4;
  
  public static final int NATIVE_MEDIA_ASPECT_RATIO_UNKNOWN = 0;
  
  private final boolean zza;
  
  private final int zzb;
  
  private final boolean zzc;
  
  private final int zzd;
  
  private final VideoOptions zze;
  
  private final boolean zzf;
  
  public int getAdChoicesPlacement() {
    return this.zzd;
  }
  
  public int getMediaAspectRatio() {
    return this.zzb;
  }
  
  public VideoOptions getVideoOptions() {
    return this.zze;
  }
  
  public boolean shouldRequestMultipleImages() {
    return this.zzc;
  }
  
  public boolean shouldReturnUrlsForImageAssets() {
    return this.zza;
  }
  
  public final boolean zza() {
    return this.zzf;
  }
  
  public static @interface AdChoicesPlacement {}
  
  public static final class Builder {
    private boolean zza = false;
    
    private int zzb = 0;
    
    private boolean zzc = false;
    
    private VideoOptions zzd;
    
    private int zze = 1;
    
    private boolean zzf = false;
    
    public NativeAdOptions build() {
      return new NativeAdOptions(this, null);
    }
    
    public Builder setAdChoicesPlacement(int param1Int) {
      this.zze = param1Int;
      return this;
    }
    
    public Builder setMediaAspectRatio(int param1Int) {
      this.zzb = param1Int;
      return this;
    }
    
    public Builder setRequestCustomMuteThisAd(boolean param1Boolean) {
      this.zzf = param1Boolean;
      return this;
    }
    
    public Builder setRequestMultipleImages(boolean param1Boolean) {
      this.zzc = param1Boolean;
      return this;
    }
    
    public Builder setReturnUrlsForImageAssets(boolean param1Boolean) {
      this.zza = param1Boolean;
      return this;
    }
    
    public Builder setVideoOptions(VideoOptions param1VideoOptions) {
      this.zzd = param1VideoOptions;
      return this;
    }
  }
  
  public static @interface NativeMediaAspectRatio {}
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\nativead\NativeAdOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */