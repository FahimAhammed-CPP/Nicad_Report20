package com.google.android.gms.ads.nonagon.signalgeneration;

import android.content.Context;
import com.google.android.gms.internal.ads.zzape;
import com.google.android.gms.internal.ads.zzchc;
import com.google.android.gms.internal.ads.zzcom;
import com.google.android.gms.internal.ads.zzcos;
import com.google.android.gms.internal.ads.zzcpc;
import com.google.android.gms.internal.ads.zzdxv;
import com.google.android.gms.internal.ads.zzffb;
import com.google.android.gms.internal.ads.zzfkm;
import com.google.android.gms.internal.ads.zzfzq;
import com.google.android.gms.internal.ads.zzgxi;
import com.google.android.gms.internal.ads.zzgxq;
import com.google.android.gms.internal.ads.zzgxv;
import java.util.concurrent.ScheduledExecutorService;

public final class zzab implements zzgxi {
  private final zzgxv zza;
  
  private final zzgxv zzb;
  
  private final zzgxv zzc;
  
  private final zzgxv zzd;
  
  private final zzgxv zze;
  
  private final zzgxv zzf;
  
  private final zzgxv zzg;
  
  private final zzgxv zzh;
  
  private final zzgxv zzi;
  
  public zzab(zzgxv paramzzgxv1, zzgxv paramzzgxv2, zzgxv paramzzgxv3, zzgxv paramzzgxv4, zzgxv paramzzgxv5, zzgxv paramzzgxv6, zzgxv paramzzgxv7, zzgxv paramzzgxv8, zzgxv paramzzgxv9) {
    this.zza = paramzzgxv1;
    this.zzb = paramzzgxv2;
    this.zzc = paramzzgxv3;
    this.zzd = paramzzgxv4;
    this.zze = paramzzgxv5;
    this.zzf = paramzzgxv6;
    this.zzg = paramzzgxv7;
    this.zzh = paramzzgxv8;
    this.zzi = paramzzgxv9;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\nonagon\signalgeneration\zzab.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */