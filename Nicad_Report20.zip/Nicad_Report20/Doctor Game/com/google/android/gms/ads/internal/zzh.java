package com.google.android.gms.ads.internal;

import com.google.android.gms.internal.ads.zzfoa;

final class zzh implements zzfoa {
  zzh(zzi paramzzi) {}
  
  public final void zza(int paramInt, long paramLong) {
    zzi.zza(this.zza).zzd(paramInt, System.currentTimeMillis() - paramLong);
  }
  
  public final void zzb(int paramInt, long paramLong, String paramString) {
    zzi.zza(this.zza).zze(paramInt, System.currentTimeMillis() - paramLong, paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\zzh.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */