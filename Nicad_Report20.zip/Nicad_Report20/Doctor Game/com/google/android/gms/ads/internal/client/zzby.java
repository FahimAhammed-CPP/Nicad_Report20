package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzasa;
import com.google.android.gms.internal.ads.zzasb;

public abstract class zzby extends zzasa implements zzbz {
  public zzby() {
    super("com.google.android.gms.ads.internal.client.IAppEventListener");
  }
  
  public static zzbz zzd(IBinder paramIBinder) {
    IInterface iInterface = paramIBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IAppEventListener");
    return (iInterface instanceof zzbz) ? (zzbz)iInterface : new zzbx(paramIBinder);
  }
  
  protected final boolean zzbI(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2) throws RemoteException {
    if (paramInt1 == 1) {
      String str1 = paramParcel1.readString();
      String str2 = paramParcel1.readString();
      zzasb.zzc(paramParcel1);
      zzc(str1, str2);
      paramParcel2.writeNoException();
      return true;
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzby.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */