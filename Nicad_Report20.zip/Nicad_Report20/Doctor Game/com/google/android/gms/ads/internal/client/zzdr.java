package com.google.android.gms.ads.internal.client;

import android.content.Context;
import android.os.Bundle;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.ads.mediation.NetworkExtras;
import com.google.android.gms.ads.query.AdInfo;
import com.google.android.gms.ads.search.SearchAdRequest;
import com.google.android.gms.internal.ads.zzcgi;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.checkerframework.checker.initialization.qual.NotOnlyInitialized;

public final class zzdr {
  private final Date zza;
  
  private final String zzb;
  
  private final List zzc;
  
  private final int zzd;
  
  private final Set zze;
  
  private final Bundle zzf;
  
  private final Map zzg;
  
  private final String zzh;
  
  private final String zzi;
  
  @NotOnlyInitialized
  private final SearchAdRequest zzj;
  
  private final int zzk;
  
  private final Set zzl;
  
  private final Bundle zzm;
  
  private final Set zzn;
  
  private final boolean zzo;
  
  private final AdInfo zzp;
  
  private final String zzq;
  
  private final int zzr;
  
  public zzdr(zzdq paramzzdq, SearchAdRequest paramSearchAdRequest) {
    this.zza = zzdq.zzk(paramzzdq);
    this.zzb = zzdq.zzh(paramzzdq);
    this.zzc = zzdq.zzp(paramzzdq);
    this.zzd = zzdq.zza(paramzzdq);
    this.zze = Collections.unmodifiableSet(zzdq.zzn(paramzzdq));
    this.zzf = zzdq.zze(paramzzdq);
    this.zzg = Collections.unmodifiableMap(zzdq.zzl(paramzzdq));
    this.zzh = zzdq.zzi(paramzzdq);
    this.zzi = zzdq.zzj(paramzzdq);
    this.zzj = paramSearchAdRequest;
    this.zzk = zzdq.zzc(paramzzdq);
    this.zzl = Collections.unmodifiableSet(zzdq.zzo(paramzzdq));
    this.zzm = zzdq.zzd(paramzzdq);
    this.zzn = Collections.unmodifiableSet(zzdq.zzm(paramzzdq));
    this.zzo = zzdq.zzJ(paramzzdq);
    this.zzp = zzdq.zzf(paramzzdq);
    this.zzq = zzdq.zzg(paramzzdq);
    this.zzr = zzdq.zzb(paramzzdq);
  }
  
  @Deprecated
  public final int zza() {
    return this.zzd;
  }
  
  public final int zzb() {
    return this.zzr;
  }
  
  public final int zzc() {
    return this.zzk;
  }
  
  public final Bundle zzd(Class paramClass) {
    Bundle bundle = this.zzf.getBundle("com.google.android.gms.ads.mediation.customevent.CustomEventAdapter");
    return (bundle != null) ? bundle.getBundle(paramClass.getName()) : null;
  }
  
  public final Bundle zze() {
    return this.zzm;
  }
  
  public final Bundle zzf(Class paramClass) {
    return this.zzf.getBundle(paramClass.getName());
  }
  
  public final Bundle zzg() {
    return this.zzf;
  }
  
  @Deprecated
  public final NetworkExtras zzh(Class paramClass) {
    return (NetworkExtras)this.zzg.get(paramClass);
  }
  
  public final AdInfo zzi() {
    return this.zzp;
  }
  
  public final SearchAdRequest zzj() {
    return this.zzj;
  }
  
  public final String zzk() {
    return this.zzq;
  }
  
  public final String zzl() {
    return this.zzb;
  }
  
  public final String zzm() {
    return this.zzh;
  }
  
  public final String zzn() {
    return this.zzi;
  }
  
  @Deprecated
  public final Date zzo() {
    return this.zza;
  }
  
  public final List zzp() {
    return new ArrayList(this.zzc);
  }
  
  public final Set zzq() {
    return this.zzn;
  }
  
  public final Set zzr() {
    return this.zze;
  }
  
  @Deprecated
  public final boolean zzs() {
    return this.zzo;
  }
  
  public final boolean zzt(Context paramContext) {
    RequestConfiguration requestConfiguration = zzed.zzf().zzc();
    zzaw.zzb();
    String str = zzcgi.zzx(paramContext);
    return (this.zzl.contains(str) || requestConfiguration.getTestDeviceIds().contains(str));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzdr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */