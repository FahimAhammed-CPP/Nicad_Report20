package com.google.android.gms.ads.internal.client;

import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzasa;
import com.google.android.gms.internal.ads.zzasb;
import java.util.List;

public abstract class zzdg extends zzasa implements zzdh {
  public zzdg() {
    super("com.google.android.gms.ads.internal.client.IResponseInfo");
  }
  
  public static zzdh zzb(IBinder paramIBinder) {
    if (paramIBinder == null)
      return null; 
    IInterface iInterface = paramIBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IResponseInfo");
    return (iInterface instanceof zzdh) ? (zzdh)iInterface : new zzdf(paramIBinder);
  }
  
  protected final boolean zzbI(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2) throws RemoteException {
    String str2;
    Bundle bundle;
    zzu zzu;
    List list;
    switch (paramInt1) {
      default:
        return false;
      case 6:
        str2 = zzh();
        paramParcel2.writeNoException();
        paramParcel2.writeString(str2);
        return true;
      case 5:
        bundle = zze();
        paramParcel2.writeNoException();
        zzasb.zzf(paramParcel2, (Parcelable)bundle);
        return true;
      case 4:
        zzu = zzf();
        paramParcel2.writeNoException();
        zzasb.zzf(paramParcel2, (Parcelable)zzu);
        return true;
      case 3:
        list = zzj();
        paramParcel2.writeNoException();
        paramParcel2.writeTypedList(list);
        return true;
      case 2:
        str1 = zzi();
        paramParcel2.writeNoException();
        paramParcel2.writeString(str1);
        return true;
      case 1:
        break;
    } 
    String str1 = zzg();
    paramParcel2.writeNoException();
    paramParcel2.writeString(str1);
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzdg.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */