package com.google.android.gms.ads;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.RemoteException;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.gms.ads.internal.client.zzaw;
import com.google.android.gms.dynamic.ObjectWrapper;
import com.google.android.gms.internal.ads.zzbzc;
import com.google.android.gms.internal.ads.zzcgp;

public final class AdActivity extends Activity {
  public static final String CLASS_NAME = "com.google.android.gms.ads.AdActivity";
  
  private zzbzc zza;
  
  private final void zza() {
    zzbzc zzbzc1 = this.zza;
    if (zzbzc1 != null)
      try {
        zzbzc1.zzv();
        return;
      } catch (RemoteException remoteException) {
        zzcgp.zzl("#007 Could not call remote method.", (Throwable)remoteException);
      }  
  }
  
  protected final void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    try {
      zzbzc zzbzc1 = this.zza;
      if (zzbzc1 != null)
        zzbzc1.zzg(paramInt1, paramInt2, paramIntent); 
    } catch (Exception exception) {
      zzcgp.zzl("#007 Could not call remote method.", exception);
    } 
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
  }
  
  public final void onBackPressed() {
    // Byte code:
    //   0: aload_0
    //   1: getfield zza : Lcom/google/android/gms/internal/ads/zzbzc;
    //   4: astore_2
    //   5: aload_2
    //   6: ifnull -> 30
    //   9: aload_2
    //   10: invokeinterface zzE : ()Z
    //   15: istore_1
    //   16: iload_1
    //   17: ifeq -> 49
    //   20: goto -> 30
    //   23: astore_2
    //   24: ldc '#007 Could not call remote method.'
    //   26: aload_2
    //   27: invokestatic zzl : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   30: aload_0
    //   31: invokespecial onBackPressed : ()V
    //   34: aload_0
    //   35: getfield zza : Lcom/google/android/gms/internal/ads/zzbzc;
    //   38: astore_2
    //   39: aload_2
    //   40: ifnull -> 49
    //   43: aload_2
    //   44: invokeinterface zzh : ()V
    //   49: return
    //   50: astore_2
    //   51: ldc '#007 Could not call remote method.'
    //   53: aload_2
    //   54: invokestatic zzl : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   57: return
    // Exception table:
    //   from	to	target	type
    //   0	5	23	android/os/RemoteException
    //   9	16	23	android/os/RemoteException
    //   34	39	50	android/os/RemoteException
    //   43	49	50	android/os/RemoteException
  }
  
  public final void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    try {
      zzbzc zzbzc1 = this.zza;
      if (zzbzc1 != null)
        zzbzc1.zzj(ObjectWrapper.wrap(paramConfiguration)); 
      return;
    } catch (RemoteException remoteException) {
      zzcgp.zzl("#007 Could not call remote method.", (Throwable)remoteException);
      return;
    } 
  }
  
  protected final void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    zzbzc zzbzc1 = zzaw.zza().zzn(this);
    this.zza = zzbzc1;
    if (zzbzc1 != null)
      try {
        zzbzc1.zzk(paramBundle);
        return;
      } catch (RemoteException remoteException) {
        zzcgp.zzl("#007 Could not call remote method.", (Throwable)remoteException);
        finish();
        return;
      }  
    zzcgp.zzl("#007 Could not call remote method.", null);
    finish();
  }
  
  protected final void onDestroy() {
    try {
      zzbzc zzbzc1 = this.zza;
      if (zzbzc1 != null)
        zzbzc1.zzl(); 
    } catch (RemoteException remoteException) {
      zzcgp.zzl("#007 Could not call remote method.", (Throwable)remoteException);
    } 
    super.onDestroy();
  }
  
  protected final void onPause() {
    try {
      zzbzc zzbzc1 = this.zza;
      if (zzbzc1 != null)
        zzbzc1.zzn(); 
    } catch (RemoteException remoteException) {
      zzcgp.zzl("#007 Could not call remote method.", (Throwable)remoteException);
      finish();
    } 
    super.onPause();
  }
  
  protected final void onRestart() {
    super.onRestart();
    try {
      zzbzc zzbzc1 = this.zza;
      if (zzbzc1 != null)
        zzbzc1.zzo(); 
      return;
    } catch (RemoteException remoteException) {
      zzcgp.zzl("#007 Could not call remote method.", (Throwable)remoteException);
      finish();
      return;
    } 
  }
  
  protected final void onResume() {
    super.onResume();
    try {
      zzbzc zzbzc1 = this.zza;
      if (zzbzc1 != null)
        zzbzc1.zzp(); 
      return;
    } catch (RemoteException remoteException) {
      zzcgp.zzl("#007 Could not call remote method.", (Throwable)remoteException);
      finish();
      return;
    } 
  }
  
  protected final void onSaveInstanceState(Bundle paramBundle) {
    try {
      zzbzc zzbzc1 = this.zza;
      if (zzbzc1 != null)
        zzbzc1.zzq(paramBundle); 
    } catch (RemoteException remoteException) {
      zzcgp.zzl("#007 Could not call remote method.", (Throwable)remoteException);
      finish();
    } 
    super.onSaveInstanceState(paramBundle);
  }
  
  protected final void onStart() {
    super.onStart();
    try {
      zzbzc zzbzc1 = this.zza;
      if (zzbzc1 != null)
        zzbzc1.zzr(); 
      return;
    } catch (RemoteException remoteException) {
      zzcgp.zzl("#007 Could not call remote method.", (Throwable)remoteException);
      finish();
      return;
    } 
  }
  
  protected final void onStop() {
    try {
      zzbzc zzbzc1 = this.zza;
      if (zzbzc1 != null)
        zzbzc1.zzs(); 
    } catch (RemoteException remoteException) {
      zzcgp.zzl("#007 Could not call remote method.", (Throwable)remoteException);
      finish();
    } 
    super.onStop();
  }
  
  protected final void onUserLeaveHint() {
    super.onUserLeaveHint();
    try {
      zzbzc zzbzc1 = this.zza;
      if (zzbzc1 != null)
        zzbzc1.zzt(); 
      return;
    } catch (RemoteException remoteException) {
      zzcgp.zzl("#007 Could not call remote method.", (Throwable)remoteException);
      return;
    } 
  }
  
  public final void setContentView(int paramInt) {
    super.setContentView(paramInt);
    zza();
  }
  
  public final void setContentView(View paramView) {
    super.setContentView(paramView);
    zza();
  }
  
  public final void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    super.setContentView(paramView, paramLayoutParams);
    zza();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\AdActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */