package com.google.android.gms.ads;

public enum AdFormat {
  BANNER, INTERSTITIAL, NATIVE, REWARDED, REWARDED_INTERSTITIAL, UNKNOWN;
  
  static {
    NATIVE = new AdFormat("NATIVE", 4);
    AdFormat adFormat = new AdFormat("UNKNOWN", 5);
    UNKNOWN = adFormat;
    zza = new AdFormat[] { BANNER, INTERSTITIAL, REWARDED, REWARDED_INTERSTITIAL, NATIVE, adFormat };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\AdFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */