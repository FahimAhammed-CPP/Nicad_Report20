package com.google.android.gms.ads.internal.util;

import android.content.Context;
import com.google.android.gms.internal.ads.zzbcp;
import com.google.android.gms.internal.ads.zzcfs;
import org.json.JSONObject;

public interface zzg {
  void zzA(String paramString);
  
  void zzB(boolean paramBoolean);
  
  void zzC(String paramString);
  
  void zzD(long paramLong);
  
  void zzE(int paramInt);
  
  void zzF(String paramString1, String paramString2);
  
  void zzG(String paramString);
  
  void zzH(boolean paramBoolean);
  
  void zzI(String paramString1, String paramString2, boolean paramBoolean);
  
  void zzJ(int paramInt);
  
  void zzK(int paramInt);
  
  void zzL(long paramLong);
  
  boolean zzM();
  
  boolean zzN();
  
  boolean zzO();
  
  boolean zzP();
  
  int zza();
  
  int zzb();
  
  int zzc();
  
  long zzd();
  
  long zze();
  
  long zzf();
  
  zzbcp zzg();
  
  zzcfs zzh();
  
  zzcfs zzi();
  
  String zzj();
  
  String zzk();
  
  String zzl();
  
  String zzm();
  
  String zzn(String paramString);
  
  String zzo();
  
  JSONObject zzp();
  
  void zzq(Runnable paramRunnable);
  
  void zzr(Context paramContext);
  
  void zzs();
  
  void zzt(long paramLong);
  
  void zzu(String paramString);
  
  void zzv(int paramInt);
  
  void zzw(String paramString);
  
  void zzx(boolean paramBoolean);
  
  void zzy(String paramString);
  
  void zzz(boolean paramBoolean);
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzg.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */