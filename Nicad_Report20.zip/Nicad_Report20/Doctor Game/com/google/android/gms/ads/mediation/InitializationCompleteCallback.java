package com.google.android.gms.ads.mediation;

public interface InitializationCompleteCallback {
  void onInitializationFailed(String paramString);
  
  void onInitializationSucceeded();
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\mediation\InitializationCompleteCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */