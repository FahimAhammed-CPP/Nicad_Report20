package com.google.android.gms.ads.mediation;

public interface MediationNativeAdCallback extends MediationAdCallback {
  void onAdLeftApplication();
  
  void onVideoComplete();
  
  void onVideoMute();
  
  void onVideoPause();
  
  void onVideoPlay();
  
  void onVideoUnmute();
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\mediation\MediationNativeAdCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */