package com.google.android.gms.ads.internal.util;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import java.util.Map;
import java.util.WeakHashMap;

public final class zzcg {
  private final BroadcastReceiver zza = new zzcf(this);
  
  private final Map zzb = new WeakHashMap<Object, Object>();
  
  private boolean zzc = false;
  
  private boolean zzd;
  
  private Context zze;
  
  private final void zze(Context paramContext, Intent paramIntent) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new java/util/ArrayList
    //   5: dup
    //   6: invokespecial <init> : ()V
    //   9: astore #5
    //   11: aload_0
    //   12: getfield zzb : Ljava/util/Map;
    //   15: invokeinterface entrySet : ()Ljava/util/Set;
    //   20: invokeinterface iterator : ()Ljava/util/Iterator;
    //   25: astore #6
    //   27: aload #6
    //   29: invokeinterface hasNext : ()Z
    //   34: ifeq -> 90
    //   37: aload #6
    //   39: invokeinterface next : ()Ljava/lang/Object;
    //   44: checkcast java/util/Map$Entry
    //   47: astore #7
    //   49: aload #7
    //   51: invokeinterface getValue : ()Ljava/lang/Object;
    //   56: checkcast android/content/IntentFilter
    //   59: aload_2
    //   60: invokevirtual getAction : ()Ljava/lang/String;
    //   63: invokevirtual hasAction : (Ljava/lang/String;)Z
    //   66: ifeq -> 27
    //   69: aload #5
    //   71: aload #7
    //   73: invokeinterface getKey : ()Ljava/lang/Object;
    //   78: checkcast android/content/BroadcastReceiver
    //   81: invokeinterface add : (Ljava/lang/Object;)Z
    //   86: pop
    //   87: goto -> 27
    //   90: aload #5
    //   92: invokeinterface size : ()I
    //   97: istore #4
    //   99: iconst_0
    //   100: istore_3
    //   101: iload_3
    //   102: iload #4
    //   104: if_icmpge -> 130
    //   107: aload #5
    //   109: iload_3
    //   110: invokeinterface get : (I)Ljava/lang/Object;
    //   115: checkcast android/content/BroadcastReceiver
    //   118: aload_1
    //   119: aload_2
    //   120: invokevirtual onReceive : (Landroid/content/Context;Landroid/content/Intent;)V
    //   123: iload_3
    //   124: iconst_1
    //   125: iadd
    //   126: istore_3
    //   127: goto -> 101
    //   130: aload_0
    //   131: monitorexit
    //   132: return
    //   133: astore_1
    //   134: aload_0
    //   135: monitorexit
    //   136: goto -> 141
    //   139: aload_1
    //   140: athrow
    //   141: goto -> 139
    // Exception table:
    //   from	to	target	type
    //   2	27	133	finally
    //   27	87	133	finally
    //   90	99	133	finally
    //   107	123	133	finally
  }
  
  public final void zzb(Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield zzc : Z
    //   6: istore_2
    //   7: iload_2
    //   8: ifeq -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: aload_1
    //   15: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   18: astore_3
    //   19: aload_0
    //   20: aload_3
    //   21: putfield zze : Landroid/content/Context;
    //   24: aload_3
    //   25: ifnonnull -> 33
    //   28: aload_0
    //   29: aload_1
    //   30: putfield zze : Landroid/content/Context;
    //   33: aload_0
    //   34: getfield zze : Landroid/content/Context;
    //   37: invokestatic zzc : (Landroid/content/Context;)V
    //   40: getstatic com/google/android/gms/internal/ads/zzbjc.zzcW : Lcom/google/android/gms/internal/ads/zzbiu;
    //   43: astore_1
    //   44: aload_0
    //   45: invokestatic zzc : ()Lcom/google/android/gms/internal/ads/zzbja;
    //   48: aload_1
    //   49: invokevirtual zzb : (Lcom/google/android/gms/internal/ads/zzbiu;)Ljava/lang/Object;
    //   52: checkcast java/lang/Boolean
    //   55: invokevirtual booleanValue : ()Z
    //   58: putfield zzd : Z
    //   61: new android/content/IntentFilter
    //   64: dup
    //   65: invokespecial <init> : ()V
    //   68: astore_1
    //   69: aload_1
    //   70: ldc 'android.intent.action.SCREEN_ON'
    //   72: invokevirtual addAction : (Ljava/lang/String;)V
    //   75: aload_1
    //   76: ldc 'android.intent.action.SCREEN_OFF'
    //   78: invokevirtual addAction : (Ljava/lang/String;)V
    //   81: aload_1
    //   82: ldc 'android.intent.action.USER_PRESENT'
    //   84: invokevirtual addAction : (Ljava/lang/String;)V
    //   87: getstatic com/google/android/gms/internal/ads/zzbjc.zziE : Lcom/google/android/gms/internal/ads/zzbiu;
    //   90: astore_3
    //   91: invokestatic zzc : ()Lcom/google/android/gms/internal/ads/zzbja;
    //   94: aload_3
    //   95: invokevirtual zzb : (Lcom/google/android/gms/internal/ads/zzbiu;)Ljava/lang/Object;
    //   98: checkcast java/lang/Boolean
    //   101: invokevirtual booleanValue : ()Z
    //   104: ifeq -> 132
    //   107: getstatic android/os/Build$VERSION.SDK_INT : I
    //   110: bipush #33
    //   112: if_icmplt -> 132
    //   115: aload_0
    //   116: getfield zze : Landroid/content/Context;
    //   119: aload_0
    //   120: getfield zza : Landroid/content/BroadcastReceiver;
    //   123: aload_1
    //   124: iconst_4
    //   125: invokevirtual registerReceiver : (Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;
    //   128: pop
    //   129: goto -> 145
    //   132: aload_0
    //   133: getfield zze : Landroid/content/Context;
    //   136: aload_0
    //   137: getfield zza : Landroid/content/BroadcastReceiver;
    //   140: aload_1
    //   141: invokevirtual registerReceiver : (Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;
    //   144: pop
    //   145: aload_0
    //   146: iconst_1
    //   147: putfield zzc : Z
    //   150: aload_0
    //   151: monitorexit
    //   152: return
    //   153: astore_1
    //   154: aload_0
    //   155: monitorexit
    //   156: aload_1
    //   157: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	153	finally
    //   14	24	153	finally
    //   28	33	153	finally
    //   33	129	153	finally
    //   132	145	153	finally
    //   145	150	153	finally
  }
  
  public final void zzc(Context paramContext, BroadcastReceiver paramBroadcastReceiver, IntentFilter paramIntentFilter) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield zzd : Z
    //   6: ifeq -> 24
    //   9: aload_0
    //   10: getfield zzb : Ljava/util/Map;
    //   13: aload_2
    //   14: aload_3
    //   15: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   20: pop
    //   21: aload_0
    //   22: monitorexit
    //   23: return
    //   24: aload_1
    //   25: invokestatic zzc : (Landroid/content/Context;)V
    //   28: getstatic com/google/android/gms/internal/ads/zzbjc.zziE : Lcom/google/android/gms/internal/ads/zzbiu;
    //   31: astore #4
    //   33: invokestatic zzc : ()Lcom/google/android/gms/internal/ads/zzbja;
    //   36: aload #4
    //   38: invokevirtual zzb : (Lcom/google/android/gms/internal/ads/zzbiu;)Ljava/lang/Object;
    //   41: checkcast java/lang/Boolean
    //   44: invokevirtual booleanValue : ()Z
    //   47: ifeq -> 69
    //   50: getstatic android/os/Build$VERSION.SDK_INT : I
    //   53: bipush #33
    //   55: if_icmplt -> 69
    //   58: aload_1
    //   59: aload_2
    //   60: aload_3
    //   61: iconst_4
    //   62: invokevirtual registerReceiver : (Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;
    //   65: pop
    //   66: aload_0
    //   67: monitorexit
    //   68: return
    //   69: aload_1
    //   70: aload_2
    //   71: aload_3
    //   72: invokevirtual registerReceiver : (Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;
    //   75: pop
    //   76: aload_0
    //   77: monitorexit
    //   78: return
    //   79: astore_1
    //   80: aload_0
    //   81: monitorexit
    //   82: aload_1
    //   83: athrow
    // Exception table:
    //   from	to	target	type
    //   2	21	79	finally
    //   24	66	79	finally
    //   69	76	79	finally
  }
  
  public final void zzd(Context paramContext, BroadcastReceiver paramBroadcastReceiver) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield zzd : Z
    //   6: ifeq -> 23
    //   9: aload_0
    //   10: getfield zzb : Ljava/util/Map;
    //   13: aload_2
    //   14: invokeinterface remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   19: pop
    //   20: aload_0
    //   21: monitorexit
    //   22: return
    //   23: aload_1
    //   24: aload_2
    //   25: invokevirtual unregisterReceiver : (Landroid/content/BroadcastReceiver;)V
    //   28: aload_0
    //   29: monitorexit
    //   30: return
    //   31: astore_1
    //   32: aload_0
    //   33: monitorexit
    //   34: aload_1
    //   35: athrow
    // Exception table:
    //   from	to	target	type
    //   2	20	31	finally
    //   23	28	31	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzcg.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */