package com.google.android.gms.ads.h5;

import android.content.Context;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.android.gms.internal.ads.zzbqn;
import com.google.android.gms.internal.ads.zzbra;

public final class H5AdsWebViewClient extends zzbqn {
  private final zzbra zza;
  
  public H5AdsWebViewClient(Context paramContext, WebView paramWebView) {
    this.zza = new zzbra(paramContext, paramWebView);
  }
  
  public void clearAdObjects() {
    this.zza.zza();
  }
  
  protected WebViewClient getDelegate() {
    return (WebViewClient)this.zza;
  }
  
  public WebViewClient getDelegateWebViewClient() {
    return this.zza.getDelegate();
  }
  
  public void setDelegateWebViewClient(WebViewClient paramWebViewClient) {
    this.zza.zzb(paramWebViewClient);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\h5\H5AdsWebViewClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */