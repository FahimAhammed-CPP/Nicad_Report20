package com.google.android.gms.ads.mediation.customevent;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.mediation.MediationAdRequest;
import com.google.android.gms.ads.mediation.MediationBannerAdapter;
import com.google.android.gms.ads.mediation.MediationBannerListener;
import com.google.android.gms.ads.mediation.MediationInterstitialAdapter;
import com.google.android.gms.ads.mediation.MediationInterstitialListener;
import com.google.android.gms.ads.mediation.MediationNativeAdapter;
import com.google.android.gms.ads.mediation.MediationNativeListener;
import com.google.android.gms.ads.mediation.NativeMediationAdRequest;
import com.google.android.gms.internal.ads.zzcgp;

public final class CustomEventAdapter implements MediationBannerAdapter, MediationInterstitialAdapter, MediationNativeAdapter {
  static final AdError zza = new AdError(0, "Could not instantiate custom event adapter", "com.google.android.gms.ads");
  
  CustomEventBanner zzb;
  
  CustomEventInterstitial zzc;
  
  CustomEventNative zzd;
  
  private View zze;
  
  private static Object zzb(Class paramClass, String paramString) {
    if (paramString != null)
      try {
        return paramClass.cast(Class.forName(paramString).getDeclaredConstructor(new Class[0]).newInstance(new Object[0]));
      } finally {
        paramClass = null;
        String str = paramClass.getMessage();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Could not instantiate custom event adapter: ");
        stringBuilder.append(paramString);
        stringBuilder.append(". ");
        stringBuilder.append(str);
        zzcgp.zzj(stringBuilder.toString());
      }  
    throw null;
  }
  
  public View getBannerView() {
    return this.zze;
  }
  
  public void onDestroy() {
    CustomEventBanner customEventBanner = this.zzb;
    if (customEventBanner != null)
      customEventBanner.onDestroy(); 
    CustomEventInterstitial customEventInterstitial = this.zzc;
    if (customEventInterstitial != null)
      customEventInterstitial.onDestroy(); 
    CustomEventNative customEventNative = this.zzd;
    if (customEventNative != null)
      customEventNative.onDestroy(); 
  }
  
  public void onPause() {
    CustomEventBanner customEventBanner = this.zzb;
    if (customEventBanner != null)
      customEventBanner.onPause(); 
    CustomEventInterstitial customEventInterstitial = this.zzc;
    if (customEventInterstitial != null)
      customEventInterstitial.onPause(); 
    CustomEventNative customEventNative = this.zzd;
    if (customEventNative != null)
      customEventNative.onPause(); 
  }
  
  public void onResume() {
    CustomEventBanner customEventBanner = this.zzb;
    if (customEventBanner != null)
      customEventBanner.onResume(); 
    CustomEventInterstitial customEventInterstitial = this.zzc;
    if (customEventInterstitial != null)
      customEventInterstitial.onResume(); 
    CustomEventNative customEventNative = this.zzd;
    if (customEventNative != null)
      customEventNative.onResume(); 
  }
  
  public void requestBannerAd(Context paramContext, MediationBannerListener paramMediationBannerListener, Bundle paramBundle1, AdSize paramAdSize, MediationAdRequest paramMediationAdRequest, Bundle paramBundle2) {
    CustomEventBanner customEventBanner = (CustomEventBanner)zzb(CustomEventBanner.class, paramBundle1.getString("class_name"));
    this.zzb = customEventBanner;
    if (customEventBanner == null) {
      paramMediationBannerListener.onAdFailedToLoad(this, zza);
      return;
    } 
    if (paramBundle2 == null) {
      paramBundle2 = null;
    } else {
      paramBundle2 = paramBundle2.getBundle(paramBundle1.getString("class_name"));
    } 
    customEventBanner = this.zzb;
    if (customEventBanner != null) {
      customEventBanner.requestBannerAd(paramContext, new zza(this, paramMediationBannerListener), paramBundle1.getString("parameter"), paramAdSize, paramMediationAdRequest, paramBundle2);
      return;
    } 
    throw null;
  }
  
  public void requestInterstitialAd(Context paramContext, MediationInterstitialListener paramMediationInterstitialListener, Bundle paramBundle1, MediationAdRequest paramMediationAdRequest, Bundle paramBundle2) {
    CustomEventInterstitial customEventInterstitial = (CustomEventInterstitial)zzb(CustomEventInterstitial.class, paramBundle1.getString("class_name"));
    this.zzc = customEventInterstitial;
    if (customEventInterstitial == null) {
      paramMediationInterstitialListener.onAdFailedToLoad(this, zza);
      return;
    } 
    if (paramBundle2 == null) {
      paramBundle2 = null;
    } else {
      paramBundle2 = paramBundle2.getBundle(paramBundle1.getString("class_name"));
    } 
    customEventInterstitial = this.zzc;
    if (customEventInterstitial != null) {
      customEventInterstitial.requestInterstitialAd(paramContext, new zzb(this, this, paramMediationInterstitialListener), paramBundle1.getString("parameter"), paramMediationAdRequest, paramBundle2);
      return;
    } 
    throw null;
  }
  
  public void requestNativeAd(Context paramContext, MediationNativeListener paramMediationNativeListener, Bundle paramBundle1, NativeMediationAdRequest paramNativeMediationAdRequest, Bundle paramBundle2) {
    CustomEventNative customEventNative = (CustomEventNative)zzb(CustomEventNative.class, paramBundle1.getString("class_name"));
    this.zzd = customEventNative;
    if (customEventNative == null) {
      paramMediationNativeListener.onAdFailedToLoad(this, zza);
      return;
    } 
    if (paramBundle2 == null) {
      paramBundle2 = null;
    } else {
      paramBundle2 = paramBundle2.getBundle(paramBundle1.getString("class_name"));
    } 
    customEventNative = this.zzd;
    if (customEventNative != null) {
      customEventNative.requestNativeAd(paramContext, new zzc(this, paramMediationNativeListener), paramBundle1.getString("parameter"), paramNativeMediationAdRequest, paramBundle2);
      return;
    } 
    throw null;
  }
  
  public void showInterstitial() {
    CustomEventInterstitial customEventInterstitial = this.zzc;
    if (customEventInterstitial != null)
      customEventInterstitial.showInterstitial(); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\mediation\customevent\CustomEventAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */