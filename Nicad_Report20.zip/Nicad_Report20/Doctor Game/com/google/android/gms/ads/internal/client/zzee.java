package com.google.android.gms.ads.internal.client;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.ProviderInfo;
import android.database.Cursor;
import android.net.Uri;

public final class zzee extends ContentProvider {
  public final void attachInfo(Context paramContext, ProviderInfo paramProviderInfo) {
    // Byte code:
    //   0: aconst_null
    //   1: astore #5
    //   3: aload_1
    //   4: invokestatic packageManager : (Landroid/content/Context;)Lcom/google/android/gms/common/wrappers/PackageManagerWrapper;
    //   7: aload_1
    //   8: invokevirtual getPackageName : ()Ljava/lang/String;
    //   11: sipush #128
    //   14: invokevirtual getApplicationInfo : (Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;
    //   17: getfield metaData : Landroid/os/Bundle;
    //   20: astore #6
    //   22: aload #6
    //   24: astore #5
    //   26: goto -> 50
    //   29: astore #6
    //   31: ldc 'Failed to load metadata: Package name not found.'
    //   33: aload #6
    //   35: invokestatic zzh : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   38: goto -> 50
    //   41: astore #6
    //   43: ldc 'Failed to load metadata: Null pointer exception.'
    //   45: aload #6
    //   47: invokestatic zzh : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   50: invokestatic zza : ()Lcom/google/android/gms/internal/ads/zzbvd;
    //   53: astore #6
    //   55: aload #5
    //   57: ifnonnull -> 68
    //   60: ldc 'Metadata was null.'
    //   62: invokestatic zzg : (Ljava/lang/String;)V
    //   65: goto -> 220
    //   68: aload #5
    //   70: ldc 'com.google.android.gms.ads.APPLICATION_ID'
    //   72: invokevirtual get : (Ljava/lang/String;)Ljava/lang/Object;
    //   75: checkcast java/lang/String
    //   78: astore #7
    //   80: aload #5
    //   82: ldc 'com.google.android.gms.ads.AD_MANAGER_APP'
    //   84: invokevirtual get : (Ljava/lang/String;)Ljava/lang/Object;
    //   87: checkcast java/lang/Boolean
    //   90: astore #8
    //   92: aload #5
    //   94: ldc 'com.google.android.gms.ads.DELAY_APP_MEASUREMENT_INIT'
    //   96: invokevirtual get : (Ljava/lang/String;)Ljava/lang/Object;
    //   99: checkcast java/lang/Boolean
    //   102: astore #9
    //   104: aload #5
    //   106: ldc 'com.google.android.gms.ads.INTEGRATION_MANAGER'
    //   108: invokevirtual get : (Ljava/lang/String;)Ljava/lang/Object;
    //   111: checkcast java/lang/String
    //   114: astore #10
    //   116: aload #7
    //   118: ifnull -> 186
    //   121: aload #7
    //   123: ldc '^/\d+~.+$'
    //   125: invokevirtual matches : (Ljava/lang/String;)Z
    //   128: ifne -> 186
    //   131: aload #7
    //   133: ldc '^ca-app-pub-[0-9]{16}~[0-9]{10}$'
    //   135: invokevirtual matches : (Ljava/lang/String;)Z
    //   138: ifeq -> 176
    //   141: ldc 'Publisher provided Google AdMob App ID in manifest: '
    //   143: aload #7
    //   145: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   148: invokestatic zze : (Ljava/lang/String;)V
    //   151: aload #9
    //   153: ifnull -> 164
    //   156: aload #9
    //   158: invokevirtual booleanValue : ()Z
    //   161: ifne -> 220
    //   164: aload #6
    //   166: aload_1
    //   167: aload #7
    //   169: invokevirtual zzb : (Landroid/content/Context;Ljava/lang/String;)Ljava/lang/Thread;
    //   172: pop
    //   173: goto -> 220
    //   176: new java/lang/IllegalStateException
    //   179: dup
    //   180: ldc '\\n\\n******************************************************************************\\n* Invalid application ID. Follow instructions here:                          *\\n* https://googlemobileadssdk.page.link/admob-android-update-manifest         *\\n* to find your app ID.                                                       *\\n******************************************************************************\\n\\n'
    //   182: invokespecial <init> : (Ljava/lang/String;)V
    //   185: athrow
    //   186: aload #8
    //   188: ifnull -> 199
    //   191: aload #8
    //   193: invokevirtual booleanValue : ()Z
    //   196: ifne -> 220
    //   199: aload #10
    //   201: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   204: ifne -> 273
    //   207: ldc 'The Google Mobile Ads SDK is integrated by '
    //   209: aload #10
    //   211: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   214: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   217: invokestatic zze : (Ljava/lang/String;)V
    //   220: aload #5
    //   222: ifnonnull -> 228
    //   225: goto -> 266
    //   228: aload #5
    //   230: ldc 'com.google.android.gms.ads.flag.OPTIMIZE_INITIALIZATION'
    //   232: iconst_0
    //   233: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   236: istore_3
    //   237: aload #5
    //   239: ldc 'com.google.android.gms.ads.flag.OPTIMIZE_AD_LOADING'
    //   241: iconst_0
    //   242: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   245: istore #4
    //   247: iload_3
    //   248: ifeq -> 256
    //   251: ldc 'com.google.android.gms.ads.flag.OPTIMIZE_INITIALIZATION is enabled'
    //   253: invokestatic zze : (Ljava/lang/String;)V
    //   256: iload #4
    //   258: ifeq -> 266
    //   261: ldc 'com.google.android.gms.ads.flag.OPTIMIZE_AD_LOADING is enabled'
    //   263: invokestatic zze : (Ljava/lang/String;)V
    //   266: aload_0
    //   267: aload_1
    //   268: aload_2
    //   269: invokespecial attachInfo : (Landroid/content/Context;Landroid/content/pm/ProviderInfo;)V
    //   272: return
    //   273: new java/lang/IllegalStateException
    //   276: dup
    //   277: ldc '\\n\\n******************************************************************************\\n* The Google Mobile Ads SDK was initialized incorrectly. AdMob publishers    *\\n* should follow the instructions here:                                       *\\n* https://googlemobileadssdk.page.link/admob-android-update-manifest         *\\n* to add a valid App ID inside the AndroidManifest.                          *\\n* Google Ad Manager publishers should follow instructions here:              *\\n* https://googlemobileadssdk.page.link/ad-manager-android-update-manifest.   *\\n******************************************************************************\\n\\n'
    //   279: invokespecial <init> : (Ljava/lang/String;)V
    //   282: athrow
    //   283: astore_1
    //   284: new java/lang/IllegalStateException
    //   287: dup
    //   288: ldc 'The com.google.android.gms.ads.INTEGRATION_MANAGER metadata must have a String value.'
    //   290: aload_1
    //   291: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   294: athrow
    //   295: astore_1
    //   296: new java/lang/IllegalStateException
    //   299: dup
    //   300: ldc 'The com.google.android.gms.ads.DELAY_APP_MEASUREMENT_INIT metadata must have a boolean value.'
    //   302: aload_1
    //   303: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   306: athrow
    //   307: astore_1
    //   308: new java/lang/IllegalStateException
    //   311: dup
    //   312: ldc 'The com.google.android.gms.ads.AD_MANAGER_APP metadata must have a boolean value.'
    //   314: aload_1
    //   315: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   318: athrow
    //   319: astore_1
    //   320: new java/lang/IllegalStateException
    //   323: dup
    //   324: ldc 'The com.google.android.gms.ads.APPLICATION_ID metadata must have a String value.'
    //   326: aload_1
    //   327: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   330: athrow
    // Exception table:
    //   from	to	target	type
    //   3	22	41	java/lang/NullPointerException
    //   3	22	29	android/content/pm/PackageManager$NameNotFoundException
    //   68	80	319	java/lang/ClassCastException
    //   80	92	307	java/lang/ClassCastException
    //   92	104	295	java/lang/ClassCastException
    //   104	116	283	java/lang/ClassCastException
  }
  
  public final int delete(Uri paramUri, String paramString, String[] paramArrayOfString) {
    return 0;
  }
  
  public final String getType(Uri paramUri) {
    return null;
  }
  
  public final Uri insert(Uri paramUri, ContentValues paramContentValues) {
    return null;
  }
  
  public final boolean onCreate() {
    return false;
  }
  
  public final Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2) {
    return null;
  }
  
  public final int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString) {
    return 0;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzee.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */