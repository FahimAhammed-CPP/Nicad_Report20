package com.google.android.gms.ads.internal.client;

import android.os.IInterface;
import android.os.RemoteException;

public interface zzde extends IInterface {
  void zze(zzs paramzzs) throws RemoteException;
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzde.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */