package com.google.android.gms.ads.nativead;

import android.content.Context;
import android.os.RemoteException;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import android.widget.ImageView;
import com.google.android.gms.ads.MediaContent;
import com.google.android.gms.dynamic.ObjectWrapper;
import com.google.android.gms.internal.ads.zzbmy;
import com.google.android.gms.internal.ads.zzcgp;

public class MediaView extends FrameLayout {
  private MediaContent zza;
  
  private boolean zzb;
  
  private ImageView.ScaleType zzc;
  
  private boolean zzd;
  
  private zzb zze;
  
  private zzc zzf;
  
  public MediaView(Context paramContext) {
    super(paramContext);
  }
  
  public MediaView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  public MediaView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
  }
  
  public MediaView(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
  }
  
  public MediaContent getMediaContent() {
    return this.zza;
  }
  
  public void setImageScaleType(ImageView.ScaleType paramScaleType) {
    this.zzd = true;
    this.zzc = paramScaleType;
    zzc zzc1 = this.zzf;
    if (zzc1 != null)
      zzc1.zza.zzc(paramScaleType); 
  }
  
  public void setMediaContent(MediaContent paramMediaContent) {
    this.zzb = true;
    this.zza = paramMediaContent;
    zzb zzb1 = this.zze;
    if (zzb1 != null)
      zzb1.zza.zzb(paramMediaContent); 
    if (paramMediaContent == null)
      return; 
    try {
      zzbmy zzbmy = paramMediaContent.zza();
      if (zzbmy != null && !zzbmy.zzr(ObjectWrapper.wrap(this)))
        removeAllViews(); 
      return;
    } catch (RemoteException remoteException) {
      removeAllViews();
      zzcgp.zzh("", (Throwable)remoteException);
      return;
    } 
  }
  
  protected final void zza(zzb paramzzb) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: putfield zze : Lcom/google/android/gms/ads/nativead/zzb;
    //   7: aload_0
    //   8: getfield zzb : Z
    //   11: ifeq -> 30
    //   14: aload_0
    //   15: getfield zza : Lcom/google/android/gms/ads/MediaContent;
    //   18: astore_2
    //   19: aload_1
    //   20: getfield zza : Lcom/google/android/gms/ads/nativead/NativeAdView;
    //   23: aload_2
    //   24: invokevirtual zzb : (Lcom/google/android/gms/ads/MediaContent;)V
    //   27: aload_0
    //   28: monitorexit
    //   29: return
    //   30: aload_0
    //   31: monitorexit
    //   32: return
    //   33: astore_1
    //   34: aload_0
    //   35: monitorexit
    //   36: aload_1
    //   37: athrow
    // Exception table:
    //   from	to	target	type
    //   2	27	33	finally
  }
  
  protected final void zzb(zzc paramzzc) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: putfield zzf : Lcom/google/android/gms/ads/nativead/zzc;
    //   7: aload_0
    //   8: getfield zzd : Z
    //   11: ifeq -> 30
    //   14: aload_0
    //   15: getfield zzc : Landroid/widget/ImageView$ScaleType;
    //   18: astore_2
    //   19: aload_1
    //   20: getfield zza : Lcom/google/android/gms/ads/nativead/NativeAdView;
    //   23: aload_2
    //   24: invokevirtual zzc : (Landroid/widget/ImageView$ScaleType;)V
    //   27: aload_0
    //   28: monitorexit
    //   29: return
    //   30: aload_0
    //   31: monitorexit
    //   32: return
    //   33: astore_1
    //   34: aload_0
    //   35: monitorexit
    //   36: aload_1
    //   37: athrow
    // Exception table:
    //   from	to	target	type
    //   2	27	33	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\nativead\MediaView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */