package com.google.android.gms.ads;

import android.os.Bundle;
import android.os.RemoteException;
import com.google.android.gms.ads.internal.client.zzaw;
import com.google.android.gms.ads.internal.client.zzdh;
import com.google.android.gms.ads.internal.client.zzu;
import com.google.android.gms.internal.ads.zzcgp;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class ResponseInfo {
  private final zzdh zza;
  
  private final List zzb;
  
  private AdapterResponseInfo zzc;
  
  private ResponseInfo(zzdh paramzzdh) {
    this.zza = paramzzdh;
    this.zzb = new ArrayList();
    paramzzdh = this.zza;
    if (paramzzdh != null)
      try {
        List list = paramzzdh.zzj();
        if (list != null) {
          Iterator<zzu> iterator = list.iterator();
          while (iterator.hasNext()) {
            AdapterResponseInfo adapterResponseInfo = AdapterResponseInfo.zza(iterator.next());
            if (adapterResponseInfo != null)
              this.zzb.add(adapterResponseInfo); 
          } 
        } 
      } catch (RemoteException remoteException) {
        zzcgp.zzh("Could not forward getAdapterResponseInfo to ResponseInfo.", (Throwable)remoteException);
      }  
    paramzzdh = this.zza;
    if (paramzzdh == null)
      return; 
    try {
      zzu zzu = paramzzdh.zzf();
      if (zzu != null)
        this.zzc = AdapterResponseInfo.zza(zzu); 
      return;
    } catch (RemoteException remoteException) {
      zzcgp.zzh("Could not forward getLoadedAdapterResponse to ResponseInfo.", (Throwable)remoteException);
      return;
    } 
  }
  
  public static ResponseInfo zza(zzdh paramzzdh) {
    return (paramzzdh != null) ? new ResponseInfo(paramzzdh) : null;
  }
  
  public static ResponseInfo zzb(zzdh paramzzdh) {
    return new ResponseInfo(paramzzdh);
  }
  
  public List<AdapterResponseInfo> getAdapterResponses() {
    return this.zzb;
  }
  
  public AdapterResponseInfo getLoadedAdapterResponseInfo() {
    return this.zzc;
  }
  
  public String getMediationAdapterClassName() {
    try {
      zzdh zzdh1 = this.zza;
      if (zzdh1 != null)
        return zzdh1.zzg(); 
    } catch (RemoteException remoteException) {
      zzcgp.zzh("Could not forward getMediationAdapterClassName to ResponseInfo.", (Throwable)remoteException);
    } 
    return null;
  }
  
  public Bundle getResponseExtras() {
    try {
      zzdh zzdh1 = this.zza;
      if (zzdh1 != null)
        return zzdh1.zze(); 
    } catch (RemoteException remoteException) {
      zzcgp.zzh("Could not forward getResponseExtras to ResponseInfo.", (Throwable)remoteException);
    } 
    return new Bundle();
  }
  
  public String getResponseId() {
    try {
      zzdh zzdh1 = this.zza;
      if (zzdh1 != null)
        return zzdh1.zzi(); 
    } catch (RemoteException remoteException) {
      zzcgp.zzh("Could not forward getResponseId to ResponseInfo.", (Throwable)remoteException);
    } 
    return null;
  }
  
  public String toString() {
    try {
      return zzd().toString(2);
    } catch (JSONException jSONException) {
      return "Error forming toString output.";
    } 
  }
  
  public final zzdh zzc() {
    return this.zza;
  }
  
  public final JSONObject zzd() throws JSONException {
    JSONObject jSONObject = new JSONObject();
    String str = getResponseId();
    if (str == null) {
      jSONObject.put("Response ID", "null");
    } else {
      jSONObject.put("Response ID", str);
    } 
    str = getMediationAdapterClassName();
    if (str == null) {
      jSONObject.put("Mediation Adapter Class Name", "null");
    } else {
      jSONObject.put("Mediation Adapter Class Name", str);
    } 
    JSONArray jSONArray = new JSONArray();
    Iterator<AdapterResponseInfo> iterator = this.zzb.iterator();
    while (iterator.hasNext())
      jSONArray.put(((AdapterResponseInfo)iterator.next()).zzb()); 
    jSONObject.put("Adapter Responses", jSONArray);
    AdapterResponseInfo adapterResponseInfo = this.zzc;
    if (adapterResponseInfo != null)
      jSONObject.put("Loaded Adapter Response", adapterResponseInfo.zzb()); 
    Bundle bundle = getResponseExtras();
    if (bundle != null)
      jSONObject.put("Response Extras", zzaw.zzb().zzh(bundle)); 
    return jSONObject;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\ResponseInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */