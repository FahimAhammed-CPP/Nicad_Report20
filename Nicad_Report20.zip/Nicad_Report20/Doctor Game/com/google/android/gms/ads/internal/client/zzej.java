package com.google.android.gms.ads.internal.client;

import android.graphics.drawable.Drawable;
import android.os.RemoteException;
import com.google.android.gms.ads.MediaContent;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.dynamic.ObjectWrapper;
import com.google.android.gms.internal.ads.zzbmb;
import com.google.android.gms.internal.ads.zzbmy;
import com.google.android.gms.internal.ads.zzcgp;

public final class zzej implements MediaContent {
  private final zzbmb zza;
  
  private final VideoController zzb = new VideoController();
  
  private final zzbmy zzc;
  
  public zzej(zzbmb paramzzbmb, zzbmy paramzzbmy) {
    this.zza = paramzzbmb;
    this.zzc = paramzzbmy;
  }
  
  public final float getAspectRatio() {
    try {
      return this.zza.zze();
    } catch (RemoteException remoteException) {
      zzcgp.zzh("", (Throwable)remoteException);
      return 0.0F;
    } 
  }
  
  public final float getCurrentTime() {
    try {
      return this.zza.zzf();
    } catch (RemoteException remoteException) {
      zzcgp.zzh("", (Throwable)remoteException);
      return 0.0F;
    } 
  }
  
  public final float getDuration() {
    try {
      return this.zza.zzg();
    } catch (RemoteException remoteException) {
      zzcgp.zzh("", (Throwable)remoteException);
      return 0.0F;
    } 
  }
  
  public final Drawable getMainImage() {
    try {
      IObjectWrapper iObjectWrapper = this.zza.zzi();
      if (iObjectWrapper != null)
        return (Drawable)ObjectWrapper.unwrap(iObjectWrapper); 
    } catch (RemoteException remoteException) {
      zzcgp.zzh("", (Throwable)remoteException);
    } 
    return null;
  }
  
  public final VideoController getVideoController() {
    try {
      if (this.zza.zzh() != null)
        this.zzb.zzb(this.zza.zzh()); 
    } catch (RemoteException remoteException) {
      zzcgp.zzh("Exception occurred while getting video controller", (Throwable)remoteException);
    } 
    return this.zzb;
  }
  
  public final boolean hasVideoContent() {
    try {
      return this.zza.zzk();
    } catch (RemoteException remoteException) {
      zzcgp.zzh("", (Throwable)remoteException);
      return false;
    } 
  }
  
  public final void setMainImage(Drawable paramDrawable) {
    try {
      this.zza.zzj(ObjectWrapper.wrap(paramDrawable));
      return;
    } catch (RemoteException remoteException) {
      zzcgp.zzh("", (Throwable)remoteException);
      return;
    } 
  }
  
  public final zzbmy zza() {
    return this.zzc;
  }
  
  public final zzbmb zzb() {
    return this.zza;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzej.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */