package com.google.android.gms.ads.internal.util;

import android.content.Context;
import com.google.android.gms.ads.internal.client.zzcx;
import com.google.android.gms.ads.internal.client.zze;

final class zzat extends zzcx {
  zzat(zzaw paramzzaw, Context paramContext) {}
  
  public final void zze(zze paramzze) {
    if (paramzze == null)
      return; 
    this.zzb.zzi(this.zza, paramzze.zzb, true, true);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */