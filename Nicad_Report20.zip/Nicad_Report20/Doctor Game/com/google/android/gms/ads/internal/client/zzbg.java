package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzarz;
import com.google.android.gms.internal.ads.zzasb;

public final class zzbg extends zzarz implements zzbi {
  zzbg(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IAdLoadCallback");
  }
  
  public final void zzb(zze paramzze) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zze(parcel, (Parcelable)paramzze);
    zzbl(2, parcel);
  }
  
  public final void zzc() throws RemoteException {
    zzbl(1, zza());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzbg.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */