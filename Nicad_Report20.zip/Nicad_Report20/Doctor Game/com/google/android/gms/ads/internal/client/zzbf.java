package com.google.android.gms.ads.internal.client;

import android.os.IInterface;
import android.os.RemoteException;

public interface zzbf extends IInterface {
  void zzc() throws RemoteException;
  
  void zzd() throws RemoteException;
  
  void zze(int paramInt) throws RemoteException;
  
  void zzf(zze paramzze) throws RemoteException;
  
  void zzg() throws RemoteException;
  
  void zzh() throws RemoteException;
  
  void zzi() throws RemoteException;
  
  void zzj() throws RemoteException;
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzbf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */