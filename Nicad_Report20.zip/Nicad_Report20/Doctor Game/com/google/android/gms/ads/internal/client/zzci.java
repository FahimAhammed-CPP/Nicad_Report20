package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzasa;
import com.google.android.gms.internal.ads.zzasb;
import com.google.android.gms.internal.ads.zzbvk;

public abstract class zzci extends zzasa implements zzcj {
  public zzci() {
    super("com.google.android.gms.ads.internal.client.ILiteSdkInfo");
  }
  
  public static zzcj asInterface(IBinder paramIBinder) {
    if (paramIBinder == null)
      return null; 
    IInterface iInterface = paramIBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.ILiteSdkInfo");
    return (iInterface instanceof zzcj) ? (zzcj)iInterface : new zzch(paramIBinder);
  }
  
  protected final boolean zzbI(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2) throws RemoteException {
    if (paramInt1 != 1) {
      if (paramInt1 != 2)
        return false; 
      zzbvk zzbvk = getAdapterCreator();
      paramParcel2.writeNoException();
      zzasb.zzg(paramParcel2, (IInterface)zzbvk);
      return true;
    } 
    zzeh zzeh = getLiteSdkVersion();
    paramParcel2.writeNoException();
    zzasb.zzf(paramParcel2, (Parcelable)zzeh);
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzci.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */