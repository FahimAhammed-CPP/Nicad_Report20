package com.google.android.gms.ads;

import android.content.Context;
import android.os.RemoteException;
import android.text.TextUtils;
import android.webkit.WebView;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.internal.client.zzed;
import com.google.android.gms.ads.mediation.rtb.RtbAdapter;
import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.dynamic.ObjectWrapper;
import com.google.android.gms.internal.ads.zzbzt;
import com.google.android.gms.internal.ads.zzcfg;
import com.google.android.gms.internal.ads.zzcgp;

public class MobileAds {
  public static final String ERROR_DOMAIN = "com.google.android.gms.ads";
  
  public static void disableMediationAdapterInitialization(Context paramContext) {
    zzed.zzf().zzl(paramContext);
  }
  
  public static InitializationStatus getInitializationStatus() {
    return zzed.zzf().zze();
  }
  
  public static RequestConfiguration getRequestConfiguration() {
    return zzed.zzf().zzc();
  }
  
  public static VersionInfo getVersion() {
    zzed.zzf();
    String[] arrayOfString = TextUtils.split("21.3.0", "\\.");
    if (arrayOfString.length != 3)
      return new VersionInfo(0, 0, 0); 
    try {
      return new VersionInfo(Integer.parseInt(arrayOfString[0]), Integer.parseInt(arrayOfString[1]), Integer.parseInt(arrayOfString[2]));
    } catch (NumberFormatException numberFormatException) {
      return new VersionInfo(0, 0, 0);
    } 
  }
  
  @Deprecated
  public static String getVersionString() {
    return zzed.zzf().zzh();
  }
  
  public static void initialize(Context paramContext) {
    zzed.zzf().zzm(paramContext, null, null);
  }
  
  public static void initialize(Context paramContext, OnInitializationCompleteListener paramOnInitializationCompleteListener) {
    zzed.zzf().zzm(paramContext, null, paramOnInitializationCompleteListener);
  }
  
  public static void openAdInspector(Context paramContext, OnAdInspectorClosedListener paramOnAdInspectorClosedListener) {
    zzed.zzf().zzp(paramContext, paramOnAdInspectorClosedListener);
  }
  
  public static void openDebugMenu(Context paramContext, String paramString) {
    zzed.zzf().zzq(paramContext, paramString);
  }
  
  public static void registerRtbAdapter(Class<? extends RtbAdapter> paramClass) {
    zzed.zzf().zzr(paramClass);
  }
  
  public static void registerWebView(WebView paramWebView) {
    zzed.zzf();
    Preconditions.checkMainThread("#008 Must be called on the main UI thread.");
    if (paramWebView == null) {
      zzcgp.zzg("The webview to be registered cannot be null.");
      return;
    } 
    zzcfg zzcfg = zzbzt.zza(paramWebView.getContext());
    if (zzcfg == null) {
      zzcgp.zzj("Internal error, query info generator is null.");
      return;
    } 
    try {
      zzcfg.zzi(ObjectWrapper.wrap(paramWebView));
      return;
    } catch (RemoteException remoteException) {
      zzcgp.zzh("", (Throwable)remoteException);
      return;
    } 
  }
  
  public static void setAppMuted(boolean paramBoolean) {
    zzed.zzf().zzs(paramBoolean);
  }
  
  public static void setAppVolume(float paramFloat) {
    zzed.zzf().zzt(paramFloat);
  }
  
  public static void setRequestConfiguration(RequestConfiguration paramRequestConfiguration) {
    zzed.zzf().zzu(paramRequestConfiguration);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\MobileAds.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */