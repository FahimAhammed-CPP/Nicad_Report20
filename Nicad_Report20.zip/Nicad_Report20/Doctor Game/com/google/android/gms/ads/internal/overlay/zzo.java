package com.google.android.gms.ads.internal.overlay;

public interface zzo {
  void zzb();
  
  void zzbC();
  
  void zzbK();
  
  void zzbr();
  
  void zze();
  
  void zzf(int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\overlay\zzo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */