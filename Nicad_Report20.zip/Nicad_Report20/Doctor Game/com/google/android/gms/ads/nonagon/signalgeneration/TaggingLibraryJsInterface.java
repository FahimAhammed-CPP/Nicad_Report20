package com.google.android.gms.ads.nonagon.signalgeneration;

import android.content.Context;
import android.os.Bundle;
import android.util.Pair;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.AdFormat;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.util.zze;
import com.google.android.gms.ads.internal.zzt;
import com.google.android.gms.ads.query.QueryInfo;
import com.google.android.gms.internal.ads.zzape;
import com.google.android.gms.internal.ads.zzbiu;
import com.google.android.gms.internal.ads.zzbjc;
import com.google.android.gms.internal.ads.zzchc;
import com.google.android.gms.internal.ads.zzdxv;
import com.google.android.gms.internal.ads.zzfzp;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import org.json.JSONException;
import org.json.JSONObject;

final class TaggingLibraryJsInterface {
  private final Context zza;
  
  private final WebView zzb;
  
  private final zzape zzc;
  
  private final int zzd;
  
  private final zzdxv zze;
  
  private final boolean zzf;
  
  TaggingLibraryJsInterface(WebView paramWebView, zzape paramzzape, zzdxv paramzzdxv) {
    this.zzb = paramWebView;
    Context context = paramWebView.getContext();
    this.zza = context;
    this.zzc = paramzzape;
    this.zze = paramzzdxv;
    zzbjc.zzc(context);
    zzbiu zzbiu = zzbjc.zzid;
    this.zzd = ((Integer)zzay.zzc().zzb(zzbiu)).intValue();
    zzbiu = zzbjc.zzie;
    this.zzf = ((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue();
  }
  
  @JavascriptInterface
  public String getClickSignals(String paramString) {
    try {
      long l = zzt.zzB().currentTimeMillis();
      paramString = this.zzc.zzc().zze(this.zza, paramString, (View)this.zzb);
      if (this.zzf) {
        long l1 = zzt.zzB().currentTimeMillis();
        zzf.zzc(this.zze, null, "csg", new Pair[] { new Pair("clat", String.valueOf(l1 - l)) });
      } 
      return paramString;
    } catch (RuntimeException runtimeException) {
      zze.zzh("Exception getting click signals. ", runtimeException);
      zzt.zzo().zzt(runtimeException, "TaggingLibraryJsInterface.getClickSignals");
      return "";
    } 
  }
  
  @JavascriptInterface
  public String getClickSignalsWithTimeout(String paramString, int paramInt) {
    StringBuilder stringBuilder;
    if (paramInt <= 0) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("Invalid timeout for getting click signals. Timeout=");
      stringBuilder.append(paramInt);
      zze.zzg(stringBuilder.toString());
      return "";
    } 
    paramInt = Math.min(paramInt, this.zzd);
    zzfzp<String> zzfzp = zzchc.zza.zzb(new zzao(this, (String)stringBuilder));
    long l = paramInt;
    try {
      return zzfzp.get(l, TimeUnit.MILLISECONDS);
    } catch (InterruptedException interruptedException) {
    
    } catch (TimeoutException timeoutException) {
    
    } catch (ExecutionException executionException) {}
    zze.zzh("Exception getting click signals with timeout. ", executionException);
    zzt.zzo().zzt(executionException, "TaggingLibraryJsInterface.getClickSignalsWithTimeout");
    return (executionException instanceof TimeoutException) ? "17" : "";
  }
  
  @JavascriptInterface
  public String getQueryInfo() {
    zzt.zzp();
    String str = UUID.randomUUID().toString();
    Bundle bundle = new Bundle();
    bundle.putString("query_info_type", "requester_type_6");
    Context context = this.zza;
    AdFormat adFormat = AdFormat.BANNER;
    AdRequest.Builder builder = new AdRequest.Builder();
    builder.addNetworkExtrasBundle(AdMobAdapter.class, bundle);
    QueryInfo.generate(context, adFormat, builder.build(), new zzap(this, str));
    return str;
  }
  
  @JavascriptInterface
  public String getViewSignals() {
    try {
      long l = zzt.zzB().currentTimeMillis();
      String str = this.zzc.zzc().zzh(this.zza, (View)this.zzb, null);
      if (this.zzf) {
        long l1 = zzt.zzB().currentTimeMillis();
        zzf.zzc(this.zze, null, "vsg", new Pair[] { new Pair("vlat", String.valueOf(l1 - l)) });
      } 
      return str;
    } catch (RuntimeException runtimeException) {
      zze.zzh("Exception getting view signals. ", runtimeException);
      zzt.zzo().zzt(runtimeException, "TaggingLibraryJsInterface.getViewSignals");
      return "";
    } 
  }
  
  @JavascriptInterface
  public String getViewSignalsWithTimeout(int paramInt) {
    if (paramInt <= 0) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Invalid timeout for getting view signals. Timeout=");
      stringBuilder.append(paramInt);
      zze.zzg(stringBuilder.toString());
      return "";
    } 
    paramInt = Math.min(paramInt, this.zzd);
    zzfzp<String> zzfzp = zzchc.zza.zzb(new zzan(this));
    long l = paramInt;
    try {
      return zzfzp.get(l, TimeUnit.MILLISECONDS);
    } catch (InterruptedException interruptedException) {
    
    } catch (TimeoutException timeoutException) {
    
    } catch (ExecutionException executionException) {}
    zze.zzh("Exception getting view signals with timeout. ", executionException);
    zzt.zzo().zzt(executionException, "TaggingLibraryJsInterface.getViewSignalsWithTimeout");
    return (executionException instanceof TimeoutException) ? "17" : "";
  }
  
  @JavascriptInterface
  public void reportTouchEvent(String paramString) {
    try {
      JSONObject jSONObject = new JSONObject(paramString);
      int j = jSONObject.getInt("x");
      int k = jSONObject.getInt("y");
      int m = jSONObject.getInt("duration_ms");
      float f = (float)jSONObject.getDouble("force");
      int i = jSONObject.getInt("type");
      if (i != 0) {
        if (i != 1) {
          if (i != 2) {
            if (i != 3) {
              i = -1;
            } else {
              i = 3;
            } 
          } else {
            i = 2;
          } 
        } else {
          i = 1;
        } 
      } else {
        i = 0;
      } 
      MotionEvent motionEvent = MotionEvent.obtain(0L, m, i, j, k, f, 1.0F, 0, 1.0F, 1.0F, 0, 0);
      try {
        this.zzc.zzd(motionEvent);
        return;
      } catch (RuntimeException runtimeException) {
      
      } catch (JSONException null) {}
    } catch (RuntimeException runtimeException) {
    
    } catch (JSONException jSONException) {}
    zze.zzh("Failed to parse the touch string. ", (Throwable)jSONException);
    zzt.zzo().zzt((Throwable)jSONException, "TaggingLibraryJsInterface.reportTouchEvent");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\nonagon\signalgeneration\TaggingLibraryJsInterface.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */