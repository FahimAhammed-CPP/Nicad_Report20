package com.google.android.gms.ads.internal.client;

import com.google.android.gms.ads.FullScreenContentCallback;

public final class zzaz extends zzcf {
  private final FullScreenContentCallback zza;
  
  public zzaz(FullScreenContentCallback paramFullScreenContentCallback) {
    this.zza = paramFullScreenContentCallback;
  }
  
  public final void zzb() {
    FullScreenContentCallback fullScreenContentCallback = this.zza;
    if (fullScreenContentCallback != null)
      fullScreenContentCallback.onAdClicked(); 
  }
  
  public final void zzc() {
    FullScreenContentCallback fullScreenContentCallback = this.zza;
    if (fullScreenContentCallback != null)
      fullScreenContentCallback.onAdDismissedFullScreenContent(); 
  }
  
  public final void zzd(zze paramzze) {
    FullScreenContentCallback fullScreenContentCallback = this.zza;
    if (fullScreenContentCallback != null)
      fullScreenContentCallback.onAdFailedToShowFullScreenContent(paramzze.zza()); 
  }
  
  public final void zze() {
    FullScreenContentCallback fullScreenContentCallback = this.zza;
    if (fullScreenContentCallback != null)
      fullScreenContentCallback.onAdImpression(); 
  }
  
  public final void zzf() {
    FullScreenContentCallback fullScreenContentCallback = this.zza;
    if (fullScreenContentCallback != null)
      fullScreenContentCallback.onAdShowedFullScreenContent(); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzaz.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */