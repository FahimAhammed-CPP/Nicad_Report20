package com.google.android.gms.ads;

import android.os.RemoteException;
import com.google.android.gms.ads.internal.client.zzdk;
import com.google.android.gms.ads.internal.client.zzdn;
import com.google.android.gms.ads.internal.client.zzfe;
import com.google.android.gms.internal.ads.zzcgp;

public final class VideoController {
  public static final int PLAYBACK_STATE_ENDED = 3;
  
  public static final int PLAYBACK_STATE_PAUSED = 2;
  
  public static final int PLAYBACK_STATE_PLAYING = 1;
  
  public static final int PLAYBACK_STATE_READY = 5;
  
  public static final int PLAYBACK_STATE_UNKNOWN = 0;
  
  private final Object zza = new Object();
  
  private zzdk zzb;
  
  private VideoLifecycleCallbacks zzc;
  
  public int getPlaybackState() {
    synchronized (this.zza) {
      zzdk zzdk1 = this.zzb;
      if (zzdk1 == null)
        return 0; 
      try {
        return zzdk1.zzh();
      } catch (RemoteException remoteException) {
        zzcgp.zzh("Unable to call getPlaybackState on video controller.", (Throwable)remoteException);
        return 0;
      } 
    } 
  }
  
  public VideoLifecycleCallbacks getVideoLifecycleCallbacks() {
    synchronized (this.zza) {
      return this.zzc;
    } 
  }
  
  public boolean hasVideoContent() {
    synchronized (this.zza) {
      if (this.zzb != null)
        return true; 
    } 
    boolean bool = false;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_2} */
    return bool;
  }
  
  public boolean isClickToExpandEnabled() {
    synchronized (this.zza) {
      zzdk zzdk1 = this.zzb;
      if (zzdk1 == null)
        return false; 
      try {
        return zzdk1.zzo();
      } catch (RemoteException remoteException) {
        zzcgp.zzh("Unable to call isClickToExpandEnabled.", (Throwable)remoteException);
        return false;
      } 
    } 
  }
  
  public boolean isCustomControlsEnabled() {
    synchronized (this.zza) {
      zzdk zzdk1 = this.zzb;
      if (zzdk1 == null)
        return false; 
      try {
        return zzdk1.zzp();
      } catch (RemoteException remoteException) {
        zzcgp.zzh("Unable to call isUsingCustomPlayerControls.", (Throwable)remoteException);
        return false;
      } 
    } 
  }
  
  public boolean isMuted() {
    synchronized (this.zza) {
      zzdk zzdk1 = this.zzb;
      if (zzdk1 == null)
        return true; 
      try {
        return zzdk1.zzq();
      } catch (RemoteException remoteException) {
        zzcgp.zzh("Unable to call isMuted on video controller.", (Throwable)remoteException);
        return true;
      } 
    } 
  }
  
  public void mute(boolean paramBoolean) {
    synchronized (this.zza) {
      zzdk zzdk1 = this.zzb;
      if (zzdk1 != null) {
        try {
          zzdk1.zzj(paramBoolean);
        } catch (RemoteException remoteException) {
          zzcgp.zzh("Unable to call mute on video controller.", (Throwable)remoteException);
        } 
        return;
      } 
      return;
    } 
  }
  
  public void pause() {
    synchronized (this.zza) {
      zzdk zzdk1 = this.zzb;
      if (zzdk1 != null) {
        try {
          zzdk1.zzk();
        } catch (RemoteException remoteException) {
          zzcgp.zzh("Unable to call pause on video controller.", (Throwable)remoteException);
        } 
        return;
      } 
      return;
    } 
  }
  
  public void play() {
    synchronized (this.zza) {
      zzdk zzdk1 = this.zzb;
      if (zzdk1 != null) {
        try {
          zzdk1.zzl();
        } catch (RemoteException remoteException) {
          zzcgp.zzh("Unable to call play on video controller.", (Throwable)remoteException);
        } 
        return;
      } 
      return;
    } 
  }
  
  public void setVideoLifecycleCallbacks(VideoLifecycleCallbacks paramVideoLifecycleCallbacks) {
    synchronized (this.zza) {
      this.zzc = paramVideoLifecycleCallbacks;
      zzdk zzdk1 = this.zzb;
      if (zzdk1 != null) {
        if (paramVideoLifecycleCallbacks == null) {
          paramVideoLifecycleCallbacks = null;
        } else {
          try {
            zzfe zzfe = new zzfe(paramVideoLifecycleCallbacks);
            zzdk1.zzm((zzdn)zzfe);
          } catch (RemoteException remoteException) {
            zzcgp.zzh("Unable to call setVideoLifecycleCallbacks on video controller.", (Throwable)remoteException);
          } 
          return;
        } 
      } else {
        return;
      } 
      zzdk1.zzm((zzdn)remoteException);
    } 
  }
  
  public void stop() {
    synchronized (this.zza) {
      zzdk zzdk1 = this.zzb;
      if (zzdk1 != null) {
        try {
          zzdk1.zzn();
        } catch (RemoteException remoteException) {
          zzcgp.zzh("Unable to call stop on video controller.", (Throwable)remoteException);
        } 
        return;
      } 
      return;
    } 
  }
  
  public final zzdk zza() {
    synchronized (this.zza) {
      return this.zzb;
    } 
  }
  
  public final void zzb(zzdk paramzzdk) {
    synchronized (this.zza) {
      this.zzb = paramzzdk;
      VideoLifecycleCallbacks videoLifecycleCallbacks = this.zzc;
      if (videoLifecycleCallbacks != null)
        setVideoLifecycleCallbacks(videoLifecycleCallbacks); 
      return;
    } 
  }
  
  public static abstract class VideoLifecycleCallbacks {
    public void onVideoEnd() {}
    
    public void onVideoMute(boolean param1Boolean) {}
    
    public void onVideoPause() {}
    
    public void onVideoPlay() {}
    
    public void onVideoStart() {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\VideoController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */