package com.google.android.gms.ads.internal.overlay;

import android.content.Context;
import android.view.ViewGroup;
import android.view.ViewParent;
import com.google.android.gms.internal.ads.zzcmp;

public final class zzh {
  public final int zza;
  
  public final ViewGroup.LayoutParams zzb;
  
  public final ViewGroup zzc;
  
  public final Context zzd;
  
  public zzh(zzcmp paramzzcmp) throws zzf {
    this.zzb = paramzzcmp.getLayoutParams();
    ViewParent viewParent = paramzzcmp.getParent();
    this.zzd = paramzzcmp.zzG();
    if (viewParent != null && viewParent instanceof ViewGroup) {
      ViewGroup viewGroup = (ViewGroup)viewParent;
      this.zzc = viewGroup;
      this.zza = viewGroup.indexOfChild(paramzzcmp.zzH());
      this.zzc.removeView(paramzzcmp.zzH());
      paramzzcmp.zzap(true);
      return;
    } 
    throw new zzf("Could not get the parent of the WebView for an overlay.");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\overlay\zzh.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */