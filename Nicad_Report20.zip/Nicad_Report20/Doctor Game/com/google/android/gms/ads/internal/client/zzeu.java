package com.google.android.gms.ads.internal.client;

import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.internal.ads.zzbmn;

public final class zzeu extends zzbmn {
  public final void zzb(IObjectWrapper paramIObjectWrapper) {}
  
  public final void zzc(IObjectWrapper paramIObjectWrapper) throws RemoteException {}
  
  public final void zzd() throws RemoteException {}
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzeu.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */