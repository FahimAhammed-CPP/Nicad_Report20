package com.google.android.gms.ads.admanager;

public interface AppEventListener {
  void onAppEvent(String paramString1, String paramString2);
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\admanager\AppEventListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */