package com.google.android.gms.ads.internal.client;

import android.os.Bundle;
import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.internal.ads.zzbdm;
import com.google.android.gms.internal.ads.zzbjx;
import com.google.android.gms.internal.ads.zzbzl;
import com.google.android.gms.internal.ads.zzbzo;
import com.google.android.gms.internal.ads.zzcby;

public interface zzbs extends IInterface {
  void zzA() throws RemoteException;
  
  void zzB() throws RemoteException;
  
  void zzC(zzbc paramzzbc) throws RemoteException;
  
  void zzD(zzbf paramzzbf) throws RemoteException;
  
  void zzE(zzbw paramzzbw) throws RemoteException;
  
  void zzF(zzq paramzzq) throws RemoteException;
  
  void zzG(zzbz paramzzbz) throws RemoteException;
  
  void zzH(zzbdm paramzzbdm) throws RemoteException;
  
  void zzI(zzw paramzzw) throws RemoteException;
  
  void zzJ(zzcg paramzzcg) throws RemoteException;
  
  void zzK(zzdo paramzzdo) throws RemoteException;
  
  void zzL(boolean paramBoolean) throws RemoteException;
  
  void zzM(zzbzl paramzzbzl) throws RemoteException;
  
  void zzN(boolean paramBoolean) throws RemoteException;
  
  void zzO(zzbjx paramzzbjx) throws RemoteException;
  
  void zzP(zzde paramzzde) throws RemoteException;
  
  void zzQ(zzbzo paramzzbzo, String paramString) throws RemoteException;
  
  void zzR(String paramString) throws RemoteException;
  
  void zzS(zzcby paramzzcby) throws RemoteException;
  
  void zzT(String paramString) throws RemoteException;
  
  void zzU(zzff paramzzff) throws RemoteException;
  
  void zzW(IObjectWrapper paramIObjectWrapper) throws RemoteException;
  
  void zzX() throws RemoteException;
  
  boolean zzY() throws RemoteException;
  
  boolean zzZ() throws RemoteException;
  
  boolean zzaa(zzl paramzzl) throws RemoteException;
  
  void zzab(zzcd paramzzcd) throws RemoteException;
  
  Bundle zzd() throws RemoteException;
  
  zzq zzg() throws RemoteException;
  
  zzbf zzi() throws RemoteException;
  
  zzbz zzj() throws RemoteException;
  
  zzdh zzk() throws RemoteException;
  
  zzdk zzl() throws RemoteException;
  
  IObjectWrapper zzn() throws RemoteException;
  
  String zzr() throws RemoteException;
  
  String zzs() throws RemoteException;
  
  String zzt() throws RemoteException;
  
  void zzx() throws RemoteException;
  
  void zzy(zzl paramzzl, zzbi paramzzbi) throws RemoteException;
  
  void zzz() throws RemoteException;
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzbs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */