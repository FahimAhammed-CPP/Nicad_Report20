package com.google.android.gms.ads.nativead;

import android.content.Context;
import android.os.RemoteException;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import com.google.android.gms.ads.MediaContent;
import com.google.android.gms.ads.internal.client.zzaw;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.client.zzej;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.dynamic.ObjectWrapper;
import com.google.android.gms.internal.ads.zzbiu;
import com.google.android.gms.internal.ads.zzbjc;
import com.google.android.gms.internal.ads.zzbmi;
import com.google.android.gms.internal.ads.zzcgp;
import org.checkerframework.checker.initialization.qual.NotOnlyInitialized;
import org.checkerframework.checker.nullness.qual.RequiresNonNull;

public final class NativeAdView extends FrameLayout {
  @NotOnlyInitialized
  private final FrameLayout zza;
  
  @NotOnlyInitialized
  private final zzbmi zzb;
  
  public NativeAdView(Context paramContext) {
    super(paramContext);
    this.zza = zzd(paramContext);
    this.zzb = zze();
  }
  
  public NativeAdView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    this.zza = zzd(paramContext);
    this.zzb = zze();
  }
  
  public NativeAdView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    this.zza = zzd(paramContext);
    this.zzb = zze();
  }
  
  public NativeAdView(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    this.zza = zzd(paramContext);
    this.zzb = zze();
  }
  
  private final FrameLayout zzd(Context paramContext) {
    FrameLayout frameLayout = new FrameLayout(paramContext);
    frameLayout.setLayoutParams((ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-1, -1));
    addView((View)frameLayout);
    return frameLayout;
  }
  
  @RequiresNonNull({"overlayFrame"})
  private final zzbmi zze() {
    return isInEditMode() ? null : zzaw.zza().zzg(this.zza.getContext(), this, this.zza);
  }
  
  private final void zzf(String paramString, View paramView) {
    zzbmi zzbmi1 = this.zzb;
    if (zzbmi1 != null)
      try {
        zzbmi1.zzbw(paramString, ObjectWrapper.wrap(paramView));
        return;
      } catch (RemoteException remoteException) {
        zzcgp.zzh("Unable to call setAssetView on delegate", (Throwable)remoteException);
      }  
  }
  
  public final void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    super.addView(paramView, paramInt, paramLayoutParams);
    super.bringChildToFront((View)this.zza);
  }
  
  public final void bringChildToFront(View paramView) {
    super.bringChildToFront(paramView);
    FrameLayout frameLayout = this.zza;
    if (frameLayout != paramView)
      super.bringChildToFront((View)frameLayout); 
  }
  
  public void destroy() {
    zzbmi zzbmi1 = this.zzb;
    if (zzbmi1 != null)
      try {
        zzbmi1.zzc();
        return;
      } catch (RemoteException remoteException) {
        zzcgp.zzh("Unable to destroy native ad view", (Throwable)remoteException);
      }  
  }
  
  public final boolean dispatchTouchEvent(MotionEvent paramMotionEvent) {
    zzbiu zzbiu = zzbjc.zzcG;
    if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue()) {
      zzbmi zzbmi1 = this.zzb;
      if (zzbmi1 != null)
        try {
          zzbmi1.zzd(ObjectWrapper.wrap(paramMotionEvent));
        } catch (RemoteException remoteException) {
          zzcgp.zzh("Unable to call handleTouchEvent on delegate", (Throwable)remoteException);
        }  
    } 
    return super.dispatchTouchEvent(paramMotionEvent);
  }
  
  public AdChoicesView getAdChoicesView() {
    View view = zza("3011");
    return (view instanceof AdChoicesView) ? (AdChoicesView)view : null;
  }
  
  public final View getAdvertiserView() {
    return zza("3005");
  }
  
  public final View getBodyView() {
    return zza("3004");
  }
  
  public final View getCallToActionView() {
    return zza("3002");
  }
  
  public final View getHeadlineView() {
    return zza("3001");
  }
  
  public final View getIconView() {
    return zza("3003");
  }
  
  public final View getImageView() {
    return zza("3008");
  }
  
  public final MediaView getMediaView() {
    View view = zza("3010");
    if (view instanceof MediaView)
      return (MediaView)view; 
    if (view != null)
      zzcgp.zze("View is not an instance of MediaView"); 
    return null;
  }
  
  public final View getPriceView() {
    return zza("3007");
  }
  
  public final View getStarRatingView() {
    return zza("3009");
  }
  
  public final View getStoreView() {
    return zza("3006");
  }
  
  public final void onVisibilityChanged(View paramView, int paramInt) {
    super.onVisibilityChanged(paramView, paramInt);
    zzbmi zzbmi1 = this.zzb;
    if (zzbmi1 != null)
      try {
        zzbmi1.zze(ObjectWrapper.wrap(paramView), paramInt);
        return;
      } catch (RemoteException remoteException) {
        zzcgp.zzh("Unable to call onVisibilityChanged on delegate", (Throwable)remoteException);
      }  
  }
  
  public final void removeAllViews() {
    super.removeAllViews();
    addView((View)this.zza);
  }
  
  public final void removeView(View paramView) {
    if (this.zza == paramView)
      return; 
    super.removeView(paramView);
  }
  
  public void setAdChoicesView(AdChoicesView paramAdChoicesView) {
    zzf("3011", (View)paramAdChoicesView);
  }
  
  public final void setAdvertiserView(View paramView) {
    zzf("3005", paramView);
  }
  
  public final void setBodyView(View paramView) {
    zzf("3004", paramView);
  }
  
  public final void setCallToActionView(View paramView) {
    zzf("3002", paramView);
  }
  
  public final void setClickConfirmingView(View paramView) {
    zzbmi zzbmi1 = this.zzb;
    if (zzbmi1 != null)
      try {
        zzbmi1.zzbx(ObjectWrapper.wrap(paramView));
        return;
      } catch (RemoteException remoteException) {
        zzcgp.zzh("Unable to call setClickConfirmingView on delegate", (Throwable)remoteException);
      }  
  }
  
  public final void setHeadlineView(View paramView) {
    zzf("3001", paramView);
  }
  
  public final void setIconView(View paramView) {
    zzf("3003", paramView);
  }
  
  public final void setImageView(View paramView) {
    zzf("3008", paramView);
  }
  
  public final void setMediaView(MediaView paramMediaView) {
    zzf("3010", (View)paramMediaView);
    if (paramMediaView == null)
      return; 
    paramMediaView.zza(new zzb(this));
    paramMediaView.zzb(new zzc(this));
  }
  
  public void setNativeAd(NativeAd paramNativeAd) {
    zzbmi zzbmi1 = this.zzb;
    if (zzbmi1 != null)
      try {
        zzbmi1.zzbA((IObjectWrapper)paramNativeAd.zza());
        return;
      } catch (RemoteException remoteException) {
        zzcgp.zzh("Unable to call setNativeAd on delegate", (Throwable)remoteException);
      }  
  }
  
  public final void setPriceView(View paramView) {
    zzf("3007", paramView);
  }
  
  public final void setStarRatingView(View paramView) {
    zzf("3009", paramView);
  }
  
  public final void setStoreView(View paramView) {
    zzf("3006", paramView);
  }
  
  protected final View zza(String paramString) {
    zzbmi zzbmi1 = this.zzb;
    if (zzbmi1 != null)
      try {
        IObjectWrapper iObjectWrapper = zzbmi1.zzb(paramString);
        if (iObjectWrapper != null)
          return (View)ObjectWrapper.unwrap(iObjectWrapper); 
      } catch (RemoteException remoteException) {
        zzcgp.zzh("Unable to call getAssetView on delegate", (Throwable)remoteException);
      }  
    return null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\nativead\NativeAdView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */