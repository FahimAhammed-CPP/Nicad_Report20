package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzarz;

public final class zzbu extends zzarz implements zzbw {
  zzbu(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IAdMetadataListener");
  }
  
  public final void zze() throws RemoteException {
    zzbl(1, zza());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzbu.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */