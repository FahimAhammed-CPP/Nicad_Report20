package com.google.android.gms.ads.internal.client;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.DisplayMetrics;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelWriter;

public final class zzq extends AbstractSafeParcelable {
  public static final Parcelable.Creator<zzq> CREATOR = new zzr();
  
  public final String zza;
  
  public final int zzb;
  
  public final int zzc;
  
  public final boolean zzd;
  
  public final int zze;
  
  public final int zzf;
  
  public final zzq[] zzg;
  
  public final boolean zzh;
  
  public final boolean zzi;
  
  public boolean zzj;
  
  public boolean zzk;
  
  public boolean zzl;
  
  public boolean zzm;
  
  public boolean zzn;
  
  public boolean zzo;
  
  public zzq() {
    this("interstitial_mb", 0, 0, true, 0, 0, null, false, false, false, false, false, false, false, false);
  }
  
  public zzq(Context paramContext, AdSize paramAdSize) {
    this(paramContext, new AdSize[] { paramAdSize });
  }
  
  public zzq(Context paramContext, AdSize[] paramArrayOfAdSize) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_2
    //   5: iconst_0
    //   6: aaload
    //   7: astore #14
    //   9: aload_0
    //   10: iconst_0
    //   11: putfield zzd : Z
    //   14: aload_0
    //   15: aload #14
    //   17: invokevirtual isFluid : ()Z
    //   20: putfield zzi : Z
    //   23: aload_0
    //   24: aload #14
    //   26: invokestatic zzf : (Lcom/google/android/gms/ads/AdSize;)Z
    //   29: putfield zzm : Z
    //   32: aload_0
    //   33: aload #14
    //   35: invokestatic zzg : (Lcom/google/android/gms/ads/AdSize;)Z
    //   38: putfield zzn : Z
    //   41: aload #14
    //   43: invokestatic zzh : (Lcom/google/android/gms/ads/AdSize;)Z
    //   46: istore #13
    //   48: aload_0
    //   49: iload #13
    //   51: putfield zzo : Z
    //   54: aload_0
    //   55: getfield zzi : Z
    //   58: ifeq -> 88
    //   61: aload_0
    //   62: getstatic com/google/android/gms/ads/AdSize.BANNER : Lcom/google/android/gms/ads/AdSize;
    //   65: invokevirtual getWidth : ()I
    //   68: putfield zze : I
    //   71: getstatic com/google/android/gms/ads/AdSize.BANNER : Lcom/google/android/gms/ads/AdSize;
    //   74: invokevirtual getHeight : ()I
    //   77: istore #7
    //   79: aload_0
    //   80: iload #7
    //   82: putfield zzb : I
    //   85: goto -> 172
    //   88: aload_0
    //   89: getfield zzn : Z
    //   92: ifeq -> 120
    //   95: aload_0
    //   96: aload #14
    //   98: invokevirtual getWidth : ()I
    //   101: putfield zze : I
    //   104: aload #14
    //   106: invokestatic zza : (Lcom/google/android/gms/ads/AdSize;)I
    //   109: istore #7
    //   111: aload_0
    //   112: iload #7
    //   114: putfield zzb : I
    //   117: goto -> 172
    //   120: iload #13
    //   122: ifeq -> 150
    //   125: aload_0
    //   126: aload #14
    //   128: invokevirtual getWidth : ()I
    //   131: putfield zze : I
    //   134: aload #14
    //   136: invokestatic zzb : (Lcom/google/android/gms/ads/AdSize;)I
    //   139: istore #7
    //   141: aload_0
    //   142: iload #7
    //   144: putfield zzb : I
    //   147: goto -> 172
    //   150: aload_0
    //   151: aload #14
    //   153: invokevirtual getWidth : ()I
    //   156: putfield zze : I
    //   159: aload #14
    //   161: invokevirtual getHeight : ()I
    //   164: istore #7
    //   166: aload_0
    //   167: iload #7
    //   169: putfield zzb : I
    //   172: aload_0
    //   173: getfield zze : I
    //   176: istore #10
    //   178: aload_1
    //   179: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   182: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   185: astore #15
    //   187: iload #10
    //   189: iconst_m1
    //   190: if_icmpne -> 468
    //   193: invokestatic zzb : ()Lcom/google/android/gms/internal/ads/zzcgi;
    //   196: pop
    //   197: aload_1
    //   198: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   201: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   204: getfield orientation : I
    //   207: iconst_2
    //   208: if_icmpeq -> 214
    //   211: goto -> 400
    //   214: aload_1
    //   215: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   218: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   221: astore #16
    //   223: aload #16
    //   225: getfield heightPixels : I
    //   228: i2f
    //   229: aload #16
    //   231: getfield density : F
    //   234: fdiv
    //   235: f2i
    //   236: sipush #600
    //   239: if_icmpge -> 400
    //   242: invokestatic zzb : ()Lcom/google/android/gms/internal/ads/zzcgi;
    //   245: pop
    //   246: aload_1
    //   247: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   250: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   253: astore #16
    //   255: aload_1
    //   256: ldc 'window'
    //   258: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   261: checkcast android/view/WindowManager
    //   264: astore #17
    //   266: aload #17
    //   268: ifnull -> 400
    //   271: aload #17
    //   273: invokeinterface getDefaultDisplay : ()Landroid/view/Display;
    //   278: astore #17
    //   280: aload #17
    //   282: aload #16
    //   284: invokevirtual getRealMetrics : (Landroid/util/DisplayMetrics;)V
    //   287: aload #16
    //   289: getfield heightPixels : I
    //   292: istore #8
    //   294: aload #16
    //   296: getfield widthPixels : I
    //   299: istore #9
    //   301: aload #17
    //   303: aload #16
    //   305: invokevirtual getMetrics : (Landroid/util/DisplayMetrics;)V
    //   308: aload #16
    //   310: getfield heightPixels : I
    //   313: istore #11
    //   315: aload #16
    //   317: getfield widthPixels : I
    //   320: istore #12
    //   322: iload #11
    //   324: iload #8
    //   326: if_icmpne -> 400
    //   329: iload #12
    //   331: iload #9
    //   333: if_icmpne -> 400
    //   336: aload #15
    //   338: getfield widthPixels : I
    //   341: istore #9
    //   343: invokestatic zzb : ()Lcom/google/android/gms/internal/ads/zzcgi;
    //   346: pop
    //   347: aload_1
    //   348: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   351: ldc 'navigation_bar_width'
    //   353: ldc 'dimen'
    //   355: ldc 'android'
    //   357: invokevirtual getIdentifier : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I
    //   360: istore #8
    //   362: iload #8
    //   364: ifle -> 381
    //   367: aload_1
    //   368: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   371: iload #8
    //   373: invokevirtual getDimensionPixelSize : (I)I
    //   376: istore #8
    //   378: goto -> 384
    //   381: iconst_0
    //   382: istore #8
    //   384: iload #9
    //   386: iload #8
    //   388: isub
    //   389: istore #8
    //   391: aload_0
    //   392: iload #8
    //   394: putfield zzf : I
    //   397: goto -> 413
    //   400: aload #15
    //   402: getfield widthPixels : I
    //   405: istore #8
    //   407: aload_0
    //   408: iload #8
    //   410: putfield zzf : I
    //   413: iload #8
    //   415: i2f
    //   416: aload #15
    //   418: getfield density : F
    //   421: fdiv
    //   422: f2d
    //   423: dstore_3
    //   424: dload_3
    //   425: d2i
    //   426: istore #9
    //   428: iload #9
    //   430: i2d
    //   431: dstore #5
    //   433: dload_3
    //   434: invokestatic isNaN : (D)Z
    //   437: pop
    //   438: dload #5
    //   440: invokestatic isNaN : (D)Z
    //   443: pop
    //   444: iload #9
    //   446: istore #8
    //   448: dload_3
    //   449: dload #5
    //   451: dsub
    //   452: ldc2_w 0.01
    //   455: dcmpl
    //   456: iflt -> 491
    //   459: iload #9
    //   461: iconst_1
    //   462: iadd
    //   463: istore #8
    //   465: goto -> 491
    //   468: aload_0
    //   469: getfield zze : I
    //   472: istore #8
    //   474: invokestatic zzb : ()Lcom/google/android/gms/internal/ads/zzcgi;
    //   477: pop
    //   478: aload_0
    //   479: aload #15
    //   481: aload_0
    //   482: getfield zze : I
    //   485: invokestatic zzo : (Landroid/util/DisplayMetrics;I)I
    //   488: putfield zzf : I
    //   491: iload #7
    //   493: bipush #-2
    //   495: if_icmpne -> 508
    //   498: aload #15
    //   500: invokestatic zzf : (Landroid/util/DisplayMetrics;)I
    //   503: istore #9
    //   505: goto -> 514
    //   508: aload_0
    //   509: getfield zzb : I
    //   512: istore #9
    //   514: invokestatic zzb : ()Lcom/google/android/gms/internal/ads/zzcgi;
    //   517: pop
    //   518: aload_0
    //   519: aload #15
    //   521: iload #9
    //   523: invokestatic zzo : (Landroid/util/DisplayMetrics;I)I
    //   526: putfield zzc : I
    //   529: iload #10
    //   531: iconst_m1
    //   532: if_icmpeq -> 657
    //   535: iload #7
    //   537: bipush #-2
    //   539: if_icmpne -> 545
    //   542: goto -> 657
    //   545: aload_0
    //   546: getfield zzn : Z
    //   549: ifne -> 588
    //   552: aload_0
    //   553: getfield zzo : Z
    //   556: ifeq -> 562
    //   559: goto -> 588
    //   562: aload_0
    //   563: getfield zzi : Z
    //   566: ifeq -> 576
    //   569: ldc '320x50_mb'
    //   571: astore #14
    //   573: goto -> 648
    //   576: aload_0
    //   577: aload #14
    //   579: invokevirtual toString : ()Ljava/lang/String;
    //   582: putfield zza : Ljava/lang/String;
    //   585: goto -> 707
    //   588: aload_0
    //   589: getfield zze : I
    //   592: istore #7
    //   594: aload_0
    //   595: getfield zzb : I
    //   598: istore #8
    //   600: new java/lang/StringBuilder
    //   603: dup
    //   604: invokespecial <init> : ()V
    //   607: astore #14
    //   609: aload #14
    //   611: iload #7
    //   613: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   616: pop
    //   617: aload #14
    //   619: ldc 'x'
    //   621: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   624: pop
    //   625: aload #14
    //   627: iload #8
    //   629: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   632: pop
    //   633: aload #14
    //   635: ldc '_as'
    //   637: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   640: pop
    //   641: aload #14
    //   643: invokevirtual toString : ()Ljava/lang/String;
    //   646: astore #14
    //   648: aload_0
    //   649: aload #14
    //   651: putfield zza : Ljava/lang/String;
    //   654: goto -> 707
    //   657: new java/lang/StringBuilder
    //   660: dup
    //   661: invokespecial <init> : ()V
    //   664: astore #14
    //   666: aload #14
    //   668: iload #8
    //   670: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   673: pop
    //   674: aload #14
    //   676: ldc 'x'
    //   678: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   681: pop
    //   682: aload #14
    //   684: iload #9
    //   686: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   689: pop
    //   690: aload #14
    //   692: ldc '_as'
    //   694: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   697: pop
    //   698: aload_0
    //   699: aload #14
    //   701: invokevirtual toString : ()Ljava/lang/String;
    //   704: putfield zza : Ljava/lang/String;
    //   707: aload_2
    //   708: arraylength
    //   709: istore #7
    //   711: iload #7
    //   713: iconst_1
    //   714: if_icmple -> 764
    //   717: aload_0
    //   718: iload #7
    //   720: anewarray com/google/android/gms/ads/internal/client/zzq
    //   723: putfield zzg : [Lcom/google/android/gms/ads/internal/client/zzq;
    //   726: iconst_0
    //   727: istore #7
    //   729: iload #7
    //   731: aload_2
    //   732: arraylength
    //   733: if_icmpge -> 769
    //   736: aload_0
    //   737: getfield zzg : [Lcom/google/android/gms/ads/internal/client/zzq;
    //   740: iload #7
    //   742: new com/google/android/gms/ads/internal/client/zzq
    //   745: dup
    //   746: aload_1
    //   747: aload_2
    //   748: iload #7
    //   750: aaload
    //   751: invokespecial <init> : (Landroid/content/Context;Lcom/google/android/gms/ads/AdSize;)V
    //   754: aastore
    //   755: iload #7
    //   757: iconst_1
    //   758: iadd
    //   759: istore #7
    //   761: goto -> 729
    //   764: aload_0
    //   765: aconst_null
    //   766: putfield zzg : [Lcom/google/android/gms/ads/internal/client/zzq;
    //   769: aload_0
    //   770: iconst_0
    //   771: putfield zzh : Z
    //   774: aload_0
    //   775: iconst_0
    //   776: putfield zzj : Z
    //   779: return
  }
  
  zzq(String paramString, int paramInt1, int paramInt2, boolean paramBoolean1, int paramInt3, int paramInt4, zzq[] paramArrayOfzzq, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, boolean paramBoolean6, boolean paramBoolean7, boolean paramBoolean8, boolean paramBoolean9) {
    this.zza = paramString;
    this.zzb = paramInt1;
    this.zzc = paramInt2;
    this.zzd = paramBoolean1;
    this.zze = paramInt3;
    this.zzf = paramInt4;
    this.zzg = paramArrayOfzzq;
    this.zzh = paramBoolean2;
    this.zzi = paramBoolean3;
    this.zzj = paramBoolean4;
    this.zzk = paramBoolean5;
    this.zzl = paramBoolean6;
    this.zzm = paramBoolean7;
    this.zzn = paramBoolean8;
    this.zzo = paramBoolean9;
  }
  
  public static int zza(DisplayMetrics paramDisplayMetrics) {
    return (int)(zzf(paramDisplayMetrics) * paramDisplayMetrics.density);
  }
  
  public static zzq zzb() {
    return new zzq("interstitial_mb", 0, 0, false, 0, 0, null, false, false, false, false, true, false, false, false);
  }
  
  public static zzq zzc() {
    return new zzq("320x50_mb", 0, 0, false, 0, 0, null, true, false, false, false, false, false, false, false);
  }
  
  public static zzq zzd() {
    return new zzq("reward_mb", 0, 0, true, 0, 0, null, false, false, false, false, false, false, false, false);
  }
  
  public static zzq zze() {
    return new zzq("invalid", 0, 0, false, 0, 0, null, false, false, false, true, false, false, false, false);
  }
  
  private static int zzf(DisplayMetrics paramDisplayMetrics) {
    int i = (int)(paramDisplayMetrics.heightPixels / paramDisplayMetrics.density);
    return (i <= 400) ? 32 : ((i <= 720) ? 50 : 90);
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = SafeParcelWriter.beginObjectHeader(paramParcel);
    SafeParcelWriter.writeString(paramParcel, 2, this.zza, false);
    SafeParcelWriter.writeInt(paramParcel, 3, this.zzb);
    SafeParcelWriter.writeInt(paramParcel, 4, this.zzc);
    SafeParcelWriter.writeBoolean(paramParcel, 5, this.zzd);
    SafeParcelWriter.writeInt(paramParcel, 6, this.zze);
    SafeParcelWriter.writeInt(paramParcel, 7, this.zzf);
    SafeParcelWriter.writeTypedArray(paramParcel, 8, (Parcelable[])this.zzg, paramInt, false);
    SafeParcelWriter.writeBoolean(paramParcel, 9, this.zzh);
    SafeParcelWriter.writeBoolean(paramParcel, 10, this.zzi);
    SafeParcelWriter.writeBoolean(paramParcel, 11, this.zzj);
    SafeParcelWriter.writeBoolean(paramParcel, 12, this.zzk);
    SafeParcelWriter.writeBoolean(paramParcel, 13, this.zzl);
    SafeParcelWriter.writeBoolean(paramParcel, 14, this.zzm);
    SafeParcelWriter.writeBoolean(paramParcel, 15, this.zzn);
    SafeParcelWriter.writeBoolean(paramParcel, 16, this.zzo);
    SafeParcelWriter.finishObjectHeader(paramParcel, i);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */