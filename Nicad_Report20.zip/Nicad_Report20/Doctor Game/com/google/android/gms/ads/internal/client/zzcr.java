package com.google.android.gms.ads.internal.client;

import com.google.android.gms.ads.MuteThisAdListener;

public final class zzcr extends zzcp {
  private final MuteThisAdListener zza;
  
  public zzcr(MuteThisAdListener paramMuteThisAdListener) {
    this.zza = paramMuteThisAdListener;
  }
  
  public final void zze() {
    this.zza.onAdMuted();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzcr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */