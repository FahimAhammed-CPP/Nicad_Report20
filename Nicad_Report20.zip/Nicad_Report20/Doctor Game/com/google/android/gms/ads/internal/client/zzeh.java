package com.google.android.gms.ads.internal.client;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelWriter;

public final class zzeh extends AbstractSafeParcelable {
  public static final Parcelable.Creator<zzeh> CREATOR = new zzei();
  
  private final int zza;
  
  private final int zzb;
  
  private final String zzc;
  
  public zzeh() {
    this(223104600, 223104000, "21.3.0");
  }
  
  public zzeh(int paramInt1, int paramInt2, String paramString) {
    this.zza = paramInt1;
    this.zzb = paramInt2;
    this.zzc = paramString;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = SafeParcelWriter.beginObjectHeader(paramParcel);
    SafeParcelWriter.writeInt(paramParcel, 1, this.zza);
    SafeParcelWriter.writeInt(paramParcel, 2, this.zzb);
    SafeParcelWriter.writeString(paramParcel, 3, this.zzc, false);
    SafeParcelWriter.finishObjectHeader(paramParcel, paramInt);
  }
  
  public final int zza() {
    return this.zzb;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzeh.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */