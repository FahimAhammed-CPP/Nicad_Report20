package com.google.android.gms.ads.nonagon.signalgeneration;

import com.google.android.gms.internal.ads.zzbez;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public final class zzae {
  private final String zza;
  
  public final zzbez zza() {
    byte b;
    String str = this.zza;
    switch (str.hashCode()) {
      default:
        b = -1;
        break;
      case 1951953708:
        if (str.equals("BANNER")) {
          b = 0;
          break;
        } 
      case 543046670:
        if (str.equals("REWARDED")) {
          b = 3;
          break;
        } 
      case -1372958932:
        if (str.equals("INTERSTITIAL")) {
          b = 1;
          break;
        } 
      case -1999289321:
        if (str.equals("NATIVE")) {
          b = 2;
          break;
        } 
    } 
    return (b != 0) ? ((b != 1) ? ((b != 2) ? ((b != 3) ? zzbez.zza : zzbez.zzh) : zzbez.zzg) : zzbez.zzd) : zzbez.zzb;
  }
  
  public final String zzb() {
    return this.zza.toLowerCase(Locale.ROOT);
  }
  
  public final Set zzc() {
    HashSet<String> hashSet = new HashSet();
    hashSet.add(this.zza.toLowerCase(Locale.ROOT));
    return hashSet;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\nonagon\signalgeneration\zzae.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */