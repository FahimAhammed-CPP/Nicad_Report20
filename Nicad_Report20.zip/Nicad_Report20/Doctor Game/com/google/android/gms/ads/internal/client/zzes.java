package com.google.android.gms.ads.internal.client;

import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.internal.ads.zzbrx;
import com.google.android.gms.internal.ads.zzbvk;
import com.google.android.gms.internal.ads.zzcgi;
import com.google.android.gms.internal.ads.zzcgp;
import java.util.Collections;
import java.util.List;

public final class zzes extends zzcl {
  private zzbrx zza;
  
  public final float zze() throws RemoteException {
    return 1.0F;
  }
  
  public final String zzf() {
    return "";
  }
  
  public final List zzg() throws RemoteException {
    return Collections.emptyList();
  }
  
  public final void zzh(String paramString) throws RemoteException {}
  
  public final void zzi() {}
  
  public final void zzj() throws RemoteException {
    zzcgp.zzg("The initialization is not processed because MobileAdsSettingsManager is not created successfully.");
    zzcgi.zza.post(new zzer(this));
  }
  
  public final void zzk(String paramString, IObjectWrapper paramIObjectWrapper) throws RemoteException {}
  
  public final void zzl(zzcy paramzzcy) {}
  
  public final void zzm(IObjectWrapper paramIObjectWrapper, String paramString) throws RemoteException {}
  
  public final void zzn(zzbvk paramzzbvk) throws RemoteException {}
  
  public final void zzo(boolean paramBoolean) throws RemoteException {}
  
  public final void zzp(float paramFloat) throws RemoteException {}
  
  public final void zzq(String paramString) throws RemoteException {}
  
  public final void zzr(zzbrx paramzzbrx) throws RemoteException {
    this.zza = paramzzbrx;
  }
  
  public final void zzs(zzez paramzzez) throws RemoteException {}
  
  public final boolean zzt() throws RemoteException {
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */