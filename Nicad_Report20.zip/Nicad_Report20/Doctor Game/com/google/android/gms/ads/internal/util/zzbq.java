package com.google.android.gms.ads.internal.util;

import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.internal.ads.zzasa;
import com.google.android.gms.internal.ads.zzasb;

public abstract class zzbq extends zzasa implements zzbr {
  public zzbq() {
    super("com.google.android.gms.ads.internal.util.IWorkManagerUtil");
  }
  
  protected final boolean zzbI(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2) throws RemoteException {
    if (paramInt1 != 1) {
      if (paramInt1 != 2)
        return false; 
      IObjectWrapper iObjectWrapper1 = IObjectWrapper.Stub.asInterface(paramParcel1.readStrongBinder());
      zzasb.zzc(paramParcel1);
      zze(iObjectWrapper1);
      paramParcel2.writeNoException();
      return true;
    } 
    IObjectWrapper iObjectWrapper = IObjectWrapper.Stub.asInterface(paramParcel1.readStrongBinder());
    String str1 = paramParcel1.readString();
    String str2 = paramParcel1.readString();
    zzasb.zzc(paramParcel1);
    boolean bool = zzf(iObjectWrapper, str1, str2);
    paramParcel2.writeNoException();
    zzasb.zzd(paramParcel2, bool);
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzbq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */