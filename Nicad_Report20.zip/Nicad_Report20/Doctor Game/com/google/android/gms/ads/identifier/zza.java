package com.google.android.gms.ads.identifier;

import android.net.Uri;
import java.util.Map;

final class zza extends Thread {
  zza(AdvertisingIdClient paramAdvertisingIdClient, Map paramMap) {}
  
  public final void run() {
    Map map = this.zza;
    Uri.Builder builder = Uri.parse("https://pagead2.googlesyndication.com/pagead/gen_204?id=gmob-apps").buildUpon();
    for (String str : map.keySet())
      builder.appendQueryParameter(str, (String)map.get(str)); 
    zzc.zza(builder.build().toString());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\identifier\zza.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */