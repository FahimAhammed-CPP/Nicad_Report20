package com.google.android.gms.ads.internal.client;

import com.google.android.gms.internal.ads.zzcgi;
import com.google.android.gms.internal.ads.zzcgv;
import java.util.Random;

public final class zzaw {
  private static final zzaw zza = new zzaw();
  
  private final zzcgi zzb;
  
  private final zzau zzc;
  
  private final String zzd;
  
  private final zzcgv zze;
  
  private final Random zzf;
  
  protected zzaw() {
    this.zzb = zzcgi1;
    this.zzc = zzau1;
    this.zzd = str;
    this.zze = zzcgv1;
    this.zzf = random;
  }
  
  public static zzau zza() {
    return zza.zzc;
  }
  
  public static zzcgi zzb() {
    return zza.zzb;
  }
  
  public static zzcgv zzc() {
    return zza.zze;
  }
  
  public static String zzd() {
    return zza.zzd;
  }
  
  public static Random zze() {
    return zza.zzf;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzaw.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */