package com.google.android.gms.ads.internal.client;

import android.os.IInterface;
import android.os.RemoteException;

public interface zzbc extends IInterface {
  void zzb() throws RemoteException;
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzbc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */