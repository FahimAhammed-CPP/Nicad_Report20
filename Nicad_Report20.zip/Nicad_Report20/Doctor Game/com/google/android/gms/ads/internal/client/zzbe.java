package com.google.android.gms.ads.internal.client;

import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzasa;
import com.google.android.gms.internal.ads.zzasb;

public abstract class zzbe extends zzasa implements zzbf {
  public zzbe() {
    super("com.google.android.gms.ads.internal.client.IAdListener");
  }
  
  protected final boolean zzbI(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2) throws RemoteException {
    zze zze;
    switch (paramInt1) {
      default:
        return false;
      case 8:
        zze = (zze)zzasb.zza(paramParcel1, zze.CREATOR);
        zzasb.zzc(paramParcel1);
        zzf(zze);
        break;
      case 7:
        zzg();
        break;
      case 6:
        zzc();
        break;
      case 5:
        zzj();
        break;
      case 4:
        zzi();
        break;
      case 2:
        paramInt1 = paramParcel1.readInt();
        zzasb.zzc(paramParcel1);
        zze(paramInt1);
        break;
      case 1:
        zzd();
        break;
      case 3:
        break;
    } 
    paramParcel2.writeNoException();
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzbe.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */