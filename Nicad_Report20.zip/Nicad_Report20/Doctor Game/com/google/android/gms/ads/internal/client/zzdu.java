package com.google.android.gms.ads.internal.client;

import android.content.Context;
import android.os.RemoteException;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.OnPaidEventListener;
import com.google.android.gms.ads.ResponseInfo;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.admanager.AppEventListener;
import com.google.android.gms.ads.zzb;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.dynamic.ObjectWrapper;
import com.google.android.gms.internal.ads.zzbce;
import com.google.android.gms.internal.ads.zzbvh;
import com.google.android.gms.internal.ads.zzcgi;
import com.google.android.gms.internal.ads.zzcgp;
import java.util.concurrent.atomic.AtomicBoolean;
import org.checkerframework.checker.initialization.qual.NotOnlyInitialized;

public final class zzdu {
  final zzax zza = new zzdt(this);
  
  private final zzbvh zzb = new zzbvh();
  
  private final zzp zzc;
  
  private final AtomicBoolean zzd;
  
  private final VideoController zze = new VideoController();
  
  private zza zzf;
  
  private AdListener zzg;
  
  private AdSize[] zzh;
  
  private AppEventListener zzi;
  
  private zzbs zzj;
  
  private VideoOptions zzk;
  
  private String zzl;
  
  @NotOnlyInitialized
  private final ViewGroup zzm;
  
  private int zzn;
  
  private boolean zzo;
  
  private OnPaidEventListener zzp;
  
  public zzdu(ViewGroup paramViewGroup) {
    this(paramViewGroup, null, false, zzp.zza, null, 0);
  }
  
  public zzdu(ViewGroup paramViewGroup, int paramInt) {
    this(paramViewGroup, null, false, zzp.zza, null, paramInt);
  }
  
  public zzdu(ViewGroup paramViewGroup, AttributeSet paramAttributeSet, boolean paramBoolean) {
    this(paramViewGroup, paramAttributeSet, paramBoolean, zzp.zza, null, 0);
  }
  
  public zzdu(ViewGroup paramViewGroup, AttributeSet paramAttributeSet, boolean paramBoolean, int paramInt) {
    this(paramViewGroup, paramAttributeSet, paramBoolean, zzp.zza, null, paramInt);
  }
  
  zzdu(ViewGroup paramViewGroup, AttributeSet paramAttributeSet, boolean paramBoolean, zzp paramzzp, zzbs paramzzbs, int paramInt) {
    this.zzm = paramViewGroup;
    this.zzc = paramzzp;
    this.zzj = null;
    this.zzd = new AtomicBoolean(false);
    this.zzn = paramInt;
    if (paramAttributeSet != null) {
      Context context = paramViewGroup.getContext();
      try {
        zzy zzy = new zzy(context, paramAttributeSet);
        this.zzh = zzy.zzb(paramBoolean);
        this.zzl = zzy.zza();
        if (paramViewGroup.isInEditMode()) {
          zzq zzq;
          zzcgi zzcgi = zzaw.zzb();
          AdSize adSize = this.zzh[0];
          paramInt = this.zzn;
          if (adSize.equals(AdSize.INVALID)) {
            zzq = zzq.zze();
          } else {
            zzq = new zzq(context, (AdSize)zzq);
            zzq.zzj = zzD(paramInt);
          } 
          zzcgi.zzl(paramViewGroup, zzq, "Ads by Google");
          return;
        } 
      } catch (IllegalArgumentException illegalArgumentException) {
        zzaw.zzb().zzk(paramViewGroup, new zzq(context, AdSize.BANNER), illegalArgumentException.getMessage(), illegalArgumentException.getMessage());
      } 
    } 
  }
  
  private static zzq zzC(Context paramContext, AdSize[] paramArrayOfAdSize, int paramInt) {
    int j = paramArrayOfAdSize.length;
    for (int i = 0; i < j; i++) {
      if (paramArrayOfAdSize[i].equals(AdSize.INVALID))
        return zzq.zze(); 
    } 
    zzq zzq = new zzq(paramContext, paramArrayOfAdSize);
    zzq.zzj = zzD(paramInt);
    return zzq;
  }
  
  private static boolean zzD(int paramInt) {
    return (paramInt == 1);
  }
  
  public final boolean zzA() {
    try {
      zzbs zzbs1 = this.zzj;
      if (zzbs1 != null)
        return zzbs1.zzY(); 
    } catch (RemoteException remoteException) {
      zzcgp.zzl("#007 Could not call remote method.", (Throwable)remoteException);
    } 
    return false;
  }
  
  public final AdSize[] zzB() {
    return this.zzh;
  }
  
  public final AdListener zza() {
    return this.zzg;
  }
  
  public final AdSize zzb() {
    try {
      zzbs zzbs1 = this.zzj;
      if (zzbs1 != null) {
        zzq zzq = zzbs1.zzg();
        if (zzq != null)
          return zzb.zzc(zzq.zze, zzq.zzb, zzq.zza); 
      } 
    } catch (RemoteException remoteException) {
      zzcgp.zzl("#007 Could not call remote method.", (Throwable)remoteException);
    } 
    AdSize[] arrayOfAdSize = this.zzh;
    return (arrayOfAdSize != null) ? arrayOfAdSize[0] : null;
  }
  
  public final OnPaidEventListener zzc() {
    return this.zzp;
  }
  
  public final ResponseInfo zzd() {
    zzdh zzdh1;
    zzdh zzdh2 = null;
    try {
      zzbs zzbs1 = this.zzj;
      zzdh1 = zzdh2;
      if (zzbs1 != null)
        zzdh1 = zzbs1.zzk(); 
    } catch (RemoteException remoteException) {
      zzcgp.zzl("#007 Could not call remote method.", (Throwable)remoteException);
      zzdh1 = zzdh2;
    } 
    return ResponseInfo.zza(zzdh1);
  }
  
  public final VideoController zzf() {
    return this.zze;
  }
  
  public final VideoOptions zzg() {
    return this.zzk;
  }
  
  public final AppEventListener zzh() {
    return this.zzi;
  }
  
  public final zzdk zzi() {
    zzbs zzbs1 = this.zzj;
    if (zzbs1 != null)
      try {
        return zzbs1.zzl();
      } catch (RemoteException remoteException) {
        zzcgp.zzl("#007 Could not call remote method.", (Throwable)remoteException);
      }  
    return null;
  }
  
  public final String zzj() {
    if (this.zzl == null) {
      zzbs zzbs1 = this.zzj;
      if (zzbs1 != null)
        try {
          this.zzl = zzbs1.zzr();
        } catch (RemoteException remoteException) {
          zzcgp.zzl("#007 Could not call remote method.", (Throwable)remoteException);
        }  
    } 
    return this.zzl;
  }
  
  public final void zzk() {
    try {
      zzbs zzbs1 = this.zzj;
      if (zzbs1 != null)
        zzbs1.zzx(); 
      return;
    } catch (RemoteException remoteException) {
      zzcgp.zzl("#007 Could not call remote method.", (Throwable)remoteException);
      return;
    } 
  }
  
  public final void zzm(zzdr paramzzdr) {
    // Byte code:
    //   0: aload_0
    //   1: getfield zzj : Lcom/google/android/gms/ads/internal/client/zzbs;
    //   4: ifnonnull -> 360
    //   7: aload_0
    //   8: getfield zzh : [Lcom/google/android/gms/ads/AdSize;
    //   11: ifnull -> 349
    //   14: aload_0
    //   15: getfield zzl : Ljava/lang/String;
    //   18: ifnull -> 349
    //   21: aload_0
    //   22: getfield zzm : Landroid/view/ViewGroup;
    //   25: invokevirtual getContext : ()Landroid/content/Context;
    //   28: astore_2
    //   29: aload_2
    //   30: aload_0
    //   31: getfield zzh : [Lcom/google/android/gms/ads/AdSize;
    //   34: aload_0
    //   35: getfield zzn : I
    //   38: invokestatic zzC : (Landroid/content/Context;[Lcom/google/android/gms/ads/AdSize;I)Lcom/google/android/gms/ads/internal/client/zzq;
    //   41: astore_3
    //   42: ldc 'search_v2'
    //   44: aload_3
    //   45: getfield zza : Ljava/lang/String;
    //   48: invokevirtual equals : (Ljava/lang/Object;)Z
    //   51: ifeq -> 82
    //   54: new com/google/android/gms/ads/internal/client/zzaj
    //   57: dup
    //   58: invokestatic zza : ()Lcom/google/android/gms/ads/internal/client/zzau;
    //   61: aload_2
    //   62: aload_3
    //   63: aload_0
    //   64: getfield zzl : Ljava/lang/String;
    //   67: invokespecial <init> : (Lcom/google/android/gms/ads/internal/client/zzau;Landroid/content/Context;Lcom/google/android/gms/ads/internal/client/zzq;Ljava/lang/String;)V
    //   70: aload_2
    //   71: iconst_0
    //   72: invokevirtual zzd : (Landroid/content/Context;Z)Ljava/lang/Object;
    //   75: checkcast com/google/android/gms/ads/internal/client/zzbs
    //   78: astore_2
    //   79: goto -> 111
    //   82: new com/google/android/gms/ads/internal/client/zzah
    //   85: dup
    //   86: invokestatic zza : ()Lcom/google/android/gms/ads/internal/client/zzau;
    //   89: aload_2
    //   90: aload_3
    //   91: aload_0
    //   92: getfield zzl : Ljava/lang/String;
    //   95: aload_0
    //   96: getfield zzb : Lcom/google/android/gms/internal/ads/zzbvh;
    //   99: invokespecial <init> : (Lcom/google/android/gms/ads/internal/client/zzau;Landroid/content/Context;Lcom/google/android/gms/ads/internal/client/zzq;Ljava/lang/String;Lcom/google/android/gms/internal/ads/zzbvk;)V
    //   102: aload_2
    //   103: iconst_0
    //   104: invokevirtual zzd : (Landroid/content/Context;Z)Ljava/lang/Object;
    //   107: checkcast com/google/android/gms/ads/internal/client/zzbs
    //   110: astore_2
    //   111: aload_0
    //   112: aload_2
    //   113: putfield zzj : Lcom/google/android/gms/ads/internal/client/zzbs;
    //   116: aload_2
    //   117: new com/google/android/gms/ads/internal/client/zzg
    //   120: dup
    //   121: aload_0
    //   122: getfield zza : Lcom/google/android/gms/ads/internal/client/zzax;
    //   125: invokespecial <init> : (Lcom/google/android/gms/ads/AdListener;)V
    //   128: invokeinterface zzD : (Lcom/google/android/gms/ads/internal/client/zzbf;)V
    //   133: aload_0
    //   134: getfield zzf : Lcom/google/android/gms/ads/internal/client/zza;
    //   137: astore_2
    //   138: aload_2
    //   139: ifnull -> 159
    //   142: aload_0
    //   143: getfield zzj : Lcom/google/android/gms/ads/internal/client/zzbs;
    //   146: new com/google/android/gms/ads/internal/client/zzb
    //   149: dup
    //   150: aload_2
    //   151: invokespecial <init> : (Lcom/google/android/gms/ads/internal/client/zza;)V
    //   154: invokeinterface zzC : (Lcom/google/android/gms/ads/internal/client/zzbc;)V
    //   159: aload_0
    //   160: getfield zzi : Lcom/google/android/gms/ads/admanager/AppEventListener;
    //   163: astore_2
    //   164: aload_2
    //   165: ifnull -> 185
    //   168: aload_0
    //   169: getfield zzj : Lcom/google/android/gms/ads/internal/client/zzbs;
    //   172: new com/google/android/gms/internal/ads/zzbce
    //   175: dup
    //   176: aload_2
    //   177: invokespecial <init> : (Lcom/google/android/gms/ads/admanager/AppEventListener;)V
    //   180: invokeinterface zzG : (Lcom/google/android/gms/ads/internal/client/zzbz;)V
    //   185: aload_0
    //   186: getfield zzk : Lcom/google/android/gms/ads/VideoOptions;
    //   189: ifnull -> 212
    //   192: aload_0
    //   193: getfield zzj : Lcom/google/android/gms/ads/internal/client/zzbs;
    //   196: new com/google/android/gms/ads/internal/client/zzff
    //   199: dup
    //   200: aload_0
    //   201: getfield zzk : Lcom/google/android/gms/ads/VideoOptions;
    //   204: invokespecial <init> : (Lcom/google/android/gms/ads/VideoOptions;)V
    //   207: invokeinterface zzU : (Lcom/google/android/gms/ads/internal/client/zzff;)V
    //   212: aload_0
    //   213: getfield zzj : Lcom/google/android/gms/ads/internal/client/zzbs;
    //   216: new com/google/android/gms/ads/internal/client/zzey
    //   219: dup
    //   220: aload_0
    //   221: getfield zzp : Lcom/google/android/gms/ads/OnPaidEventListener;
    //   224: invokespecial <init> : (Lcom/google/android/gms/ads/OnPaidEventListener;)V
    //   227: invokeinterface zzP : (Lcom/google/android/gms/ads/internal/client/zzde;)V
    //   232: aload_0
    //   233: getfield zzj : Lcom/google/android/gms/ads/internal/client/zzbs;
    //   236: aload_0
    //   237: getfield zzo : Z
    //   240: invokeinterface zzN : (Z)V
    //   245: aload_0
    //   246: getfield zzj : Lcom/google/android/gms/ads/internal/client/zzbs;
    //   249: astore_2
    //   250: aload_2
    //   251: ifnonnull -> 257
    //   254: goto -> 360
    //   257: aload_2
    //   258: invokeinterface zzn : ()Lcom/google/android/gms/dynamic/IObjectWrapper;
    //   263: astore_2
    //   264: aload_2
    //   265: ifnull -> 360
    //   268: getstatic com/google/android/gms/internal/ads/zzbkq.zzf : Lcom/google/android/gms/internal/ads/zzbke;
    //   271: invokevirtual zze : ()Ljava/lang/Object;
    //   274: checkcast java/lang/Boolean
    //   277: invokevirtual booleanValue : ()Z
    //   280: ifeq -> 322
    //   283: getstatic com/google/android/gms/internal/ads/zzbjc.zziM : Lcom/google/android/gms/internal/ads/zzbiu;
    //   286: astore_3
    //   287: invokestatic zzc : ()Lcom/google/android/gms/internal/ads/zzbja;
    //   290: aload_3
    //   291: invokevirtual zzb : (Lcom/google/android/gms/internal/ads/zzbiu;)Ljava/lang/Object;
    //   294: checkcast java/lang/Boolean
    //   297: invokevirtual booleanValue : ()Z
    //   300: ifeq -> 322
    //   303: getstatic com/google/android/gms/internal/ads/zzcgi.zza : Landroid/os/Handler;
    //   306: new com/google/android/gms/ads/internal/client/zzds
    //   309: dup
    //   310: aload_0
    //   311: aload_2
    //   312: invokespecial <init> : (Lcom/google/android/gms/ads/internal/client/zzdu;Lcom/google/android/gms/dynamic/IObjectWrapper;)V
    //   315: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   318: pop
    //   319: goto -> 360
    //   322: aload_0
    //   323: getfield zzm : Landroid/view/ViewGroup;
    //   326: aload_2
    //   327: invokestatic unwrap : (Lcom/google/android/gms/dynamic/IObjectWrapper;)Ljava/lang/Object;
    //   330: checkcast android/view/View
    //   333: invokevirtual addView : (Landroid/view/View;)V
    //   336: goto -> 360
    //   339: astore_2
    //   340: ldc '#007 Could not call remote method.'
    //   342: aload_2
    //   343: invokestatic zzl : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   346: goto -> 360
    //   349: new java/lang/IllegalStateException
    //   352: dup
    //   353: ldc_w 'The ad size and ad unit ID must be set before loadAd is called.'
    //   356: invokespecial <init> : (Ljava/lang/String;)V
    //   359: athrow
    //   360: aload_0
    //   361: getfield zzj : Lcom/google/android/gms/ads/internal/client/zzbs;
    //   364: astore_2
    //   365: aload_2
    //   366: ifnull -> 392
    //   369: aload_2
    //   370: aload_0
    //   371: getfield zzc : Lcom/google/android/gms/ads/internal/client/zzp;
    //   374: aload_0
    //   375: getfield zzm : Landroid/view/ViewGroup;
    //   378: invokevirtual getContext : ()Landroid/content/Context;
    //   381: aload_1
    //   382: invokevirtual zza : (Landroid/content/Context;Lcom/google/android/gms/ads/internal/client/zzdr;)Lcom/google/android/gms/ads/internal/client/zzl;
    //   385: invokeinterface zzaa : (Lcom/google/android/gms/ads/internal/client/zzl;)Z
    //   390: pop
    //   391: return
    //   392: aconst_null
    //   393: athrow
    //   394: astore_1
    //   395: ldc '#007 Could not call remote method.'
    //   397: aload_1
    //   398: invokestatic zzl : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   401: return
    // Exception table:
    //   from	to	target	type
    //   0	79	394	android/os/RemoteException
    //   82	111	394	android/os/RemoteException
    //   111	138	394	android/os/RemoteException
    //   142	159	394	android/os/RemoteException
    //   159	164	394	android/os/RemoteException
    //   168	185	394	android/os/RemoteException
    //   185	212	394	android/os/RemoteException
    //   212	250	394	android/os/RemoteException
    //   257	264	339	android/os/RemoteException
    //   268	319	339	android/os/RemoteException
    //   322	336	339	android/os/RemoteException
    //   340	346	394	android/os/RemoteException
    //   349	360	394	android/os/RemoteException
    //   360	365	394	android/os/RemoteException
    //   369	391	394	android/os/RemoteException
    //   392	394	394	android/os/RemoteException
  }
  
  public final void zzn() {
    try {
      zzbs zzbs1 = this.zzj;
      if (zzbs1 != null)
        zzbs1.zzz(); 
      return;
    } catch (RemoteException remoteException) {
      zzcgp.zzl("#007 Could not call remote method.", (Throwable)remoteException);
      return;
    } 
  }
  
  public final void zzo() {
    if (this.zzd.getAndSet(true))
      return; 
    try {
      zzbs zzbs1 = this.zzj;
      if (zzbs1 != null)
        zzbs1.zzA(); 
      return;
    } catch (RemoteException remoteException) {
      zzcgp.zzl("#007 Could not call remote method.", (Throwable)remoteException);
      return;
    } 
  }
  
  public final void zzp() {
    try {
      zzbs zzbs1 = this.zzj;
      if (zzbs1 != null)
        zzbs1.zzB(); 
      return;
    } catch (RemoteException remoteException) {
      zzcgp.zzl("#007 Could not call remote method.", (Throwable)remoteException);
      return;
    } 
  }
  
  public final void zzq(zza paramzza) {
    try {
      this.zzf = paramzza;
      zzbs zzbs1 = this.zzj;
      if (zzbs1 != null) {
        if (paramzza != null) {
          zzb zzb = new zzb(paramzza);
        } else {
          paramzza = null;
        } 
        zzbs1.zzC((zzbc)paramzza);
      } 
      return;
    } catch (RemoteException remoteException) {
      zzcgp.zzl("#007 Could not call remote method.", (Throwable)remoteException);
      return;
    } 
  }
  
  public final void zzr(AdListener paramAdListener) {
    this.zzg = paramAdListener;
    this.zza.zza(paramAdListener);
  }
  
  public final void zzs(AdSize... paramVarArgs) {
    if (this.zzh == null) {
      zzt(paramVarArgs);
      return;
    } 
    throw new IllegalStateException("The ad size can only be set once on AdView.");
  }
  
  public final void zzt(AdSize... paramVarArgs) {
    this.zzh = paramVarArgs;
    try {
      zzbs zzbs1 = this.zzj;
      if (zzbs1 != null)
        zzbs1.zzF(zzC(this.zzm.getContext(), this.zzh, this.zzn)); 
    } catch (RemoteException remoteException) {
      zzcgp.zzl("#007 Could not call remote method.", (Throwable)remoteException);
    } 
    this.zzm.requestLayout();
  }
  
  public final void zzu(String paramString) {
    if (this.zzl == null) {
      this.zzl = paramString;
      return;
    } 
    throw new IllegalStateException("The ad unit ID can only be set once on AdView.");
  }
  
  public final void zzv(AppEventListener paramAppEventListener) {
    try {
      this.zzi = paramAppEventListener;
      zzbs zzbs1 = this.zzj;
      if (zzbs1 != null) {
        if (paramAppEventListener != null) {
          zzbce zzbce = new zzbce(paramAppEventListener);
        } else {
          paramAppEventListener = null;
        } 
        zzbs1.zzG((zzbz)paramAppEventListener);
      } 
      return;
    } catch (RemoteException remoteException) {
      zzcgp.zzl("#007 Could not call remote method.", (Throwable)remoteException);
      return;
    } 
  }
  
  public final void zzw(boolean paramBoolean) {
    this.zzo = paramBoolean;
    try {
      zzbs zzbs1 = this.zzj;
      if (zzbs1 != null)
        zzbs1.zzN(paramBoolean); 
      return;
    } catch (RemoteException remoteException) {
      zzcgp.zzl("#007 Could not call remote method.", (Throwable)remoteException);
      return;
    } 
  }
  
  public final void zzx(OnPaidEventListener paramOnPaidEventListener) {
    try {
      this.zzp = paramOnPaidEventListener;
      zzbs zzbs1 = this.zzj;
      if (zzbs1 != null)
        zzbs1.zzP(new zzey(paramOnPaidEventListener)); 
      return;
    } catch (RemoteException remoteException) {
      zzcgp.zzl("#007 Could not call remote method.", (Throwable)remoteException);
      return;
    } 
  }
  
  public final void zzy(VideoOptions paramVideoOptions) {
    this.zzk = paramVideoOptions;
    try {
      zzbs zzbs1 = this.zzj;
      if (zzbs1 != null) {
        zzff zzff;
        if (paramVideoOptions == null) {
          paramVideoOptions = null;
        } else {
          zzff = new zzff(paramVideoOptions);
        } 
        zzbs1.zzU(zzff);
      } 
      return;
    } catch (RemoteException remoteException) {
      zzcgp.zzl("#007 Could not call remote method.", (Throwable)remoteException);
      return;
    } 
  }
  
  public final boolean zzz(zzbs paramzzbs) {
    try {
      IObjectWrapper iObjectWrapper = paramzzbs.zzn();
      if (iObjectWrapper == null)
        return false; 
      if (((View)ObjectWrapper.unwrap(iObjectWrapper)).getParent() != null)
        return false; 
      this.zzm.addView((View)ObjectWrapper.unwrap(iObjectWrapper));
      this.zzj = paramzzbs;
      return true;
    } catch (RemoteException remoteException) {
      zzcgp.zzl("#007 Could not call remote method.", (Throwable)remoteException);
      return false;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzdu.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */