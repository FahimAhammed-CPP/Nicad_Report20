package com.google.android.gms.ads.internal.util;

import android.content.DialogInterface;
import android.net.Uri;
import com.google.android.gms.ads.internal.zzt;

final class zzau implements DialogInterface.OnClickListener {
  zzau(zzav paramzzav) {}
  
  public final void onClick(DialogInterface paramDialogInterface, int paramInt) {
    zzt.zzp();
    zzs.zzQ(this.zza.zza, Uri.parse("https://support.google.com/dfp_premium/answer/7160685#push"));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzau.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */