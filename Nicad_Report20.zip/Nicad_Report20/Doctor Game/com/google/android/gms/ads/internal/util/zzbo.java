package com.google.android.gms.ads.internal.util;

import android.content.Context;
import com.google.android.gms.internal.ads.zzajl;
import com.google.android.gms.internal.ads.zzakd;
import com.google.android.gms.internal.ads.zzakg;
import com.google.android.gms.internal.ads.zzcgo;
import com.google.android.gms.internal.ads.zzchh;
import com.google.android.gms.internal.ads.zzfzp;
import java.util.Map;
import javax.annotation.ParametersAreNonnullByDefault;

@ParametersAreNonnullByDefault
public final class zzbo {
  @Deprecated
  public static final zzbj zza;
  
  private static zzakg zzb;
  
  private static final Object zzc = new Object();
  
  static {
    zza = new zzbg();
  }
  
  public zzbo(Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_1
    //   5: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   8: ifnonnull -> 14
    //   11: goto -> 19
    //   14: aload_1
    //   15: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   18: astore_1
    //   19: getstatic com/google/android/gms/ads/internal/util/zzbo.zzc : Ljava/lang/Object;
    //   22: astore_2
    //   23: aload_2
    //   24: monitorenter
    //   25: getstatic com/google/android/gms/ads/internal/util/zzbo.zzb : Lcom/google/android/gms/internal/ads/zzakg;
    //   28: ifnonnull -> 79
    //   31: aload_1
    //   32: invokestatic zzc : (Landroid/content/Context;)V
    //   35: invokestatic isPackageSide : ()Z
    //   38: ifne -> 69
    //   41: getstatic com/google/android/gms/internal/ads/zzbjc.zzdC : Lcom/google/android/gms/internal/ads/zzbiu;
    //   44: astore_3
    //   45: invokestatic zzc : ()Lcom/google/android/gms/internal/ads/zzbja;
    //   48: aload_3
    //   49: invokevirtual zzb : (Lcom/google/android/gms/internal/ads/zzbiu;)Ljava/lang/Object;
    //   52: checkcast java/lang/Boolean
    //   55: invokevirtual booleanValue : ()Z
    //   58: ifeq -> 69
    //   61: aload_1
    //   62: invokestatic zzb : (Landroid/content/Context;)Lcom/google/android/gms/internal/ads/zzakg;
    //   65: astore_1
    //   66: goto -> 75
    //   69: aload_1
    //   70: aconst_null
    //   71: invokestatic zza : (Landroid/content/Context;Lcom/google/android/gms/internal/ads/zzakr;)Lcom/google/android/gms/internal/ads/zzakg;
    //   74: astore_1
    //   75: aload_1
    //   76: putstatic com/google/android/gms/ads/internal/util/zzbo.zzb : Lcom/google/android/gms/internal/ads/zzakg;
    //   79: aload_2
    //   80: monitorexit
    //   81: return
    //   82: astore_1
    //   83: aload_2
    //   84: monitorexit
    //   85: aload_1
    //   86: athrow
    // Exception table:
    //   from	to	target	type
    //   25	66	82	finally
    //   69	75	82	finally
    //   75	79	82	finally
    //   79	81	82	finally
    //   83	85	82	finally
  }
  
  public final zzfzp zza(String paramString) {
    zzchh zzchh = new zzchh();
    zzb.zza(new zzbn(paramString, null, zzchh));
    return (zzfzp)zzchh;
  }
  
  public final zzfzp zzb(int paramInt, String paramString, Map paramMap, byte[] paramArrayOfbyte) {
    zzbl zzbl = new zzbl(null);
    zzbh zzbh = new zzbh(this, paramString, zzbl);
    zzcgo zzcgo = new zzcgo(null);
    zzbi zzbi = new zzbi(this, paramInt, paramString, zzbl, zzbh, paramArrayOfbyte, paramMap, zzcgo);
    if (zzcgo.zzl())
      try {
        zzcgo.zzd(paramString, "GET", zzbi.zzl(), zzbi.zzx());
      } catch (zzajl zzajl) {
        zze.zzj(zzajl.getMessage());
      }  
    zzb.zza((zzakd)zzbi);
    return (zzfzp)zzbl;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzbo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */