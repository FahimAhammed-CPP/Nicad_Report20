package com.google.android.gms.ads.internal.util;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.client.zzcy;
import com.google.android.gms.ads.internal.zzt;
import com.google.android.gms.common.util.IOUtils;
import com.google.android.gms.internal.ads.zzbiu;
import com.google.android.gms.internal.ads.zzbjc;
import com.google.android.gms.internal.ads.zzeaj;
import com.google.android.gms.internal.ads.zzeak;
import com.google.android.gms.internal.ads.zzfzp;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import org.json.JSONException;
import org.json.JSONObject;

public final class zzaw {
  protected String zza = "";
  
  private final Object zzb = new Object();
  
  private String zzc = "";
  
  private String zzd = "";
  
  private boolean zze = false;
  
  private boolean zzf = false;
  
  private zzeak zzg;
  
  protected static final String zzo(Context paramContext, String paramString1, String paramString2) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.put("User-Agent", zzt.zzp().zzc(paramContext, paramString2));
    zzfzp zzfzp = (new zzbo(paramContext)).zzb(0, paramString1, hashMap, null);
    try {
      zzbiu zzbiu = zzbjc.zzdT;
      return (String)zzfzp.get(((Integer)zzay.zzc().zzb(zzbiu)).intValue(), TimeUnit.MILLISECONDS);
    } catch (TimeoutException timeoutException) {
      zze.zzh("Timeout while retrieving a response from: ".concat(String.valueOf(paramString1)), timeoutException);
      zzfzp.cancel(true);
      return null;
    } catch (InterruptedException interruptedException) {
      zze.zzh("Interrupted while retrieving a response from: ".concat(String.valueOf(paramString1)), interruptedException);
      zzfzp.cancel(true);
      return null;
    } catch (Exception exception) {
      zze.zzh("Error retrieving a response from: ".concat(String.valueOf(paramString1)), exception);
      return null;
    } 
  }
  
  private final Uri zzp(Context paramContext, String paramString1, String paramString2, String paramString3) {
    Uri.Builder builder = Uri.parse(paramString1).buildUpon();
    synchronized (this.zzb) {
      if (TextUtils.isEmpty(this.zzc)) {
        String str1;
        zzt.zzp();
        try {
          paramString1 = new String(IOUtils.readInputStreamFully(paramContext.openFileInput("debug_signals_id.txt"), true), "UTF-8");
        } catch (IOException iOException) {
          zze.zze("Error reading from internal storage.");
          str1 = "";
        } 
        this.zzc = str1;
        if (TextUtils.isEmpty(str1)) {
          zzt.zzp();
          this.zzc = UUID.randomUUID().toString();
          zzt.zzp();
          str1 = this.zzc;
          try {
            FileOutputStream fileOutputStream = paramContext.openFileOutput("debug_signals_id.txt", 0);
            fileOutputStream.write(str1.getBytes("UTF-8"));
            fileOutputStream.close();
          } catch (Exception exception) {
            zze.zzh("Error writing to file in internal storage.", exception);
          } 
        } 
      } 
      String str = this.zzc;
      builder.appendQueryParameter("linkedDeviceId", str);
      builder.appendQueryParameter("adSlotPath", paramString2);
      builder.appendQueryParameter("afmaVersion", paramString3);
      return builder.build();
    } 
  }
  
  public final zzeak zza() {
    return this.zzg;
  }
  
  public final String zzb() {
    synchronized (this.zzb) {
      return this.zzd;
    } 
  }
  
  public final void zzc(Context paramContext) {
    zzbiu zzbiu = zzbjc.zzhT;
    if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue()) {
      zzeak zzeak1 = this.zzg;
      if (zzeak1 == null)
        return; 
      zzeak1.zzh((zzcy)new zzat(this, paramContext), zzeaj.zzd);
    } 
  }
  
  public final void zzd(Context paramContext, String paramString1, String paramString2) {
    zzt.zzp();
    zzbiu zzbiu = zzbjc.zzdP;
    zzs.zzQ(paramContext, zzp(paramContext, (String)zzay.zzc().zzb(zzbiu), paramString1, paramString2));
  }
  
  public final void zze(Context paramContext, String paramString1, String paramString2, String paramString3) {
    zzbiu zzbiu = zzbjc.zzdS;
    Uri.Builder builder = zzp(paramContext, (String)zzay.zzc().zzb(zzbiu), paramString3, paramString1).buildUpon();
    builder.appendQueryParameter("debugData", paramString2);
    zzt.zzp();
    zzs.zzH(paramContext, paramString1, builder.build().toString());
  }
  
  public final void zzf(boolean paramBoolean) {
    synchronized (this.zzb) {
      this.zzf = paramBoolean;
      zzbiu zzbiu = zzbjc.zzhT;
      if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue()) {
        zzt.zzo().zzh().zzB(paramBoolean);
        zzeak zzeak1 = this.zzg;
        if (zzeak1 != null)
          zzeak1.zzj(paramBoolean); 
      } 
      return;
    } 
  }
  
  public final void zzg(zzeak paramzzeak) {
    this.zzg = paramzzeak;
  }
  
  public final void zzh(boolean paramBoolean) {
    synchronized (this.zzb) {
      this.zze = paramBoolean;
      return;
    } 
  }
  
  protected final void zzi(Context paramContext, String paramString, boolean paramBoolean1, boolean paramBoolean2) {
    if (!(paramContext instanceof android.app.Activity)) {
      zze.zzi("Can not create dialog without Activity Context");
      return;
    } 
    zzs.zza.post(new zzav(this, paramContext, paramString, paramBoolean1, paramBoolean2));
  }
  
  public final boolean zzj(Context paramContext, String paramString1, String paramString2) {
    zzbiu zzbiu = zzbjc.zzdR;
    String str = zzo(paramContext, zzp(paramContext, (String)zzay.zzc().zzb(zzbiu), paramString1, paramString2).toString(), paramString2);
    if (TextUtils.isEmpty(str)) {
      zze.zze("Not linked for debug signals.");
      return false;
    } 
    str = str.trim();
    try {
      str = (new JSONObject(str)).optString("debug_mode");
      boolean bool = "1".equals(str);
      zzf(bool);
      zzbiu zzbiu1 = zzbjc.zzhT;
      if (((Boolean)zzay.zzc().zzb(zzbiu1)).booleanValue()) {
        zzg zzg = zzt.zzo().zzh();
        if (true != bool)
          paramString1 = ""; 
        zzg.zzA(paramString1);
      } 
      return bool;
    } catch (JSONException jSONException) {
      zze.zzk("Fail to get debug mode response json.", (Throwable)jSONException);
      return false;
    } 
  }
  
  final boolean zzk(Context paramContext, String paramString1, String paramString2) {
    zzbiu zzbiu = zzbjc.zzdQ;
    String str = zzo(paramContext, zzp(paramContext, (String)zzay.zzc().zzb(zzbiu), paramString1, paramString2).toString(), paramString2);
    if (TextUtils.isEmpty(str)) {
      zze.zze("Not linked for in app preview.");
      return false;
    } 
    str = str.trim();
    try {
      JSONObject jSONObject = new JSONObject(str);
      str = jSONObject.optString("gct");
      this.zza = jSONObject.optString("status");
      zzbiu zzbiu1 = zzbjc.zzhT;
      if (((Boolean)zzay.zzc().zzb(zzbiu1)).booleanValue()) {
        boolean bool;
        if ("0".equals(this.zza) || "2".equals(this.zza)) {
          bool = true;
        } else {
          bool = false;
        } 
        zzf(bool);
        zzg zzg = zzt.zzo().zzh();
        if (true != bool)
          paramString1 = ""; 
        zzg.zzA(paramString1);
      } 
      synchronized (this.zzb) {
        this.zzd = str;
        return true;
      } 
    } catch (JSONException jSONException) {
      zze.zzk("Fail to get in app preview response json.", (Throwable)jSONException);
      return false;
    } 
  }
  
  public final boolean zzl() {
    synchronized (this.zzb) {
      return this.zzf;
    } 
  }
  
  public final boolean zzm() {
    synchronized (this.zzb) {
      return this.zze;
    } 
  }
  
  public final boolean zzn(Context paramContext, String paramString1, String paramString2, String paramString3) {
    if (TextUtils.isEmpty(paramString2) || !zzm())
      return false; 
    zze.zze("Sending troubleshooting signals to the server.");
    zze(paramContext, paramString1, paramString2, paramString3);
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzaw.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */