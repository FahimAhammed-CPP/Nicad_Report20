package com.google.android.gms.ads.internal.client;

import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.gms.dynamite.DynamiteModule;
import com.google.android.gms.internal.ads.zzbjc;
import com.google.android.gms.internal.ads.zzbkn;
import com.google.android.gms.internal.ads.zzbla;
import com.google.android.gms.internal.ads.zzcgi;
import com.google.android.gms.internal.ads.zzcgp;

abstract class zzav {
  private static final zzcc zza;
  
  static {
    zzcc zzcc1 = null;
    try {
      IBinder iBinder = (IBinder)zzau.class.getClassLoader().loadClass("com.google.android.gms.ads.internal.ClientApi").getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
      if (!(iBinder instanceof IBinder)) {
        zzcgp.zzj("ClientApi class is not an instance of IBinder.");
      } else {
        iBinder = iBinder;
        if (iBinder != null) {
          zzcc zzcc2;
          IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IClientApi");
          if (iInterface instanceof zzcc) {
            zzcc2 = (zzcc)iInterface;
            zzcc1 = zzcc2;
          } else {
            zzcc2 = new zzca((IBinder)zzcc2);
            zzcc1 = zzcc2;
          } 
        } 
      } 
    } catch (Exception exception) {
      zzcgp.zzj("Failed to instantiate ClientApi class.");
    } 
    zza = zzcc1;
  }
  
  private final Object zze() {
    zzcc zzcc1 = zza;
    if (zzcc1 != null)
      try {
        return zzb(zzcc1);
      } catch (RemoteException remoteException) {
        zzcgp.zzk("Cannot invoke local loader using ClientApi class.", (Throwable)remoteException);
        return null;
      }  
    zzcgp.zzj("ClientApi class cannot be loaded.");
    return null;
  }
  
  private final Object zzf() {
    try {
      return zzc();
    } catch (RemoteException remoteException) {
      zzcgp.zzk("Cannot invoke remote loader.", (Throwable)remoteException);
      return null;
    } 
  }
  
  protected abstract Object zza();
  
  protected abstract Object zzb(zzcc paramzzcc) throws RemoteException;
  
  protected abstract Object zzc() throws RemoteException;
  
  public final Object zzd(Context paramContext, boolean paramBoolean) {
    boolean bool1 = paramBoolean;
    if (!paramBoolean) {
      zzaw.zzb();
      bool1 = paramBoolean;
      if (!zzcgi.zzr(paramContext, 12451000)) {
        zzcgp.zze("Google Play Services is not available.");
        bool1 = true;
      } 
    } 
    int i = DynamiteModule.getLocalVersion(paramContext, "com.google.android.gms.ads.dynamite");
    int j = DynamiteModule.getRemoteVersion(paramContext, "com.google.android.gms.ads.dynamite");
    boolean bool = false;
    if (i > j) {
      i = 0;
    } else {
      i = 1;
    } 
    zzbjc.zzc(paramContext);
    if (((Boolean)zzbkn.zza.zze()).booleanValue()) {
      i = bool;
    } else {
      Object object1;
      if (((Boolean)zzbkn.zzb.zze()).booleanValue()) {
        bool = true;
        i = 1;
      } else {
        i = bool1 | i ^ 0x1;
        bool = false;
      } 
      if (i != 0) {
        Object object = zze();
        object1 = object;
        if (object == null) {
          object1 = object;
          if (!bool)
            object1 = zzf(); 
        } 
      } else {
        Object object = zzf();
        if (object == null) {
          i = ((Long)zzbla.zza.zze()).intValue();
          if (zzaw.zze().nextInt(i) == 0) {
            Bundle bundle = new Bundle();
            bundle.putString("action", "dynamite_load");
            bundle.putInt("is_missing", 1);
            zzaw.zzb().zzm((Context)object1, (zzaw.zzc()).zza, "gmob-apps", bundle, true);
          } 
        } 
        if (object == null) {
          object1 = zze();
        } else {
          object1 = object;
        } 
      } 
      Object object2 = object1;
      if (object1 == null)
        object2 = zza(); 
      return object2;
    } 
    bool = false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzav.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */