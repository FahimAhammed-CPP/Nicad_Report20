package com.google.android.gms.ads.internal.util;

import android.app.AlertDialog;
import android.content.Context;
import com.google.android.gms.ads.internal.zzt;

final class zzav implements Runnable {
  zzav(zzaw paramzzaw, Context paramContext, String paramString, boolean paramBoolean1, boolean paramBoolean2) {}
  
  public final void run() {
    zzt.zzp();
    AlertDialog.Builder builder = zzs.zzG(this.zza);
    builder.setMessage(this.zzb);
    if (this.zzc) {
      builder.setTitle("Error");
    } else {
      builder.setTitle("Info");
    } 
    if (this.zzd) {
      builder.setNeutralButton("Dismiss", null);
    } else {
      builder.setPositiveButton("Learn More", new zzau(this));
      builder.setNegativeButton("Dismiss", null);
    } 
    builder.create().show();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzav.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */