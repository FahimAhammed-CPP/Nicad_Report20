package com.google.android.gms.ads.internal.client;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import com.google.android.gms.ads.h5.OnH5AdsEventListener;
import com.google.android.gms.internal.ads.zzbmi;
import com.google.android.gms.internal.ads.zzbmo;
import com.google.android.gms.internal.ads.zzbod;
import com.google.android.gms.internal.ads.zzboe;
import com.google.android.gms.internal.ads.zzbqu;
import com.google.android.gms.internal.ads.zzbvk;
import com.google.android.gms.internal.ads.zzbyv;
import com.google.android.gms.internal.ads.zzbyz;
import com.google.android.gms.internal.ads.zzbzc;
import com.google.android.gms.internal.ads.zzcah;
import com.google.android.gms.internal.ads.zzccl;
import com.google.android.gms.internal.ads.zzccx;
import com.google.android.gms.internal.ads.zzcfg;
import com.google.android.gms.internal.ads.zzcgp;
import java.util.HashMap;

public final class zzau {
  private final zzk zza;
  
  private final zzi zzb;
  
  private final zzek zzc;
  
  private final zzbod zzd;
  
  private final zzccx zze;
  
  private final zzbyz zzf;
  
  private final zzboe zzg;
  
  private zzcah zzh;
  
  public zzau(zzk paramzzk, zzi paramzzi, zzek paramzzek, zzbod paramzzbod, zzccx paramzzccx, zzbyz paramzzbyz, zzboe paramzzboe) {
    this.zza = paramzzk;
    this.zzb = paramzzi;
    this.zzc = paramzzek;
    this.zzd = paramzzbod;
    this.zze = paramzzccx;
    this.zzf = paramzzbyz;
    this.zzg = paramzzboe;
  }
  
  public final zzbo zzc(Context paramContext, String paramString, zzbvk paramzzbvk) {
    return (zzbo)(new zzam(this, paramContext, paramString, paramzzbvk)).zzd(paramContext, false);
  }
  
  public final zzbs zzd(Context paramContext, zzq paramzzq, String paramString, zzbvk paramzzbvk) {
    return (zzbs)(new zzai(this, paramContext, paramzzq, paramString, paramzzbvk)).zzd(paramContext, false);
  }
  
  public final zzbs zze(Context paramContext, zzq paramzzq, String paramString, zzbvk paramzzbvk) {
    return (zzbs)(new zzak(this, paramContext, paramzzq, paramString, paramzzbvk)).zzd(paramContext, false);
  }
  
  public final zzbmi zzg(Context paramContext, FrameLayout paramFrameLayout1, FrameLayout paramFrameLayout2) {
    return (zzbmi)(new zzaq(this, paramFrameLayout1, paramFrameLayout2, paramContext)).zzd(paramContext, false);
  }
  
  public final zzbmo zzh(View paramView, HashMap paramHashMap1, HashMap paramHashMap2) {
    return (zzbmo)(new zzas(this, paramView, paramHashMap1, paramHashMap2)).zzd(paramView.getContext(), false);
  }
  
  public final zzbqu zzk(Context paramContext, zzbvk paramzzbvk, OnH5AdsEventListener paramOnH5AdsEventListener) {
    return (zzbqu)(new zzag(this, paramContext, paramzzbvk, paramOnH5AdsEventListener)).zzd(paramContext, false);
  }
  
  public final zzbyv zzl(Context paramContext, zzbvk paramzzbvk) {
    return (zzbyv)(new zzae(this, paramContext, paramzzbvk)).zzd(paramContext, false);
  }
  
  public final zzbzc zzn(Activity paramActivity) {
    zzaa zzaa = new zzaa(this, paramActivity);
    Intent intent = paramActivity.getIntent();
    boolean bool2 = intent.hasExtra("com.google.android.gms.ads.internal.overlay.useClientJar");
    boolean bool1 = false;
    if (!bool2) {
      zzcgp.zzg("useClientJar flag not found in activity intent extras.");
    } else {
      bool1 = intent.getBooleanExtra("com.google.android.gms.ads.internal.overlay.useClientJar", false);
    } 
    return (zzbzc)zzaa.zzd((Context)paramActivity, bool1);
  }
  
  public final zzccl zzp(Context paramContext, String paramString, zzbvk paramzzbvk) {
    return (zzccl)(new zzat(this, paramContext, paramString, paramzzbvk)).zzd(paramContext, false);
  }
  
  public final zzcfg zzq(Context paramContext, zzbvk paramzzbvk) {
    return (zzcfg)(new zzac(this, paramContext, paramzzbvk)).zzd(paramContext, false);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzau.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */