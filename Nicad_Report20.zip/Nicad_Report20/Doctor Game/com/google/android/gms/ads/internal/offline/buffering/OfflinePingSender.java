package com.google.android.gms.ads.internal.offline.buffering;

import android.content.Context;
import android.os.RemoteException;
import androidx.work.ListenableWorker;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import com.google.android.gms.ads.internal.client.zzaw;
import com.google.android.gms.internal.ads.zzbvh;
import com.google.android.gms.internal.ads.zzbvk;
import com.google.android.gms.internal.ads.zzbyv;

public class OfflinePingSender extends Worker {
  private final zzbyv zza;
  
  public OfflinePingSender(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
    this.zza = zzaw.zza().zzl(paramContext, (zzbvk)new zzbvh());
  }
  
  public final ListenableWorker.Result doWork() {
    try {
      this.zza.zzf();
      return ListenableWorker.Result.success();
    } catch (RemoteException remoteException) {
      return ListenableWorker.Result.failure();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\offline\buffering\OfflinePingSender.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */