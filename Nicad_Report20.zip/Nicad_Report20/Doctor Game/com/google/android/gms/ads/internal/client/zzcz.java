package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzarz;

public final class zzcz extends zzarz implements zzdb {
  zzcz(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IOnAdMetadataChangedListener");
  }
  
  public final void zze() throws RemoteException {
    zzbl(1, zza());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzcz.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */