package com.google.android.gms.ads.internal.client;

import android.os.RemoteException;

public final class zzef extends zzct {
  private final String zza;
  
  private final String zzb;
  
  public zzef(String paramString1, String paramString2) {
    this.zza = paramString1;
    this.zzb = paramString2;
  }
  
  public final String zze() throws RemoteException {
    return this.zza;
  }
  
  public final String zzf() throws RemoteException {
    return this.zzb;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzef.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */