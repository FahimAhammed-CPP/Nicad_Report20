package com.google.android.gms.ads.internal.overlay;

import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.internal.client.zza;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.util.zzbr;
import com.google.android.gms.ads.internal.zzj;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelWriter;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.dynamic.ObjectWrapper;
import com.google.android.gms.internal.ads.zzbiu;
import com.google.android.gms.internal.ads.zzbjc;
import com.google.android.gms.internal.ads.zzbop;
import com.google.android.gms.internal.ads.zzbor;
import com.google.android.gms.internal.ads.zzcgv;
import com.google.android.gms.internal.ads.zzcmp;
import com.google.android.gms.internal.ads.zzddn;
import com.google.android.gms.internal.ads.zzdkn;
import com.google.android.gms.internal.ads.zzdxq;
import com.google.android.gms.internal.ads.zzego;
import com.google.android.gms.internal.ads.zzfir;

public final class AdOverlayInfoParcel extends AbstractSafeParcelable implements ReflectedParcelable {
  public static final Parcelable.Creator<AdOverlayInfoParcel> CREATOR = new zzn();
  
  public final zzc zza;
  
  public final zza zzb;
  
  public final zzo zzc;
  
  public final zzcmp zzd;
  
  public final zzbor zze;
  
  public final String zzf;
  
  public final boolean zzg;
  
  public final String zzh;
  
  public final zzz zzi;
  
  public final int zzj;
  
  public final int zzk;
  
  public final String zzl;
  
  public final zzcgv zzm;
  
  public final String zzn;
  
  public final zzj zzo;
  
  public final zzbop zzp;
  
  public final String zzq;
  
  public final zzego zzr;
  
  public final zzdxq zzs;
  
  public final zzfir zzt;
  
  public final zzbr zzu;
  
  public final String zzv;
  
  public final String zzw;
  
  public final zzddn zzx;
  
  public final zzdkn zzy;
  
  public AdOverlayInfoParcel(zza paramzza, zzo paramzzo, zzz paramzzz, zzcmp paramzzcmp, int paramInt, zzcgv paramzzcgv, String paramString1, zzj paramzzj, String paramString2, String paramString3, String paramString4, zzddn paramzzddn) {
    this.zza = null;
    this.zzb = null;
    this.zzc = paramzzo;
    this.zzd = paramzzcmp;
    this.zzp = null;
    this.zze = null;
    this.zzg = false;
    zzbiu zzbiu = zzbjc.zzaC;
    if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue()) {
      this.zzf = null;
      this.zzh = null;
    } else {
      this.zzf = paramString2;
      this.zzh = paramString3;
    } 
    this.zzi = null;
    this.zzj = paramInt;
    this.zzk = 1;
    this.zzl = null;
    this.zzm = paramzzcgv;
    this.zzn = paramString1;
    this.zzo = paramzzj;
    this.zzq = null;
    this.zzv = null;
    this.zzr = null;
    this.zzs = null;
    this.zzt = null;
    this.zzu = null;
    this.zzw = paramString4;
    this.zzx = paramzzddn;
    this.zzy = null;
  }
  
  public AdOverlayInfoParcel(zza paramzza, zzo paramzzo, zzz paramzzz, zzcmp paramzzcmp, boolean paramBoolean, int paramInt, zzcgv paramzzcgv, zzdkn paramzzdkn) {
    this.zza = null;
    this.zzb = paramzza;
    this.zzc = paramzzo;
    this.zzd = paramzzcmp;
    this.zzp = null;
    this.zze = null;
    this.zzf = null;
    this.zzg = paramBoolean;
    this.zzh = null;
    this.zzi = paramzzz;
    this.zzj = paramInt;
    this.zzk = 2;
    this.zzl = null;
    this.zzm = paramzzcgv;
    this.zzn = null;
    this.zzo = null;
    this.zzq = null;
    this.zzv = null;
    this.zzr = null;
    this.zzs = null;
    this.zzt = null;
    this.zzu = null;
    this.zzw = null;
    this.zzx = null;
    this.zzy = paramzzdkn;
  }
  
  public AdOverlayInfoParcel(zza paramzza, zzo paramzzo, zzbop paramzzbop, zzbor paramzzbor, zzz paramzzz, zzcmp paramzzcmp, boolean paramBoolean, int paramInt, String paramString, zzcgv paramzzcgv, zzdkn paramzzdkn) {
    this.zza = null;
    this.zzb = paramzza;
    this.zzc = paramzzo;
    this.zzd = paramzzcmp;
    this.zzp = paramzzbop;
    this.zze = paramzzbor;
    this.zzf = null;
    this.zzg = paramBoolean;
    this.zzh = null;
    this.zzi = paramzzz;
    this.zzj = paramInt;
    this.zzk = 3;
    this.zzl = paramString;
    this.zzm = paramzzcgv;
    this.zzn = null;
    this.zzo = null;
    this.zzq = null;
    this.zzv = null;
    this.zzr = null;
    this.zzs = null;
    this.zzt = null;
    this.zzu = null;
    this.zzw = null;
    this.zzx = null;
    this.zzy = paramzzdkn;
  }
  
  public AdOverlayInfoParcel(zza paramzza, zzo paramzzo, zzbop paramzzbop, zzbor paramzzbor, zzz paramzzz, zzcmp paramzzcmp, boolean paramBoolean, int paramInt, String paramString1, String paramString2, zzcgv paramzzcgv, zzdkn paramzzdkn) {
    this.zza = null;
    this.zzb = paramzza;
    this.zzc = paramzzo;
    this.zzd = paramzzcmp;
    this.zzp = paramzzbop;
    this.zze = paramzzbor;
    this.zzf = paramString2;
    this.zzg = paramBoolean;
    this.zzh = paramString1;
    this.zzi = paramzzz;
    this.zzj = paramInt;
    this.zzk = 3;
    this.zzl = null;
    this.zzm = paramzzcgv;
    this.zzn = null;
    this.zzo = null;
    this.zzq = null;
    this.zzv = null;
    this.zzr = null;
    this.zzs = null;
    this.zzt = null;
    this.zzu = null;
    this.zzw = null;
    this.zzx = null;
    this.zzy = paramzzdkn;
  }
  
  AdOverlayInfoParcel(zzc paramzzc, IBinder paramIBinder1, IBinder paramIBinder2, IBinder paramIBinder3, IBinder paramIBinder4, String paramString1, boolean paramBoolean, String paramString2, IBinder paramIBinder5, int paramInt1, int paramInt2, String paramString3, zzcgv paramzzcgv, String paramString4, zzj paramzzj, IBinder paramIBinder6, String paramString5, IBinder paramIBinder7, IBinder paramIBinder8, IBinder paramIBinder9, IBinder paramIBinder10, String paramString6, String paramString7, IBinder paramIBinder11, IBinder paramIBinder12) {
    this.zza = paramzzc;
    this.zzb = (zza)ObjectWrapper.unwrap(IObjectWrapper.Stub.asInterface(paramIBinder1));
    this.zzc = (zzo)ObjectWrapper.unwrap(IObjectWrapper.Stub.asInterface(paramIBinder2));
    this.zzd = (zzcmp)ObjectWrapper.unwrap(IObjectWrapper.Stub.asInterface(paramIBinder3));
    this.zzp = (zzbop)ObjectWrapper.unwrap(IObjectWrapper.Stub.asInterface(paramIBinder6));
    this.zze = (zzbor)ObjectWrapper.unwrap(IObjectWrapper.Stub.asInterface(paramIBinder4));
    this.zzf = paramString1;
    this.zzg = paramBoolean;
    this.zzh = paramString2;
    this.zzi = (zzz)ObjectWrapper.unwrap(IObjectWrapper.Stub.asInterface(paramIBinder5));
    this.zzj = paramInt1;
    this.zzk = paramInt2;
    this.zzl = paramString3;
    this.zzm = paramzzcgv;
    this.zzn = paramString4;
    this.zzo = paramzzj;
    this.zzq = paramString5;
    this.zzv = paramString6;
    this.zzr = (zzego)ObjectWrapper.unwrap(IObjectWrapper.Stub.asInterface(paramIBinder7));
    this.zzs = (zzdxq)ObjectWrapper.unwrap(IObjectWrapper.Stub.asInterface(paramIBinder8));
    this.zzt = (zzfir)ObjectWrapper.unwrap(IObjectWrapper.Stub.asInterface(paramIBinder9));
    this.zzu = (zzbr)ObjectWrapper.unwrap(IObjectWrapper.Stub.asInterface(paramIBinder10));
    this.zzw = paramString7;
    this.zzx = (zzddn)ObjectWrapper.unwrap(IObjectWrapper.Stub.asInterface(paramIBinder11));
    this.zzy = (zzdkn)ObjectWrapper.unwrap(IObjectWrapper.Stub.asInterface(paramIBinder12));
  }
  
  public AdOverlayInfoParcel(zzc paramzzc, zza paramzza, zzo paramzzo, zzz paramzzz, zzcgv paramzzcgv, zzcmp paramzzcmp, zzdkn paramzzdkn) {
    this.zza = paramzzc;
    this.zzb = paramzza;
    this.zzc = paramzzo;
    this.zzd = paramzzcmp;
    this.zzp = null;
    this.zze = null;
    this.zzf = null;
    this.zzg = false;
    this.zzh = null;
    this.zzi = paramzzz;
    this.zzj = -1;
    this.zzk = 4;
    this.zzl = null;
    this.zzm = paramzzcgv;
    this.zzn = null;
    this.zzo = null;
    this.zzq = null;
    this.zzv = null;
    this.zzr = null;
    this.zzs = null;
    this.zzt = null;
    this.zzu = null;
    this.zzw = null;
    this.zzx = null;
    this.zzy = paramzzdkn;
  }
  
  public AdOverlayInfoParcel(zzo paramzzo, zzcmp paramzzcmp, int paramInt, zzcgv paramzzcgv) {
    this.zzc = paramzzo;
    this.zzd = paramzzcmp;
    this.zzj = 1;
    this.zzm = paramzzcgv;
    this.zza = null;
    this.zzb = null;
    this.zzp = null;
    this.zze = null;
    this.zzf = null;
    this.zzg = false;
    this.zzh = null;
    this.zzi = null;
    this.zzk = 1;
    this.zzl = null;
    this.zzn = null;
    this.zzo = null;
    this.zzq = null;
    this.zzv = null;
    this.zzr = null;
    this.zzs = null;
    this.zzt = null;
    this.zzu = null;
    this.zzw = null;
    this.zzx = null;
    this.zzy = null;
  }
  
  public AdOverlayInfoParcel(zzcmp paramzzcmp, zzcgv paramzzcgv, zzbr paramzzbr, zzego paramzzego, zzdxq paramzzdxq, zzfir paramzzfir, String paramString1, String paramString2, int paramInt) {
    this.zza = null;
    this.zzb = null;
    this.zzc = null;
    this.zzd = paramzzcmp;
    this.zzp = null;
    this.zze = null;
    this.zzf = null;
    this.zzg = false;
    this.zzh = null;
    this.zzi = null;
    this.zzj = 14;
    this.zzk = 5;
    this.zzl = null;
    this.zzm = paramzzcgv;
    this.zzn = null;
    this.zzo = null;
    this.zzq = paramString1;
    this.zzv = paramString2;
    this.zzr = paramzzego;
    this.zzs = paramzzdxq;
    this.zzt = paramzzfir;
    this.zzu = paramzzbr;
    this.zzw = null;
    this.zzx = null;
    this.zzy = null;
  }
  
  public static AdOverlayInfoParcel zza(Intent paramIntent) {
    try {
      Bundle bundle = paramIntent.getBundleExtra("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo");
      bundle.setClassLoader(AdOverlayInfoParcel.class.getClassLoader());
      return (AdOverlayInfoParcel)bundle.getParcelable("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo");
    } catch (Exception exception) {
      return null;
    } 
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = SafeParcelWriter.beginObjectHeader(paramParcel);
    SafeParcelWriter.writeParcelable(paramParcel, 2, (Parcelable)this.zza, paramInt, false);
    SafeParcelWriter.writeIBinder(paramParcel, 3, ObjectWrapper.wrap(this.zzb).asBinder(), false);
    SafeParcelWriter.writeIBinder(paramParcel, 4, ObjectWrapper.wrap(this.zzc).asBinder(), false);
    SafeParcelWriter.writeIBinder(paramParcel, 5, ObjectWrapper.wrap(this.zzd).asBinder(), false);
    SafeParcelWriter.writeIBinder(paramParcel, 6, ObjectWrapper.wrap(this.zze).asBinder(), false);
    SafeParcelWriter.writeString(paramParcel, 7, this.zzf, false);
    SafeParcelWriter.writeBoolean(paramParcel, 8, this.zzg);
    SafeParcelWriter.writeString(paramParcel, 9, this.zzh, false);
    SafeParcelWriter.writeIBinder(paramParcel, 10, ObjectWrapper.wrap(this.zzi).asBinder(), false);
    SafeParcelWriter.writeInt(paramParcel, 11, this.zzj);
    SafeParcelWriter.writeInt(paramParcel, 12, this.zzk);
    SafeParcelWriter.writeString(paramParcel, 13, this.zzl, false);
    SafeParcelWriter.writeParcelable(paramParcel, 14, (Parcelable)this.zzm, paramInt, false);
    SafeParcelWriter.writeString(paramParcel, 16, this.zzn, false);
    SafeParcelWriter.writeParcelable(paramParcel, 17, (Parcelable)this.zzo, paramInt, false);
    SafeParcelWriter.writeIBinder(paramParcel, 18, ObjectWrapper.wrap(this.zzp).asBinder(), false);
    SafeParcelWriter.writeString(paramParcel, 19, this.zzq, false);
    SafeParcelWriter.writeIBinder(paramParcel, 20, ObjectWrapper.wrap(this.zzr).asBinder(), false);
    SafeParcelWriter.writeIBinder(paramParcel, 21, ObjectWrapper.wrap(this.zzs).asBinder(), false);
    SafeParcelWriter.writeIBinder(paramParcel, 22, ObjectWrapper.wrap(this.zzt).asBinder(), false);
    SafeParcelWriter.writeIBinder(paramParcel, 23, ObjectWrapper.wrap(this.zzu).asBinder(), false);
    SafeParcelWriter.writeString(paramParcel, 24, this.zzv, false);
    SafeParcelWriter.writeString(paramParcel, 25, this.zzw, false);
    SafeParcelWriter.writeIBinder(paramParcel, 26, ObjectWrapper.wrap(this.zzx).asBinder(), false);
    SafeParcelWriter.writeIBinder(paramParcel, 27, ObjectWrapper.wrap(this.zzy).asBinder(), false);
    SafeParcelWriter.finishObjectHeader(paramParcel, i);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\overlay\AdOverlayInfoParcel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */