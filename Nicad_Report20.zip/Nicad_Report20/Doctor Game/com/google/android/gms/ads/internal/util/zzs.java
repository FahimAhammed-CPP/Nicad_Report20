package com.google.android.gms.ads.internal.util;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.KeyguardManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.PowerManager;
import android.os.Process;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import androidx.browser.customtabs.CustomTabsIntent;
import com.google.android.gms.ads.impl.R;
import com.google.android.gms.ads.internal.client.zzaw;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.zzt;
import com.google.android.gms.common.GooglePlayServicesUtilLight;
import com.google.android.gms.common.util.ClientLibraryUtils;
import com.google.android.gms.common.util.CrashUtils;
import com.google.android.gms.common.wrappers.Wrappers;
import com.google.android.gms.internal.ads.zzbiu;
import com.google.android.gms.internal.ads.zzbjc;
import com.google.android.gms.internal.ads.zzbka;
import com.google.android.gms.internal.ads.zzbla;
import com.google.android.gms.internal.ads.zzcbq;
import com.google.android.gms.internal.ads.zzcgo;
import com.google.android.gms.internal.ads.zzchc;
import com.google.android.gms.internal.ads.zzfpz;
import com.google.android.gms.internal.ads.zzfzg;
import com.google.android.gms.internal.ads.zzfzp;
import com.google.android.gms.internal.ads.zzgxw;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public final class zzs {
  public static final zzfpz zza = new zzf(Looper.getMainLooper());
  
  private final AtomicReference zzb = new AtomicReference(null);
  
  private final AtomicReference zzc = new AtomicReference(null);
  
  private boolean zzd = true;
  
  private final Object zze = new Object();
  
  private String zzf;
  
  private boolean zzg = false;
  
  private boolean zzh = false;
  
  private final Executor zzi = Executors.newSingleThreadExecutor();
  
  public static final boolean zzA(Context paramContext) {
    try {
      return false;
    } catch (ClassNotFoundException classNotFoundException) {
      return true;
    } finally {
      paramContext = null;
      zze.zzh("Error loading class.", (Throwable)paramContext);
      zzt.zzo().zzt((Throwable)paramContext, "AdUtil.isLiteSdk");
    } 
  }
  
  public static final boolean zzB() {
    int i = Process.myUid();
    return (i == 0 || i == 1000);
  }
  
  public static final boolean zzC(Context paramContext) {
    try {
      ActivityManager activityManager = (ActivityManager)paramContext.getSystemService("activity");
      KeyguardManager keyguardManager = (KeyguardManager)paramContext.getSystemService("keyguard");
      return false;
    } finally {
      paramContext = null;
    } 
  }
  
  public static final boolean zzD(Context paramContext) {
    Bundle bundle = zzU(paramContext);
    String str = bundle.getString("com.google.android.gms.ads.INTEGRATION_MANAGER");
    return (TextUtils.isEmpty(zzV(bundle)) && !TextUtils.isEmpty(str));
  }
  
  public static final boolean zzE(Context paramContext) {
    if (!(paramContext instanceof Activity))
      return false; 
    Window window = ((Activity)paramContext).getWindow();
    if (window != null) {
      if (window.getDecorView() == null)
        return false; 
      Rect rect1 = new Rect();
      Rect rect2 = new Rect();
      window.getDecorView().getGlobalVisibleRect(rect1, null);
      window.getDecorView().getWindowVisibleDisplayFrame(rect2);
      if (rect1.bottom != 0 && rect2.bottom != 0 && rect1.top == rect2.top)
        return true; 
    } 
    return false;
  }
  
  public static final void zzF(View paramView, int paramInt, MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_0
    //   1: astore #12
    //   3: iconst_2
    //   4: newarray int
    //   6: astore #13
    //   8: new android/graphics/Rect
    //   11: dup
    //   12: invokespecial <init> : ()V
    //   15: astore #14
    //   17: aload_0
    //   18: invokevirtual getContext : ()Landroid/content/Context;
    //   21: invokevirtual getPackageName : ()Ljava/lang/String;
    //   24: astore #16
    //   26: aload #12
    //   28: astore_2
    //   29: aload #12
    //   31: instanceof com/google/android/gms/internal/ads/zzdvb
    //   34: ifeq -> 47
    //   37: aload #12
    //   39: checkcast com/google/android/gms/internal/ads/zzdvb
    //   42: iconst_0
    //   43: invokevirtual getChildAt : (I)Landroid/view/View;
    //   46: astore_2
    //   47: aload_2
    //   48: instanceof com/google/android/gms/ads/formats/zzg
    //   51: ifne -> 76
    //   54: aload_2
    //   55: instanceof com/google/android/gms/ads/nativead/NativeAdView
    //   58: istore #9
    //   60: iload #9
    //   62: ifeq -> 68
    //   65: goto -> 76
    //   68: ldc 'UNKNOWN'
    //   70: astore_0
    //   71: iconst_0
    //   72: istore_3
    //   73: goto -> 81
    //   76: ldc 'NATIVE'
    //   78: astore_0
    //   79: iconst_1
    //   80: istore_3
    //   81: aload_2
    //   82: aload #14
    //   84: invokevirtual getLocalVisibleRect : (Landroid/graphics/Rect;)Z
    //   87: ifeq -> 445
    //   90: aload #14
    //   92: invokevirtual width : ()I
    //   95: istore #5
    //   97: aload #14
    //   99: invokevirtual height : ()I
    //   102: istore #4
    //   104: goto -> 107
    //   107: invokestatic zzp : ()Lcom/google/android/gms/ads/internal/util/zzs;
    //   110: pop
    //   111: aload_2
    //   112: invokestatic zzt : (Landroid/view/View;)J
    //   115: lstore #10
    //   117: aload_2
    //   118: aload #13
    //   120: invokevirtual getLocationOnScreen : ([I)V
    //   123: aload #13
    //   125: iconst_0
    //   126: iaload
    //   127: istore #7
    //   129: aload #13
    //   131: iconst_1
    //   132: iaload
    //   133: istore #8
    //   135: aload_2
    //   136: instanceof com/google/android/gms/internal/ads/zzcnm
    //   139: istore #9
    //   141: ldc_w 'none'
    //   144: astore #15
    //   146: iload #9
    //   148: ifeq -> 454
    //   151: aload_2
    //   152: checkcast com/google/android/gms/internal/ads/zzcnm
    //   155: invokeinterface zzR : ()Lcom/google/android/gms/internal/ads/zzfdn;
    //   160: astore #12
    //   162: aload #12
    //   164: ifnull -> 454
    //   167: aload #12
    //   169: getfield zzb : Ljava/lang/String;
    //   172: astore #12
    //   174: aload_2
    //   175: invokevirtual hashCode : ()I
    //   178: istore #6
    //   180: new java/lang/StringBuilder
    //   183: dup
    //   184: invokespecial <init> : ()V
    //   187: astore #13
    //   189: aload #13
    //   191: aload #12
    //   193: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   196: pop
    //   197: aload #13
    //   199: ldc_w ':'
    //   202: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   205: pop
    //   206: aload #13
    //   208: iload #6
    //   210: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   213: pop
    //   214: aload_2
    //   215: aload #13
    //   217: invokevirtual toString : ()Ljava/lang/String;
    //   220: invokevirtual setContentDescription : (Ljava/lang/CharSequence;)V
    //   223: goto -> 226
    //   226: aload_0
    //   227: astore #14
    //   229: iload_3
    //   230: istore #6
    //   232: aload #15
    //   234: astore #13
    //   236: aload_2
    //   237: instanceof com/google/android/gms/internal/ads/zzcmg
    //   240: ifeq -> 293
    //   243: aload_2
    //   244: checkcast com/google/android/gms/internal/ads/zzcmg
    //   247: invokeinterface zzF : ()Lcom/google/android/gms/internal/ads/zzfdk;
    //   252: astore #17
    //   254: aload_0
    //   255: astore #14
    //   257: iload_3
    //   258: istore #6
    //   260: aload #15
    //   262: astore #13
    //   264: aload #17
    //   266: ifnull -> 293
    //   269: aload #17
    //   271: getfield zzb : I
    //   274: invokestatic zza : (I)Ljava/lang/String;
    //   277: astore #14
    //   279: aload #17
    //   281: getfield zzf : I
    //   284: istore #6
    //   286: aload #17
    //   288: getfield zzF : Ljava/lang/String;
    //   291: astore #13
    //   293: getstatic java/util/Locale.US : Ljava/util/Locale;
    //   296: ldc_w '<Ad hashCode=%d, package=%s, adNetCls=%s, gwsQueryId=%s, format=%s, impType=%d, class=%s, x=%d, y=%d, width=%d, height=%d, vWidth=%d, vHeight=%d, alpha=%d, state=%s>'
    //   299: bipush #15
    //   301: anewarray java/lang/Object
    //   304: dup
    //   305: iconst_0
    //   306: aload_2
    //   307: invokevirtual hashCode : ()I
    //   310: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   313: aastore
    //   314: dup
    //   315: iconst_1
    //   316: aload #16
    //   318: aastore
    //   319: dup
    //   320: iconst_2
    //   321: aload #13
    //   323: aastore
    //   324: dup
    //   325: iconst_3
    //   326: aload #12
    //   328: aastore
    //   329: dup
    //   330: iconst_4
    //   331: aload #14
    //   333: aastore
    //   334: dup
    //   335: iconst_5
    //   336: iload #6
    //   338: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   341: aastore
    //   342: dup
    //   343: bipush #6
    //   345: aload_2
    //   346: invokevirtual getClass : ()Ljava/lang/Class;
    //   349: invokevirtual getName : ()Ljava/lang/String;
    //   352: aastore
    //   353: dup
    //   354: bipush #7
    //   356: iload #7
    //   358: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   361: aastore
    //   362: dup
    //   363: bipush #8
    //   365: iload #8
    //   367: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   370: aastore
    //   371: dup
    //   372: bipush #9
    //   374: aload_2
    //   375: invokevirtual getWidth : ()I
    //   378: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   381: aastore
    //   382: dup
    //   383: bipush #10
    //   385: aload_2
    //   386: invokevirtual getHeight : ()I
    //   389: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   392: aastore
    //   393: dup
    //   394: bipush #11
    //   396: iload #5
    //   398: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   401: aastore
    //   402: dup
    //   403: bipush #12
    //   405: iload #4
    //   407: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   410: aastore
    //   411: dup
    //   412: bipush #13
    //   414: lload #10
    //   416: invokestatic valueOf : (J)Ljava/lang/Long;
    //   419: aastore
    //   420: dup
    //   421: bipush #14
    //   423: iload_1
    //   424: iconst_2
    //   425: invokestatic toString : (II)Ljava/lang/String;
    //   428: aastore
    //   429: invokestatic format : (Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   432: invokestatic zzi : (Ljava/lang/String;)V
    //   435: return
    //   436: astore_0
    //   437: ldc_w 'Failure getting view location.'
    //   440: aload_0
    //   441: invokestatic zzh : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   444: return
    //   445: iconst_0
    //   446: istore #4
    //   448: iconst_0
    //   449: istore #5
    //   451: goto -> 107
    //   454: ldc_w 'none'
    //   457: astore #12
    //   459: goto -> 226
    // Exception table:
    //   from	to	target	type
    //   17	26	436	java/lang/Exception
    //   29	47	436	java/lang/Exception
    //   47	60	436	java/lang/Exception
    //   81	104	436	java/lang/Exception
    //   107	123	436	java/lang/Exception
    //   135	141	436	java/lang/Exception
    //   151	162	436	java/lang/Exception
    //   167	223	436	java/lang/Exception
    //   236	254	436	java/lang/Exception
    //   269	293	436	java/lang/Exception
    //   293	435	436	java/lang/Exception
  }
  
  public static final AlertDialog.Builder zzG(Context paramContext) {
    return new AlertDialog.Builder(paramContext, zzt.zzq().zza());
  }
  
  public static final void zzH(Context paramContext, String paramString1, String paramString2) {
    ArrayList<String> arrayList = new ArrayList();
    arrayList.add(paramString2);
    Iterator<String> iterator = arrayList.iterator();
    while (iterator.hasNext())
      (new zzby(paramContext, paramString1, iterator.next())).zzb(); 
  }
  
  public static final void zzI(Context paramContext, Throwable paramThrowable) {
    if (paramContext != null)
      try {
        boolean bool = ((Boolean)zzbla.zzb.zze()).booleanValue();
        if (bool)
          CrashUtils.addDynamiteErrorToDropBox(paramContext, paramThrowable); 
        return;
      } catch (IllegalStateException illegalStateException) {
        return;
      }  
  }
  
  public static final void zzJ(Context paramContext, Intent paramIntent) {
    try {
      return;
    } finally {
      Exception exception = null;
      paramIntent.addFlags(268435456);
      paramContext.startActivity(paramIntent);
    } 
  }
  
  public static final int zzK(String paramString) {
    try {
      return Integer.parseInt(paramString);
    } catch (NumberFormatException numberFormatException) {
      zze.zzj("Could not parse value:".concat(numberFormatException.toString()));
      return 0;
    } 
  }
  
  public static final Map zzL(Uri paramUri) {
    if (paramUri == null)
      return null; 
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    for (String str : paramUri.getQueryParameterNames()) {
      if (!TextUtils.isEmpty(str))
        hashMap.put(str, paramUri.getQueryParameter(str)); 
    } 
    return hashMap;
  }
  
  public static final WebResourceResponse zzM(HttpURLConnection paramHttpURLConnection) throws IOException {
    zzt.zzp();
    String str1 = paramHttpURLConnection.getContentType();
    boolean bool = TextUtils.isEmpty(str1);
    String str3 = "";
    if (bool) {
      str1 = "";
    } else {
      str1 = str1.split(";")[0].trim();
    } 
    zzt.zzp();
    String str2 = paramHttpURLConnection.getContentType();
    if (TextUtils.isEmpty(str2)) {
      str2 = str3;
    } else {
      String[] arrayOfString = str2.split(";");
      if (arrayOfString.length == 1) {
        str2 = str3;
      } else {
        int i = 1;
        while (true) {
          str2 = str3;
          if (i < arrayOfString.length) {
            if (arrayOfString[i].trim().startsWith("charset")) {
              String[] arrayOfString1 = arrayOfString[i].trim().split("=");
              if (arrayOfString1.length > 1) {
                str2 = arrayOfString1[1].trim();
                break;
              } 
            } 
            i++;
            continue;
          } 
          break;
        } 
      } 
    } 
    Map<String, List<String>> map = paramHttpURLConnection.getHeaderFields();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>(map.size());
    for (Map.Entry<String, List<String>> entry : map.entrySet()) {
      if (entry.getKey() != null && entry.getValue() != null && !((List)entry.getValue()).isEmpty())
        hashMap.put(entry.getKey(), ((List<String>)entry.getValue()).get(0)); 
    } 
    return zzt.zzq().zzc(str1, str2, paramHttpURLConnection.getResponseCode(), paramHttpURLConnection.getResponseMessage(), hashMap, paramHttpURLConnection.getInputStream());
  }
  
  public static final int[] zzN(Activity paramActivity) {
    Window window = paramActivity.getWindow();
    if (window != null) {
      View view = window.findViewById(16908290);
      if (view != null)
        return new int[] { view.getWidth(), view.getHeight() }; 
    } 
    return zzs();
  }
  
  public static final int[] zzO(Activity paramActivity) {
    Window window = paramActivity.getWindow();
    if (window != null) {
      View view = window.findViewById(16908290);
      if (view != null) {
        int[] arrayOfInt1 = new int[2];
        arrayOfInt1[0] = view.getTop();
        arrayOfInt1[1] = view.getBottom();
        return new int[] { zzaw.zzb().zzb((Context)paramActivity, arrayOfInt1[0]), zzaw.zzb().zzb((Context)paramActivity, arrayOfInt1[1]) };
      } 
    } 
    int[] arrayOfInt = zzs();
    return new int[] { zzaw.zzb().zzb((Context)paramActivity, arrayOfInt[0]), zzaw.zzb().zzb((Context)paramActivity, arrayOfInt[1]) };
  }
  
  public static final boolean zzP(View paramView, PowerManager paramPowerManager, KeyguardManager paramKeyguardManager) {
    boolean bool;
    boolean bool1 = (zzt.zzp()).zzd;
    null = true;
    if (bool1 || paramKeyguardManager == null || !paramKeyguardManager.inKeyguardRestrictedInputMode() || zzl(paramView)) {
      bool = true;
    } else {
      bool = false;
    } 
    long l = zzt(paramView);
    if (paramView.getVisibility() == 0 && paramView.isShown() && (paramPowerManager == null || paramPowerManager.isScreenOn()) && bool) {
      zzbiu zzbiu = zzbjc.zzbe;
      if (!((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue() || paramView.getLocalVisibleRect(new Rect()) || paramView.getGlobalVisibleRect(new Rect())) {
        zzbiu zzbiu1 = zzbjc.zzin;
        if (((Boolean)zzay.zzc().zzb(zzbiu1)).booleanValue()) {
          zzbiu1 = zzbjc.zzip;
          if (l >= ((Integer)zzay.zzc().zzb(zzbiu1)).intValue())
            return true; 
        } else {
          return null;
        } 
      } 
    } 
    return false;
  }
  
  public static final void zzQ(Context paramContext, Uri paramUri) {
    try {
      Intent intent = new Intent("android.intent.action.VIEW", paramUri);
      Bundle bundle = new Bundle();
      intent.putExtras(bundle);
      zzm(paramContext, intent);
      bundle.putString("com.android.browser.application_id", paramContext.getPackageName());
      paramContext.startActivity(intent);
      String str = paramUri.toString();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Opening ");
      stringBuilder.append(str);
      stringBuilder.append(" in a new browser.");
      zze.zze(stringBuilder.toString());
      return;
    } catch (ActivityNotFoundException activityNotFoundException) {
      zze.zzh("No browser is found.", (Throwable)activityNotFoundException);
      return;
    } 
  }
  
  public static final int[] zzR(Activity paramActivity) {
    int[] arrayOfInt = zzN(paramActivity);
    return new int[] { zzaw.zzb().zzb((Context)paramActivity, arrayOfInt[0]), zzaw.zzb().zzb((Context)paramActivity, arrayOfInt[1]) };
  }
  
  public static final boolean zzS(View paramView, Context paramContext) {
    Context context = paramContext.getApplicationContext();
    if (context != null) {
      PowerManager powerManager = (PowerManager)context.getSystemService("power");
    } else {
      context = null;
    } 
    return zzP(paramView, (PowerManager)context, zzT(paramContext));
  }
  
  private static KeyguardManager zzT(Context paramContext) {
    Object object = paramContext.getSystemService("keyguard");
    return (object != null && object instanceof KeyguardManager) ? (KeyguardManager)object : null;
  }
  
  private static Bundle zzU(Context paramContext) {
    try {
      return (Wrappers.packageManager(paramContext).getApplicationInfo(paramContext.getPackageName(), 128)).metaData;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
    
    } catch (NullPointerException nullPointerException) {}
    zze.zzb("Error getting metadata", nullPointerException);
    return null;
  }
  
  private static String zzV(Bundle paramBundle) {
    if (paramBundle == null)
      return ""; 
    String str = paramBundle.getString("com.google.android.gms.ads.APPLICATION_ID");
    return TextUtils.isEmpty(str) ? "" : (!str.matches("^ca-app-pub-[0-9]{16}~[0-9]{10}$") ? (str.matches("^/\\d+~.+$") ? str : "") : str);
  }
  
  private static boolean zzW(String paramString1, AtomicReference<Pattern> paramAtomicReference, String paramString2) {
    if (TextUtils.isEmpty(paramString1))
      return false; 
    try {
      Pattern pattern2 = paramAtomicReference.get();
      if (pattern2 != null) {
        Pattern pattern = pattern2;
        if (!paramString2.equals(pattern2.pattern())) {
          pattern = Pattern.compile(paramString2);
          paramAtomicReference.set(pattern);
          return pattern.matcher(paramString1).matches();
        } 
        return pattern.matcher(paramString1).matches();
      } 
      Pattern pattern1 = Pattern.compile(paramString2);
      paramAtomicReference.set(pattern1);
      return pattern1.matcher(paramString1).matches();
    } catch (PatternSyntaxException patternSyntaxException) {
      return false;
    } 
  }
  
  public static int zza(int paramInt) {
    if (paramInt >= 5000)
      return paramInt; 
    if (paramInt > 0) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("HTTP timeout too low: ");
      stringBuilder.append(paramInt);
      stringBuilder.append(" milliseconds. Reverting to default timeout: 60000 milliseconds.");
      zze.zzj(stringBuilder.toString());
    } 
    return 60000;
  }
  
  public static void zzf(Runnable paramRunnable) {
    if (Looper.getMainLooper().getThread() != Thread.currentThread()) {
      paramRunnable.run();
      return;
    } 
    zzchc.zza.execute(paramRunnable);
  }
  
  public static final boolean zzl(View paramView) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getRootView : ()Landroid/view/View;
    //   4: astore_0
    //   5: aconst_null
    //   6: astore_1
    //   7: aload_0
    //   8: ifnonnull -> 16
    //   11: aconst_null
    //   12: astore_0
    //   13: goto -> 33
    //   16: aload_0
    //   17: invokevirtual getContext : ()Landroid/content/Context;
    //   20: astore_0
    //   21: aload_0
    //   22: instanceof android/app/Activity
    //   25: ifeq -> 11
    //   28: aload_0
    //   29: checkcast android/app/Activity
    //   32: astore_0
    //   33: aload_0
    //   34: ifnonnull -> 39
    //   37: iconst_0
    //   38: ireturn
    //   39: aload_0
    //   40: invokevirtual getWindow : ()Landroid/view/Window;
    //   43: astore_0
    //   44: aload_0
    //   45: ifnonnull -> 53
    //   48: aload_1
    //   49: astore_0
    //   50: goto -> 58
    //   53: aload_0
    //   54: invokevirtual getAttributes : ()Landroid/view/WindowManager$LayoutParams;
    //   57: astore_0
    //   58: aload_0
    //   59: ifnull -> 75
    //   62: aload_0
    //   63: getfield flags : I
    //   66: ldc_w 524288
    //   69: iand
    //   70: ifeq -> 75
    //   73: iconst_1
    //   74: ireturn
    //   75: iconst_0
    //   76: ireturn
  }
  
  public static final void zzm(Context paramContext, Intent paramIntent) {
    Bundle bundle;
    if (paramIntent == null)
      return; 
    if (paramIntent.getExtras() != null) {
      bundle = paramIntent.getExtras();
    } else {
      bundle = new Bundle();
    } 
    bundle.putBinder("android.support.customtabs.extra.SESSION", null);
    bundle.putString("com.android.browser.application_id", paramContext.getPackageName());
    paramIntent.putExtras(bundle);
  }
  
  public static final ViewGroup.LayoutParams zzn() {
    return new ViewGroup.LayoutParams(-1, -1);
  }
  
  public static final String zzo(Context paramContext) {
    Context context = paramContext;
    if (paramContext.getApplicationContext() != null)
      context = paramContext.getApplicationContext(); 
    return zzV(zzU(context));
  }
  
  static final String zzp() {
    StringBuilder stringBuilder = new StringBuilder(256);
    stringBuilder.append("Mozilla/5.0 (Linux; U; Android");
    if (Build.VERSION.RELEASE != null) {
      stringBuilder.append(" ");
      stringBuilder.append(Build.VERSION.RELEASE);
    } 
    stringBuilder.append("; ");
    stringBuilder.append(Locale.getDefault());
    if (Build.DEVICE != null) {
      stringBuilder.append("; ");
      stringBuilder.append(Build.DEVICE);
      if (Build.DISPLAY != null) {
        stringBuilder.append(" Build/");
        stringBuilder.append(Build.DISPLAY);
      } 
    } 
    stringBuilder.append(") AppleWebKit/533 Version/4.0 Safari/533");
    return stringBuilder.toString();
  }
  
  public static final String zzq() {
    String str1 = Build.MANUFACTURER;
    String str2 = Build.MODEL;
    if (str2.startsWith(str1))
      return str2; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(str1);
    stringBuilder.append(" ");
    stringBuilder.append(str2);
    return stringBuilder.toString();
  }
  
  public static final DisplayMetrics zzr(WindowManager paramWindowManager) {
    DisplayMetrics displayMetrics = new DisplayMetrics();
    paramWindowManager.getDefaultDisplay().getMetrics(displayMetrics);
    return displayMetrics;
  }
  
  protected static final int[] zzs() {
    return new int[] { 0, 0 };
  }
  
  public static final long zzt(View paramView) {
    float f2;
    float f3;
    float f1 = Float.MAX_VALUE;
    while (true) {
      boolean bool = paramView instanceof View;
      f3 = 0.0F;
      f2 = f1;
      if (bool) {
        paramView = paramView;
        f2 = Math.min(f1, paramView.getAlpha());
        ViewParent viewParent = paramView.getParent();
        f1 = f2;
        if (f2 <= 0.0F)
          break; 
        continue;
      } 
      break;
    } 
    if (f2 < 0.0F)
      f2 = f3; 
    return Math.round(f2 * 100.0F);
  }
  
  public static final WebResourceResponse zzu(Context paramContext, String paramString1, String paramString2) {
    try {
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      hashMap.put("User-Agent", zzt.zzp().zzc(paramContext, paramString1));
      hashMap.put("Cache-Control", "max-stale=3600");
      String str = (String)(new zzbo(paramContext)).zzb(0, paramString2, hashMap, null).get(60L, TimeUnit.SECONDS);
      if (str != null)
        return new WebResourceResponse("application/javascript", "UTF-8", new ByteArrayInputStream(str.getBytes("UTF-8"))); 
    } catch (IOException iOException) {
      zze.zzk("Could not fetch MRAID JS.", iOException);
    } catch (ExecutionException executionException) {
    
    } catch (InterruptedException interruptedException) {
    
    } catch (TimeoutException timeoutException) {}
    return null;
  }
  
  public static final String zzv() {
    Resources resources = zzt.zzo().zzd();
    return (resources != null) ? resources.getString(R.string.s7) : "Test Ad";
  }
  
  public static final zzbr zzw(Context paramContext) {
    try {
      paramContext = paramContext.getClassLoader().loadClass("com.google.android.gms.ads.internal.util.WorkManagerUtil").getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
      if (!(paramContext instanceof IBinder)) {
        zze.zzg("Instantiated WorkManagerUtil not instance of IBinder.");
        return null;
      } 
      IBinder iBinder = (IBinder)paramContext;
      if (iBinder == null)
        return null; 
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.util.IWorkManagerUtil");
      return (iInterface instanceof zzbr) ? (zzbr)iInterface : new zzbp(iBinder);
    } catch (Exception exception) {
      zzt.zzo().zzt(exception, "Failed to instantiate WorkManagerUtil");
      return null;
    } 
  }
  
  public static final boolean zzx(Context paramContext, String paramString) {
    paramContext = zzcbq.zza(paramContext);
    String str = paramContext.getPackageName();
    return (Wrappers.packageManager(paramContext).checkPermission(paramString, str) == 0);
  }
  
  public static final boolean zzy(String paramString) {
    if (!zzcgo.zzl())
      return false; 
    zzbiu zzbiu2 = zzbjc.zzec;
    if (!((Boolean)zzay.zzc().zzb(zzbiu2)).booleanValue())
      return false; 
    zzbiu2 = zzbjc.zzee;
    String str2 = (String)zzay.zzc().zzb(zzbiu2);
    if (!str2.isEmpty()) {
      String[] arrayOfString1 = str2.split(";");
      int m = arrayOfString1.length;
      for (int k = 0; k < m; k++) {
        if (arrayOfString1[k].equals(paramString))
          return false; 
      } 
    } 
    zzbiu zzbiu1 = zzbjc.zzed;
    String str1 = (String)zzay.zzc().zzb(zzbiu1);
    if (str1.isEmpty())
      return true; 
    String[] arrayOfString = str1.split(";");
    int j = arrayOfString.length;
    for (int i = 0; i < j; i++) {
      if (arrayOfString[i].equals(paramString))
        return true; 
    } 
    return false;
  }
  
  public static final boolean zzz(Context paramContext) {
    if (paramContext == null)
      return false; 
    KeyguardManager keyguardManager = zzT(paramContext);
    return (keyguardManager != null && keyguardManager.isKeyguardLocked());
  }
  
  public final zzfzp zzb(Uri paramUri) {
    return zzfzg.zzk(new zzl(paramUri), this.zzi);
  }
  
  public final String zzc(Context paramContext, String paramString) {
    synchronized (this.zze) {
      String str2 = this.zzf;
      if (str2 != null)
        return str2; 
      if (paramString == null) {
        str1 = zzp();
        return str1;
      } 
      try {
        zzce zzce = zzce.zza();
        if (TextUtils.isEmpty(zzce.zza)) {
          if (ClientLibraryUtils.isPackageSide()) {
            str2 = (String)zzcb.zza((Context)str1, new zzcc((Context)str1));
          } else {
            str2 = (String)zzcb.zza((Context)str1, new zzcd(GooglePlayServicesUtilLight.getRemoteContext((Context)str1), (Context)str1));
          } 
          zzce.zza = str2;
        } 
        this.zzf = zzce.zza;
      } catch (Exception exception) {}
      if (TextUtils.isEmpty(this.zzf))
        this.zzf = WebSettings.getDefaultUserAgent((Context)str1); 
      if (TextUtils.isEmpty(this.zzf))
        this.zzf = zzp(); 
      str2 = this.zzf;
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append(str2);
      stringBuilder2.append(" (Mobile; ");
      stringBuilder2.append(paramString);
      this.zzf = stringBuilder2.toString();
      try {
        if (Wrappers.packageManager((Context)str1).isCallerInstantApp()) {
          str1 = this.zzf;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(str1);
          stringBuilder.append(";aia");
          this.zzf = stringBuilder.toString();
        } 
      } catch (Exception exception) {
        zzt.zzo().zzt(exception, "AdUtil.getUserAgent");
      } 
      String str1 = this.zzf;
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(str1);
      stringBuilder1.append(")");
      str1 = stringBuilder1.toString();
      this.zzf = str1;
      return str1;
    } 
  }
  
  public final void zze(Context paramContext, String paramString, boolean paramBoolean1, HttpURLConnection paramHttpURLConnection, boolean paramBoolean2, int paramInt) {
    paramInt = zza(paramInt);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("HTTP timeout: ");
    stringBuilder.append(paramInt);
    stringBuilder.append(" milliseconds.");
    zze.zzi(stringBuilder.toString());
    paramHttpURLConnection.setConnectTimeout(paramInt);
    paramHttpURLConnection.setInstanceFollowRedirects(false);
    paramHttpURLConnection.setReadTimeout(paramInt);
    paramHttpURLConnection.setRequestProperty("User-Agent", zzc(paramContext, paramString));
    paramHttpURLConnection.setUseCaches(false);
  }
  
  public final boolean zzg(String paramString) {
    AtomicReference atomicReference = this.zzb;
    zzbiu zzbiu = zzbjc.zzZ;
    return zzW(paramString, atomicReference, (String)zzay.zzc().zzb(zzbiu));
  }
  
  public final boolean zzh(String paramString) {
    AtomicReference atomicReference = this.zzc;
    zzbiu zzbiu = zzbjc.zzaa;
    return zzW(paramString, atomicReference, (String)zzay.zzc().zzb(zzbiu));
  }
  
  public final boolean zzi(Context paramContext) {
    if (this.zzh)
      return false; 
    IntentFilter intentFilter = new IntentFilter();
    intentFilter.addAction("com.google.android.ads.intent.DEBUG_LOGGING_ENABLEMENT_CHANGED");
    zzbjc.zzc(paramContext);
    zzbiu zzbiu = zzbjc.zziE;
    if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue() && Build.VERSION.SDK_INT >= 33) {
      paramContext.getApplicationContext().registerReceiver(new zzp(this, null), intentFilter, 4);
    } else {
      paramContext.getApplicationContext().registerReceiver(new zzp(this, null), intentFilter);
    } 
    this.zzh = true;
    return true;
  }
  
  public final boolean zzj(Context paramContext) {
    if (this.zzg)
      return false; 
    IntentFilter intentFilter = new IntentFilter();
    intentFilter.addAction("android.intent.action.USER_PRESENT");
    intentFilter.addAction("android.intent.action.SCREEN_OFF");
    zzbjc.zzc(paramContext);
    zzbiu zzbiu = zzbjc.zziE;
    if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue() && Build.VERSION.SDK_INT >= 33) {
      paramContext.getApplicationContext().registerReceiver(new zzr(this, null), intentFilter, 4);
    } else {
      paramContext.getApplicationContext().registerReceiver(new zzr(this, null), intentFilter);
    } 
    this.zzg = true;
    return true;
  }
  
  public final int zzk(Context paramContext, Uri paramUri) {
    byte b;
    if (paramContext == null) {
      zze.zza("Trying to open chrome custom tab on a null context");
      return 3;
    } 
    if (!(paramContext instanceof Activity)) {
      zze.zza("Chrome Custom Tabs can only work with Activity context.");
      b = 2;
    } else {
      b = 0;
    } 
    zzbiu zzbiu2 = zzbjc.zzdI;
    Boolean bool = (Boolean)zzay.zzc().zzb(zzbiu2);
    zzbiu zzbiu3 = zzbjc.zzdJ;
    if (true == bool.equals(zzay.zzc().zzb(zzbiu3)))
      b = 9; 
    if (b != 0) {
      Intent intent = new Intent("android.intent.action.VIEW");
      intent.setData(paramUri);
      intent.addFlags(268435456);
      paramContext.startActivity(intent);
      return b;
    } 
    zzbiu zzbiu1 = zzbjc.zzdI;
    if (((Boolean)zzay.zzc().zzb(zzbiu1)).booleanValue()) {
      zzbka zzbka = new zzbka();
      zzbka.zze(new zzn(this, zzbka, paramContext, paramUri));
      zzbka.zzb((Activity)paramContext);
    } 
    zzbiu1 = zzbjc.zzdJ;
    if (((Boolean)zzay.zzc().zzb(zzbiu1)).booleanValue()) {
      CustomTabsIntent customTabsIntent = (new CustomTabsIntent.Builder()).build();
      customTabsIntent.intent.setPackage(zzgxw.zza(paramContext));
      customTabsIntent.launchUrl(paramContext, paramUri);
    } 
    return 5;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */