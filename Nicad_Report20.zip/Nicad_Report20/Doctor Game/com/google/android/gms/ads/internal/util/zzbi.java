package com.google.android.gms.ads.internal.util;

import com.google.android.gms.internal.ads.zzajl;
import com.google.android.gms.internal.ads.zzakh;
import com.google.android.gms.internal.ads.zzaki;
import com.google.android.gms.internal.ads.zzali;
import com.google.android.gms.internal.ads.zzcgo;
import java.util.Collections;
import java.util.Map;

final class zzbi extends zzali {
  zzbi(zzbo paramzzbo, int paramInt, String paramString, zzaki paramzzaki, zzakh paramzzakh, byte[] paramArrayOfbyte, Map paramMap, zzcgo paramzzcgo) {
    super(paramInt, paramString, paramzzaki, paramzzakh);
  }
  
  public final Map zzl() throws zzajl {
    Map<?, ?> map2 = this.zzb;
    Map<?, ?> map1 = map2;
    if (map2 == null)
      map1 = Collections.emptyMap(); 
    return map1;
  }
  
  public final byte[] zzx() throws zzajl {
    byte[] arrayOfByte2 = this.zza;
    byte[] arrayOfByte1 = arrayOfByte2;
    if (arrayOfByte2 == null)
      arrayOfByte1 = null; 
    return arrayOfByte1;
  }
  
  protected final void zzz(String paramString) {
    this.zzc.zzg(paramString);
    super.zzz(paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzbi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */