package com.google.android.gms.ads.h5;

import android.content.Context;
import com.google.android.gms.internal.ads.zzbqy;

public final class H5AdsRequestHandler {
  private final zzbqy zza;
  
  public H5AdsRequestHandler(Context paramContext, OnH5AdsEventListener paramOnH5AdsEventListener) {
    this.zza = new zzbqy(paramContext, paramOnH5AdsEventListener);
  }
  
  public void clearAdObjects() {
    this.zza.zza();
  }
  
  public boolean handleH5AdsRequest(String paramString) {
    return this.zza.zzb(paramString);
  }
  
  public boolean shouldInterceptRequest(String paramString) {
    return zzbqy.zzc(paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\h5\H5AdsRequestHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */