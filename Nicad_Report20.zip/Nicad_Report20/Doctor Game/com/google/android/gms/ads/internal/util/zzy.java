package com.google.android.gms.ads.internal.util;

import android.content.Context;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.internal.ads.zzbiu;
import com.google.android.gms.internal.ads.zzbjc;
import javax.annotation.ParametersAreNonnullByDefault;

@ParametersAreNonnullByDefault
public final class zzy extends zzx {
  public final int zzl(Context paramContext) {
    zzbiu zzbiu = zzbjc.zzhn;
    return ((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue() ? 0 : super.zzl(paramContext);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */