package com.google.android.gms.ads.formats;

import com.google.android.gms.ads.admanager.AdManagerAdView;

public interface OnAdManagerAdViewLoadedListener {
  void onAdManagerAdViewLoaded(AdManagerAdView paramAdManagerAdView);
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\formats\OnAdManagerAdViewLoadedListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */