package com.google.android.gms.ads.internal.util;

import android.content.Context;
import com.google.android.gms.ads.identifier.AdvertisingIdClient;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.internal.ads.zzcgo;
import java.io.IOException;

final class zzc extends zzb {
  private final Context zza;
  
  zzc(Context paramContext) {
    this.zza = paramContext;
  }
  
  public final void zza() {
    boolean bool;
    try {
      bool = AdvertisingIdClient.getIsAdIdFakeForDebugLogging(this.zza);
    } catch (IOException iOException) {
      zze.zzh("Fail to get isAdIdFakeForDebugLogging", iOException);
      bool = false;
    } catch (IllegalStateException illegalStateException) {
    
    } catch (GooglePlayServicesNotAvailableException googlePlayServicesNotAvailableException) {
    
    } catch (GooglePlayServicesRepairableException googlePlayServicesRepairableException) {}
    zzcgo.zzj(bool);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Update ad debug logging enablement as ");
    stringBuilder.append(bool);
    zze.zzj(stringBuilder.toString());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */