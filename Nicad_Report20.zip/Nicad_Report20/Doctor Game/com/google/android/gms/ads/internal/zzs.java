package com.google.android.gms.ads.internal;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.RemoteException;
import android.text.TextUtils;
import android.view.ViewGroup;
import android.webkit.WebView;
import com.google.android.gms.ads.internal.client.zzaw;
import com.google.android.gms.ads.internal.client.zzbc;
import com.google.android.gms.ads.internal.client.zzbf;
import com.google.android.gms.ads.internal.client.zzbi;
import com.google.android.gms.ads.internal.client.zzbr;
import com.google.android.gms.ads.internal.client.zzbw;
import com.google.android.gms.ads.internal.client.zzbz;
import com.google.android.gms.ads.internal.client.zzcd;
import com.google.android.gms.ads.internal.client.zzcg;
import com.google.android.gms.ads.internal.client.zzde;
import com.google.android.gms.ads.internal.client.zzdh;
import com.google.android.gms.ads.internal.client.zzdk;
import com.google.android.gms.ads.internal.client.zzdo;
import com.google.android.gms.ads.internal.client.zzff;
import com.google.android.gms.ads.internal.client.zzl;
import com.google.android.gms.ads.internal.client.zzq;
import com.google.android.gms.ads.internal.client.zzw;
import com.google.android.gms.ads.internal.util.zze;
import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.dynamic.ObjectWrapper;
import com.google.android.gms.internal.ads.zzape;
import com.google.android.gms.internal.ads.zzapf;
import com.google.android.gms.internal.ads.zzbdm;
import com.google.android.gms.internal.ads.zzbjx;
import com.google.android.gms.internal.ads.zzbkg;
import com.google.android.gms.internal.ads.zzbzl;
import com.google.android.gms.internal.ads.zzbzo;
import com.google.android.gms.internal.ads.zzcby;
import com.google.android.gms.internal.ads.zzcgi;
import com.google.android.gms.internal.ads.zzcgv;
import com.google.android.gms.internal.ads.zzchc;
import java.util.Map;
import java.util.concurrent.Future;
import javax.annotation.ParametersAreNonnullByDefault;

@ParametersAreNonnullByDefault
public final class zzs extends zzbr {
  private final zzcgv zza;
  
  private final zzq zzb;
  
  private final Future zzc;
  
  private final Context zzd;
  
  private final zzr zze;
  
  private WebView zzf;
  
  private zzbf zzg;
  
  private zzape zzh;
  
  private AsyncTask zzi;
  
  public zzs(Context paramContext, zzq paramzzq, String paramString, zzcgv paramzzcgv) {
    this.zzd = paramContext;
    this.zza = paramzzcgv;
    this.zzb = paramzzq;
    this.zzf = new WebView(this.zzd);
    this.zzc = (Future)zzchc.zza.zzb(new zzo(this));
    this.zze = new zzr(paramContext, paramString);
    zzV(0);
    this.zzf.setVerticalScrollBarEnabled(false);
    this.zzf.getSettings().setJavaScriptEnabled(true);
    this.zzf.setWebViewClient(new zzm(this));
    this.zzf.setOnTouchListener(new zzn(this));
  }
  
  public final void zzA() throws RemoteException {
    throw new IllegalStateException("Unused method");
  }
  
  public final void zzB() throws RemoteException {
    Preconditions.checkMainThread("resume must be called on the main UI thread.");
  }
  
  public final void zzC(zzbc paramzzbc) throws RemoteException {
    throw new IllegalStateException("Unused method");
  }
  
  public final void zzD(zzbf paramzzbf) throws RemoteException {
    this.zzg = paramzzbf;
  }
  
  public final void zzE(zzbw paramzzbw) {
    throw new IllegalStateException("Unused method");
  }
  
  public final void zzF(zzq paramzzq) throws RemoteException {
    throw new IllegalStateException("AdSize must be set before initialization");
  }
  
  public final void zzG(zzbz paramzzbz) throws RemoteException {
    throw new IllegalStateException("Unused method");
  }
  
  public final void zzH(zzbdm paramzzbdm) throws RemoteException {
    throw new IllegalStateException("Unused method");
  }
  
  public final void zzI(zzw paramzzw) {
    throw new IllegalStateException("Unused method");
  }
  
  public final void zzJ(zzcg paramzzcg) {}
  
  public final void zzK(zzdo paramzzdo) {
    throw new IllegalStateException("Unused method");
  }
  
  public final void zzL(boolean paramBoolean) {
    throw new IllegalStateException("Unused method");
  }
  
  public final void zzM(zzbzl paramzzbzl) throws RemoteException {
    throw new IllegalStateException("Unused method");
  }
  
  public final void zzN(boolean paramBoolean) throws RemoteException {}
  
  public final void zzO(zzbjx paramzzbjx) throws RemoteException {
    throw new IllegalStateException("Unused method");
  }
  
  public final void zzP(zzde paramzzde) {}
  
  public final void zzQ(zzbzo paramzzbzo, String paramString) throws RemoteException {
    throw new IllegalStateException("Unused method");
  }
  
  public final void zzR(String paramString) {
    throw new IllegalStateException("Unused method");
  }
  
  public final void zzS(zzcby paramzzcby) throws RemoteException {
    throw new IllegalStateException("Unused method");
  }
  
  public final void zzT(String paramString) throws RemoteException {
    throw new IllegalStateException("Unused method");
  }
  
  public final void zzU(zzff paramzzff) {
    throw new IllegalStateException("Unused method");
  }
  
  final void zzV(int paramInt) {
    if (this.zzf == null)
      return; 
    ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-1, paramInt);
    this.zzf.setLayoutParams(layoutParams);
  }
  
  public final void zzW(IObjectWrapper paramIObjectWrapper) {}
  
  public final void zzX() throws RemoteException {
    throw new IllegalStateException("Unused method");
  }
  
  public final boolean zzY() throws RemoteException {
    return false;
  }
  
  public final boolean zzZ() throws RemoteException {
    return false;
  }
  
  public final boolean zzaa(zzl paramzzl) throws RemoteException {
    Preconditions.checkNotNull(this.zzf, "This Search Ad has already been torn down");
    this.zze.zzf(paramzzl, this.zza);
    this.zzi = (new zzq(this, null)).execute((Object[])new Void[0]);
    return true;
  }
  
  public final void zzab(zzcd paramzzcd) throws RemoteException {
    throw new IllegalStateException("Unused method");
  }
  
  final int zzb(String paramString) {
    paramString = Uri.parse(paramString).getQueryParameter("height");
    if (TextUtils.isEmpty(paramString))
      return 0; 
    try {
      zzaw.zzb();
      return zzcgi.zzw(this.zzd, Integer.parseInt(paramString));
    } catch (NumberFormatException numberFormatException) {
      return 0;
    } 
  }
  
  public final Bundle zzd() {
    throw new IllegalStateException("Unused method");
  }
  
  public final zzq zzg() throws RemoteException {
    return this.zzb;
  }
  
  public final zzbf zzi() {
    throw new IllegalStateException("getIAdListener not implemented");
  }
  
  public final zzbz zzj() {
    throw new IllegalStateException("getIAppEventListener not implemented");
  }
  
  public final zzdh zzk() {
    return null;
  }
  
  public final zzdk zzl() {
    return null;
  }
  
  public final IObjectWrapper zzn() throws RemoteException {
    Preconditions.checkMainThread("getAdFrame must be called on the main UI thread.");
    return ObjectWrapper.wrap(this.zzf);
  }
  
  final String zzp() {
    Uri.Builder builder = new Uri.Builder();
    builder.scheme("https://").appendEncodedPath((String)zzbkg.zzd.zze());
    builder.appendQueryParameter("query", this.zze.zzd());
    builder.appendQueryParameter("pubId", this.zze.zzc());
    builder.appendQueryParameter("mappver", this.zze.zza());
    Map map = this.zze.zze();
    for (String str : map.keySet())
      builder.appendQueryParameter(str, (String)map.get(str)); 
    Uri uri2 = builder.build();
    zzape zzape1 = this.zzh;
    Uri uri1 = uri2;
    if (zzape1 != null)
      try {
        uri1 = zzape1.zzb(uri2, this.zzd);
      } catch (zzapf zzapf) {
        zze.zzk("Unable to process ad data", (Throwable)zzapf);
        uri1 = uri2;
      }  
    String str2 = zzq();
    String str1 = uri1.getEncodedQuery();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(str2);
    stringBuilder.append("#");
    stringBuilder.append(str1);
    return stringBuilder.toString();
  }
  
  final String zzq() {
    String str2 = this.zze.zzb();
    String str1 = str2;
    if (true == TextUtils.isEmpty(str2))
      str1 = "www.google.com"; 
    str2 = (String)zzbkg.zzd.zze();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("https://");
    stringBuilder.append(str1);
    stringBuilder.append(str2);
    return stringBuilder.toString();
  }
  
  public final String zzr() {
    throw new IllegalStateException("getAdUnitId not implemented");
  }
  
  public final String zzs() throws RemoteException {
    return null;
  }
  
  public final String zzt() throws RemoteException {
    return null;
  }
  
  public final void zzx() throws RemoteException {
    Preconditions.checkMainThread("destroy must be called on the main UI thread.");
    this.zzi.cancel(true);
    this.zzc.cancel(true);
    this.zzf.destroy();
    this.zzf = null;
  }
  
  public final void zzy(zzl paramzzl, zzbi paramzzbi) {}
  
  public final void zzz() throws RemoteException {
    Preconditions.checkMainThread("pause must be called on the main UI thread.");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\zzs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */