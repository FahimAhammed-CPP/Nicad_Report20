package com.google.android.gms.ads.impl;

public final class R {
  public static final class drawable {
    public static final int admob_close_button_black_circle_white_cross = 2131034112;
    
    public static final int admob_close_button_white_circle_black_cross = 2131034113;
  }
  
  public static final class string {
    public static final int offline_notification_text = 2131361822;
    
    public static final int offline_notification_title = 2131361823;
    
    public static final int offline_opt_in_confirm = 2131361824;
    
    public static final int offline_opt_in_confirmation = 2131361825;
    
    public static final int offline_opt_in_decline = 2131361826;
    
    public static final int offline_opt_in_message = 2131361827;
    
    public static final int offline_opt_in_title = 2131361828;
    
    public static final int s1 = 2131361829;
    
    public static final int s2 = 2131361830;
    
    public static final int s3 = 2131361831;
    
    public static final int s4 = 2131361832;
    
    public static final int s5 = 2131361833;
    
    public static final int s6 = 2131361834;
    
    public static final int s7 = 2131361835;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\impl\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */