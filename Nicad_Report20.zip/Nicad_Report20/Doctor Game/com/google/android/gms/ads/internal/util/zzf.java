package com.google.android.gms.ads.internal.util;

import android.os.Looper;
import android.os.Message;
import com.google.android.gms.ads.internal.zzt;
import com.google.android.gms.internal.ads.zzfpz;

public final class zzf extends zzfpz {
  public zzf(Looper paramLooper) {
    super(paramLooper);
  }
  
  public final void handleMessage(Message paramMessage) {
    try {
      super.handleMessage(paramMessage);
      return;
    } catch (Exception exception) {
      zzt.zzo().zzt(exception, "AdMobHandler.handleMessage");
      return;
    } 
  }
  
  protected final void zza(Message paramMessage) {
    try {
      return;
    } finally {
      zzt.zzp();
      zzs.zzI(zzt.zzo().zzc(), (Throwable)paramMessage);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */