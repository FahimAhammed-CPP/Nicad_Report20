package com.google.android.gms.ads.internal.overlay;

import android.content.Context;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.util.zze;
import com.google.android.gms.internal.ads.zzbiu;
import com.google.android.gms.internal.ads.zzbjc;
import com.google.android.gms.internal.ads.zzchc;
import com.google.android.gms.internal.ads.zzcmp;
import com.google.android.gms.internal.ads.zzfqq;
import com.google.android.gms.internal.ads.zzfqr;
import com.google.android.gms.internal.ads.zzfqs;
import com.google.android.gms.internal.ads.zzfrc;
import com.google.android.gms.internal.ads.zzfre;
import com.google.android.gms.internal.ads.zzfrf;
import com.google.android.gms.internal.ads.zzfrg;
import com.google.android.gms.internal.ads.zzfrh;
import java.util.HashMap;
import java.util.Map;

public final class zzw {
  private String zza = null;
  
  private String zzb = null;
  
  private zzcmp zzc = null;
  
  private zzfqs zzd = null;
  
  private boolean zze = false;
  
  private zzfrf zzf;
  
  private final zzfrh zzl() {
    zzfrg zzfrg = zzfrh.zzc();
    zzbiu zzbiu = zzbjc.zziT;
    if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue() && !TextUtils.isEmpty(this.zzb)) {
      zzfrg.zza(this.zzb);
    } else {
      String str = this.zza;
      if (str != null) {
        zzfrg.zzb(str);
      } else {
        zzf("Missing session token and/or appId", "onLMDupdate");
      } 
    } 
    return zzfrg.zzc();
  }
  
  private final void zzm() {
    if (this.zzf == null)
      this.zzf = new zzv(this); 
  }
  
  public final void zza(zzcmp paramzzcmp, Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: putfield zzc : Lcom/google/android/gms/internal/ads/zzcmp;
    //   7: aload_0
    //   8: aload_2
    //   9: invokevirtual zzk : (Landroid/content/Context;)Z
    //   12: ifne -> 26
    //   15: aload_0
    //   16: ldc 'Unable to bind'
    //   18: ldc 'on_play_store_bind'
    //   20: invokevirtual zzf : (Ljava/lang/String;Ljava/lang/String;)V
    //   23: aload_0
    //   24: monitorexit
    //   25: return
    //   26: new java/util/HashMap
    //   29: dup
    //   30: invokespecial <init> : ()V
    //   33: astore_1
    //   34: aload_1
    //   35: ldc 'action'
    //   37: ldc 'fetch_completed'
    //   39: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   44: pop
    //   45: aload_0
    //   46: ldc 'on_play_store_bind'
    //   48: aload_1
    //   49: invokevirtual zze : (Ljava/lang/String;Ljava/util/Map;)V
    //   52: aload_0
    //   53: monitorexit
    //   54: return
    //   55: astore_1
    //   56: aload_0
    //   57: monitorexit
    //   58: aload_1
    //   59: athrow
    // Exception table:
    //   from	to	target	type
    //   2	23	55	finally
    //   26	52	55	finally
  }
  
  public final void zzb() {
    if (this.zze) {
      zzfqs zzfqs1 = this.zzd;
      if (zzfqs1 != null) {
        zzfqs1.zza(zzl(), this.zzf);
        zzd("onLMDOverlayCollapse");
        return;
      } 
    } 
    zze.zza("LastMileDelivery not connected");
  }
  
  public final void zzc() {
    if (this.zze) {
      zzfqs zzfqs1 = this.zzd;
      if (zzfqs1 != null) {
        zzfqq zzfqq = zzfqr.zzc();
        zzbiu zzbiu = zzbjc.zziT;
        if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue() && !TextUtils.isEmpty(this.zzb)) {
          zzfqq.zza(this.zzb);
        } else {
          String str = this.zza;
          if (str != null) {
            zzfqq.zzb(str);
          } else {
            zzf("Missing session token and/or appId", "onLMDupdate");
          } 
        } 
        zzfqs1.zzb(zzfqq.zzc(), this.zzf);
        return;
      } 
    } 
    zze.zza("LastMileDelivery not connected");
  }
  
  final void zzd(String paramString) {
    zze(paramString, new HashMap<Object, Object>());
  }
  
  final void zze(String paramString, Map paramMap) {
    zzchc.zze.execute(new zzu(this, paramString, paramMap));
  }
  
  final void zzf(String paramString1, String paramString2) {
    zze.zza(paramString1);
    if (this.zzc != null) {
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      hashMap.put("message", paramString1);
      hashMap.put("action", paramString2);
      zze("onError", hashMap);
    } 
  }
  
  public final void zzg() {
    if (this.zze) {
      zzfqs zzfqs1 = this.zzd;
      if (zzfqs1 != null) {
        zzfqs1.zzc(zzl(), this.zzf);
        zzd("onLMDOverlayExpand");
        return;
      } 
    } 
    zze.zza("LastMileDelivery not connected");
  }
  
  final void zzi(zzfre paramzzfre) {
    HashMap<Object, Object> hashMap;
    if (!TextUtils.isEmpty(paramzzfre.zzb())) {
      zzbiu zzbiu = zzbjc.zziT;
      if (!((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue())
        this.zza = paramzzfre.zzb(); 
    } 
    switch (paramzzfre.zza()) {
      default:
        return;
      case 8160:
      case 8161:
      case 8162:
        hashMap = new HashMap<Object, Object>();
        hashMap.put("error", String.valueOf(paramzzfre.zza()));
        zze("onLMDOverlayFailedToOpen", hashMap);
        return;
      case 8157:
        this.zza = null;
        this.zzb = null;
        this.zze = false;
        return;
      case 8155:
        zzd("onLMDOverlayClose");
        return;
      case 8153:
        zzd("onLMDOverlayClicked");
        return;
      case 8152:
        break;
    } 
    zzd("onLMDOverlayOpened");
  }
  
  public final void zzj(zzcmp paramzzcmp, zzfrc paramzzfrc) {
    if (paramzzcmp == null) {
      zzf("adWebview missing", "onLMDShow");
      return;
    } 
    this.zzc = paramzzcmp;
    if (this.zze || zzk(paramzzcmp.getContext())) {
      zzbiu zzbiu = zzbjc.zziT;
      if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue())
        this.zzb = paramzzfrc.zzg(); 
      zzm();
      zzfqs zzfqs1 = this.zzd;
      if (zzfqs1 != null)
        zzfqs1.zzd(paramzzfrc, this.zzf); 
      return;
    } 
    zzf("LMDOverlay not bound", "on_play_store_bind");
  }
  
  public final boolean zzk(Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: invokestatic zza : (Landroid/content/Context;)Z
    //   6: istore_2
    //   7: iload_2
    //   8: ifne -> 15
    //   11: aload_0
    //   12: monitorexit
    //   13: iconst_0
    //   14: ireturn
    //   15: aload_0
    //   16: aload_1
    //   17: invokestatic zza : (Landroid/content/Context;)Lcom/google/android/gms/internal/ads/zzfqs;
    //   20: putfield zzd : Lcom/google/android/gms/internal/ads/zzfqs;
    //   23: goto -> 41
    //   26: astore_1
    //   27: ldc 'Error connecting LMD Overlay service'
    //   29: invokestatic zza : (Ljava/lang/String;)V
    //   32: invokestatic zzo : ()Lcom/google/android/gms/internal/ads/zzcfy;
    //   35: aload_1
    //   36: ldc 'LastMileDeliveryOverlay.bindLastMileDeliveryService'
    //   38: invokevirtual zzt : (Ljava/lang/Throwable;Ljava/lang/String;)V
    //   41: aload_0
    //   42: getfield zzd : Lcom/google/android/gms/internal/ads/zzfqs;
    //   45: ifnonnull -> 57
    //   48: aload_0
    //   49: iconst_0
    //   50: putfield zze : Z
    //   53: aload_0
    //   54: monitorexit
    //   55: iconst_0
    //   56: ireturn
    //   57: aload_0
    //   58: invokespecial zzm : ()V
    //   61: aload_0
    //   62: iconst_1
    //   63: putfield zze : Z
    //   66: aload_0
    //   67: monitorexit
    //   68: iconst_1
    //   69: ireturn
    //   70: astore_1
    //   71: aload_0
    //   72: monitorexit
    //   73: aload_1
    //   74: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	70	finally
    //   15	23	26	java/lang/NullPointerException
    //   15	23	70	finally
    //   27	41	70	finally
    //   41	53	70	finally
    //   57	66	70	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\overlay\zzw.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */