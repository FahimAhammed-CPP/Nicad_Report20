package com.google.android.gms.ads.internal.util;

import android.app.Activity;
import android.graphics.Rect;
import android.media.AudioManager;
import android.text.TextUtils;
import android.view.DisplayCutout;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.zzt;
import com.google.android.gms.internal.ads.zzbiu;
import com.google.android.gms.internal.ads.zzbjc;
import java.util.Locale;
import javax.annotation.ParametersAreNonnullByDefault;

@ParametersAreNonnullByDefault
public class zzx extends zzv {
  private static final void zzn(boolean paramBoolean, Activity paramActivity) {
    Window window = paramActivity.getWindow();
    WindowManager.LayoutParams layoutParams = window.getAttributes();
    int i = layoutParams.layoutInDisplayCutoutMode;
    byte b = 1;
    if (true != paramBoolean)
      b = 2; 
    if (b != i) {
      layoutParams.layoutInDisplayCutoutMode = b;
      window.setAttributes(layoutParams);
    } 
  }
  
  public final int zzi(AudioManager paramAudioManager) {
    return paramAudioManager.getStreamMinVolume(3);
  }
  
  public final void zzj(Activity paramActivity) {
    zzbiu zzbiu = zzbjc.zzaZ;
    if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue() && zzt.zzo().zzh().zzm() == null && !paramActivity.isInMultiWindowMode()) {
      zzn(true, paramActivity);
      paramActivity.getWindow().getDecorView().setOnApplyWindowInsetsListener(new zzw(this, paramActivity));
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzx.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */