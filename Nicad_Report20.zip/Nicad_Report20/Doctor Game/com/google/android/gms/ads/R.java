package com.google.android.gms.ads;

public final class R {
  public static final class attr {
    public static final int adSize = 2130771968;
    
    public static final int adSizes = 2130771969;
    
    public static final int adUnitId = 2130771970;
  }
  
  public static final class style {
    public static final int Theme_IAPTheme = 2131427334;
  }
  
  public static final class styleable {
    public static final int[] AdsAttrs = new int[] { 2130771968, 2130771969, 2130771970 };
    
    public static final int AdsAttrs_adSize = 0;
    
    public static final int AdsAttrs_adSizes = 1;
    
    public static final int AdsAttrs_adUnitId = 2;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */