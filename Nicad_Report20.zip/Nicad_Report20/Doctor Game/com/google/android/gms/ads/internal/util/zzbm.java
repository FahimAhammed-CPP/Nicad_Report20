package com.google.android.gms.ads.internal.util;

import com.google.android.gms.internal.ads.zzakh;
import com.google.android.gms.internal.ads.zzakm;
import com.google.android.gms.internal.ads.zzchh;

final class zzbm implements zzakh {
  zzbm(zzchh paramzzchh) {}
  
  public final void zza(zzakm paramzzakm) {
    this.zza.zze((Throwable)paramzzakm);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzbm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */