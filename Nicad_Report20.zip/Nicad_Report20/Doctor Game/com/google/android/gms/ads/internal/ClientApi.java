package com.google.android.gms.ads.internal;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.widget.FrameLayout;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.client.zzbo;
import com.google.android.gms.ads.internal.client.zzbs;
import com.google.android.gms.ads.internal.client.zzcb;
import com.google.android.gms.ads.internal.client.zzcm;
import com.google.android.gms.ads.internal.client.zzq;
import com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel;
import com.google.android.gms.ads.internal.overlay.zzac;
import com.google.android.gms.ads.internal.overlay.zzae;
import com.google.android.gms.ads.internal.overlay.zzaf;
import com.google.android.gms.ads.internal.overlay.zzs;
import com.google.android.gms.ads.internal.overlay.zzt;
import com.google.android.gms.ads.internal.overlay.zzy;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.dynamic.ObjectWrapper;
import com.google.android.gms.internal.ads.zzbiu;
import com.google.android.gms.internal.ads.zzbjc;
import com.google.android.gms.internal.ads.zzbmi;
import com.google.android.gms.internal.ads.zzbmo;
import com.google.android.gms.internal.ads.zzbqr;
import com.google.android.gms.internal.ads.zzbqu;
import com.google.android.gms.internal.ads.zzbvk;
import com.google.android.gms.internal.ads.zzbyv;
import com.google.android.gms.internal.ads.zzbzc;
import com.google.android.gms.internal.ads.zzcbv;
import com.google.android.gms.internal.ads.zzccl;
import com.google.android.gms.internal.ads.zzcfg;
import com.google.android.gms.internal.ads.zzcgv;
import com.google.android.gms.internal.ads.zzcom;
import com.google.android.gms.internal.ads.zzdpk;
import com.google.android.gms.internal.ads.zzdpm;
import com.google.android.gms.internal.ads.zzdyy;
import com.google.android.gms.internal.ads.zzenj;
import com.google.android.gms.internal.ads.zzeyi;
import com.google.android.gms.internal.ads.zzeyj;
import com.google.android.gms.internal.ads.zzezw;
import com.google.android.gms.internal.ads.zzfbp;
import com.google.android.gms.internal.ads.zzfdd;
import java.util.HashMap;

public class ClientApi extends zzcb {
  public final zzbo zzb(IObjectWrapper paramIObjectWrapper, String paramString, zzbvk paramzzbvk, int paramInt) {
    Context context = (Context)ObjectWrapper.unwrap(paramIObjectWrapper);
    return (zzbo)new zzenj(zzcom.zza(context, paramzzbvk, paramInt), context, paramString);
  }
  
  public final zzbs zzc(IObjectWrapper paramIObjectWrapper, zzq paramzzq, String paramString, zzbvk paramzzbvk, int paramInt) {
    Context context = (Context)ObjectWrapper.unwrap(paramIObjectWrapper);
    zzeyi zzeyi = zzcom.zza(context, paramzzbvk, paramInt).zzr();
    zzeyi.zza(paramString);
    zzeyi.zzb(context);
    zzeyj zzeyj = zzeyi.zzc();
    zzbiu zzbiu = zzbjc.zzeq;
    return (zzbs)((paramInt >= ((Integer)zzay.zzc().zzb(zzbiu)).intValue()) ? zzeyj.zzb() : zzeyj.zza());
  }
  
  public final zzbs zzd(IObjectWrapper paramIObjectWrapper, zzq paramzzq, String paramString, zzbvk paramzzbvk, int paramInt) {
    Context context = (Context)ObjectWrapper.unwrap(paramIObjectWrapper);
    zzezw zzezw = zzcom.zza(context, paramzzbvk, paramInt).zzs();
    zzezw.zzc(context);
    zzezw.zza(paramzzq);
    zzezw.zzb(paramString);
    return (zzbs)zzezw.zzd().zza();
  }
  
  public final zzbs zze(IObjectWrapper paramIObjectWrapper, zzq paramzzq, String paramString, zzbvk paramzzbvk, int paramInt) {
    Context context = (Context)ObjectWrapper.unwrap(paramIObjectWrapper);
    zzfbp zzfbp = zzcom.zza(context, paramzzbvk, paramInt).zzt();
    zzfbp.zzc(context);
    zzfbp.zza(paramzzq);
    zzfbp.zzb(paramString);
    return (zzbs)zzfbp.zzd().zza();
  }
  
  public final zzbs zzf(IObjectWrapper paramIObjectWrapper, zzq paramzzq, String paramString, int paramInt) {
    return (zzbs)new zzs((Context)ObjectWrapper.unwrap(paramIObjectWrapper), paramzzq, paramString, new zzcgv(223104000, paramInt, true, false));
  }
  
  public final zzcm zzg(IObjectWrapper paramIObjectWrapper, int paramInt) {
    return (zzcm)zzcom.zza((Context)ObjectWrapper.unwrap(paramIObjectWrapper), null, paramInt).zzb();
  }
  
  public final zzbmi zzh(IObjectWrapper paramIObjectWrapper1, IObjectWrapper paramIObjectWrapper2) {
    return (zzbmi)new zzdpm((FrameLayout)ObjectWrapper.unwrap(paramIObjectWrapper1), (FrameLayout)ObjectWrapper.unwrap(paramIObjectWrapper2), 223104000);
  }
  
  public final zzbmo zzi(IObjectWrapper paramIObjectWrapper1, IObjectWrapper paramIObjectWrapper2, IObjectWrapper paramIObjectWrapper3) {
    return (zzbmo)new zzdpk((View)ObjectWrapper.unwrap(paramIObjectWrapper1), (HashMap)ObjectWrapper.unwrap(paramIObjectWrapper2), (HashMap)ObjectWrapper.unwrap(paramIObjectWrapper3));
  }
  
  public final zzbqu zzj(IObjectWrapper paramIObjectWrapper, zzbvk paramzzbvk, int paramInt, zzbqr paramzzbqr) {
    Context context = (Context)ObjectWrapper.unwrap(paramIObjectWrapper);
    zzdyy zzdyy = zzcom.zza(context, paramzzbvk, paramInt).zzj();
    zzdyy.zzb(context);
    zzdyy.zza(paramzzbqr);
    return (zzbqu)zzdyy.zzc().zzd();
  }
  
  public final zzbyv zzk(IObjectWrapper paramIObjectWrapper, zzbvk paramzzbvk, int paramInt) {
    return (zzbyv)zzcom.zza((Context)ObjectWrapper.unwrap(paramIObjectWrapper), paramzzbvk, paramInt).zzl();
  }
  
  public final zzbzc zzl(IObjectWrapper paramIObjectWrapper) {
    Activity activity = (Activity)ObjectWrapper.unwrap(paramIObjectWrapper);
    AdOverlayInfoParcel adOverlayInfoParcel = AdOverlayInfoParcel.zza(activity.getIntent());
    if (adOverlayInfoParcel == null)
      return (zzbzc)new zzt(activity); 
    int i = adOverlayInfoParcel.zzk;
    return (zzbzc)((i != 1) ? ((i != 2) ? ((i != 3) ? ((i != 4) ? ((i != 5) ? new zzt(activity) : new zzac(activity)) : new zzy(activity, adOverlayInfoParcel)) : new zzaf(activity)) : new zzae(activity)) : new zzs(activity));
  }
  
  public final zzcbv zzm(IObjectWrapper paramIObjectWrapper, zzbvk paramzzbvk, int paramInt) {
    Context context = (Context)ObjectWrapper.unwrap(paramIObjectWrapper);
    zzfdd zzfdd = zzcom.zza(context, paramzzbvk, paramInt).zzu();
    zzfdd.zzb(context);
    return (zzcbv)zzfdd.zzc().zzb();
  }
  
  public final zzccl zzn(IObjectWrapper paramIObjectWrapper, String paramString, zzbvk paramzzbvk, int paramInt) {
    Context context = (Context)ObjectWrapper.unwrap(paramIObjectWrapper);
    zzfdd zzfdd = zzcom.zza(context, paramzzbvk, paramInt).zzu();
    zzfdd.zzb(context);
    zzfdd.zza(paramString);
    return (zzccl)zzfdd.zzc().zza();
  }
  
  public final zzcfg zzo(IObjectWrapper paramIObjectWrapper, zzbvk paramzzbvk, int paramInt) {
    return (zzcfg)zzcom.zza((Context)ObjectWrapper.unwrap(paramIObjectWrapper), paramzzbvk, paramInt).zzo();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\ClientApi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */