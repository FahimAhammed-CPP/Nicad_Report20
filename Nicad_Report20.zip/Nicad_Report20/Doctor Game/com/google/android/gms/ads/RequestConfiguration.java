package com.google.android.gms.ads;

import com.google.android.gms.internal.ads.zzcgp;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.annotation.Nullable;

public class RequestConfiguration {
  public static final String MAX_AD_CONTENT_RATING_G = "G";
  
  public static final String MAX_AD_CONTENT_RATING_MA = "MA";
  
  public static final String MAX_AD_CONTENT_RATING_PG = "PG";
  
  public static final String MAX_AD_CONTENT_RATING_T = "T";
  
  public static final String MAX_AD_CONTENT_RATING_UNSPECIFIED = "";
  
  public static final int TAG_FOR_CHILD_DIRECTED_TREATMENT_FALSE = 0;
  
  public static final int TAG_FOR_CHILD_DIRECTED_TREATMENT_TRUE = 1;
  
  public static final int TAG_FOR_CHILD_DIRECTED_TREATMENT_UNSPECIFIED = -1;
  
  public static final int TAG_FOR_UNDER_AGE_OF_CONSENT_FALSE = 0;
  
  public static final int TAG_FOR_UNDER_AGE_OF_CONSENT_TRUE = 1;
  
  public static final int TAG_FOR_UNDER_AGE_OF_CONSENT_UNSPECIFIED = -1;
  
  public static final List zza = Arrays.asList(new String[] { "MA", "T", "PG", "G" });
  
  private final int zzb;
  
  private final int zzc;
  
  @Nullable
  private final String zzd;
  
  private final List zze;
  
  public String getMaxAdContentRating() {
    String str2 = this.zzd;
    String str1 = str2;
    if (str2 == null)
      str1 = ""; 
    return str1;
  }
  
  public int getTagForChildDirectedTreatment() {
    return this.zzb;
  }
  
  public int getTagForUnderAgeOfConsent() {
    return this.zzc;
  }
  
  public List<String> getTestDeviceIds() {
    return new ArrayList<String>(this.zze);
  }
  
  public Builder toBuilder() {
    Builder builder = new Builder();
    builder.setTagForChildDirectedTreatment(this.zzb);
    builder.setTagForUnderAgeOfConsent(this.zzc);
    builder.setMaxAdContentRating(this.zzd);
    builder.setTestDeviceIds(this.zze);
    return builder;
  }
  
  public static class Builder {
    private int zza = -1;
    
    private int zzb = -1;
    
    @Nullable
    private String zzc = null;
    
    private final List zzd = new ArrayList();
    
    public RequestConfiguration build() {
      return new RequestConfiguration(this.zza, this.zzb, this.zzc, this.zzd, null);
    }
    
    public Builder setMaxAdContentRating(@Nullable String param1String) {
      if (param1String == null || "".equals(param1String)) {
        this.zzc = null;
        return this;
      } 
      if ("G".equals(param1String) || "PG".equals(param1String) || "T".equals(param1String) || "MA".equals(param1String)) {
        this.zzc = param1String;
        return this;
      } 
      zzcgp.zzj("Invalid value passed to setMaxAdContentRating: ".concat(param1String));
      return this;
    }
    
    public Builder setTagForChildDirectedTreatment(int param1Int) {
      if (param1Int == -1 || param1Int == 0 || param1Int == 1) {
        this.zza = param1Int;
        return this;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Invalid value passed to setTagForChildDirectedTreatment: ");
      stringBuilder.append(param1Int);
      zzcgp.zzj(stringBuilder.toString());
      return this;
    }
    
    public Builder setTagForUnderAgeOfConsent(int param1Int) {
      if (param1Int == -1 || param1Int == 0 || param1Int == 1) {
        this.zzb = param1Int;
        return this;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Invalid value passed to setTagForUnderAgeOfConsent: ");
      stringBuilder.append(param1Int);
      zzcgp.zzj(stringBuilder.toString());
      return this;
    }
    
    public Builder setTestDeviceIds(@Nullable List<String> param1List) {
      this.zzd.clear();
      if (param1List != null)
        this.zzd.addAll(param1List); 
      return this;
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface MaxAdContentRating {}
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface TagForChildDirectedTreatment {}
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface TagForUnderAgeOfConsent {}
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\RequestConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */