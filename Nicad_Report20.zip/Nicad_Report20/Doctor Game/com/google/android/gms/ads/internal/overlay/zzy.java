package com.google.android.gms.ads.internal.overlay;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.RemoteException;
import com.google.android.gms.ads.internal.client.zza;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.zzt;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.internal.ads.zzbiu;
import com.google.android.gms.internal.ads.zzbjc;
import com.google.android.gms.internal.ads.zzbzb;
import com.google.android.gms.internal.ads.zzdkn;

public final class zzy extends zzbzb {
  private final AdOverlayInfoParcel zza;
  
  private final Activity zzb;
  
  private boolean zzc = false;
  
  private boolean zzd = false;
  
  public zzy(Activity paramActivity, AdOverlayInfoParcel paramAdOverlayInfoParcel) {
    this.zza = paramAdOverlayInfoParcel;
    this.zzb = paramActivity;
  }
  
  private final void zzb() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield zzd : Z
    //   6: ifne -> 36
    //   9: aload_0
    //   10: getfield zza : Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;
    //   13: getfield zzc : Lcom/google/android/gms/ads/internal/overlay/zzo;
    //   16: astore_1
    //   17: aload_1
    //   18: ifnull -> 28
    //   21: aload_1
    //   22: iconst_4
    //   23: invokeinterface zzf : (I)V
    //   28: aload_0
    //   29: iconst_1
    //   30: putfield zzd : Z
    //   33: aload_0
    //   34: monitorexit
    //   35: return
    //   36: aload_0
    //   37: monitorexit
    //   38: return
    //   39: astore_1
    //   40: aload_0
    //   41: monitorexit
    //   42: aload_1
    //   43: athrow
    // Exception table:
    //   from	to	target	type
    //   2	17	39	finally
    //   21	28	39	finally
    //   28	33	39	finally
  }
  
  public final boolean zzE() throws RemoteException {
    return false;
  }
  
  public final void zzg(int paramInt1, int paramInt2, Intent paramIntent) throws RemoteException {}
  
  public final void zzh() throws RemoteException {}
  
  public final void zzj(IObjectWrapper paramIObjectWrapper) throws RemoteException {}
  
  public final void zzk(Bundle paramBundle) {
    zzbiu zzbiu = zzbjc.zzhC;
    if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue())
      this.zzb.requestWindowFeature(1); 
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (paramBundle != null) {
      bool1 = bool2;
      if (paramBundle.getBoolean("com.google.android.gms.ads.internal.overlay.hasResumed", false))
        bool1 = true; 
    } 
    AdOverlayInfoParcel adOverlayInfoParcel = this.zza;
    if (adOverlayInfoParcel == null) {
      this.zzb.finish();
      return;
    } 
    if (bool1) {
      this.zzb.finish();
      return;
    } 
    if (paramBundle == null) {
      zza zza = adOverlayInfoParcel.zzb;
      if (zza != null)
        zza.onAdClicked(); 
      zzdkn zzdkn = this.zza.zzy;
      if (zzdkn != null)
        zzdkn.zzq(); 
      if (this.zzb.getIntent() != null && this.zzb.getIntent().getBooleanExtra("shouldCallOnOverlayOpened", true)) {
        zzo zzo = this.zza.zzc;
        if (zzo != null)
          zzo.zzb(); 
      } 
    } 
    zzt.zzh();
    Activity activity = this.zzb;
    adOverlayInfoParcel = this.zza;
    zzc zzc = adOverlayInfoParcel.zza;
    if (!zza.zzb((Context)activity, zzc, adOverlayInfoParcel.zzi, zzc.zzi))
      this.zzb.finish(); 
  }
  
  public final void zzl() throws RemoteException {
    if (this.zzb.isFinishing())
      zzb(); 
  }
  
  public final void zzn() throws RemoteException {
    zzo zzo = this.zza.zzc;
    if (zzo != null)
      zzo.zzbr(); 
    if (this.zzb.isFinishing())
      zzb(); 
  }
  
  public final void zzo() throws RemoteException {}
  
  public final void zzp() throws RemoteException {
    if (this.zzc) {
      this.zzb.finish();
      return;
    } 
    this.zzc = true;
    zzo zzo = this.zza.zzc;
    if (zzo != null)
      zzo.zzbK(); 
  }
  
  public final void zzq(Bundle paramBundle) throws RemoteException {
    paramBundle.putBoolean("com.google.android.gms.ads.internal.overlay.hasResumed", this.zzc);
  }
  
  public final void zzr() throws RemoteException {}
  
  public final void zzs() throws RemoteException {
    if (this.zzb.isFinishing())
      zzb(); 
  }
  
  public final void zzt() throws RemoteException {
    zzo zzo = this.zza.zzc;
    if (zzo != null)
      zzo.zze(); 
  }
  
  public final void zzv() throws RemoteException {}
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\overlay\zzy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */