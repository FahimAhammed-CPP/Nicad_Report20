package com.google.android.gms.ads.internal.client;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelWriter;

public final class zzff extends AbstractSafeParcelable {
  public static final Parcelable.Creator<zzff> CREATOR = new zzfg();
  
  public final boolean zza;
  
  public final boolean zzb;
  
  public final boolean zzc;
  
  public zzff(VideoOptions paramVideoOptions) {
    this(paramVideoOptions.getStartMuted(), paramVideoOptions.getCustomControlsRequested(), paramVideoOptions.getClickToExpandRequested());
  }
  
  public zzff(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    this.zza = paramBoolean1;
    this.zzb = paramBoolean2;
    this.zzc = paramBoolean3;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = SafeParcelWriter.beginObjectHeader(paramParcel);
    SafeParcelWriter.writeBoolean(paramParcel, 2, this.zza);
    SafeParcelWriter.writeBoolean(paramParcel, 3, this.zzb);
    SafeParcelWriter.writeBoolean(paramParcel, 4, this.zzc);
    SafeParcelWriter.finishObjectHeader(paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzff.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */