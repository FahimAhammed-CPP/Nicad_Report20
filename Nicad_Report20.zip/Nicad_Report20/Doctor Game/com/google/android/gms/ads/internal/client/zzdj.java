package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzasa;
import com.google.android.gms.internal.ads.zzasb;

public abstract class zzdj extends zzasa implements zzdk {
  public zzdj() {
    super("com.google.android.gms.ads.internal.client.IVideoController");
  }
  
  public static zzdk zzb(IBinder paramIBinder) {
    if (paramIBinder == null)
      return null; 
    IInterface iInterface = paramIBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IVideoController");
    return (iInterface instanceof zzdk) ? (zzdk)iInterface : new zzdi(paramIBinder);
  }
  
  protected final boolean zzbI(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2) throws RemoteException {
    zzdn zzdn1;
    float f;
    boolean bool;
    IBinder iBinder;
    zzdn zzdn2;
    switch (paramInt1) {
      default:
        return false;
      case 13:
        zzn();
        paramParcel2.writeNoException();
        return true;
      case 12:
        bool = zzo();
        paramParcel2.writeNoException();
        zzasb.zzd(paramParcel2, bool);
        return true;
      case 11:
        zzdn1 = zzi();
        paramParcel2.writeNoException();
        zzasb.zzg(paramParcel2, zzdn1);
        return true;
      case 10:
        bool = zzp();
        paramParcel2.writeNoException();
        zzasb.zzd(paramParcel2, bool);
        return true;
      case 9:
        f = zze();
        paramParcel2.writeNoException();
        paramParcel2.writeFloat(f);
        return true;
      case 8:
        iBinder = zzdn1.readStrongBinder();
        if (iBinder == null) {
          iBinder = null;
        } else {
          IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IVideoLifecycleCallbacks");
          if (iInterface instanceof zzdn) {
            zzdn2 = (zzdn)iInterface;
          } else {
            zzdn2 = new zzdl((IBinder)zzdn2);
          } 
        } 
        zzasb.zzc((Parcel)zzdn1);
        zzm(zzdn2);
        paramParcel2.writeNoException();
        return true;
      case 7:
        f = zzf();
        paramParcel2.writeNoException();
        paramParcel2.writeFloat(f);
        return true;
      case 6:
        f = zzg();
        paramParcel2.writeNoException();
        paramParcel2.writeFloat(f);
        return true;
      case 5:
        paramInt1 = zzh();
        paramParcel2.writeNoException();
        paramParcel2.writeInt(paramInt1);
        return true;
      case 4:
        bool = zzq();
        paramParcel2.writeNoException();
        zzasb.zzd(paramParcel2, bool);
        return true;
      case 3:
        bool = zzasb.zzh((Parcel)zzdn1);
        zzasb.zzc((Parcel)zzdn1);
        zzj(bool);
        paramParcel2.writeNoException();
        return true;
      case 2:
        zzk();
        paramParcel2.writeNoException();
        return true;
      case 1:
        break;
    } 
    zzl();
    paramParcel2.writeNoException();
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzdj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */