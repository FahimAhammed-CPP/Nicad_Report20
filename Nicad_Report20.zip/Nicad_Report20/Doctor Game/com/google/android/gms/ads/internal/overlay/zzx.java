package com.google.android.gms.ads.internal.overlay;

public interface zzx {
  void zza(boolean paramBoolean);
  
  void zzb(int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\overlay\zzx.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */