package com.google.android.gms.ads.internal.util;

import android.content.Context;
import androidx.work.Configuration;
import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;
import androidx.work.WorkRequest;
import com.google.android.gms.ads.internal.offline.buffering.OfflineNotificationPoster;
import com.google.android.gms.ads.internal.offline.buffering.OfflinePingSender;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.dynamic.ObjectWrapper;
import com.google.android.gms.internal.ads.zzcgp;

public class WorkManagerUtil extends zzbq {
  private static void zzb(Context paramContext) {
    try {
      WorkManager.initialize(paramContext.getApplicationContext(), (new Configuration.Builder()).build());
      return;
    } catch (IllegalStateException illegalStateException) {
      return;
    } 
  }
  
  public final void zze(IObjectWrapper paramIObjectWrapper) {
    Context context = (Context)ObjectWrapper.unwrap(paramIObjectWrapper);
    zzb(context);
    try {
      WorkManager workManager = WorkManager.getInstance(context);
      workManager.cancelAllWorkByTag("offline_ping_sender_work");
      Constraints constraints = (new Constraints.Builder()).setRequiredNetworkType(NetworkType.CONNECTED).build();
      workManager.enqueue(((OneTimeWorkRequest.Builder)((OneTimeWorkRequest.Builder)(new OneTimeWorkRequest.Builder(OfflinePingSender.class)).setConstraints(constraints)).addTag("offline_ping_sender_work")).build());
      return;
    } catch (IllegalStateException illegalStateException) {
      zzcgp.zzk("Failed to instantiate WorkManager.", illegalStateException);
      return;
    } 
  }
  
  public final boolean zzf(IObjectWrapper paramIObjectWrapper, String paramString1, String paramString2) {
    Context context = (Context)ObjectWrapper.unwrap(paramIObjectWrapper);
    zzb(context);
    Constraints constraints = (new Constraints.Builder()).setRequiredNetworkType(NetworkType.CONNECTED).build();
    Data data = (new Data.Builder()).putString("uri", paramString1).putString("gws_query_id", paramString2).build();
    OneTimeWorkRequest oneTimeWorkRequest = (OneTimeWorkRequest)((OneTimeWorkRequest.Builder)((OneTimeWorkRequest.Builder)((OneTimeWorkRequest.Builder)(new OneTimeWorkRequest.Builder(OfflineNotificationPoster.class)).setConstraints(constraints)).setInputData(data)).addTag("offline_notification_work")).build();
    try {
      WorkManager workManager = WorkManager.getInstance(context);
      workManager.enqueue((WorkRequest)oneTimeWorkRequest);
      return true;
    } catch (IllegalStateException illegalStateException) {
      zzcgp.zzk("Failed to instantiate WorkManager.", illegalStateException);
      return false;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\WorkManagerUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */