package com.google.android.gms.ads.internal.client;

import android.content.Context;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.dynamic.ObjectWrapper;
import com.google.android.gms.dynamic.RemoteCreator;
import com.google.android.gms.internal.ads.zzcgp;

public final class zzek extends RemoteCreator {
  public zzek() {
    super("com.google.android.gms.ads.MobileAdsSettingManagerCreatorImpl");
  }
  
  public final zzcm zza(Context paramContext) {
    try {
      zzcm zzcm;
      IObjectWrapper iObjectWrapper = ObjectWrapper.wrap(paramContext);
      IBinder iBinder = ((zzcn)getRemoteCreatorInstance(paramContext)).zze(iObjectWrapper, 223104000);
      if (iBinder == null)
        return null; 
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IMobileAdsSettingManager");
      if (iInterface instanceof zzcm) {
        zzcm = (zzcm)iInterface;
      } else {
        zzcm = new zzck((IBinder)zzcm);
      } 
    } catch (RemoteException remoteException) {
      zzcgp.zzk("Could not get remote MobileAdsSettingManager.", (Throwable)remoteException);
      return null;
    } catch (com.google.android.gms.dynamic.RemoteCreator.RemoteCreatorException remoteCreatorException) {}
    return (zzcm)remoteCreatorException;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzek.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */