package com.google.android.gms.ads.internal.client;

import com.google.android.gms.internal.ads.zzbiv;
import com.google.android.gms.internal.ads.zzbiw;
import com.google.android.gms.internal.ads.zzbja;

public final class zzay {
  private static final zzay zza = new zzay();
  
  private final zzbiv zzb;
  
  private final zzbiw zzc;
  
  private final zzbja zzd;
  
  protected zzay() {
    this.zzb = zzbiv1;
    this.zzc = zzbiw1;
    this.zzd = zzbja1;
  }
  
  public static zzbiv zza() {
    return zza.zzb;
  }
  
  public static zzbiw zzb() {
    return zza.zzc;
  }
  
  public static zzbja zzc() {
    return zza.zzd;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzay.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */