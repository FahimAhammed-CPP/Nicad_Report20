package com.google.android.gms.ads.internal.util;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import com.google.android.gms.ads.internal.client.zzaw;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.zzt;
import com.google.android.gms.internal.ads.zzbiu;
import com.google.android.gms.internal.ads.zzbjc;
import com.google.android.gms.internal.ads.zzcgi;

public class zzu extends zzt {
  static final boolean zzf(int paramInt1, int paramInt2, int paramInt3) {
    return (Math.abs(paramInt1 - paramInt2) <= paramInt3);
  }
  
  public final boolean zze(Activity paramActivity, Configuration paramConfiguration) {
    zzbiu zzbiu2 = zzbjc.zzdW;
    if (!((Boolean)zzay.zzc().zzb(zzbiu2)).booleanValue())
      return false; 
    zzbiu2 = zzbjc.zzdY;
    if (((Boolean)zzay.zzc().zzb(zzbiu2)).booleanValue())
      return paramActivity.isInMultiWindowMode(); 
    zzaw.zzb();
    int j = zzcgi.zzw((Context)paramActivity, paramConfiguration.screenHeightDp);
    int k = zzcgi.zzw((Context)paramActivity, paramConfiguration.screenWidthDp);
    WindowManager windowManager = (WindowManager)paramActivity.getApplicationContext().getSystemService("window");
    zzt.zzp();
    DisplayMetrics displayMetrics = zzs.zzr(windowManager);
    int m = displayMetrics.heightPixels;
    int n = displayMetrics.widthPixels;
    int i = paramActivity.getResources().getIdentifier("status_bar_height", "dimen", "android");
    if (i > 0) {
      i = paramActivity.getResources().getDimensionPixelSize(i);
    } else {
      i = 0;
    } 
    double d = (paramActivity.getResources().getDisplayMetrics()).density;
    Double.isNaN(d);
    long l = Math.round(d + 0.5D);
    zzbiu zzbiu1 = zzbjc.zzdU;
    int i1 = (int)l * ((Integer)zzay.zzc().zzb(zzbiu1)).intValue();
    return zzf(m, j + i, i1) ? (!zzf(n, k, i1)) : true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzu.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */