package com.google.android.gms.ads.internal;

import android.os.RemoteException;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.android.gms.ads.internal.util.zze;
import com.google.android.gms.internal.ads.zzffe;

final class zzm extends WebViewClient {
  zzm(zzs paramzzs) {}
  
  public final void onReceivedError(WebView paramWebView, WebResourceRequest paramWebResourceRequest, WebResourceError paramWebResourceError) {
    zzs zzs1 = this.zza;
    if (zzs.zzh(zzs1) != null)
      try {
        zzs.zzh(zzs1).zzf(zzffe.zzd(1, null, null));
      } catch (RemoteException remoteException) {
        zze.zzl("#007 Could not call remote method.", (Throwable)remoteException);
      }  
    zzs1 = this.zza;
    if (zzs.zzh(zzs1) != null)
      try {
        zzs.zzh(zzs1).zze(0);
        return;
      } catch (RemoteException remoteException) {
        zze.zzl("#007 Could not call remote method.", (Throwable)remoteException);
      }  
  }
  
  public final boolean shouldOverrideUrlLoading(WebView paramWebView, String paramString) {
    if (paramString.startsWith(this.zza.zzq()))
      return false; 
    if (paramString.startsWith("gmsg://noAdLoaded")) {
      zzs zzs2 = this.zza;
      if (zzs.zzh(zzs2) != null)
        try {
          zzs.zzh(zzs2).zzf(zzffe.zzd(3, null, null));
        } catch (RemoteException remoteException) {
          zze.zzl("#007 Could not call remote method.", (Throwable)remoteException);
        }  
      zzs2 = this.zza;
      if (zzs.zzh(zzs2) != null)
        try {
          zzs.zzh(zzs2).zze(3);
        } catch (RemoteException remoteException) {
          zze.zzl("#007 Could not call remote method.", (Throwable)remoteException);
        }  
      this.zza.zzV(0);
      return true;
    } 
    if (paramString.startsWith("gmsg://scriptLoadFailed")) {
      zzs zzs2 = this.zza;
      if (zzs.zzh(zzs2) != null)
        try {
          zzs.zzh(zzs2).zzf(zzffe.zzd(1, null, null));
        } catch (RemoteException remoteException) {
          zze.zzl("#007 Could not call remote method.", (Throwable)remoteException);
        }  
      zzs2 = this.zza;
      if (zzs.zzh(zzs2) != null)
        try {
          zzs.zzh(zzs2).zze(0);
        } catch (RemoteException remoteException) {
          zze.zzl("#007 Could not call remote method.", (Throwable)remoteException);
        }  
      this.zza.zzV(0);
      return true;
    } 
    if (paramString.startsWith("gmsg://adResized")) {
      zzs zzs2 = this.zza;
      if (zzs.zzh(zzs2) != null)
        try {
          zzs.zzh(zzs2).zzi();
        } catch (RemoteException remoteException) {
          zze.zzl("#007 Could not call remote method.", (Throwable)remoteException);
        }  
      int i = this.zza.zzb(paramString);
      this.zza.zzV(i);
      return true;
    } 
    if (paramString.startsWith("gmsg://"))
      return true; 
    zzs zzs1 = this.zza;
    if (zzs.zzh(zzs1) != null)
      try {
        zzs.zzh(zzs1).zzc();
        zzs.zzh(this.zza).zzh();
      } catch (RemoteException remoteException) {
        zze.zzl("#007 Could not call remote method.", (Throwable)remoteException);
      }  
    String str = zzs.zzo(this.zza, paramString);
    zzs.zzw(this.zza, str);
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\zzm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */