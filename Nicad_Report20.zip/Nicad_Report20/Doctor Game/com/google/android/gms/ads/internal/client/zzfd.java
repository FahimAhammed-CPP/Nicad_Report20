package com.google.android.gms.ads.internal.client;

import android.os.RemoteException;
import com.google.android.gms.ads.formats.ShouldDelayBannerRenderingListener;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.dynamic.ObjectWrapper;
import com.google.android.gms.internal.ads.zzbnu;

public final class zzfd extends zzbnu {
  private final ShouldDelayBannerRenderingListener zza;
  
  public zzfd(ShouldDelayBannerRenderingListener paramShouldDelayBannerRenderingListener) {
    this.zza = paramShouldDelayBannerRenderingListener;
  }
  
  public final boolean zzb(IObjectWrapper paramIObjectWrapper) throws RemoteException {
    return this.zza.shouldDelayBannerRendering((Runnable)ObjectWrapper.unwrap(paramIObjectWrapper));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzfd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */