package com.google.android.gms.ads.nonagon.signalgeneration;

import com.google.android.gms.ads.internal.util.zze;
import com.google.android.gms.ads.query.QueryInfo;
import com.google.android.gms.ads.query.QueryInfoGenerationCallback;
import org.json.JSONException;
import org.json.JSONObject;

final class zzap extends QueryInfoGenerationCallback {
  zzap(TaggingLibraryJsInterface paramTaggingLibraryJsInterface, String paramString) {}
  
  public final void onFailure(String paramString) {
    zze.zzj("Failed to generate query info for the tagging library, error: ".concat(String.valueOf(paramString)));
    paramString = String.format("window.postMessage({'paw_id': '%1$s', 'error': '%2$s'}, '*');", new Object[] { this.zza, paramString });
    TaggingLibraryJsInterface.zza(this.zzb).evaluateJavascript(paramString, null);
  }
  
  public final void onSuccess(QueryInfo paramQueryInfo) {
    String str1;
    String str2 = paramQueryInfo.getQuery();
    try {
      JSONObject jSONObject = new JSONObject();
      jSONObject.put("paw_id", this.zza);
      jSONObject.put("signal", str2);
      str2 = String.format("window.postMessage(%1$s, '*');", new Object[] { jSONObject });
      str1 = str2;
    } catch (JSONException jSONException) {
      str1 = String.format("window.postMessage({'paw_id': '%1$s', 'signal': '%2$s'}, '*');", new Object[] { this.zza, str1.getQuery() });
    } 
    TaggingLibraryJsInterface.zza(this.zzb).evaluateJavascript(str1, null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\nonagon\signalgeneration\zzap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */