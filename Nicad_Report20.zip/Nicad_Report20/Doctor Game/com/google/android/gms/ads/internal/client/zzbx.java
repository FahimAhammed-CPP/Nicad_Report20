package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzarz;

public final class zzbx extends zzarz implements zzbz {
  zzbx(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IAppEventListener");
  }
  
  public final void zzc(String paramString1, String paramString2) throws RemoteException {
    Parcel parcel = zza();
    parcel.writeString(paramString1);
    parcel.writeString(paramString2);
    zzbl(1, parcel);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzbx.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */