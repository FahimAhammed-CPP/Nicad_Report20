package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.ResponseInfo;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelWriter;

public final class zze extends AbstractSafeParcelable {
  public static final Parcelable.Creator<zze> CREATOR = new zzf();
  
  public final int zza;
  
  public final String zzb;
  
  public final String zzc;
  
  public zze zzd;
  
  public IBinder zze;
  
  public zze(int paramInt, String paramString1, String paramString2, zze paramzze, IBinder paramIBinder) {
    this.zza = paramInt;
    this.zzb = paramString1;
    this.zzc = paramString2;
    this.zzd = paramzze;
    this.zze = paramIBinder;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = SafeParcelWriter.beginObjectHeader(paramParcel);
    SafeParcelWriter.writeInt(paramParcel, 1, this.zza);
    SafeParcelWriter.writeString(paramParcel, 2, this.zzb, false);
    SafeParcelWriter.writeString(paramParcel, 3, this.zzc, false);
    SafeParcelWriter.writeParcelable(paramParcel, 4, (Parcelable)this.zzd, paramInt, false);
    SafeParcelWriter.writeIBinder(paramParcel, 5, this.zze, false);
    SafeParcelWriter.finishObjectHeader(paramParcel, i);
  }
  
  public final AdError zza() {
    AdError adError;
    zze zze1 = this.zzd;
    if (zze1 == null) {
      zze1 = null;
    } else {
      adError = new AdError(zze1.zza, zze1.zzb, zze1.zzc);
    } 
    return new AdError(this.zza, this.zzb, this.zzc, adError);
  }
  
  public final LoadAdError zzb() {
    AdError adError;
    zze zze1 = this.zzd;
    IInterface iInterface = null;
    if (zze1 == null) {
      zze1 = null;
    } else {
      adError = new AdError(zze1.zza, zze1.zzb, zze1.zzc);
    } 
    int i = this.zza;
    String str1 = this.zzb;
    String str2 = this.zzc;
    IBinder iBinder = this.zze;
    if (iBinder != null) {
      iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IResponseInfo");
      if (iInterface instanceof zzdh) {
        iInterface = iInterface;
      } else {
        iInterface = new zzdf(iBinder);
      } 
    } 
    return new LoadAdError(i, str1, str2, adError, ResponseInfo.zza((zzdh)iInterface));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zze.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */