package com.google.android.gms.ads.nonagon.signalgeneration;

import com.google.android.gms.internal.ads.zzcbc;
import com.google.android.gms.internal.ads.zzecf;
import com.google.android.gms.internal.ads.zzfyn;
import com.google.android.gms.internal.ads.zzfzg;
import com.google.android.gms.internal.ads.zzfzp;
import java.util.concurrent.Executor;

public final class zzak implements zzfyn {
  private final Executor zza;
  
  private final zzecf zzb;
  
  public zzak(Executor paramExecutor, zzecf paramzzecf) {
    this.zza = paramExecutor;
    this.zzb = paramzzecf;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\nonagon\signalgeneration\zzak.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */