package com.google.android.gms.ads.internal.util;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

final class zzr extends BroadcastReceiver {
  public final void onReceive(Context paramContext, Intent paramIntent) {
    if ("android.intent.action.USER_PRESENT".equals(paramIntent.getAction())) {
      zzs.zzd(this.zza, true);
      return;
    } 
    if ("android.intent.action.SCREEN_OFF".equals(paramIntent.getAction()))
      zzs.zzd(this.zza, false); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */