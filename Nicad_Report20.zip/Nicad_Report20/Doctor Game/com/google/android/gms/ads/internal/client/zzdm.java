package com.google.android.gms.ads.internal.client;

import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzasa;
import com.google.android.gms.internal.ads.zzasb;

public abstract class zzdm extends zzasa implements zzdn {
  public zzdm() {
    super("com.google.android.gms.ads.internal.client.IVideoLifecycleCallbacks");
  }
  
  protected final boolean zzbI(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2) throws RemoteException {
    if (paramInt1 != 1) {
      if (paramInt1 != 2) {
        if (paramInt1 != 3) {
          if (paramInt1 != 4) {
            if (paramInt1 != 5)
              return false; 
            boolean bool = zzasb.zzh(paramParcel1);
            zzasb.zzc(paramParcel1);
            zzf(bool);
          } else {
            zze();
          } 
        } else {
          zzg();
        } 
      } else {
        zzh();
      } 
    } else {
      zzi();
    } 
    paramParcel2.writeNoException();
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzdm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */