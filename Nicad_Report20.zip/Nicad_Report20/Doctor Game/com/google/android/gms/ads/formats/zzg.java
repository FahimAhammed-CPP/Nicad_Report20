package com.google.android.gms.ads.formats;

import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

@Deprecated
public final class zzg extends FrameLayout {
  public final void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    throw null;
  }
  
  public final void bringChildToFront(View paramView) {
    throw null;
  }
  
  public final boolean dispatchTouchEvent(MotionEvent paramMotionEvent) {
    throw null;
  }
  
  public final void onVisibilityChanged(View paramView, int paramInt) {
    throw null;
  }
  
  public final void removeAllViews() {
    throw null;
  }
  
  public final void removeView(View paramView) {
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\formats\zzg.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */