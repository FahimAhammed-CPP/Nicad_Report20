package com.google.android.gms.ads.internal.util;

import android.content.Context;
import android.webkit.CookieManager;
import android.webkit.WebResourceResponse;
import com.google.android.gms.internal.ads.zzbep;
import com.google.android.gms.internal.ads.zzcmp;
import com.google.android.gms.internal.ads.zzcmw;
import com.google.android.gms.internal.ads.zzcnt;
import java.io.InputStream;
import java.util.Map;

public class zzt extends zzaa {
  public zzt() {
    super(null);
  }
  
  public final int zza() {
    return 16974374;
  }
  
  public final CookieManager zzb(Context paramContext) {
    com.google.android.gms.ads.internal.zzt.zzp();
    if (zzs.zzB())
      return null; 
    try {
      return CookieManager.getInstance();
    } finally {
      paramContext = null;
      zze.zzh("Failed to obtain CookieManager.", (Throwable)paramContext);
      com.google.android.gms.ads.internal.zzt.zzo().zzt((Throwable)paramContext, "ApiLevelUtil.getCookieManager");
    } 
  }
  
  public final WebResourceResponse zzc(String paramString1, String paramString2, int paramInt, String paramString3, Map paramMap, InputStream paramInputStream) {
    return new WebResourceResponse(paramString1, paramString2, paramInt, paramString3, paramMap, paramInputStream);
  }
  
  public final zzcmw zzd(zzcmp paramzzcmp, zzbep paramzzbep, boolean paramBoolean) {
    return (zzcmw)new zzcnt(paramzzcmp, paramzzbep, paramBoolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */