package com.google.android.gms.ads.internal.util;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.PointF;
import android.net.Uri;
import android.os.Handler;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.zzt;
import com.google.android.gms.internal.ads.zzbiu;
import com.google.android.gms.internal.ads.zzbjc;
import com.google.android.gms.internal.ads.zzchc;
import com.google.android.gms.internal.ads.zzeag;
import com.google.android.gms.internal.ads.zzeak;
import com.google.android.gms.internal.ads.zzfzq;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public final class zzas {
  private final Context zza;
  
  private final zzeak zzb;
  
  private String zzc;
  
  private String zzd;
  
  private String zze;
  
  private String zzf;
  
  private int zzg = 0;
  
  private int zzh;
  
  private PointF zzi;
  
  private PointF zzj;
  
  private Handler zzk;
  
  private Runnable zzl = new zzar(this);
  
  public zzas(Context paramContext) {
    this.zza = paramContext;
    this.zzh = ViewConfiguration.get(paramContext).getScaledTouchSlop();
    zzt.zzt().zzb();
    this.zzk = zzt.zzt().zza();
    this.zzb = zzt.zzs().zza();
  }
  
  public zzas(Context paramContext, String paramString) {
    this(paramContext);
    this.zzc = paramString;
  }
  
  private final void zzs(Context paramContext) {
    ArrayList arrayList = new ArrayList();
    int i = zzu(arrayList, "None", true);
    int j = zzu(arrayList, "Shake", true);
    int k = zzu(arrayList, "Flick", true);
    zzeag zzeag = zzeag.zza;
    int m = this.zzb.zza().ordinal();
    if (m != 1) {
      if (m == 2)
        i = k; 
    } else {
      i = j;
    } 
    zzt.zzp();
    AlertDialog.Builder builder = zzs.zzG(paramContext);
    AtomicInteger atomicInteger = new AtomicInteger(i);
    builder.setTitle("Setup gesture");
    builder.setSingleChoiceItems((CharSequence[])arrayList.toArray((Object[])new String[0]), i, new zzaj(atomicInteger));
    builder.setNegativeButton("Dismiss", new zzak(this));
    builder.setPositiveButton("Save", new zzal(this, atomicInteger, i, j, k));
    builder.setOnCancelListener(new zzam(this));
    builder.create().show();
  }
  
  private final boolean zzt(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    return (Math.abs(this.zzi.x - paramFloat1) < this.zzh && Math.abs(this.zzi.y - paramFloat2) < this.zzh && Math.abs(this.zzj.x - paramFloat3) < this.zzh && Math.abs(this.zzj.y - paramFloat4) < this.zzh);
  }
  
  private static final int zzu(List<String> paramList, String paramString, boolean paramBoolean) {
    if (!paramBoolean)
      return -1; 
    paramList.add(paramString);
    return paramList.size() - 1;
  }
  
  public final String toString() {
    StringBuilder stringBuilder = new StringBuilder(100);
    stringBuilder.append("{Dialog: ");
    stringBuilder.append(this.zzc);
    stringBuilder.append(",DebugSignal: ");
    stringBuilder.append(this.zzf);
    stringBuilder.append(",AFMA Version: ");
    stringBuilder.append(this.zze);
    stringBuilder.append(",Ad Unit ID: ");
    stringBuilder.append(this.zzd);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public final void zzm(MotionEvent paramMotionEvent) {
    Handler handler;
    int i = paramMotionEvent.getActionMasked();
    int k = paramMotionEvent.getHistorySize();
    int j = paramMotionEvent.getPointerCount();
    if (i == 0) {
      this.zzg = 0;
      this.zzi = new PointF(paramMotionEvent.getX(0), paramMotionEvent.getY(0));
      return;
    } 
    int m = this.zzg;
    if (m == -1)
      return; 
    if (m == 0) {
      if (i == 5) {
        this.zzg = 5;
        this.zzj = new PointF(paramMotionEvent.getX(1), paramMotionEvent.getY(1));
        handler = this.zzk;
        Runnable runnable = this.zzl;
        zzbiu zzbiu = zzbjc.zzdO;
        handler.postDelayed(runnable, ((Long)zzay.zzc().zzb(zzbiu)).longValue());
        return;
      } 
    } else if (m == 5) {
      if (j != 2) {
        this.zzg = -1;
        this.zzk.removeCallbacks(this.zzl);
        return;
      } 
      if (i == 2) {
        i = 0;
        j = 0;
        while (i < k) {
          j |= zzt(handler.getHistoricalX(0, i), handler.getHistoricalY(0, i), handler.getHistoricalX(1, i), handler.getHistoricalY(1, i)) ^ true;
          i++;
        } 
        if (!zzt(handler.getX(), handler.getY(), handler.getX(1), handler.getY(1)) || j != 0) {
          this.zzg = -1;
          this.zzk.removeCallbacks(this.zzl);
          return;
        } 
      } 
    } 
  }
  
  public final void zzn(String paramString) {
    this.zzd = paramString;
  }
  
  public final void zzo(String paramString) {
    this.zze = paramString;
  }
  
  public final void zzp(String paramString) {
    this.zzc = paramString;
  }
  
  public final void zzq(String paramString) {
    this.zzf = paramString;
  }
  
  public final void zzr() {
    try {
      if (!(this.zza instanceof android.app.Activity)) {
        zze.zzi("Can not create dialog without Activity Context");
        return;
      } 
      boolean bool = TextUtils.isEmpty(zzt.zzs().zzb());
      String str1 = "Creative preview (enabled)";
      if (true == bool)
        str1 = "Creative preview"; 
      bool = zzt.zzs().zzm();
      String str2 = "Troubleshooting (enabled)";
      if (true != bool)
        str2 = "Troubleshooting"; 
      ArrayList arrayList = new ArrayList();
      int i = zzu(arrayList, "Ad information", true);
      int j = zzu(arrayList, str1, true);
      int k = zzu(arrayList, str2, true);
      zzbiu zzbiu = zzbjc.zzhT;
      bool = ((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue();
      int m = zzu(arrayList, "Open ad inspector", bool);
      int n = zzu(arrayList, "Ad inspector settings", bool);
      zzt.zzp();
      AlertDialog.Builder builder = zzs.zzG(this.zza);
      builder.setTitle("Select a debug mode").setItems((CharSequence[])arrayList.toArray((Object[])new String[0]), new zzap(this, i, j, k, m, n));
      builder.create().show();
      return;
    } catch (android.view.WindowManager.BadTokenException badTokenException) {
      zze.zzb("", (Throwable)badTokenException);
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzas.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */