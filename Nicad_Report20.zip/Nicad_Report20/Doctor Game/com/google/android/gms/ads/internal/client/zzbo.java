package com.google.android.gms.ads.internal.client;

import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.gms.ads.formats.AdManagerAdViewOptions;
import com.google.android.gms.ads.formats.PublisherAdViewOptions;
import com.google.android.gms.internal.ads.zzbls;
import com.google.android.gms.internal.ads.zzbnc;
import com.google.android.gms.internal.ads.zzbnf;
import com.google.android.gms.internal.ads.zzbni;
import com.google.android.gms.internal.ads.zzbnl;
import com.google.android.gms.internal.ads.zzbnp;
import com.google.android.gms.internal.ads.zzbns;
import com.google.android.gms.internal.ads.zzbsc;
import com.google.android.gms.internal.ads.zzbsl;

public interface zzbo extends IInterface {
  zzbl zze() throws RemoteException;
  
  void zzf(zzbnc paramzzbnc) throws RemoteException;
  
  void zzg(zzbnf paramzzbnf) throws RemoteException;
  
  void zzh(String paramString, zzbnl paramzzbnl, zzbni paramzzbni) throws RemoteException;
  
  void zzi(zzbsl paramzzbsl) throws RemoteException;
  
  void zzj(zzbnp paramzzbnp, zzq paramzzq) throws RemoteException;
  
  void zzk(zzbns paramzzbns) throws RemoteException;
  
  void zzl(zzbf paramzzbf) throws RemoteException;
  
  void zzm(AdManagerAdViewOptions paramAdManagerAdViewOptions) throws RemoteException;
  
  void zzn(zzbsc paramzzbsc) throws RemoteException;
  
  void zzo(zzbls paramzzbls) throws RemoteException;
  
  void zzp(PublisherAdViewOptions paramPublisherAdViewOptions) throws RemoteException;
  
  void zzq(zzcd paramzzcd) throws RemoteException;
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzbo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */