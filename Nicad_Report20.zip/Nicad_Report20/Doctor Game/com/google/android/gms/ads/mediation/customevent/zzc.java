package com.google.android.gms.ads.mediation.customevent;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.mediation.MediationNativeListener;
import com.google.android.gms.ads.mediation.UnifiedNativeAdMapper;
import com.google.android.gms.internal.ads.zzcgp;

final class zzc implements CustomEventNativeListener {
  private final CustomEventAdapter zza;
  
  private final MediationNativeListener zzb;
  
  public zzc(CustomEventAdapter paramCustomEventAdapter, MediationNativeListener paramMediationNativeListener) {
    this.zza = paramCustomEventAdapter;
    this.zzb = paramMediationNativeListener;
  }
  
  public final void onAdClicked() {
    zzcgp.zze("Custom event adapter called onAdClicked.");
    this.zzb.onAdClicked(this.zza);
  }
  
  public final void onAdClosed() {
    zzcgp.zze("Custom event adapter called onAdClosed.");
    this.zzb.onAdClosed(this.zza);
  }
  
  public final void onAdFailedToLoad(int paramInt) {
    zzcgp.zze("Custom event adapter called onAdFailedToLoad.");
    this.zzb.onAdFailedToLoad(this.zza, paramInt);
  }
  
  public final void onAdFailedToLoad(AdError paramAdError) {
    zzcgp.zze("Custom event adapter called onAdFailedToLoad.");
    this.zzb.onAdFailedToLoad(this.zza, paramAdError);
  }
  
  public final void onAdImpression() {
    zzcgp.zze("Custom event adapter called onAdImpression.");
    this.zzb.onAdImpression(this.zza);
  }
  
  public final void onAdLeftApplication() {
    zzcgp.zze("Custom event adapter called onAdLeftApplication.");
    this.zzb.onAdLeftApplication(this.zza);
  }
  
  public final void onAdLoaded(UnifiedNativeAdMapper paramUnifiedNativeAdMapper) {
    zzcgp.zze("Custom event adapter called onAdLoaded.");
    this.zzb.onAdLoaded(this.zza, paramUnifiedNativeAdMapper);
  }
  
  public final void onAdOpened() {
    zzcgp.zze("Custom event adapter called onAdOpened.");
    this.zzb.onAdOpened(this.zza);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\mediation\customevent\zzc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */