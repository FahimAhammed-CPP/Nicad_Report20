package com.google.android.gms.ads.mediation;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.rewarded.RewardItem;

public interface MediationRewardedAdCallback extends MediationAdCallback {
  void onAdFailedToShow(AdError paramAdError);
  
  @Deprecated
  void onAdFailedToShow(String paramString);
  
  void onUserEarnedReward(RewardItem paramRewardItem);
  
  void onVideoComplete();
  
  void onVideoStart();
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\mediation\MediationRewardedAdCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */