package com.google.android.gms.ads.internal.client;

import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzcgp;

final class zzel implements Runnable {
  zzel(zzen paramzzen) {}
  
  public final void run() {
    zzeo zzeo = this.zza.zza;
    if (zzeo.zzb(zzeo) != null)
      try {
        zzeo.zzb(zzeo).zze(1);
        return;
      } catch (RemoteException remoteException) {
        zzcgp.zzk("Could not notify onAdFailedToLoad event.", (Throwable)remoteException);
      }  
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */