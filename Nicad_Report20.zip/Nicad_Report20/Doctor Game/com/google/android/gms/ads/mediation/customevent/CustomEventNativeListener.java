package com.google.android.gms.ads.mediation.customevent;

import com.google.android.gms.ads.mediation.UnifiedNativeAdMapper;

@Deprecated
public interface CustomEventNativeListener extends CustomEventListener {
  void onAdImpression();
  
  void onAdLoaded(UnifiedNativeAdMapper paramUnifiedNativeAdMapper);
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\mediation\customevent\CustomEventNativeListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */