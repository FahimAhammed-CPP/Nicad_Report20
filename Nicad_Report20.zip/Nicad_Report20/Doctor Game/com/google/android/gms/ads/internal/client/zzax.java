package com.google.android.gms.ads.internal.client;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.LoadAdError;

public class zzax extends AdListener {
  private final Object zza = new Object();
  
  private AdListener zzb;
  
  public final void onAdClicked() {
    synchronized (this.zza) {
      AdListener adListener = this.zzb;
      if (adListener != null)
        adListener.onAdClicked(); 
      return;
    } 
  }
  
  public final void onAdClosed() {
    synchronized (this.zza) {
      AdListener adListener = this.zzb;
      if (adListener != null)
        adListener.onAdClosed(); 
      return;
    } 
  }
  
  public void onAdFailedToLoad(LoadAdError paramLoadAdError) {
    synchronized (this.zza) {
      AdListener adListener = this.zzb;
      if (adListener != null)
        adListener.onAdFailedToLoad(paramLoadAdError); 
      return;
    } 
  }
  
  public final void onAdImpression() {
    synchronized (this.zza) {
      AdListener adListener = this.zzb;
      if (adListener != null)
        adListener.onAdImpression(); 
      return;
    } 
  }
  
  public void onAdLoaded() {
    synchronized (this.zza) {
      AdListener adListener = this.zzb;
      if (adListener != null)
        adListener.onAdLoaded(); 
      return;
    } 
  }
  
  public final void onAdOpened() {
    synchronized (this.zza) {
      AdListener adListener = this.zzb;
      if (adListener != null)
        adListener.onAdOpened(); 
      return;
    } 
  }
  
  public final void zza(AdListener paramAdListener) {
    synchronized (this.zza) {
      this.zzb = paramAdListener;
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzax.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */