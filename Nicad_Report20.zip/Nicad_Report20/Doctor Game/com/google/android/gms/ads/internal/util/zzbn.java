package com.google.android.gms.ads.internal.util;

import com.google.android.gms.internal.ads.zzajz;
import com.google.android.gms.internal.ads.zzakd;
import com.google.android.gms.internal.ads.zzakj;
import com.google.android.gms.internal.ads.zzala;
import com.google.android.gms.internal.ads.zzcgo;
import com.google.android.gms.internal.ads.zzchh;
import java.util.Map;

public final class zzbn extends zzakd {
  private final zzchh zza;
  
  private final zzcgo zzb;
  
  public zzbn(String paramString, Map paramMap, zzchh paramzzchh) {
    super(0, paramString, new zzbm(paramzzchh));
    this.zza = paramzzchh;
    zzcgo zzcgo1 = new zzcgo(null);
    this.zzb = zzcgo1;
    zzcgo1.zzd(paramString, "GET", null, null);
  }
  
  protected final zzakj zzh(zzajz paramzzajz) {
    return zzakj.zzb(paramzzajz, zzala.zzb(paramzzajz));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzbn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */