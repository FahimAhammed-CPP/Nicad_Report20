package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.internal.ads.zzasa;
import com.google.android.gms.internal.ads.zzasb;
import com.google.android.gms.internal.ads.zzbrw;
import com.google.android.gms.internal.ads.zzbrx;
import com.google.android.gms.internal.ads.zzbvj;
import com.google.android.gms.internal.ads.zzbvk;
import java.util.List;

public abstract class zzcl extends zzasa implements zzcm {
  public zzcl() {
    super("com.google.android.gms.ads.internal.client.IMobileAdsSettingManager");
  }
  
  protected final boolean zzbI(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2) throws RemoteException {
    List list;
    String str1;
    float f;
    boolean bool;
    IBinder iBinder;
    zzcy zzcy;
    zzez zzez;
    zzbrx zzbrx;
    zzbvk zzbvk;
    String str3;
    IObjectWrapper iObjectWrapper1;
    String str2;
    IObjectWrapper iObjectWrapper2;
    String str4;
    switch (paramInt1) {
      default:
        return false;
      case 16:
        iBinder = paramParcel1.readStrongBinder();
        if (iBinder == null) {
          iBinder = null;
        } else {
          IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IOnAdInspectorClosedListener");
          if (iInterface instanceof zzcy) {
            zzcy = (zzcy)iInterface;
          } else {
            zzcy = new zzcw((IBinder)zzcy);
          } 
        } 
        zzasb.zzc(paramParcel1);
        zzl(zzcy);
        paramParcel2.writeNoException();
        return true;
      case 15:
        zzi();
        paramParcel2.writeNoException();
        return true;
      case 14:
        zzez = (zzez)zzasb.zza(paramParcel1, zzez.CREATOR);
        zzasb.zzc(paramParcel1);
        zzs(zzez);
        paramParcel2.writeNoException();
        return true;
      case 13:
        list = zzg();
        paramParcel2.writeNoException();
        paramParcel2.writeTypedList(list);
        return true;
      case 12:
        zzbrx = zzbrw.zzc(list.readStrongBinder());
        zzasb.zzc((Parcel)list);
        zzr(zzbrx);
        paramParcel2.writeNoException();
        return true;
      case 11:
        zzbvk = zzbvj.zzf(list.readStrongBinder());
        zzasb.zzc((Parcel)list);
        zzn(zzbvk);
        paramParcel2.writeNoException();
        return true;
      case 10:
        str3 = list.readString();
        zzasb.zzc((Parcel)list);
        zzh(str3);
        paramParcel2.writeNoException();
        return true;
      case 9:
        str1 = zzf();
        paramParcel2.writeNoException();
        paramParcel2.writeString(str1);
        return true;
      case 8:
        bool = zzt();
        paramParcel2.writeNoException();
        zzasb.zzd(paramParcel2, bool);
        return true;
      case 7:
        f = zze();
        paramParcel2.writeNoException();
        paramParcel2.writeFloat(f);
        return true;
      case 6:
        str3 = str1.readString();
        iObjectWrapper2 = IObjectWrapper.Stub.asInterface(str1.readStrongBinder());
        zzasb.zzc((Parcel)str1);
        zzk(str3, iObjectWrapper2);
        paramParcel2.writeNoException();
        return true;
      case 5:
        iObjectWrapper1 = IObjectWrapper.Stub.asInterface(str1.readStrongBinder());
        str4 = str1.readString();
        zzasb.zzc((Parcel)str1);
        zzm(iObjectWrapper1, str4);
        paramParcel2.writeNoException();
        return true;
      case 4:
        bool = zzasb.zzh((Parcel)str1);
        zzasb.zzc((Parcel)str1);
        zzo(bool);
        paramParcel2.writeNoException();
        return true;
      case 3:
        str2 = str1.readString();
        zzasb.zzc((Parcel)str1);
        zzq(str2);
        paramParcel2.writeNoException();
        return true;
      case 2:
        f = str1.readFloat();
        zzasb.zzc((Parcel)str1);
        zzp(f);
        paramParcel2.writeNoException();
        return true;
      case 1:
        break;
    } 
    zzj();
    paramParcel2.writeNoException();
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzcl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */