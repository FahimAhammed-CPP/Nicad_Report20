package com.google.android.gms.ads.internal.client;

import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzasa;
import com.google.android.gms.internal.ads.zzasb;

public abstract class zzcx extends zzasa implements zzcy {
  public zzcx() {
    super("com.google.android.gms.ads.internal.client.IOnAdInspectorClosedListener");
  }
  
  protected final boolean zzbI(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2) throws RemoteException {
    if (paramInt1 == 1) {
      zze zze = (zze)zzasb.zza(paramParcel1, zze.CREATOR);
      zzasb.zzc(paramParcel1);
      zze(zze);
      paramParcel2.writeNoException();
      return true;
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzcx.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */