package com.google.android.gms.ads.internal.client;

import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.internal.ads.zzasa;
import com.google.android.gms.internal.ads.zzasb;
import com.google.android.gms.internal.ads.zzbmi;
import com.google.android.gms.internal.ads.zzbmo;
import com.google.android.gms.internal.ads.zzbqq;
import com.google.android.gms.internal.ads.zzbqr;
import com.google.android.gms.internal.ads.zzbqu;
import com.google.android.gms.internal.ads.zzbvj;
import com.google.android.gms.internal.ads.zzbvk;
import com.google.android.gms.internal.ads.zzbyv;
import com.google.android.gms.internal.ads.zzbzc;
import com.google.android.gms.internal.ads.zzcbv;
import com.google.android.gms.internal.ads.zzccl;
import com.google.android.gms.internal.ads.zzcfg;

public abstract class zzcb extends zzasa implements zzcc {
  public zzcb() {
    super("com.google.android.gms.ads.internal.client.IClientApi");
  }
  
  protected final boolean zzbI(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2) throws RemoteException {
    zzbqu zzbqu;
    zzbyv zzbyv;
    zzcfg zzcfg;
    zzbs zzbs3;
    zzccl zzccl;
    zzbmo zzbmo;
    zzbs zzbs2;
    zzcm zzcm;
    zzbzc zzbzc;
    zzcbv zzcbv;
    zzbmi zzbmi;
    zzbo zzbo;
    zzbvk zzbvk2;
    zzq zzq3;
    String str2;
    IObjectWrapper iObjectWrapper3;
    zzq zzq2;
    zzbvk zzbvk1;
    IObjectWrapper iObjectWrapper2;
    String str1;
    zzbqr zzbqr;
    String str5;
    zzbvk zzbvk4;
    IObjectWrapper iObjectWrapper4;
    String str4;
    zzbvk zzbvk3;
    switch (paramInt1) {
      default:
        return false;
      case 16:
        iObjectWrapper1 = IObjectWrapper.Stub.asInterface(paramParcel1.readStrongBinder());
        zzbvk2 = zzbvj.zzf(paramParcel1.readStrongBinder());
        paramInt1 = paramParcel1.readInt();
        zzbqr = zzbqq.zzc(paramParcel1.readStrongBinder());
        zzasb.zzc(paramParcel1);
        zzbqu = zzj(iObjectWrapper1, zzbvk2, paramInt1, zzbqr);
        paramParcel2.writeNoException();
        zzasb.zzg(paramParcel2, (IInterface)zzbqu);
        return true;
      case 15:
        iObjectWrapper1 = IObjectWrapper.Stub.asInterface(zzbqu.readStrongBinder());
        zzbvk2 = zzbvj.zzf(zzbqu.readStrongBinder());
        paramInt1 = zzbqu.readInt();
        zzasb.zzc((Parcel)zzbqu);
        zzbyv = zzk(iObjectWrapper1, zzbvk2, paramInt1);
        paramParcel2.writeNoException();
        zzasb.zzg(paramParcel2, (IInterface)zzbyv);
        return true;
      case 14:
        iObjectWrapper1 = IObjectWrapper.Stub.asInterface(zzbyv.readStrongBinder());
        zzbvk2 = zzbvj.zzf(zzbyv.readStrongBinder());
        paramInt1 = zzbyv.readInt();
        zzasb.zzc((Parcel)zzbyv);
        zzcfg = zzo(iObjectWrapper1, zzbvk2, paramInt1);
        paramParcel2.writeNoException();
        zzasb.zzg(paramParcel2, (IInterface)zzcfg);
        return true;
      case 13:
        iObjectWrapper1 = IObjectWrapper.Stub.asInterface(zzcfg.readStrongBinder());
        zzq3 = (zzq)zzasb.zza((Parcel)zzcfg, zzq.CREATOR);
        str5 = zzcfg.readString();
        zzbvk5 = zzbvj.zzf(zzcfg.readStrongBinder());
        paramInt1 = zzcfg.readInt();
        zzasb.zzc((Parcel)zzcfg);
        zzbs3 = zzc(iObjectWrapper1, zzq3, str5, zzbvk5, paramInt1);
        paramParcel2.writeNoException();
        zzasb.zzg(paramParcel2, zzbs3);
        return true;
      case 12:
        iObjectWrapper1 = IObjectWrapper.Stub.asInterface(zzbs3.readStrongBinder());
        str2 = zzbs3.readString();
        zzbvk4 = zzbvj.zzf(zzbs3.readStrongBinder());
        paramInt1 = zzbs3.readInt();
        zzasb.zzc((Parcel)zzbs3);
        zzccl = zzn(iObjectWrapper1, str2, zzbvk4, paramInt1);
        paramParcel2.writeNoException();
        zzasb.zzg(paramParcel2, (IInterface)zzccl);
        return true;
      case 11:
        iObjectWrapper1 = IObjectWrapper.Stub.asInterface(zzccl.readStrongBinder());
        iObjectWrapper3 = IObjectWrapper.Stub.asInterface(zzccl.readStrongBinder());
        iObjectWrapper4 = IObjectWrapper.Stub.asInterface(zzccl.readStrongBinder());
        zzasb.zzc((Parcel)zzccl);
        zzbmo = zzi(iObjectWrapper1, iObjectWrapper3, iObjectWrapper4);
        paramParcel2.writeNoException();
        zzasb.zzg(paramParcel2, (IInterface)zzbmo);
        return true;
      case 10:
        iObjectWrapper1 = IObjectWrapper.Stub.asInterface(zzbmo.readStrongBinder());
        zzq2 = (zzq)zzasb.zza((Parcel)zzbmo, zzq.CREATOR);
        str4 = zzbmo.readString();
        paramInt1 = zzbmo.readInt();
        zzasb.zzc((Parcel)zzbmo);
        zzbs2 = zzf(iObjectWrapper1, zzq2, str4, paramInt1);
        paramParcel2.writeNoException();
        zzasb.zzg(paramParcel2, zzbs2);
        return true;
      case 9:
        iObjectWrapper1 = IObjectWrapper.Stub.asInterface(zzbs2.readStrongBinder());
        paramInt1 = zzbs2.readInt();
        zzasb.zzc((Parcel)zzbs2);
        zzcm = zzg(iObjectWrapper1, paramInt1);
        paramParcel2.writeNoException();
        zzasb.zzg(paramParcel2, zzcm);
        return true;
      case 8:
        iObjectWrapper1 = IObjectWrapper.Stub.asInterface(zzcm.readStrongBinder());
        zzasb.zzc((Parcel)zzcm);
        zzbzc = zzl(iObjectWrapper1);
        paramParcel2.writeNoException();
        zzasb.zzg(paramParcel2, (IInterface)zzbzc);
        return true;
      case 7:
        IObjectWrapper.Stub.asInterface(zzbzc.readStrongBinder());
        zzasb.zzc((Parcel)zzbzc);
        paramParcel2.writeNoException();
        zzasb.zzg(paramParcel2, null);
        return true;
      case 6:
        iObjectWrapper1 = IObjectWrapper.Stub.asInterface(zzbzc.readStrongBinder());
        zzbvk1 = zzbvj.zzf(zzbzc.readStrongBinder());
        paramInt1 = zzbzc.readInt();
        zzasb.zzc((Parcel)zzbzc);
        zzcbv = zzm(iObjectWrapper1, zzbvk1, paramInt1);
        paramParcel2.writeNoException();
        zzasb.zzg(paramParcel2, (IInterface)zzcbv);
        return true;
      case 5:
        iObjectWrapper1 = IObjectWrapper.Stub.asInterface(zzcbv.readStrongBinder());
        iObjectWrapper2 = IObjectWrapper.Stub.asInterface(zzcbv.readStrongBinder());
        zzasb.zzc((Parcel)zzcbv);
        zzbmi = zzh(iObjectWrapper1, iObjectWrapper2);
        paramParcel2.writeNoException();
        zzasb.zzg(paramParcel2, (IInterface)zzbmi);
        return true;
      case 4:
        IObjectWrapper.Stub.asInterface(zzbmi.readStrongBinder());
        zzasb.zzc((Parcel)zzbmi);
        paramParcel2.writeNoException();
        zzasb.zzg(paramParcel2, null);
        return true;
      case 3:
        iObjectWrapper1 = IObjectWrapper.Stub.asInterface(zzbmi.readStrongBinder());
        str1 = zzbmi.readString();
        zzbvk3 = zzbvj.zzf(zzbmi.readStrongBinder());
        paramInt1 = zzbmi.readInt();
        zzasb.zzc((Parcel)zzbmi);
        zzbo = zzb(iObjectWrapper1, str1, zzbvk3, paramInt1);
        paramParcel2.writeNoException();
        zzasb.zzg(paramParcel2, zzbo);
        return true;
      case 2:
        iObjectWrapper1 = IObjectWrapper.Stub.asInterface(zzbo.readStrongBinder());
        zzq1 = (zzq)zzasb.zza((Parcel)zzbo, zzq.CREATOR);
        str3 = zzbo.readString();
        zzbvk5 = zzbvj.zzf(zzbo.readStrongBinder());
        paramInt1 = zzbo.readInt();
        zzasb.zzc((Parcel)zzbo);
        zzbs1 = zze(iObjectWrapper1, zzq1, str3, zzbvk5, paramInt1);
        paramParcel2.writeNoException();
        zzasb.zzg(paramParcel2, zzbs1);
        return true;
      case 1:
        break;
    } 
    IObjectWrapper iObjectWrapper1 = IObjectWrapper.Stub.asInterface(zzbs1.readStrongBinder());
    zzq zzq1 = (zzq)zzasb.zza((Parcel)zzbs1, zzq.CREATOR);
    String str3 = zzbs1.readString();
    zzbvk zzbvk5 = zzbvj.zzf(zzbs1.readStrongBinder());
    paramInt1 = zzbs1.readInt();
    zzasb.zzc((Parcel)zzbs1);
    zzbs zzbs1 = zzd(iObjectWrapper1, zzq1, str3, zzbvk5, paramInt1);
    paramParcel2.writeNoException();
    zzasb.zzg(paramParcel2, zzbs1);
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzcb.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */