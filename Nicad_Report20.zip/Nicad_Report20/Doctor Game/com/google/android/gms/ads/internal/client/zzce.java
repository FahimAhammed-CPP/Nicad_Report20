package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzarz;
import com.google.android.gms.internal.ads.zzasb;

public final class zzce extends zzarz implements zzcg {
  zzce(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IFullScreenContentCallback");
  }
  
  public final void zzb() throws RemoteException {
    zzbl(5, zza());
  }
  
  public final void zzc() throws RemoteException {
    zzbl(3, zza());
  }
  
  public final void zzd(zze paramzze) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zze(parcel, (Parcelable)paramzze);
    zzbl(1, parcel);
  }
  
  public final void zze() throws RemoteException {
    zzbl(4, zza());
  }
  
  public final void zzf() throws RemoteException {
    zzbl(2, zza());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzce.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */