package com.google.android.gms.ads;

import com.google.android.gms.ads.internal.client.zze;
import org.json.JSONException;
import org.json.JSONObject;

public class AdError {
  public static final String UNDEFINED_DOMAIN = "undefined";
  
  private final int zza;
  
  private final String zzb;
  
  private final String zzc;
  
  private final AdError zzd;
  
  public AdError(int paramInt, String paramString1, String paramString2) {
    this(paramInt, paramString1, paramString2, null);
  }
  
  public AdError(int paramInt, String paramString1, String paramString2, AdError paramAdError) {
    this.zza = paramInt;
    this.zzb = paramString1;
    this.zzc = paramString2;
    this.zzd = paramAdError;
  }
  
  public AdError getCause() {
    return this.zzd;
  }
  
  public int getCode() {
    return this.zza;
  }
  
  public String getDomain() {
    return this.zzc;
  }
  
  public String getMessage() {
    return this.zzb;
  }
  
  public String toString() {
    try {
      return zzb().toString(2);
    } catch (JSONException jSONException) {
      return "Error forming toString output.";
    } 
  }
  
  public final zze zza() {
    zze zze;
    if (this.zzd == null) {
      zze = null;
    } else {
      AdError adError = this.zzd;
      zze = new zze(adError.zza, adError.zzb, adError.zzc, null, null);
    } 
    return new zze(this.zza, this.zzb, this.zzc, zze, null);
  }
  
  public JSONObject zzb() throws JSONException {
    JSONObject jSONObject = new JSONObject();
    jSONObject.put("Code", this.zza);
    jSONObject.put("Message", this.zzb);
    jSONObject.put("Domain", this.zzc);
    AdError adError = this.zzd;
    if (adError == null) {
      jSONObject.put("Cause", "null");
      return jSONObject;
    } 
    jSONObject.put("Cause", adError.zzb());
    return jSONObject;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\AdError.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */