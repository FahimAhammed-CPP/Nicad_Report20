package com.google.android.gms.ads.internal;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.util.zze;
import com.google.android.gms.common.wrappers.Wrappers;
import com.google.android.gms.internal.ads.zzbiu;
import com.google.android.gms.internal.ads.zzbjc;
import com.google.android.gms.internal.ads.zzbua;
import com.google.android.gms.internal.ads.zzbuc;
import com.google.android.gms.internal.ads.zzbud;
import com.google.android.gms.internal.ads.zzbuh;
import com.google.android.gms.internal.ads.zzcfs;
import com.google.android.gms.internal.ads.zzcgv;
import com.google.android.gms.internal.ads.zzchc;
import com.google.android.gms.internal.ads.zzchf;
import com.google.android.gms.internal.ads.zzfji;
import com.google.android.gms.internal.ads.zzfjj;
import com.google.android.gms.internal.ads.zzfjw;
import com.google.android.gms.internal.ads.zzfzg;
import com.google.android.gms.internal.ads.zzfzp;
import java.util.concurrent.Executor;
import javax.annotation.ParametersAreNonnullByDefault;
import org.json.JSONObject;

@ParametersAreNonnullByDefault
public final class zze {
  private Context zza;
  
  private long zzb = 0L;
  
  public final void zza(Context paramContext, zzcgv paramzzcgv, String paramString, Runnable paramRunnable, zzfjw paramzzfjw) {
    zzb(paramContext, paramzzcgv, true, null, paramString, null, paramRunnable, paramzzfjw);
  }
  
  final void zzb(Context paramContext, zzcgv paramzzcgv, boolean paramBoolean, zzcfs paramzzcfs, String paramString1, String paramString2, Runnable paramRunnable, zzfjw paramzzfjw) {
    if (zzt.zzB().elapsedRealtime() - this.zzb < 5000L) {
      zze.zzj("Not retrying to fetch app settings");
      return;
    } 
    this.zzb = zzt.zzB().elapsedRealtime();
    if (paramzzcfs != null) {
      long l1 = paramzzcfs.zza();
      long l2 = zzt.zzB().currentTimeMillis();
      zzbiu zzbiu = zzbjc.zzdi;
      if (l2 - l1 <= ((Long)zzay.zzc().zzb(zzbiu)).longValue() && paramzzcfs.zzi())
        return; 
    } 
    if (paramContext == null) {
      zze.zzj("Context not provided to fetch application settings");
      return;
    } 
    if (!TextUtils.isEmpty(paramString1) || !TextUtils.isEmpty(paramString2)) {
      Context context2 = paramContext.getApplicationContext();
      Context context1 = context2;
      if (context2 == null)
        context1 = paramContext; 
      this.zza = context1;
      zzfjj zzfjj = zzfji.zza(paramContext, 4);
      zzfjj.zzf();
      zzbua zzbua = zzt.zzf().zza(this.zza, paramzzcgv, paramzzfjw).zza("google.afma.config.fetchAppSettings", (zzbud)zzbuh.zza, (zzbuc)zzbuh.zza);
      try {
        JSONObject jSONObject = new JSONObject();
        if (!TextUtils.isEmpty(paramString1)) {
          jSONObject.put("app_id", paramString1);
        } else if (!TextUtils.isEmpty(paramString2)) {
          jSONObject.put("ad_unit_id", paramString2);
        } 
        jSONObject.put("is_init", paramBoolean);
        jSONObject.put("pn", paramContext.getPackageName());
        jSONObject.put("experiment_ids", TextUtils.join(",", zzbjc.zza()));
        try {
          ApplicationInfo applicationInfo = this.zza.getApplicationInfo();
          if (applicationInfo != null) {
            PackageInfo packageInfo = Wrappers.packageManager(paramContext).getPackageInfo(applicationInfo.packageName, 0);
            if (packageInfo != null)
              jSONObject.put("version", packageInfo.versionCode); 
          } 
        } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
          zze.zza("Error fetching PackageInfo.");
        } 
        zzfzp zzfzp1 = zzbua.zzb(jSONObject);
        zzfzp zzfzp2 = zzfzg.zzn(zzfzp1, new zzd(paramzzfjw, zzfjj), (Executor)zzchc.zzf);
        if (paramRunnable != null)
          zzfzp1.zzc(paramRunnable, (Executor)zzchc.zzf); 
        zzchf.zza(zzfzp2, "ConfigLoader.maybeFetchNewAppSettings");
        return;
      } catch (Exception exception) {
        zze.zzh("Error requesting application settings", exception);
        zzfjj.zze(false);
        paramzzfjw.zzb(zzfjj.zzj());
        return;
      } 
    } 
    zze.zzj("App settings could not be fetched. Required parameters missing");
  }
  
  public final void zzc(Context paramContext, zzcgv paramzzcgv, String paramString, zzcfs paramzzcfs, zzfjw paramzzfjw) {
    String str;
    if (paramzzcfs != null) {
      str = paramzzcfs.zzb();
    } else {
      str = null;
    } 
    zzb(paramContext, paramzzcgv, false, paramzzcfs, str, paramString, null, paramzzfjw);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\zze.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */