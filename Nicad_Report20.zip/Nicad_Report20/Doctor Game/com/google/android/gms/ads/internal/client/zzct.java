package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzasa;

public abstract class zzct extends zzasa implements zzcu {
  public zzct() {
    super("com.google.android.gms.ads.internal.client.IMuteThisAdReason");
  }
  
  public static zzcu zzb(IBinder paramIBinder) {
    if (paramIBinder == null)
      return null; 
    IInterface iInterface = paramIBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IMuteThisAdReason");
    return (iInterface instanceof zzcu) ? (zzcu)iInterface : new zzcs(paramIBinder);
  }
  
  protected final boolean zzbI(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2) throws RemoteException {
    if (paramInt1 != 1) {
      if (paramInt1 != 2)
        return false; 
      String str1 = zzf();
      paramParcel2.writeNoException();
      paramParcel2.writeString(str1);
      return true;
    } 
    String str = zze();
    paramParcel2.writeNoException();
    paramParcel2.writeString(str);
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzct.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */