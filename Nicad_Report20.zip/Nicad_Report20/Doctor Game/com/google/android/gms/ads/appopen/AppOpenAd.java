package com.google.android.gms.ads.appopen;

import android.app.Activity;
import android.content.Context;
import com.google.android.gms.ads.AdLoadCallback;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.OnPaidEventListener;
import com.google.android.gms.ads.ResponseInfo;
import com.google.android.gms.ads.admanager.AdManagerAdRequest;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.internal.ads.zzbdr;
import com.google.android.gms.internal.ads.zzbiu;
import com.google.android.gms.internal.ads.zzbjc;
import com.google.android.gms.internal.ads.zzbkq;
import com.google.android.gms.internal.ads.zzcge;

public abstract class AppOpenAd {
  public static final int APP_OPEN_AD_ORIENTATION_LANDSCAPE = 2;
  
  public static final int APP_OPEN_AD_ORIENTATION_PORTRAIT = 1;
  
  public static void load(Context paramContext, String paramString, AdRequest paramAdRequest, int paramInt, AppOpenAdLoadCallback paramAppOpenAdLoadCallback) {
    Preconditions.checkNotNull(paramContext, "Context cannot be null.");
    Preconditions.checkNotNull(paramString, "adUnitId cannot be null.");
    Preconditions.checkNotNull(paramAdRequest, "AdRequest cannot be null.");
    Preconditions.checkMainThread("#008 Must be called on the main UI thread.");
    zzbjc.zzc(paramContext);
    if (((Boolean)zzbkq.zzd.zze()).booleanValue()) {
      zzbiu zzbiu = zzbjc.zziM;
      if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue()) {
        zzcge.zzb.execute(new zzb(paramContext, paramString, paramAdRequest, paramInt, paramAppOpenAdLoadCallback));
        return;
      } 
    } 
    (new zzbdr(paramContext, paramString, paramAdRequest.zza(), paramInt, paramAppOpenAdLoadCallback)).zza();
  }
  
  public static void load(Context paramContext, String paramString, AdManagerAdRequest paramAdManagerAdRequest, int paramInt, AppOpenAdLoadCallback paramAppOpenAdLoadCallback) {
    Preconditions.checkNotNull(paramContext, "Context cannot be null.");
    Preconditions.checkNotNull(paramString, "adUnitId cannot be null.");
    Preconditions.checkNotNull(paramAdManagerAdRequest, "AdManagerAdRequest cannot be null.");
    Preconditions.checkMainThread("#008 Must be called on the main UI thread.");
    zzbjc.zzc(paramContext);
    if (((Boolean)zzbkq.zzd.zze()).booleanValue()) {
      zzbiu zzbiu = zzbjc.zziM;
      if (((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue()) {
        zzcge.zzb.execute(new zza(paramContext, paramString, paramAdManagerAdRequest, paramInt, paramAppOpenAdLoadCallback));
        return;
      } 
    } 
    (new zzbdr(paramContext, paramString, paramAdManagerAdRequest.zza(), paramInt, paramAppOpenAdLoadCallback)).zza();
  }
  
  public abstract String getAdUnitId();
  
  public abstract FullScreenContentCallback getFullScreenContentCallback();
  
  public abstract OnPaidEventListener getOnPaidEventListener();
  
  public abstract ResponseInfo getResponseInfo();
  
  public abstract void setFullScreenContentCallback(FullScreenContentCallback paramFullScreenContentCallback);
  
  public abstract void setImmersiveMode(boolean paramBoolean);
  
  public abstract void setOnPaidEventListener(OnPaidEventListener paramOnPaidEventListener);
  
  public abstract void show(Activity paramActivity);
  
  public static abstract class AppOpenAdLoadCallback extends AdLoadCallback<AppOpenAd> {}
  
  public static @interface AppOpenAdOrientation {}
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\appopen\AppOpenAd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */