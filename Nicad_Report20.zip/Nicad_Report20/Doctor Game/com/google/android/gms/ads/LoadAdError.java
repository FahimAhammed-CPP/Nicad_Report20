package com.google.android.gms.ads;

import org.json.JSONException;
import org.json.JSONObject;

public final class LoadAdError extends AdError {
  private final ResponseInfo zza;
  
  public LoadAdError(int paramInt, String paramString1, String paramString2, AdError paramAdError, ResponseInfo paramResponseInfo) {
    super(paramInt, paramString1, paramString2, paramAdError);
    this.zza = paramResponseInfo;
  }
  
  public ResponseInfo getResponseInfo() {
    return this.zza;
  }
  
  public String toString() {
    try {
      return super.zzb().toString(2);
    } catch (JSONException jSONException) {
      return "Error forming toString output.";
    } 
  }
  
  public final JSONObject zzb() throws JSONException {
    JSONObject jSONObject = super.zzb();
    ResponseInfo responseInfo = getResponseInfo();
    if (responseInfo == null) {
      jSONObject.put("Response Info", "null");
      return jSONObject;
    } 
    jSONObject.put("Response Info", responseInfo.zzd());
    return jSONObject;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\LoadAdError.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */