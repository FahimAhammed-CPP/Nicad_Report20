package com.google.android.gms.ads.mediation;

import android.content.Context;
import android.os.Bundle;

@Deprecated
public interface MediationInterstitialAdapter extends MediationAdapter {
  void requestInterstitialAd(Context paramContext, MediationInterstitialListener paramMediationInterstitialListener, Bundle paramBundle1, MediationAdRequest paramMediationAdRequest, Bundle paramBundle2);
  
  void showInterstitial();
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\mediation\MediationInterstitialAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */