package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzarz;
import com.google.android.gms.internal.ads.zzasb;

public final class zzdi extends zzarz implements zzdk {
  zzdi(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.ads.internal.client.IVideoController");
  }
  
  public final float zze() throws RemoteException {
    throw null;
  }
  
  public final float zzf() throws RemoteException {
    throw null;
  }
  
  public final float zzg() throws RemoteException {
    throw null;
  }
  
  public final int zzh() throws RemoteException {
    Parcel parcel = zzbk(5, zza());
    int i = parcel.readInt();
    parcel.recycle();
    return i;
  }
  
  public final zzdn zzi() throws RemoteException {
    zzdn zzdn;
    Parcel parcel = zzbk(11, zza());
    IBinder iBinder = parcel.readStrongBinder();
    if (iBinder == null) {
      iBinder = null;
    } else {
      IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IVideoLifecycleCallbacks");
      if (iInterface instanceof zzdn) {
        zzdn = (zzdn)iInterface;
      } else {
        zzdn = new zzdl((IBinder)zzdn);
      } 
    } 
    parcel.recycle();
    return zzdn;
  }
  
  public final void zzj(boolean paramBoolean) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zzd(parcel, paramBoolean);
    zzbl(3, parcel);
  }
  
  public final void zzk() throws RemoteException {
    zzbl(2, zza());
  }
  
  public final void zzl() throws RemoteException {
    zzbl(1, zza());
  }
  
  public final void zzm(zzdn paramzzdn) throws RemoteException {
    Parcel parcel = zza();
    zzasb.zzg(parcel, paramzzdn);
    zzbl(8, parcel);
  }
  
  public final void zzn() throws RemoteException {
    zzbl(13, zza());
  }
  
  public final boolean zzo() throws RemoteException {
    Parcel parcel = zzbk(12, zza());
    boolean bool = zzasb.zzh(parcel);
    parcel.recycle();
    return bool;
  }
  
  public final boolean zzp() throws RemoteException {
    Parcel parcel = zzbk(10, zza());
    boolean bool = zzasb.zzh(parcel);
    parcel.recycle();
    return bool;
  }
  
  public final boolean zzq() throws RemoteException {
    Parcel parcel = zzbk(4, zza());
    boolean bool = zzasb.zzh(parcel);
    parcel.recycle();
    return bool;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzdi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */