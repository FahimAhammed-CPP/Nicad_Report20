package com.google.android.gms.ads.internal.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Looper;
import android.security.NetworkSecurityPolicy;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.zzt;
import com.google.android.gms.common.util.PlatformVersion;
import com.google.android.gms.internal.ads.zzbcp;
import com.google.android.gms.internal.ads.zzbiu;
import com.google.android.gms.internal.ads.zzbjc;
import com.google.android.gms.internal.ads.zzbkk;
import com.google.android.gms.internal.ads.zzcfs;
import com.google.android.gms.internal.ads.zzchc;
import com.google.android.gms.internal.ads.zzfzp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class zzj implements zzg {
  private boolean zzA = false;
  
  private String zzB = "";
  
  private int zzC = -1;
  
  private int zzD = -1;
  
  private long zzE = 0L;
  
  private final Object zza = new Object();
  
  private boolean zzb;
  
  private final List zzc = new ArrayList();
  
  private zzfzp zzd;
  
  private zzbcp zze = null;
  
  private SharedPreferences zzf;
  
  private SharedPreferences.Editor zzg;
  
  private boolean zzh = true;
  
  private String zzi;
  
  private String zzj;
  
  private boolean zzk = true;
  
  private String zzl = "-1";
  
  private String zzm = "-1";
  
  private String zzn = "-1";
  
  private int zzo = -1;
  
  private zzcfs zzp = new zzcfs("", 0L);
  
  private long zzq = 0L;
  
  private long zzr = 0L;
  
  private int zzs = -1;
  
  private int zzt = 0;
  
  private Set zzu = Collections.emptySet();
  
  private JSONObject zzv = new JSONObject();
  
  private boolean zzw = true;
  
  private boolean zzx = true;
  
  private String zzy = null;
  
  private String zzz = "";
  
  private final void zzR() {
    zzfzp zzfzp1 = this.zzd;
    if (zzfzp1 == null)
      return; 
    if (zzfzp1.isDone())
      return; 
    try {
      this.zzd.get(1L, TimeUnit.SECONDS);
      return;
    } catch (InterruptedException interruptedException) {
      Thread.currentThread().interrupt();
      zze.zzk("Interrupted while waiting for preferences loaded.", interruptedException);
      return;
    } catch (CancellationException cancellationException) {
      zze.zzh("Fail to initialize AdSharedPreferenceManager.", cancellationException);
      return;
    } catch (ExecutionException executionException) {
      zze.zzh("Fail to initialize AdSharedPreferenceManager.", executionException);
      return;
    } catch (TimeoutException timeoutException) {
      zze.zzh("Fail to initialize AdSharedPreferenceManager.", timeoutException);
      return;
    } 
  }
  
  private final void zzS() {
    zzchc.zza.execute(new zzi(this));
  }
  
  public final void zzA(String paramString) {
    zzbiu zzbiu = zzbjc.zzhT;
    if (!((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue())
      return; 
    zzR();
    synchronized (this.zza) {
      if (this.zzB.equals(paramString))
        return; 
      this.zzB = paramString;
      SharedPreferences.Editor editor = this.zzg;
      if (editor != null) {
        editor.putString("linked_ad_unit", paramString);
        this.zzg.apply();
      } 
      zzS();
      return;
    } 
  }
  
  public final void zzB(boolean paramBoolean) {
    zzbiu zzbiu = zzbjc.zzhT;
    if (!((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue())
      return; 
    zzR();
    synchronized (this.zza) {
      if (this.zzA == paramBoolean)
        return; 
      this.zzA = paramBoolean;
      SharedPreferences.Editor editor = this.zzg;
      if (editor != null) {
        editor.putBoolean("linked_device", paramBoolean);
        this.zzg.apply();
      } 
      zzS();
      return;
    } 
  }
  
  public final void zzC(String paramString) {
    zzR();
    synchronized (this.zza) {
      if (TextUtils.equals(this.zzy, paramString))
        return; 
      this.zzy = paramString;
      SharedPreferences.Editor editor = this.zzg;
      if (editor != null) {
        editor.putString("display_cutout", paramString);
        this.zzg.apply();
      } 
      zzS();
      return;
    } 
  }
  
  public final void zzD(long paramLong) {
    zzR();
    synchronized (this.zza) {
      if (this.zzr == paramLong)
        return; 
      this.zzr = paramLong;
      SharedPreferences.Editor editor = this.zzg;
      if (editor != null) {
        editor.putLong("first_ad_req_time_ms", paramLong);
        this.zzg.apply();
      } 
      zzS();
      return;
    } 
  }
  
  public final void zzE(int paramInt) {
    zzR();
    synchronized (this.zza) {
      this.zzo = paramInt;
      SharedPreferences.Editor editor = this.zzg;
      if (editor != null) {
        if (paramInt == -1) {
          editor.remove("gad_has_consent_for_cookies");
        } else {
          editor.putInt("gad_has_consent_for_cookies", paramInt);
        } 
        this.zzg.apply();
      } 
      zzS();
      return;
    } 
  }
  
  public final void zzF(String paramString1, String paramString2) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial zzR : ()V
    //   4: aload_0
    //   5: getfield zza : Ljava/lang/Object;
    //   8: astore #4
    //   10: aload #4
    //   12: monitorenter
    //   13: aload_1
    //   14: invokevirtual hashCode : ()I
    //   17: istore_3
    //   18: iload_3
    //   19: ldc_w -2004976699
    //   22: if_icmpeq -> 72
    //   25: iload_3
    //   26: ldc_w 83641339
    //   29: if_icmpeq -> 57
    //   32: iload_3
    //   33: ldc_w 1218895378
    //   36: if_icmpeq -> 42
    //   39: goto -> 87
    //   42: aload_1
    //   43: ldc_w 'IABTCF_TCString'
    //   46: invokevirtual equals : (Ljava/lang/Object;)Z
    //   49: ifeq -> 87
    //   52: iconst_1
    //   53: istore_3
    //   54: goto -> 89
    //   57: aload_1
    //   58: ldc_w 'IABTCF_gdprApplies'
    //   61: invokevirtual equals : (Ljava/lang/Object;)Z
    //   64: ifeq -> 87
    //   67: iconst_0
    //   68: istore_3
    //   69: goto -> 89
    //   72: aload_1
    //   73: ldc_w 'IABTCF_PurposeConsents'
    //   76: invokevirtual equals : (Ljava/lang/Object;)Z
    //   79: ifeq -> 87
    //   82: iconst_2
    //   83: istore_3
    //   84: goto -> 89
    //   87: iconst_m1
    //   88: istore_3
    //   89: iload_3
    //   90: ifeq -> 123
    //   93: iload_3
    //   94: iconst_1
    //   95: if_icmpeq -> 115
    //   98: iload_3
    //   99: iconst_2
    //   100: if_icmpeq -> 107
    //   103: aload #4
    //   105: monitorexit
    //   106: return
    //   107: aload_0
    //   108: aload_2
    //   109: putfield zzn : Ljava/lang/String;
    //   112: goto -> 128
    //   115: aload_0
    //   116: aload_2
    //   117: putfield zzm : Ljava/lang/String;
    //   120: goto -> 128
    //   123: aload_0
    //   124: aload_2
    //   125: putfield zzl : Ljava/lang/String;
    //   128: aload_0
    //   129: getfield zzg : Landroid/content/SharedPreferences$Editor;
    //   132: ifnull -> 179
    //   135: aload_2
    //   136: ldc '-1'
    //   138: invokevirtual equals : (Ljava/lang/Object;)Z
    //   141: ifeq -> 158
    //   144: aload_0
    //   145: getfield zzg : Landroid/content/SharedPreferences$Editor;
    //   148: aload_1
    //   149: invokeinterface remove : (Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    //   154: pop
    //   155: goto -> 170
    //   158: aload_0
    //   159: getfield zzg : Landroid/content/SharedPreferences$Editor;
    //   162: aload_1
    //   163: aload_2
    //   164: invokeinterface putString : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    //   169: pop
    //   170: aload_0
    //   171: getfield zzg : Landroid/content/SharedPreferences$Editor;
    //   174: invokeinterface apply : ()V
    //   179: aload_0
    //   180: invokespecial zzS : ()V
    //   183: aload #4
    //   185: monitorexit
    //   186: return
    //   187: astore_1
    //   188: aload #4
    //   190: monitorexit
    //   191: aload_1
    //   192: athrow
    // Exception table:
    //   from	to	target	type
    //   13	18	187	finally
    //   103	106	187	finally
    //   107	112	187	finally
    //   115	120	187	finally
    //   123	128	187	finally
    //   128	155	187	finally
    //   158	170	187	finally
    //   170	179	187	finally
    //   179	186	187	finally
    //   188	191	187	finally
  }
  
  public final void zzG(String paramString) {
    zzbiu zzbiu = zzbjc.zzhE;
    if (!((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue())
      return; 
    zzR();
    synchronized (this.zza) {
      if (this.zzz.equals(paramString))
        return; 
      this.zzz = paramString;
      SharedPreferences.Editor editor = this.zzg;
      if (editor != null) {
        editor.putString("inspector_info", paramString);
        this.zzg.apply();
      } 
      zzS();
      return;
    } 
  }
  
  public final void zzH(boolean paramBoolean) {
    zzR();
    synchronized (this.zza) {
      if (paramBoolean == this.zzk)
        return; 
      this.zzk = paramBoolean;
      SharedPreferences.Editor editor = this.zzg;
      if (editor != null) {
        editor.putBoolean("gad_idless", paramBoolean);
        this.zzg.apply();
      } 
      zzS();
      return;
    } 
  }
  
  public final void zzI(String paramString1, String paramString2, boolean paramBoolean) {
    zzR();
    synchronized (this.zza) {
      int j;
      JSONArray jSONArray2 = this.zzv.optJSONArray(paramString1);
      JSONArray jSONArray1 = jSONArray2;
      if (jSONArray2 == null)
        jSONArray1 = new JSONArray(); 
      int k = jSONArray1.length();
      int i = 0;
      while (true) {
        j = k;
        if (i < jSONArray1.length()) {
          JSONObject jSONObject = jSONArray1.optJSONObject(i);
          if (jSONObject == null)
            return; 
          if (paramString2.equals(jSONObject.optString("template_id"))) {
            if (!paramBoolean || !jSONObject.optBoolean("uses_media_view", false)) {
              j = i;
              break;
            } 
            return;
          } 
          i++;
          continue;
        } 
        break;
      } 
      try {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("template_id", paramString2);
        jSONObject.put("uses_media_view", paramBoolean);
        jSONObject.put("timestamp_ms", zzt.zzB().currentTimeMillis());
        jSONArray1.put(j, jSONObject);
        this.zzv.put(paramString1, jSONArray1);
      } catch (JSONException jSONException) {
        zze.zzk("Could not update native advanced settings", (Throwable)jSONException);
      } 
      SharedPreferences.Editor editor = this.zzg;
      if (editor != null) {
        editor.putString("native_advanced_settings", this.zzv.toString());
        this.zzg.apply();
      } 
      zzS();
      return;
    } 
  }
  
  public final void zzJ(int paramInt) {
    zzR();
    synchronized (this.zza) {
      if (this.zzs == paramInt)
        return; 
      this.zzs = paramInt;
      SharedPreferences.Editor editor = this.zzg;
      if (editor != null) {
        editor.putInt("request_in_session_count", paramInt);
        this.zzg.apply();
      } 
      zzS();
      return;
    } 
  }
  
  public final void zzK(int paramInt) {
    zzR();
    synchronized (this.zza) {
      if (this.zzD == paramInt)
        return; 
      this.zzD = paramInt;
      SharedPreferences.Editor editor = this.zzg;
      if (editor != null) {
        editor.putInt("sd_app_measure_npa", paramInt);
        this.zzg.apply();
      } 
      zzS();
      return;
    } 
  }
  
  public final void zzL(long paramLong) {
    zzR();
    synchronized (this.zza) {
      if (this.zzE == paramLong)
        return; 
      this.zzE = paramLong;
      SharedPreferences.Editor editor = this.zzg;
      if (editor != null) {
        editor.putLong("sd_app_measure_npa_ts", paramLong);
        this.zzg.apply();
      } 
      zzS();
      return;
    } 
  }
  
  public final boolean zzM() {
    zzR();
    synchronized (this.zza) {
      return this.zzw;
    } 
  }
  
  public final boolean zzN() {
    zzR();
    synchronized (this.zza) {
      return this.zzx;
    } 
  }
  
  public final boolean zzO() {
    zzR();
    synchronized (this.zza) {
      return this.zzA;
    } 
  }
  
  public final boolean zzP() {
    zzbiu zzbiu = zzbjc.zzar;
    if (!((Boolean)zzay.zzc().zzb(zzbiu)).booleanValue())
      return false; 
    zzR();
    synchronized (this.zza) {
      return this.zzk;
    } 
  }
  
  public final int zza() {
    zzR();
    synchronized (this.zza) {
      return this.zzt;
    } 
  }
  
  public final int zzb() {
    zzR();
    synchronized (this.zza) {
      return this.zzo;
    } 
  }
  
  public final int zzc() {
    zzR();
    synchronized (this.zza) {
      return this.zzs;
    } 
  }
  
  public final long zzd() {
    zzR();
    synchronized (this.zza) {
      return this.zzq;
    } 
  }
  
  public final long zze() {
    zzR();
    synchronized (this.zza) {
      return this.zzr;
    } 
  }
  
  public final long zzf() {
    zzR();
    synchronized (this.zza) {
      return this.zzE;
    } 
  }
  
  public final zzbcp zzg() {
    if (!this.zzb)
      return null; 
    if (!zzM() || !zzN()) {
      if (!((Boolean)zzbkk.zzb.zze()).booleanValue())
        return null; 
      synchronized (this.zza) {
        if (Looper.getMainLooper() == null)
          return null; 
        if (this.zze == null)
          this.zze = new zzbcp(); 
        this.zze.zze();
        zze.zzi("start fetching content...");
        return this.zze;
      } 
    } 
    return null;
  }
  
  public final zzcfs zzh() {
    zzR();
    synchronized (this.zza) {
      return this.zzp;
    } 
  }
  
  public final zzcfs zzi() {
    synchronized (this.zza) {
      return this.zzp;
    } 
  }
  
  public final String zzj() {
    zzR();
    synchronized (this.zza) {
      return this.zzi;
    } 
  }
  
  public final String zzk() {
    zzR();
    synchronized (this.zza) {
      return this.zzj;
    } 
  }
  
  public final String zzl() {
    zzR();
    synchronized (this.zza) {
      return this.zzB;
    } 
  }
  
  public final String zzm() {
    zzR();
    synchronized (this.zza) {
      return this.zzy;
    } 
  }
  
  public final String zzn(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial zzR : ()V
    //   4: aload_0
    //   5: getfield zza : Ljava/lang/Object;
    //   8: astore_3
    //   9: aload_3
    //   10: monitorenter
    //   11: aload_1
    //   12: invokevirtual hashCode : ()I
    //   15: istore_2
    //   16: iload_2
    //   17: ldc_w -2004976699
    //   20: if_icmpeq -> 70
    //   23: iload_2
    //   24: ldc_w 83641339
    //   27: if_icmpeq -> 55
    //   30: iload_2
    //   31: ldc_w 1218895378
    //   34: if_icmpeq -> 40
    //   37: goto -> 85
    //   40: aload_1
    //   41: ldc_w 'IABTCF_TCString'
    //   44: invokevirtual equals : (Ljava/lang/Object;)Z
    //   47: ifeq -> 85
    //   50: iconst_1
    //   51: istore_2
    //   52: goto -> 87
    //   55: aload_1
    //   56: ldc_w 'IABTCF_gdprApplies'
    //   59: invokevirtual equals : (Ljava/lang/Object;)Z
    //   62: ifeq -> 85
    //   65: iconst_0
    //   66: istore_2
    //   67: goto -> 87
    //   70: aload_1
    //   71: ldc_w 'IABTCF_PurposeConsents'
    //   74: invokevirtual equals : (Ljava/lang/Object;)Z
    //   77: ifeq -> 85
    //   80: iconst_2
    //   81: istore_2
    //   82: goto -> 87
    //   85: iconst_m1
    //   86: istore_2
    //   87: iload_2
    //   88: ifeq -> 123
    //   91: iload_2
    //   92: iconst_1
    //   93: if_icmpeq -> 114
    //   96: iload_2
    //   97: iconst_2
    //   98: if_icmpeq -> 105
    //   101: aload_3
    //   102: monitorexit
    //   103: aconst_null
    //   104: areturn
    //   105: aload_0
    //   106: getfield zzn : Ljava/lang/String;
    //   109: astore_1
    //   110: aload_3
    //   111: monitorexit
    //   112: aload_1
    //   113: areturn
    //   114: aload_0
    //   115: getfield zzm : Ljava/lang/String;
    //   118: astore_1
    //   119: aload_3
    //   120: monitorexit
    //   121: aload_1
    //   122: areturn
    //   123: aload_0
    //   124: getfield zzl : Ljava/lang/String;
    //   127: astore_1
    //   128: aload_3
    //   129: monitorexit
    //   130: aload_1
    //   131: areturn
    //   132: astore_1
    //   133: aload_3
    //   134: monitorexit
    //   135: aload_1
    //   136: athrow
    // Exception table:
    //   from	to	target	type
    //   11	16	132	finally
    //   101	103	132	finally
    //   105	112	132	finally
    //   114	121	132	finally
    //   123	130	132	finally
    //   133	135	132	finally
  }
  
  public final String zzo() {
    zzR();
    synchronized (this.zza) {
      return this.zzz;
    } 
  }
  
  public final JSONObject zzp() {
    zzR();
    synchronized (this.zza) {
      return this.zzv;
    } 
  }
  
  public final void zzq(Runnable paramRunnable) {
    this.zzc.add(paramRunnable);
  }
  
  public final void zzr(Context paramContext) {
    synchronized (this.zza) {
      if (this.zzf != null)
        return; 
      this.zzd = zzchc.zza.zza(new zzh(this, paramContext, "admob"));
      this.zzb = true;
      return;
    } 
  }
  
  public final void zzs() {
    zzR();
    synchronized (this.zza) {
      this.zzv = new JSONObject();
      SharedPreferences.Editor editor = this.zzg;
      if (editor != null) {
        editor.remove("native_advanced_settings");
        this.zzg.apply();
      } 
      zzS();
      return;
    } 
  }
  
  public final void zzt(long paramLong) {
    zzR();
    synchronized (this.zza) {
      if (this.zzq == paramLong)
        return; 
      this.zzq = paramLong;
      SharedPreferences.Editor editor = this.zzg;
      if (editor != null) {
        editor.putLong("app_last_background_time_ms", paramLong);
        this.zzg.apply();
      } 
      zzS();
      return;
    } 
  }
  
  public final void zzu(String paramString) {
    zzR();
    synchronized (this.zza) {
      long l = zzt.zzB().currentTimeMillis();
      if (paramString == null || paramString.equals(this.zzp.zzc())) {
        this.zzp.zzg(l);
        return;
      } 
      this.zzp = new zzcfs(paramString, l);
      SharedPreferences.Editor editor = this.zzg;
      if (editor != null) {
        editor.putString("app_settings_json", paramString);
        this.zzg.putLong("app_settings_last_update_ms", l);
        this.zzg.apply();
      } 
      zzS();
      Iterator<Runnable> iterator = this.zzc.iterator();
      while (iterator.hasNext())
        ((Runnable)iterator.next()).run(); 
      return;
    } 
  }
  
  public final void zzv(int paramInt) {
    zzR();
    synchronized (this.zza) {
      if (this.zzt == paramInt)
        return; 
      this.zzt = paramInt;
      SharedPreferences.Editor editor = this.zzg;
      if (editor != null) {
        editor.putInt("version_code", paramInt);
        this.zzg.apply();
      } 
      zzS();
      return;
    } 
  }
  
  public final void zzw(String paramString) {
    zzR();
    synchronized (this.zza) {
      if (paramString.equals(this.zzi))
        return; 
      this.zzi = paramString;
      SharedPreferences.Editor editor = this.zzg;
      if (editor != null) {
        editor.putString("content_url_hashes", paramString);
        this.zzg.apply();
      } 
      zzS();
      return;
    } 
  }
  
  public final void zzx(boolean paramBoolean) {
    zzR();
    synchronized (this.zza) {
      if (this.zzw == paramBoolean)
        return; 
      this.zzw = paramBoolean;
      SharedPreferences.Editor editor = this.zzg;
      if (editor != null) {
        editor.putBoolean("content_url_opted_out", paramBoolean);
        this.zzg.apply();
      } 
      zzS();
      return;
    } 
  }
  
  public final void zzy(String paramString) {
    zzR();
    synchronized (this.zza) {
      if (paramString.equals(this.zzj))
        return; 
      this.zzj = paramString;
      SharedPreferences.Editor editor = this.zzg;
      if (editor != null) {
        editor.putString("content_vertical_hashes", paramString);
        this.zzg.apply();
      } 
      zzS();
      return;
    } 
  }
  
  public final void zzz(boolean paramBoolean) {
    zzR();
    synchronized (this.zza) {
      if (this.zzx == paramBoolean)
        return; 
      this.zzx = paramBoolean;
      SharedPreferences.Editor editor = this.zzg;
      if (editor != null) {
        editor.putBoolean("content_vertical_opted_out", paramBoolean);
        this.zzg.apply();
      } 
      zzS();
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\google\android\gms\ads\interna\\util\zzj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */