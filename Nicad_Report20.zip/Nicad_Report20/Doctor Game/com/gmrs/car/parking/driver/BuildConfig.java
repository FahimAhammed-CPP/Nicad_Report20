package com.gmrs.car.parking.driver;

public final class BuildConfig {
  public static final String APPLICATION_ID = "com.gmrs.car.parking.driver";
  
  public static final String BUILD_TYPE = "release";
  
  public static final boolean DEBUG = false;
  
  public static final int VERSION_CODE = 33;
  
  public static final String VERSION_NAME = "3.3";
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\gmrs\car\parking\driver\BuildConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */