package com.gmrs.car.parking.driver;

public final class R {
  public static final class attr {
    public static final int adSize = 2130771968;
    
    public static final int adSizes = 2130771969;
    
    public static final int adUnitId = 2130771970;
    
    public static final int alpha = 2130771971;
    
    public static final int buttonSize = 2130771972;
    
    public static final int circleCrop = 2130771973;
    
    public static final int colorScheme = 2130771974;
    
    public static final int coordinatorLayoutStyle = 2130771975;
    
    public static final int font = 2130771976;
    
    public static final int fontProviderAuthority = 2130771977;
    
    public static final int fontProviderCerts = 2130771978;
    
    public static final int fontProviderFetchStrategy = 2130771979;
    
    public static final int fontProviderFetchTimeout = 2130771980;
    
    public static final int fontProviderPackage = 2130771981;
    
    public static final int fontProviderQuery = 2130771982;
    
    public static final int fontProviderSystemFontFamily = 2130771983;
    
    public static final int fontStyle = 2130771984;
    
    public static final int fontVariationSettings = 2130771985;
    
    public static final int fontWeight = 2130771986;
    
    public static final int imageAspectRatio = 2130771987;
    
    public static final int imageAspectRatioAdjust = 2130771988;
    
    public static final int keylines = 2130771989;
    
    public static final int layout_anchor = 2130771990;
    
    public static final int layout_anchorGravity = 2130771991;
    
    public static final int layout_behavior = 2130771992;
    
    public static final int layout_dodgeInsetEdges = 2130771993;
    
    public static final int layout_insetEdge = 2130771994;
    
    public static final int layout_keyline = 2130771995;
    
    public static final int nestedScrollViewStyle = 2130771996;
    
    public static final int queryPatterns = 2130771997;
    
    public static final int scopeUris = 2130771998;
    
    public static final int shortcutMatchRequired = 2130771999;
    
    public static final int statusBarBackground = 2130772000;
    
    public static final int ttcIndex = 2130772001;
  }
  
  public static final class bool {
    public static final int enable_system_alarm_service_default = 2130837504;
    
    public static final int enable_system_foreground_service_default = 2130837505;
    
    public static final int enable_system_job_service_default = 2130837506;
    
    public static final int workmanager_test_configuration = 2130837507;
  }
  
  public static final class color {
    public static final int androidx_core_ripple_material_light = 2130903040;
    
    public static final int androidx_core_secondary_text_default_material_light = 2130903041;
    
    public static final int browser_actions_bg_grey = 2130903042;
    
    public static final int browser_actions_divider_color = 2130903043;
    
    public static final int browser_actions_text_color = 2130903044;
    
    public static final int browser_actions_title_color = 2130903045;
    
    public static final int common_google_signin_btn_text_dark = 2130903046;
    
    public static final int common_google_signin_btn_text_dark_default = 2130903047;
    
    public static final int common_google_signin_btn_text_dark_disabled = 2130903048;
    
    public static final int common_google_signin_btn_text_dark_focused = 2130903049;
    
    public static final int common_google_signin_btn_text_dark_pressed = 2130903050;
    
    public static final int common_google_signin_btn_text_light = 2130903051;
    
    public static final int common_google_signin_btn_text_light_default = 2130903052;
    
    public static final int common_google_signin_btn_text_light_disabled = 2130903053;
    
    public static final int common_google_signin_btn_text_light_focused = 2130903054;
    
    public static final int common_google_signin_btn_text_light_pressed = 2130903055;
    
    public static final int common_google_signin_btn_tint = 2130903056;
    
    public static final int notification_action_color_filter = 2130903057;
    
    public static final int notification_icon_bg_color = 2130903058;
  }
  
  public static final class dimen {
    public static final int browser_actions_context_menu_max_width = 2130968576;
    
    public static final int browser_actions_context_menu_min_padding = 2130968577;
    
    public static final int compat_button_inset_horizontal_material = 2130968578;
    
    public static final int compat_button_inset_vertical_material = 2130968579;
    
    public static final int compat_button_padding_horizontal_material = 2130968580;
    
    public static final int compat_button_padding_vertical_material = 2130968581;
    
    public static final int compat_control_corner_material = 2130968582;
    
    public static final int compat_notification_large_icon_max_height = 2130968583;
    
    public static final int compat_notification_large_icon_max_width = 2130968584;
    
    public static final int notification_action_icon_size = 2130968585;
    
    public static final int notification_action_text_size = 2130968586;
    
    public static final int notification_big_circle_margin = 2130968587;
    
    public static final int notification_content_margin_start = 2130968588;
    
    public static final int notification_large_icon_height = 2130968589;
    
    public static final int notification_large_icon_width = 2130968590;
    
    public static final int notification_main_column_padding_top = 2130968591;
    
    public static final int notification_media_narrow_margin = 2130968592;
    
    public static final int notification_right_icon_size = 2130968593;
    
    public static final int notification_right_side_padding_top = 2130968594;
    
    public static final int notification_small_icon_background_padding = 2130968595;
    
    public static final int notification_small_icon_size_as_large = 2130968596;
    
    public static final int notification_subtext_size = 2130968597;
    
    public static final int notification_top_pad = 2130968598;
    
    public static final int notification_top_pad_large_text = 2130968599;
  }
  
  public static final class drawable {
    public static final int admob_close_button_black_circle_white_cross = 2131034112;
    
    public static final int admob_close_button_white_circle_black_cross = 2131034113;
    
    public static final int app_banner = 2131034114;
    
    public static final int common_full_open_on_phone = 2131034115;
    
    public static final int common_google_signin_btn_icon_dark = 2131034116;
    
    public static final int common_google_signin_btn_icon_dark_focused = 2131034117;
    
    public static final int common_google_signin_btn_icon_dark_normal = 2131034118;
    
    public static final int common_google_signin_btn_icon_dark_normal_background = 2131034119;
    
    public static final int common_google_signin_btn_icon_disabled = 2131034120;
    
    public static final int common_google_signin_btn_icon_light = 2131034121;
    
    public static final int common_google_signin_btn_icon_light_focused = 2131034122;
    
    public static final int common_google_signin_btn_icon_light_normal = 2131034123;
    
    public static final int common_google_signin_btn_icon_light_normal_background = 2131034124;
    
    public static final int common_google_signin_btn_text_dark = 2131034125;
    
    public static final int common_google_signin_btn_text_dark_focused = 2131034126;
    
    public static final int common_google_signin_btn_text_dark_normal = 2131034127;
    
    public static final int common_google_signin_btn_text_dark_normal_background = 2131034128;
    
    public static final int common_google_signin_btn_text_disabled = 2131034129;
    
    public static final int common_google_signin_btn_text_light = 2131034130;
    
    public static final int common_google_signin_btn_text_light_focused = 2131034131;
    
    public static final int common_google_signin_btn_text_light_normal = 2131034132;
    
    public static final int common_google_signin_btn_text_light_normal_background = 2131034133;
    
    public static final int googleg_disabled_color_18 = 2131034134;
    
    public static final int googleg_standard_color_18 = 2131034135;
    
    public static final int notification_action_background = 2131034136;
    
    public static final int notification_bg = 2131034137;
    
    public static final int notification_bg_low = 2131034138;
    
    public static final int notification_bg_low_normal = 2131034139;
    
    public static final int notification_bg_low_pressed = 2131034140;
    
    public static final int notification_bg_normal = 2131034141;
    
    public static final int notification_bg_normal_pressed = 2131034142;
    
    public static final int notification_icon_background = 2131034143;
    
    public static final int notification_template_icon_bg = 2131034144;
    
    public static final int notification_template_icon_low_bg = 2131034145;
    
    public static final int notification_tile_bg = 2131034146;
    
    public static final int notify_panel_notification_icon_bg = 2131034147;
  }
  
  public static final class id {
    public static final int accessibility_action_clickable_span = 2131099648;
    
    public static final int accessibility_custom_action_0 = 2131099649;
    
    public static final int accessibility_custom_action_1 = 2131099650;
    
    public static final int accessibility_custom_action_10 = 2131099651;
    
    public static final int accessibility_custom_action_11 = 2131099652;
    
    public static final int accessibility_custom_action_12 = 2131099653;
    
    public static final int accessibility_custom_action_13 = 2131099654;
    
    public static final int accessibility_custom_action_14 = 2131099655;
    
    public static final int accessibility_custom_action_15 = 2131099656;
    
    public static final int accessibility_custom_action_16 = 2131099657;
    
    public static final int accessibility_custom_action_17 = 2131099658;
    
    public static final int accessibility_custom_action_18 = 2131099659;
    
    public static final int accessibility_custom_action_19 = 2131099660;
    
    public static final int accessibility_custom_action_2 = 2131099661;
    
    public static final int accessibility_custom_action_20 = 2131099662;
    
    public static final int accessibility_custom_action_21 = 2131099663;
    
    public static final int accessibility_custom_action_22 = 2131099664;
    
    public static final int accessibility_custom_action_23 = 2131099665;
    
    public static final int accessibility_custom_action_24 = 2131099666;
    
    public static final int accessibility_custom_action_25 = 2131099667;
    
    public static final int accessibility_custom_action_26 = 2131099668;
    
    public static final int accessibility_custom_action_27 = 2131099669;
    
    public static final int accessibility_custom_action_28 = 2131099670;
    
    public static final int accessibility_custom_action_29 = 2131099671;
    
    public static final int accessibility_custom_action_3 = 2131099672;
    
    public static final int accessibility_custom_action_30 = 2131099673;
    
    public static final int accessibility_custom_action_31 = 2131099674;
    
    public static final int accessibility_custom_action_4 = 2131099675;
    
    public static final int accessibility_custom_action_5 = 2131099676;
    
    public static final int accessibility_custom_action_6 = 2131099677;
    
    public static final int accessibility_custom_action_7 = 2131099678;
    
    public static final int accessibility_custom_action_8 = 2131099679;
    
    public static final int accessibility_custom_action_9 = 2131099680;
    
    public static final int action_container = 2131099681;
    
    public static final int action_divider = 2131099682;
    
    public static final int action_image = 2131099683;
    
    public static final int action_text = 2131099684;
    
    public static final int actions = 2131099685;
    
    public static final int adjust_height = 2131099686;
    
    public static final int adjust_width = 2131099687;
    
    public static final int all = 2131099688;
    
    public static final int async = 2131099689;
    
    public static final int auto = 2131099690;
    
    public static final int blocking = 2131099691;
    
    public static final int bottom = 2131099692;
    
    public static final int browser_actions_header_text = 2131099693;
    
    public static final int browser_actions_menu_item_icon = 2131099694;
    
    public static final int browser_actions_menu_item_text = 2131099695;
    
    public static final int browser_actions_menu_items = 2131099696;
    
    public static final int browser_actions_menu_view = 2131099697;
    
    public static final int center = 2131099698;
    
    public static final int center_horizontal = 2131099699;
    
    public static final int center_vertical = 2131099700;
    
    public static final int chronometer = 2131099701;
    
    public static final int clip_horizontal = 2131099702;
    
    public static final int clip_vertical = 2131099703;
    
    public static final int dark = 2131099704;
    
    public static final int dialog_button = 2131099705;
    
    public static final int end = 2131099706;
    
    public static final int fill = 2131099707;
    
    public static final int fill_horizontal = 2131099708;
    
    public static final int fill_vertical = 2131099709;
    
    public static final int forever = 2131099710;
    
    public static final int icon = 2131099711;
    
    public static final int icon_group = 2131099712;
    
    public static final int icon_only = 2131099713;
    
    public static final int info = 2131099714;
    
    public static final int italic = 2131099715;
    
    public static final int left = 2131099716;
    
    public static final int light = 2131099717;
    
    public static final int line1 = 2131099718;
    
    public static final int line3 = 2131099719;
    
    public static final int none = 2131099720;
    
    public static final int normal = 2131099721;
    
    public static final int notification_background = 2131099722;
    
    public static final int notification_main_column = 2131099723;
    
    public static final int notification_main_column_container = 2131099724;
    
    public static final int right = 2131099725;
    
    public static final int right_icon = 2131099726;
    
    public static final int right_side = 2131099727;
    
    public static final int standard = 2131099728;
    
    public static final int start = 2131099729;
    
    public static final int tag_accessibility_actions = 2131099730;
    
    public static final int tag_accessibility_clickable_spans = 2131099731;
    
    public static final int tag_accessibility_heading = 2131099732;
    
    public static final int tag_accessibility_pane_title = 2131099733;
    
    public static final int tag_on_apply_window_listener = 2131099734;
    
    public static final int tag_on_receive_content_listener = 2131099735;
    
    public static final int tag_on_receive_content_mime_types = 2131099736;
    
    public static final int tag_screen_reader_focusable = 2131099737;
    
    public static final int tag_state_description = 2131099738;
    
    public static final int tag_transition_group = 2131099739;
    
    public static final int tag_unhandled_key_event_manager = 2131099740;
    
    public static final int tag_unhandled_key_listeners = 2131099741;
    
    public static final int tag_window_insets_animation_callback = 2131099742;
    
    public static final int text = 2131099743;
    
    public static final int text2 = 2131099744;
    
    public static final int time = 2131099745;
    
    public static final int title = 2131099746;
    
    public static final int top = 2131099747;
    
    public static final int unitySurfaceView = 2131099748;
    
    public static final int view_tree_lifecycle_owner = 2131099749;
    
    public static final int wide = 2131099750;
  }
  
  public static final class integer {
    public static final int google_play_services_version = 2131165184;
    
    public static final int status_bar_notification_info_maxnum = 2131165185;
  }
  
  public static final class layout {
    public static final int browser_actions_context_menu_page = 2131230720;
    
    public static final int browser_actions_context_menu_row = 2131230721;
    
    public static final int custom_dialog = 2131230722;
    
    public static final int notification_action = 2131230723;
    
    public static final int notification_action_tombstone = 2131230724;
    
    public static final int notification_template_custom_big = 2131230725;
    
    public static final int notification_template_icon_group = 2131230726;
    
    public static final int notification_template_part_chronometer = 2131230727;
    
    public static final int notification_template_part_time = 2131230728;
  }
  
  public static final class mipmap {
    public static final int app_icon = 2131296256;
    
    public static final int app_icon_round = 2131296257;
  }
  
  public static final class string {
    public static final int FreeformWindowOrientation_landscape = 2131361792;
    
    public static final int FreeformWindowOrientation_portrait = 2131361793;
    
    public static final int FreeformWindowSize_maximize = 2131361794;
    
    public static final int FreeformWindowSize_phone = 2131361795;
    
    public static final int FreeformWindowSize_tablet = 2131361796;
    
    public static final int androidx_startup = 2131361797;
    
    public static final int app_name = 2131361798;
    
    public static final int common_google_play_services_enable_button = 2131361799;
    
    public static final int common_google_play_services_enable_text = 2131361800;
    
    public static final int common_google_play_services_enable_title = 2131361801;
    
    public static final int common_google_play_services_install_button = 2131361802;
    
    public static final int common_google_play_services_install_text = 2131361803;
    
    public static final int common_google_play_services_install_title = 2131361804;
    
    public static final int common_google_play_services_notification_channel_name = 2131361805;
    
    public static final int common_google_play_services_notification_ticker = 2131361806;
    
    public static final int common_google_play_services_unknown_issue = 2131361807;
    
    public static final int common_google_play_services_unsupported_text = 2131361808;
    
    public static final int common_google_play_services_update_button = 2131361809;
    
    public static final int common_google_play_services_update_text = 2131361810;
    
    public static final int common_google_play_services_update_title = 2131361811;
    
    public static final int common_google_play_services_updating_text = 2131361812;
    
    public static final int common_google_play_services_wear_update_text = 2131361813;
    
    public static final int common_open_on_phone = 2131361814;
    
    public static final int common_signin_button_text = 2131361815;
    
    public static final int common_signin_button_text_long = 2131361816;
    
    public static final int copy_toast_msg = 2131361817;
    
    public static final int fallback_menu_item_copy_link = 2131361818;
    
    public static final int fallback_menu_item_open_in_browser = 2131361819;
    
    public static final int fallback_menu_item_share_link = 2131361820;
    
    public static final int game_view_content_description = 2131361821;
    
    public static final int offline_notification_text = 2131361822;
    
    public static final int offline_notification_title = 2131361823;
    
    public static final int offline_opt_in_confirm = 2131361824;
    
    public static final int offline_opt_in_confirmation = 2131361825;
    
    public static final int offline_opt_in_decline = 2131361826;
    
    public static final int offline_opt_in_message = 2131361827;
    
    public static final int offline_opt_in_title = 2131361828;
    
    public static final int s1 = 2131361829;
    
    public static final int s2 = 2131361830;
    
    public static final int s3 = 2131361831;
    
    public static final int s4 = 2131361832;
    
    public static final int s5 = 2131361833;
    
    public static final int s6 = 2131361834;
    
    public static final int s7 = 2131361835;
    
    public static final int status_bar_notification_info_overflow = 2131361836;
  }
  
  public static final class style {
    public static final int BaseUnityTheme = 2131427328;
    
    public static final int TextAppearance_Compat_Notification = 2131427329;
    
    public static final int TextAppearance_Compat_Notification_Info = 2131427330;
    
    public static final int TextAppearance_Compat_Notification_Line2 = 2131427331;
    
    public static final int TextAppearance_Compat_Notification_Time = 2131427332;
    
    public static final int TextAppearance_Compat_Notification_Title = 2131427333;
    
    public static final int Theme_IAPTheme = 2131427334;
    
    public static final int UnityThemeSelector = 2131427335;
    
    public static final int UnityThemeSelector_Translucent = 2131427336;
    
    public static final int Widget_Compat_NotificationActionContainer = 2131427337;
    
    public static final int Widget_Compat_NotificationActionText = 2131427338;
    
    public static final int Widget_Support_CoordinatorLayout = 2131427339;
  }
  
  public static final class styleable {
    public static final int[] AdsAttrs = new int[] { 2130771968, 2130771969, 2130771970 };
    
    public static final int AdsAttrs_adSize = 0;
    
    public static final int AdsAttrs_adSizes = 1;
    
    public static final int AdsAttrs_adUnitId = 2;
    
    public static final int[] Capability = new int[] { 2130771997, 2130771999 };
    
    public static final int Capability_queryPatterns = 0;
    
    public static final int Capability_shortcutMatchRequired = 1;
    
    public static final int[] ColorStateListItem = new int[] { 16843173, 16843551, 2130771971 };
    
    public static final int ColorStateListItem_alpha = 2;
    
    public static final int ColorStateListItem_android_alpha = 1;
    
    public static final int ColorStateListItem_android_color = 0;
    
    public static final int[] CoordinatorLayout = new int[] { 2130771989, 2130772000 };
    
    public static final int[] CoordinatorLayout_Layout = new int[] { 16842931, 2130771990, 2130771991, 2130771992, 2130771993, 2130771994, 2130771995 };
    
    public static final int CoordinatorLayout_Layout_android_layout_gravity = 0;
    
    public static final int CoordinatorLayout_Layout_layout_anchor = 1;
    
    public static final int CoordinatorLayout_Layout_layout_anchorGravity = 2;
    
    public static final int CoordinatorLayout_Layout_layout_behavior = 3;
    
    public static final int CoordinatorLayout_Layout_layout_dodgeInsetEdges = 4;
    
    public static final int CoordinatorLayout_Layout_layout_insetEdge = 5;
    
    public static final int CoordinatorLayout_Layout_layout_keyline = 6;
    
    public static final int CoordinatorLayout_keylines = 0;
    
    public static final int CoordinatorLayout_statusBarBackground = 1;
    
    public static final int[] FontFamily = new int[] { 2130771977, 2130771978, 2130771979, 2130771980, 2130771981, 2130771982, 2130771983 };
    
    public static final int[] FontFamilyFont = new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130771976, 2130771984, 2130771985, 2130771986, 2130772001 };
    
    public static final int FontFamilyFont_android_font = 0;
    
    public static final int FontFamilyFont_android_fontStyle = 2;
    
    public static final int FontFamilyFont_android_fontVariationSettings = 4;
    
    public static final int FontFamilyFont_android_fontWeight = 1;
    
    public static final int FontFamilyFont_android_ttcIndex = 3;
    
    public static final int FontFamilyFont_font = 5;
    
    public static final int FontFamilyFont_fontStyle = 6;
    
    public static final int FontFamilyFont_fontVariationSettings = 7;
    
    public static final int FontFamilyFont_fontWeight = 8;
    
    public static final int FontFamilyFont_ttcIndex = 9;
    
    public static final int FontFamily_fontProviderAuthority = 0;
    
    public static final int FontFamily_fontProviderCerts = 1;
    
    public static final int FontFamily_fontProviderFetchStrategy = 2;
    
    public static final int FontFamily_fontProviderFetchTimeout = 3;
    
    public static final int FontFamily_fontProviderPackage = 4;
    
    public static final int FontFamily_fontProviderQuery = 5;
    
    public static final int FontFamily_fontProviderSystemFontFamily = 6;
    
    public static final int[] GradientColor = new int[] { 
        16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 
        16844050, 16844051 };
    
    public static final int[] GradientColorItem = new int[] { 16843173, 16844052 };
    
    public static final int GradientColorItem_android_color = 0;
    
    public static final int GradientColorItem_android_offset = 1;
    
    public static final int GradientColor_android_centerColor = 7;
    
    public static final int GradientColor_android_centerX = 3;
    
    public static final int GradientColor_android_centerY = 4;
    
    public static final int GradientColor_android_endColor = 1;
    
    public static final int GradientColor_android_endX = 10;
    
    public static final int GradientColor_android_endY = 11;
    
    public static final int GradientColor_android_gradientRadius = 5;
    
    public static final int GradientColor_android_startColor = 0;
    
    public static final int GradientColor_android_startX = 8;
    
    public static final int GradientColor_android_startY = 9;
    
    public static final int GradientColor_android_tileMode = 6;
    
    public static final int GradientColor_android_type = 2;
    
    public static final int[] LoadingImageView = new int[] { 2130771973, 2130771987, 2130771988 };
    
    public static final int LoadingImageView_circleCrop = 0;
    
    public static final int LoadingImageView_imageAspectRatio = 1;
    
    public static final int LoadingImageView_imageAspectRatioAdjust = 2;
    
    public static final int[] SignInButton = new int[] { 2130771972, 2130771974, 2130771998 };
    
    public static final int SignInButton_buttonSize = 0;
    
    public static final int SignInButton_colorScheme = 1;
    
    public static final int SignInButton_scopeUris = 2;
  }
  
  public static final class xml {
    public static final int image_share_filepaths = 2131558400;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Doctor Game-dex2jar.jar!\com\gmrs\car\parking\driver\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */